--[[修改说明：
1. 2026-07-28 新建：SH2 治疗系统 VR 改造主模块
   - spawn/despawn 表演道具（health_drink / syringe）到指定手
   - 消费 4 个 edge 信号：heal_spawn_left_edge / heal_spawn_right_edge
     / heal_despawn_left_edge / heal_despawn_right_edge
   - 分手机制：左右手独立 spawn/despawn，互不干扰
   - 不实现 prop 隐藏（由 pawn.lua doHideBodyMesh 统一处理）
   - 偏移管理：手动从 attachments_parameters.json 读取（attachments 系统无法自动匹配 spawn 组件）
     health_drink 用左手专用条目 heal_health_drink_left，syringe 用现有右手条目 ItemBase_BP_C_Syringe_03_A
   - 不实现"先 despawn"逻辑（由 attachments 系统自动处理同手冲突）
   - 参考 plans/sh2_heal_system_design.md
2. 2026-07-28 修复：表演道具生成后看不见
   - 根因：attachments grip update 在 leftAttachment/rightAttachment 为 nil 时会
     detachGripAttachments，把刚 attach 的 heal prop 立刻拆掉（漂到远处/原点）
   - 对齐 pistol_reload：on_grip_update_merge 每帧认领该手 + on_init_attachment 重写偏移
   - 对齐 shotgun_reload：attach 后 SnapToTarget(2) 再应用 JSON 偏移（KeepRelative 会留错位）
3. 2026-07-28 修复：右手针剂应挤掉枪，但枪还在且歪
   - 根因：grip merge 把枪 detach 回 origin 后，main.lua 瞄准同步仍把武器 Root
     每帧对齐到当前右手附着（已是针剂），枪 mesh 可见+位姿错乱
   - 针剂占用右手期间隐藏装备武器 mesh；despawn 后恢复（main 同步侧同步跳过）
4. 2026-07-28 修复：Attachments 调偏移无效 / 松手回弹
   - 固定表演 id：heal_health_drink_left / heal_syringe_right（与 pistol_mag 同模式）
   - 优先读 configui，持有期间每帧重写
   - 持有时调 Actor_* 滑条会镜像进 heal_*，避免松手被 tick 打回
5. 2026-07-29 修复：左手药水手势仍为 open_left
   - 根因：spawn 组件派生 id=Actor_HealthDrink_01_B（animation=generic），未命中 heal_*
   - 底层 attachments 支持 options.attachmentId；此处传入 heal_* 固定 id
6. 2026-07-30 新增：despawn 时先垂直掉落再消失（复用 reload_tools + follow provider）
   - 需求：health_drink / syringe 收到 despawn 信号后，必须先垂直掉落再销毁
   - 复用：reload_tools.new_drop_state / get_component_world_location / get_drop_scene_component
           / start_fall / tick_fall（与 pistol mag release 同源，不重复造轮子）
   - 移动补偿：follow_provider 追踪「手柄」水平位置（heal 道具挂手柄，非枪体），
     tick_fall 据此做相对运动，走动时道具跟手水平移动、垂直自由下坠
   - 参数对齐手枪：duration=0.25s / distance=120cm
   - 右手针剂：掉落期间持续藏枪（on_tick 检查 right_drop.active），on_finish 才恢复枪可见，
     避免下坠针剂与恢复的枪穿模
   - 状态：actor/mesh_comp 在掉落启动时移入 left_drop/right_drop，held 槽清空，
     grip merge / transform loop 不再触碰正在下坠的 comp
7. 2026-07-30 修复：喝药半握拳偶发跳成 open_left
   - 根因：attachments grip animation 短暂丢失时 hands 回落空手 open_*
   - spawn 成功后 hands.setHoldingAttachment 强制 drink_potion / inject_syringe；
     despawn/清理时清空，优先于 getCurrentGripAnimation
]]--

local uevrUtils = require("libs/uevr_utils")
local attachments = require("libs/attachments")
local controllers = require("libs/controllers")
local configui = require("libs/configui")
local reload_tools = require("libs/reload_tools")
local hands = require("libs/hands")
local vr_globals = require("UEVR_00_init_globals")

local M = {}

-- 持有表演道具期间强制手势，避免 attachments grip animation 短暂丢失时跳成 open_*
local PROP_HAND_ANIMATIONS = {
    health_drink = "drink_potion",
    syringe      = "inject_syringe",
}

local function set_heal_hand_animation(hand, prop_type_or_nil)
    local handed = (hand == "left") and Handed.Left or Handed.Right
    local anim = nil
    if prop_type_or_nil ~= nil then
        anim = PROP_HAND_ANIMATIONS[prop_type_or_nil]
    end
    pcall(function()
        hands.setHoldingAttachment(handed, anim)
    end)
end

-- 表演道具 StaticMesh 资源路径（从 SDK UE4SS_ObjectDump.txt 确认）
local MESH_PATHS = {
    health_drink = "/Game/Game/Art/Items/HealthDrink/HealthDrink_01_B.HealthDrink_01_B",
    syringe      = "/Game/Game/Art/Items/Syringe/Syringe_03_C.Syringe_03_C",  -- Syringe_03_A 无独立 mesh，用 _03_C 占位；待 diagnose 反查确认
}

-- 固定表演偏移 id（对齐 pistol_mag）：UI/JSON 调这两条
-- spawn 后 attachments 派生 id 仍是 Actor_*；持有时若去调 Actor_* 滑条会跟着动，
-- 但松手后 tick 用 heal_* 盖回去 → 表现为「松手回弹」。因此双向同步 heal_* ↔ Actor_*。
local PROP_ATTACHMENT_IDS = {
    health_drink = "heal_health_drink_left",
    syringe      = "heal_syringe_right",
}

local PROP_CONFIG_PREFIX = {
    health_drink = "uevr_attachments_heal_health_drink_left_",
    syringe      = "uevr_attachments_heal_syringe_right_",
}

-- spawn 组件 outer+mesh 派生 id（attachments UI 持有时高亮的条目）
local PROP_DERIVED_ACTOR_IDS = {
    health_drink = "Actor_HealthDrink_01_B",
    syringe      = "Actor_Syringe_03_C",
}

-- 与 pistol magAttachOptions / shotgun shellAttachOptions 同源：关闭 attachments 默认可见性改写
-- attachmentId：spawn 出的 Actor_* 组件强制走 heal_* 固定条目（含 drink_potion / inject_syringe）
local function make_prop_attach_options(prop_type)
    return {
        detachFromOriginOnGrip = true,
        maintainWorldPositionOnDetachFromOrigin = false,
        detachFromParentOnRelease = true,
        maintainWorldPositionOnDetachFromParent = false,
        reattachToOriginOnRelease = false,
        restoreTransformToOriginOnReattach = false,
        useZeroTransformOnReattach = false,
        allowChildVisibilityHandling = false,
        allowChildHiddenInGameHandling = false,
        allowRenderInMainPassHandling = false,
        attachmentId = PROP_ATTACHMENT_IDS[prop_type],
    }
end

-- 掉落动画参数（对齐 pistol_reload DROP_DURATION / DROP_DISTANCE）
-- despawn 信号触发后先垂直掉落再销毁，复用 reload_tools.start_fall / tick_fall
local HEAL_FALL_DURATION = 0.25   -- 秒
local HEAL_FALL_DISTANCE = 120.0  -- cm

-- 状态：分手独立管理
M._state = {
    left_actor    = nil,
    left_mesh_comp = nil,
    left_prop_type = nil,
    right_actor   = nil,
    right_mesh_comp = nil,
    right_prop_type = nil,
    heal_active   = false,
    -- 掉落动画状态（despawn 时先垂直掉落再销毁，复用 reload_tools）
    left_drop  = reload_tools.new_drop_state(),
    right_drop = reload_tools.new_drop_state(),
}

local function print_log(msg, level)
    local lvl = level or 4  -- Info
    pcall(function() uevrUtils.print("[HEAL] " .. tostring(msg), lvl) end)
end

-- 加载 StaticMesh 资源（find_required_object 优先，回退 find_instance_of）
-- @param mesh_path string 不带 "StaticMesh " 前缀的资源路径
-- @return UObject|nil
local function load_static_mesh(mesh_path)
    local mesh = nil
    pcall(function()
        mesh = uevrUtils.find_required_object("StaticMesh " .. mesh_path)
    end)
    if mesh == nil then
        pcall(function()
            mesh = uevrUtils.find_instance_of("Class /Script/Engine.StaticMesh", mesh_path)
        end)
    end
    if mesh == nil then
        print_log("load_static_mesh failed: " .. tostring(mesh_path), 3)  -- Warn
    end
    return mesh
end

-- 读取表演偏移：优先 Attachments Config UI（configui），回退 JSON（对齐 pistol load_pistol_mag_params）
-- @param prop_type "health_drink" | "syringe"
-- @return table {location, rotation, scale}
local function load_prop_params(prop_type)
    local attachment_id = PROP_ATTACHMENT_IDS[prop_type]
    local prefix = PROP_CONFIG_PREFIX[prop_type]
    if prefix ~= nil then
        local loc = configui.getValue(prefix .. "position")
        local rot = configui.getValue(prefix .. "rotation")
        local scale = configui.getValue(prefix .. "scale")
        if loc ~= nil and rot ~= nil then
            return {
                location = loc,
                rotation = rot,
                scale = scale or { 1.0, 1.0, 1.0 },
            }
        end
    end

    local defaults = {
        location = { 0.0, 0.0, 0.0 },
        rotation = { 0.0, 0.0, 0.0 },
        scale = { 1.0, 1.0, 1.0 },
    }
    if attachment_id == nil then
        return defaults
    end
    pcall(function()
        local params = json.load_file("attachments_parameters.json")
        if params ~= nil and params.attachmentOffsets ~= nil then
            for i = 1, #params.attachmentOffsets do
                local entry = params.attachmentOffsets[i]
                if entry ~= nil and entry.id == attachment_id then
                    defaults = {
                        location = entry.location or defaults.location,
                        rotation = entry.rotation or defaults.rotation,
                        scale = entry.scale or defaults.scale,
                    }
                    break
                end
            end
        end
    end)
    return defaults
end

-- 应用偏移（对齐 pistol apply_pistol_mag_transform）
-- @param comp StaticMeshComponent
-- @param prop_type "health_drink" | "syringe"
local function apply_prop_transform(comp, prop_type)
    if comp == nil or prop_type == nil then
        return
    end
    local params = load_prop_params(prop_type)
    local loc = params.location or { 0, 0, 0 }
    local rot = params.rotation or { 0, 0, 0 }
    local scale = params.scale or { 1, 1, 1 }
    pcall(function()
        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(loc))
        uevrUtils.set_component_relative_rotation(comp, uevrUtils.rotator(rot))
        uevrUtils.set_component_relative_scale(comp, uevrUtils.vector(scale))
    end)
end

-- 把 loc/rot/scale 写入 attachments 内存条目（让 initAttachment 的 Actor_* 匹配不再盖回旧值）
local function persist_offset_id(id, loc, rot, scale)
    if id == nil then
        return
    end
    pcall(function()
        local vloc = loc ~= nil and uevrUtils.vector(loc) or nil
        -- setAttachmentOffset 的 rotation 按 .X/.Y/.Z 存，用 vector 传 pitch/yaw/roll
        local vrot = nil
        if rot ~= nil then
            local r = uevrUtils.rotator(rot)
            if r ~= nil then
                vrot = uevrUtils.vector(r.Pitch or r.X or 0, r.Yaw or r.Y or 0, r.Roll or r.Z or 0)
            else
                vrot = uevrUtils.vector(rot)
            end
        end
        if vloc ~= nil or vrot ~= nil then
            attachments.setAttachmentOffset(id, vloc, vrot)
        end
    end)
    -- scale 无专用 API：直接改 configui（若有）即可；tick/load 会读到
    if scale ~= nil then
        pcall(function()
            configui.setValue("uevr_attachments_" .. id .. "_scale", scale, true)
        end)
    end
end

local function get_held_comp_for_prop_type(prop_type)
    local mod = rawget(_G, "__sh2_heal_module") or M
    local st = mod ~= nil and mod._state or nil
    if st == nil then
        return nil
    end
    if prop_type == "health_drink" then
        return uevrUtils.getValid(st.left_mesh_comp)
    elseif prop_type == "syringe" then
        return uevrUtils.getValid(st.right_mesh_comp)
    end
    return nil
end

-- 以 heal_* 为源，同步到 Actor_*（避免松手后 initAttachment/UI 用旧 Actor_* 抢回去）
local function sync_heal_to_derived(prop_type, loc, rot, scale)
    local heal_id = PROP_ATTACHMENT_IDS[prop_type]
    local actor_id = PROP_DERIVED_ACTOR_IDS[prop_type]
    local actor_prefix = actor_id ~= nil and ("uevr_attachments_" .. actor_id .. "_") or nil
    persist_offset_id(heal_id, loc, rot, scale)
    persist_offset_id(actor_id, loc, rot, scale)
    if actor_prefix ~= nil then
        if loc ~= nil then
            pcall(function() configui.setValue(actor_prefix .. "position", loc, true) end)
        end
        if rot ~= nil then
            pcall(function() configui.setValue(actor_prefix .. "rotation", rot, true) end)
        end
        if scale ~= nil then
            pcall(function() configui.setValue(actor_prefix .. "scale", scale, true) end)
        end
    end
end

-- 安装 UI 回调：调 heal_* 或持有时调 Actor_*，都落到 heal_* 并立刻套到手上道具
local function install_offset_ui_hooks()
    if rawget(_G, "__sh2_heal_offset_ui_hooks") then
        return
    end
    for prop_type, prefix in pairs(PROP_CONFIG_PREFIX) do
        local actor_id = PROP_DERIVED_ACTOR_IDS[prop_type]
        local actor_prefix = "uevr_attachments_" .. tostring(actor_id) .. "_"

        local function apply_from_ui(loc, rot, scale)
            local comp = get_held_comp_for_prop_type(prop_type)
            sync_heal_to_derived(prop_type, loc, rot, scale)
            if comp ~= nil then
                pcall(function()
                    if loc ~= nil then
                        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(loc))
                    end
                    if rot ~= nil then
                        uevrUtils.set_component_relative_rotation(comp, uevrUtils.rotator(rot))
                    end
                    if scale ~= nil then
                        uevrUtils.set_component_relative_scale(comp, uevrUtils.vector(scale))
                    end
                end)
            end
        end

        -- 调 heal_* 条目（推荐）
        configui.onUpdate(prefix .. "position", function(value)
            apply_from_ui(value, nil, nil)
        end)
        configui.onUpdate(prefix .. "rotation", function(value)
            apply_from_ui(nil, value, nil)
        end)
        configui.onUpdate(prefix .. "scale", function(value)
            apply_from_ui(nil, nil, value)
        end)

        -- 持有时若误调了 Actor_*（面板高亮派生 id），镜像进 heal_*，松手不再被 tick 打回
        configui.onUpdate(actor_prefix .. "position", function(value)
            if get_held_comp_for_prop_type(prop_type) == nil then
                return
            end
            pcall(function() configui.setValue(prefix .. "position", value, true) end)
            apply_from_ui(value, nil, nil)
        end)
        configui.onUpdate(actor_prefix .. "rotation", function(value)
            if get_held_comp_for_prop_type(prop_type) == nil then
                return
            end
            pcall(function() configui.setValue(prefix .. "rotation", value, true) end)
            apply_from_ui(nil, value, nil)
        end)
        configui.onUpdate(actor_prefix .. "scale", function(value)
            if get_held_comp_for_prop_type(prop_type) == nil then
                return
            end
            pcall(function() configui.setValue(prefix .. "scale", value, true) end)
            apply_from_ui(nil, nil, value)
        end)
    end
    _G.__sh2_heal_offset_ui_hooks = true
    print_log("offset UI hooks installed (heal_* ↔ Actor_* sync)", 4)
end

local function resolve_hand_controller(handed)
    local mc = controllers.getController(handed)
    if mc == nil then
        pcall(function()
            controllers.createController(handed)
        end)
        mc = controllers.getController(handed)
    end
    return uevrUtils.getValid(mc)
end

local function snap_to_controller_and_offset(comp, handed, prop_type)
    if comp == nil then return end
    local mc = resolve_hand_controller(handed)
    if mc ~= nil and comp.K2_AttachTo ~= nil then
        -- EAttachLocation::SnapToTarget = 2（shotgun spawn_single_shell 同源）
        pcall(function()
            comp:K2_AttachTo(mc, uevrUtils.fname_from_string(""), 2, false)
        end)
    end
    apply_prop_transform(comp, prop_type)
end

local function is_heal_hand_comp(comp, hand)
    local key = (hand == "left") and "left_mesh_comp" or "right_mesh_comp"
    local mine = uevrUtils.getValid(M._state[key])
    local other = uevrUtils.getValid(comp)
    return mine ~= nil and other ~= nil and mine == other
end

-- 右手针剂占用期间隐藏装备武器（detach 回 origin 后仍会被瞄准同步拽歪并可见）
local function get_equipped_weapon_mesh()
    local from_global = rawget(_G, vr_globals.KEYS.equipped_weapon)
    local weapon = uevrUtils.getValid(from_global)
    if weapon == nil then
        local pawn = uevrUtils.get_local_pawn()
        weapon = uevrUtils.getValid(pawn, {"Mesh", "AnimScriptInstance", "WeaponManageCmbSubcomp", "EquippedWeapon"})
    end
    return uevrUtils.getValid(weapon, {"Mesh"}), weapon
end

local function set_equipped_weapon_hidden(hidden)
    local mesh, weapon = get_equipped_weapon_mesh()
    pcall(function()
        if mesh ~= nil then
            if mesh.SetVisibility ~= nil then
                mesh:SetVisibility(not hidden, true)
            end
            if mesh.SetHiddenInGame ~= nil then
                mesh:SetHiddenInGame(hidden, true)
            end
            pcall(function()
                mesh:call("SetRenderInMainPass", not hidden)
            end)
        end
        if weapon ~= nil and weapon.SetActorHiddenInGame ~= nil then
            weapon:SetActorHiddenInGame(hidden)
        end
    end)
end

-- B 类 grip update merge：认领治疗表演道具，防止 interval 在 attachment=nil 时 detach 掉
-- 对齐 pistol_reload.merge_mag_into_grip_update / shotgun shell merge
-- 右手有针剂时覆盖武器附着（设计意图：挤掉枪）；枪的可见性由 set_equipped_weapon_hidden 管
function M.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
    local left_comp = uevrUtils.getValid(M._state.left_mesh_comp)
    if left_comp ~= nil then
        local mc = resolve_hand_controller(Handed.Left)
        if mc ~= nil then
            lA, lM, lS, oL = left_comp, mc, nil, make_prop_attach_options(M._state.left_prop_type or "health_drink")
        end
    end
    local right_comp = uevrUtils.getValid(M._state.right_mesh_comp)
    if right_comp ~= nil then
        local mc = resolve_hand_controller(Handed.Right)
        if mc ~= nil then
            rA, rM, rS, oR = right_comp, mc, nil, make_prop_attach_options(M._state.right_prop_type or "syringe")
        end
    end
    return rA, rM, rS, lA, lM, lS, oR, oL
end

-- B 类 initAttachment：对齐 pistol on_init_attachment → apply_pistol_mag_transform
function M.on_init_attachment(attachment, gripHand, options)
    if gripHand == Handed.Left and is_heal_hand_comp(attachment, "left") then
        apply_prop_transform(attachment, M._state.left_prop_type or "health_drink")
    elseif gripHand == Handed.Right and is_heal_hand_comp(attachment, "right") then
        apply_prop_transform(attachment, M._state.right_prop_type or "syringe")
    end
end

-- spawn 表演道具到指定手（供 on_tick 消费 spawn 信号时调用）
-- @param hand "left" 或 "right"
-- @param prop_type "health_drink" 或 "syringe"
-- @return boolean 成功与否
function M.spawn_prop_on_hand(hand, prop_type)
    if hand ~= "left" and hand ~= "right" then
        print_log("spawn_prop_on_hand: invalid hand=" .. tostring(hand), 3)
        return false
    end
    if MESH_PATHS[prop_type] == nil then
        print_log("spawn_prop_on_hand: invalid prop_type=" .. tostring(prop_type), 3)
        return false
    end

    -- 2026-07-30 审计修复 A：该手正在掉落时拒绝 spawn（窗口仅 0.25s）
    -- 从根上消除「掉落中再 spawn → 再 despawn 被 _despawn_prop 重入守卫吞掉」竞态：
    -- 掉落期间不生成新道具，掉落结束 held 槽仍为 nil，finish_heal_fall 走正常清理路径
    local drop = (hand == "left") and M._state.left_drop or M._state.right_drop
    if drop.active then
        print_log("spawn_prop_on_hand: " .. hand .. " drop in progress, reject spawn", 4)
        return false
    end

    -- 1. 加载 StaticMesh 资源
    local mesh_asset = load_static_mesh(MESH_PATHS[prop_type])
    if mesh_asset == nil then
        return false
    end

    -- 2. 获取 motion controller 位置/旋转作为 spawn 起点（与 shotgun / attachToController 同源）
    local handed = (hand == "left") and Handed.Left or Handed.Right
    local mc = resolve_hand_controller(handed)
    local spawn_loc = nil
    local spawn_rot = nil
    if mc ~= nil then
        spawn_loc = reload_tools.get_component_world_location(mc)
            or controllers.getControllerLocation(handed)
        spawn_rot = reload_tools.get_component_world_rotation(mc)
            or controllers.getControllerRotation(handed)
    else
        spawn_loc = controllers.getControllerLocation(handed)
        spawn_rot = controllers.getControllerRotation(handed)
    end
    if spawn_loc == nil or spawn_rot == nil then
        print_log("spawn_prop_on_hand: controller location/rotation nil for hand=" .. hand, 3)
        return false
    end

    -- 3. spawn 通用 Actor（参考 shotgun_reload.lua spawn_single_shell 模式）
    local actor = nil
    pcall(function()
        actor = uevrUtils.spawn_actor(
            reload_tools.make_spawn_transform(spawn_loc, spawn_rot), 1, nil)
    end)
    if actor == nil then
        print_log("spawn_prop_on_hand: spawn_actor failed", 3)
        return false
    end

    -- 4. 创建 StaticMeshComponent 并设置 mesh
    local identity_xf = uevrUtils.get_transform()
    local mesh_comp = nil
    pcall(function()
        mesh_comp = uevrUtils.createStaticMeshComponent(mesh_asset, {
            manualAttachment = true,
            relativeTransform = identity_xf,
            deferredFinish = false,
            parent = actor,
        })
    end)
    if mesh_comp == nil then
        pcall(function() uevrUtils.destroy_actor(actor) end)
        print_log("spawn_prop_on_hand: createStaticMeshComponent failed", 3)
        return false
    end

    -- 5. 设置根组件 + Movable
    pcall(function()
        if mesh_comp.SetMobility ~= nil then
            mesh_comp:SetMobility(2)  -- Movable
        end
        if actor.K2_SetRootComponent ~= nil then
            actor:K2_SetRootComponent(mesh_comp)
        end
    end)

    -- 6. 先写入 state，再 attach：attachToMesh → initAttachment 可能立刻回调 on_init_attachment
    if hand == "left" then
        M._state.left_actor = actor
        M._state.left_mesh_comp = mesh_comp
        M._state.left_prop_type = prop_type
        pcall(function() _G[vr_globals.KEYS.heal_left_prop_active] = true end)
    else
        M._state.right_actor = actor
        M._state.right_mesh_comp = mesh_comp
        M._state.right_prop_type = prop_type
        pcall(function() _G[vr_globals.KEYS.heal_right_prop_active] = true end)
        -- 针剂占用右手：先卸枪附着并隐藏，避免 detach 回 origin 后仍可见/被瞄准同步拽歪
        pcall(function() attachments.detachGripAttachments(Handed.Right) end)
        set_equipped_weapon_hidden(true)
    end

    -- 7. attachToController + SnapToTarget + JSON 偏移（shotgun spawn_single_shell 同源）
    --    attachmentId 强制走 heal_* 条目，避免 Actor_* 派生 id 落到 generic / 无动画
    local attach_ok, attach_err = pcall(function()
        attachments.attachToController(mesh_comp, handed, make_prop_attach_options(prop_type))
    end)
    if not attach_ok then
        print_log("spawn_prop_on_hand: attachToController failed: " .. tostring(attach_err), 3)
        if hand == "left" then
            M._state.left_actor = nil
            M._state.left_mesh_comp = nil
            M._state.left_prop_type = nil
            pcall(function() _G[vr_globals.KEYS.heal_left_prop_active] = false end)
            set_heal_hand_animation("left", nil)
        else
            M._state.right_actor = nil
            M._state.right_mesh_comp = nil
            M._state.right_prop_type = nil
            pcall(function() _G[vr_globals.KEYS.heal_right_prop_active] = false end)
            set_heal_hand_animation("right", nil)
            set_equipped_weapon_hidden(false)
        end
        pcall(function() uevrUtils.destroy_actor(actor) end)
        return false
    end
    snap_to_controller_and_offset(mesh_comp, handed, prop_type)

    -- 8. 强制手势（优先于 getCurrentGripAnimation，防止短暂丢失跳成 open_*）
    set_heal_hand_animation(hand, prop_type)

    -- 9. 发布治疗状态
    if not M._state.heal_active then
        M._state.heal_active = true
        pcall(function() _G[vr_globals.KEYS.heal_active] = true end)
    end

    print_log("spawn_prop_on_hand: " .. prop_type .. " -> " .. hand .. " OK", 4)
    return true
end

-- 构造掉落跟随提供器：每帧返回指定手柄的水平世界坐标
-- 用于 reload_tools.tick_fall 的相对运动补偿：道具 x/y 跟随手柄移动，z 自由下坠
-- 对齐 pistol make_slide_follow_provider「追踪掉落源」模式（pistol 追踪枪 socket，heal 追踪手柄）
local function make_heal_follow_provider(hand)
    local handed = (hand == "left") and Handed.Left or Handed.Right
    local last_valid = { x = nil, y = nil }
    return function()
        local mc = resolve_hand_controller(handed)
        if mc == nil then
            -- 回退缓存，消除帧间抖动（手柄偶发读空时保持上一帧位置）
            if last_valid.x == nil then
                return nil
            end
            return { sx = last_valid.x, sy = last_valid.y }
        end
        local loc = reload_tools.get_component_world_location(mc)
        if loc == nil then
            if last_valid.x == nil then
                return nil
            end
            return { sx = last_valid.x, sy = last_valid.y }
        end
        last_valid.x = loc.X
        last_valid.y = loc.Y
        return { sx = loc.X, sy = loc.Y }
    end
end

-- 掉落动画完成回调（on_finish）：销毁 actor + 清理状态 + 右手恢复枪可见
-- 由 reload_tools.tick_fall 在 done 时触发，不再走外部 tick loop 的 done 分支
-- 2026-07-30 审计修复：
--   1. 调 reload_tools.cancel(drop) 对齐 pistol finish_mag_drop_visual（清 follow_provider/at_rest 等，
--      tick_fall 已清 active/on_finish，cancel 补齐其余字段，防御未来 tick_fall 内部变化）
--   2. 「掉落期间同手再 spawn」守卫：若掉落期间该手被新 spawn 占用（held 槽非空），
--      只销毁旧 actor + 清 drop，不清 prop_type/prop_active/枪可见（新道具拥有这些状态）
local function finish_heal_fall(hand)
    local drop = (hand == "left") and M._state.left_drop or M._state.right_drop
    local actor_key = (hand == "left") and "left_actor" or "right_actor"
    local actor = drop.actor
    if actor ~= nil then
        pcall(function() actor:SetHiddenInGame(true, true) end)
        pcall(function() uevrUtils.destroy_actor(actor) end)
    end
    drop.actor = nil
    drop.root = nil
    reload_tools.cancel(drop)

    -- 掉落期间同手再 spawn 检测：held 槽被新道具占用则不清状态（避免陈旧回调污染新状态）
    if M._state[actor_key] ~= nil then
        print_log("heal fall finished: " .. hand .. " re-spawned during fall, skip state clear", 4)
        return
    end

    if hand == "left" then
        M._state.left_prop_type = nil
        pcall(function() _G[vr_globals.KEYS.heal_left_prop_active] = false end)
        set_heal_hand_animation("left", nil)
    else
        M._state.right_prop_type = nil
        pcall(function() _G[vr_globals.KEYS.heal_right_prop_active] = false end)
        set_heal_hand_animation("right", nil)
        -- 针剂掉落结束：恢复装备武器可见，下一帧 grip update 会重新挂回右手
        set_equipped_weapon_hidden(false)
    end

    -- 两手都无道具且无掉落进行中时关闭 heal_active
    if M._state.left_actor == nil and M._state.right_actor == nil
        and not M._state.left_drop.active and not M._state.right_drop.active then
        M._state.heal_active = false
        pcall(function() _G[vr_globals.KEYS.heal_active] = false end)
    end

    print_log("heal fall finished: " .. hand, 4)
end

-- 每帧驱动治疗道具掉落动画（复用 reload_tools.tick_fall，对齐 pistol tick_mag_release_drop）
local function tick_heal_fall()
    for _, hand in ipairs({ "left", "right" }) do
        local drop = (hand == "left") and M._state.left_drop or M._state.right_drop
        if drop.active and drop.root ~= nil then
            local result = reload_tools.tick_fall(drop)
            if result ~= nil and not result.done and drop.root ~= nil then
                pcall(function()
                    drop.root:K2_SetWorldLocation(
                        uevrUtils.vector(result.x, result.y, result.z),
                        false, reusable_hit_result, false)
                end)
            end
        end
    end
end

-- 清理单手状态（无动画的兜底路径：无 actor/comp 或坐标/root 取不到时直接清理）
local function cleanup_hand_no_fall(hand)
    local actor_key = (hand == "left") and "left_actor" or "right_actor"
    local comp_key  = (hand == "left") and "left_mesh_comp" or "right_mesh_comp"
    local actor = M._state[actor_key]
    if actor ~= nil then
        pcall(function() uevrUtils.destroy_actor(actor) end)
    end
    M._state[actor_key] = nil
    M._state[comp_key] = nil
    if hand == "left" then
        M._state.left_prop_type = nil
        pcall(function() _G[vr_globals.KEYS.heal_left_prop_active] = false end)
        set_heal_hand_animation("left", nil)
    else
        M._state.right_prop_type = nil
        pcall(function() _G[vr_globals.KEYS.heal_right_prop_active] = false end)
        set_heal_hand_animation("right", nil)
        set_equipped_weapon_hidden(false)
    end
    if M._state.left_actor == nil and M._state.right_actor == nil
        and not M._state.left_drop.active and not M._state.right_drop.active then
        M._state.heal_active = false
        pcall(function() _G[vr_globals.KEYS.heal_active] = false end)
    end
end

-- despawn 指定手的表演道具（分手机制，仅清理指定手）
-- 2026-07-30：改为先垂直掉落再消失（复用 reload_tools.start_fall + follow provider）
-- @param hand "left" 或 "right"
function M._despawn_prop(hand)
    if hand ~= "left" and hand ~= "right" then
        return
    end
    local actor_key = (hand == "left") and "left_actor" or "right_actor"
    local comp_key  = (hand == "left") and "left_mesh_comp" or "right_mesh_comp"
    local drop = (hand == "left") and M._state.left_drop or M._state.right_drop

    -- 已在掉落中：忽略重复 despawn 信号
    if drop.active then
        print_log("_despawn_prop: " .. hand .. " already falling, skip", 4)
        return
    end

    local mesh_comp = M._state[comp_key]
    local actor = M._state[actor_key]

    -- 兜底：无 actor/comp 时直接清理（无动画）
    if actor == nil and mesh_comp == nil then
        cleanup_hand_no_fall(hand)
        print_log("_despawn_prop: " .. hand .. " nothing to drop, cleanup done", 4)
        return
    end

    -- 捕获当前世界坐标（手柄位置 = 掉落起点）
    local world_loc = reload_tools.get_component_world_location(mesh_comp)

    -- 分离 attachments（DetachFromParent，世界坐标会跳，随后吸回）
    if mesh_comp ~= nil then
        pcall(function() attachments.detach(mesh_comp) end)
    end
    local root = reload_tools.get_drop_scene_component(actor, mesh_comp)

    -- 兜底：取不到坐标或 root 时直接清理（无动画）
    if world_loc == nil or root == nil then
        cleanup_hand_no_fall(hand)
        print_log("_despawn_prop: " .. hand .. " loc/root nil, cleanup done", 4)
        return
    end

    -- 吸回原位（detach 后世界坐标已跳，重新对齐到掉落起点）
    pcall(function()
        root:K2_SetWorldLocation(
            uevrUtils.vector(world_loc.X, world_loc.Y, world_loc.Z),
            false, reusable_hit_result, false)
    end)

    -- 把 actor/root 移入掉落状态，清出 held 槽
    -- （grip merge / transform loop 读 held 槽，清空后不再触碰正在下坠的 comp）
    drop.actor = actor
    drop.root = root
    M._state[actor_key] = nil
    M._state[comp_key] = nil
    -- 掉落开始即松开强制手势（道具已离手）；finish/cleanup 再清一次兜底
    set_heal_hand_animation(hand, nil)

    -- 启动垂直下落（复用 reload_tools.start_fall，对齐 pistol mag release）
    -- follow_provider 追踪手柄水平位置：走动时道具跟手水平移动，垂直自由下坠
    local follow_provider = make_heal_follow_provider(hand)
    reload_tools.start_fall(drop, {
        sx = world_loc.X, sy = world_loc.Y, sz = world_loc.Z,
        duration = HEAL_FALL_DURATION,
        distance = HEAL_FALL_DISTANCE,
        on_finish = function() finish_heal_fall(hand) end,
        follow_provider = follow_provider,
    })

    print_log("_despawn_prop: " .. hand .. " fall started", 4)
end

-- on_tick：消费 4 个 edge 信号（spawn/despawn 对称，分手独立）
local function on_tick()
    -- 左手 spawn 信号 → spawn health_drink 到左手
    if rawget(_G, vr_globals.KEYS.heal_spawn_left_edge) == true then
        pcall(function() M.spawn_prop_on_hand("left", "health_drink") end)
        _G[vr_globals.KEYS.heal_spawn_left_edge] = false
    end
    -- 右手 spawn 信号 → spawn syringe 到右手
    if rawget(_G, vr_globals.KEYS.heal_spawn_right_edge) == true then
        pcall(function() M.spawn_prop_on_hand("right", "syringe") end)
        _G[vr_globals.KEYS.heal_spawn_right_edge] = false
    end
    -- 左手 despawn 信号 → 仅 despawn 左手道具
    if rawget(_G, vr_globals.KEYS.heal_despawn_left_edge) == true then
        pcall(function() M._despawn_prop("left") end)
        _G[vr_globals.KEYS.heal_despawn_left_edge] = false
    end
    -- 右手 despawn 信号 → 仅 despawn 右手道具
    if rawget(_G, vr_globals.KEYS.heal_despawn_right_edge) == true then
        pcall(function() M._despawn_prop("right") end)
        _G[vr_globals.KEYS.heal_despawn_right_edge] = false
    end

    -- 针剂仍在右手时持续藏枪（防止其他逻辑把武器又显示出来）
    -- 右手掉落进行中也保持藏枪：避免下坠针剂与恢复的枪穿模（掉落结束 on_finish 才恢复）
    if uevrUtils.getValid(M._state.right_mesh_comp) ~= nil or M._state.right_drop.active then
        set_equipped_weapon_hidden(true)
    end

    -- 持有期间每帧套用 heal_* 偏移（固定 id 与 spawn 派生 Actor_* 不同，须主动盖住；对齐 shotgun shell tick）
    -- 掉落中的 comp 已移入 left_drop/right_drop，held 槽已清空 → 此处自然跳过，不会与动画打架
    local left = uevrUtils.getValid(M._state.left_mesh_comp)
    if left ~= nil then
        apply_prop_transform(left, M._state.left_prop_type or "health_drink")
    end
    local right = uevrUtils.getValid(M._state.right_mesh_comp)
    if right ~= nil then
        apply_prop_transform(right, M._state.right_prop_type or "syringe")
    end

    -- 驱动掉落动画（despawn 信号触发的垂直下坠 + 手柄移动补偿）
    tick_heal_fall()
end

function M.init()
    -- 热重载关键：tick 必须经 _G 间接调用（参考 shotgun_reload.lua L4074-4093）
    _G.__sh2_heal_on_tick = on_tick
    _G.__sh2_heal_module = M
    install_offset_ui_hooks()

    if rawget(_G, "__sh2_heal_initialized") then
        print_log("hot-reload: rebound tick via _G", 4)
        return M
    end

    uevrUtils.registerPostEngineTickCallback(function()
        local fn = rawget(_G, "__sh2_heal_on_tick")
        if type(fn) == "function" then
            pcall(fn)
        end
    end)

    _G.__sh2_heal_initialized = true
    print_log("heal.lua initialized (spawn/despawn edge consumer ready)", 4)
    return M
end

return M
