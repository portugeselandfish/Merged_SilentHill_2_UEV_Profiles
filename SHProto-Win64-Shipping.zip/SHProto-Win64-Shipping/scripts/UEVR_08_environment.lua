local module_name = "UEVR_08_environment"
if package.loaded[module_name] ~= nil then
    return package.loaded[module_name]
end

-- UEVR_08_environment.lua
-- Runtime bridge that samples UEVR VR data (uevr.params.vr), manages timing, applies
-- haptics, and owns reset/calibration.
--
-- 关键移植点（草稿失败原因 = 用错了取数据方式）：
--   * get_pose(index, out_pos, out_rot) 是“出参”接口，out_pos/out_rot 必须是
--     Vector3f.new()/Quaternionf.new() 创建的 userdata，绝不能传普通 Lua 表，否则取不到数据。
--   * 姿态索引用 get_hmd_index / get_left_controller_index / get_right_controller_index。
--   * 按键/扳机用 is_action_active(get_action_handle(path), source)，A/B 键左右手是独立 action。
--   * 摇杆轴用 get_joystick_axis(source, out_vec2)，同样是出参。
--   * 体感用 trigger_haptic_vibration(seconds_from_now, duration, frequency, amplitude, source)。
local numerics = require("UEVR_01_numerics")
local keyboard_input = require("UEVR_02_keyboard")
local keyboard_wrapper = keyboard_input.KeyboardWrapper
local input = require("UEVR_03_KBM_input")
local gamepad = require("UEVR_04_binding")
local haptics = require("UEVR_05_haptics")
local actions = require("UEVR_06_actions")
local gestures = require("UEVR_07_gestures")
local compat = require("UEVR_00_init_globals").compat

-- UEVR SteamVR action 路径（见 uevr 源码 src/mods/vr/Bindings.cpp）。
local ACTION_PATHS = {
    trigger = "/actions/default/in/Trigger",
    grip = "/actions/default/in/Grip",
    joystick_click = "/actions/default/in/JoystickClick",
    a_button_left = "/actions/default/in/AButtonLeft",
    a_button_right = "/actions/default/in/AButtonRight",
    b_button_left = "/actions/default/in/BButtonLeft",
    b_button_right = "/actions/default/in/BButtonRight",
}

-- get_pose 出参：Vector3f/Quaternionf（PluginLoader get_pose）。
-- get_joystick_axis 出参：UEVR_Vector2f*（API.h）；优先 UEVR_Vector2f.new()。
local function new_axis_buffer()
    if UEVR_Vector2f ~= nil and type(UEVR_Vector2f.new) == "function" then
        return UEVR_Vector2f.new()
    end
    return compat.new_vector2f()
end

local pose_buffers = {
    head = { pos = compat.new_vector3f(), rot = compat.new_quaternionf() },
    left = { pos = compat.new_vector3f(), rot = compat.new_quaternionf() },
    right = { pos = compat.new_vector3f(), rot = compat.new_quaternionf() },
}
local axis_buffers = {
    left = new_axis_buffer(),
    right = new_axis_buffer(),
}

-- OpenXR 下 get_left_joystick_source() 返回 (UEVR_InputSourceHandle)Hand::LEFT，即 NULL 指针。
-- sol2 把 NULL 指针压成 Lua nil，因此左手 source 在 Lua 侧呈现为 nil；但 C++ 侧（VR.cpp）
-- 仍把 NULL 当作 Hand::LEFT 处理（is_action_active / get_joystick_axis / trigger_haptic_vibration
-- 均以 source==0 命中左手分支）。所以 OpenXR 下 nil 是合法的左手 source，不能拒。
-- 用模块级 upvalue 让 is_valid_input_source 在 OpenXR 下放行 nil。
local openxr_runtime_active = false

local function is_valid_input_source(source)
    if openxr_runtime_active then
        -- OpenXR: source 是 Hand 枚举转成的指针；LEFT=0=NULL=nil（合法），RIGHT=1=userdata。
        return true
    end
    -- OpenVR: source 是真实 VRInputValueHandle_t；nil 才是无效。
    return source ~= nil
end

local function safe_require(module_name)
    local ok, value = pcall(require, module_name)
    if ok then
        return value
    end
    return nil
end

local function new_pose()
    return {
        position = numerics.new_vector(0.0, 0.0, 0.0),
        forward = numerics.new_vector(0.0, 0.0, 1.0),
        left = numerics.new_vector(-1.0, 0.0, 0.0),
        up = numerics.new_vector(0.0, 1.0, 0.0),
        rotation = nil,
    }
end

local controller_indices_buffer = { nil, nil }

local function clear_controller_indices_buffer()
    controller_indices_buffer[1] = nil
    controller_indices_buffer[2] = nil
end

local environment = {
    updateFrequency = 1.0 / 60.0,
    numerics = numerics,
    keyboardInput = keyboard_input,
    keyboardWrapper = keyboard_wrapper,
    input = input,
    gamepad = gamepad,
    haptics = haptics,
    actions = actions,
    gestures = gestures,
    modules = {
        numerics = numerics,
        keyboard_input = keyboard_input,
        keyboard_wrapper = keyboard_wrapper,
        input = input,
        gamepad = gamepad,
        haptics = haptics,
        actions = actions,
        gestures = gestures,
    },
    vr_controller_manager = safe_require("vr/VRControllerManager"),
    vr = compat.get_vr(),
    time = {
        current = 0.0,
        delta = 0.0,
        _last_clock = nil,
        accumulator = 0.0,
    },
    state = {
        hasVrmod = false,
        isMounted = false,
        usingControllers = false,
        isOpenXR = false,
        runtimeName = "unavailable",
        handleStatus = {
            leftJoystick = false,
            rightJoystick = false,
            trigger = false,
            grip = false,
            aButton = false,
            bButton = false,
            joystickClick = false,
        },
        lastHaptic = {
            success = false,
            leftHand = false,
            duration = 0.0,
            frequency = 0.0,
            amplitude = 0.0,
            api = "not_called",
            reason = "not_called",
        },
        calibrated = false,
        standingHeight = 0.0,
        rollCenter = 0.0,
        headPose = new_pose(),
        leftTouchPose = new_pose(),
        rightTouchPose = new_pose(),
        headController = {
            standingHeight = 0.0,
        },
        leftController = numerics.new_vector(0.0, 0.0, 0.0),
        rightController = numerics.new_vector(0.0, 0.0, 0.0),
        leftTrigger = 0.0,
        rightTrigger = 0.0,
        leftGrip = 0.0,
        rightGrip = 0.0,
        a = 0.0,
        b = 0.0,
        x = 0.0,
        y = 0.0,
        leftStick = 0.0,
        rightStick = 0.0,
        leftStickAxes = { x = 0.0, y = 0.0 },
        rightStickAxes = { x = 0.0, y = 0.0 },
        controllerIndices = { 0, 0 },
    },
    handles = {
        -- input source handles (用于 is_action_active / get_joystick_axis / haptics)
        left = nil,
        right = nil,
        -- tracked device indices (用于 get_pose)
        hmd_index = nil,
        left_index = nil,
        right_index = nil,
        -- action handles
        trigger = nil,
        grip = nil,
        a_button_left = nil,
        a_button_right = nil,
        b_button_left = nil,
        b_button_right = nil,
        joystick_click = nil,
    },
    _initialized = false,
}

-- 安全调用 uevr.params.vr 上的某个函数（点式调用，无 self），失败返回 nil。
local function vr_call(vr, name, ...)
    if vr == nil or type(vr[name]) ~= "function" then
        return nil
    end
    local ok, result = pcall(vr[name], ...)
    if ok then
        return result
    end
    return nil
end

-- get_pose(index, out_pos, out_rot) 是出参式接口：必须传 Vector3f/Quaternionf userdata。
local function update_pose(vr, index, pose, buffers)
    if vr == nil or index == nil or buffers == nil then
        return pose
    end

    local pos = buffers.pos
    local rot = buffers.rot
    if pos == nil or rot == nil or type(vr.get_pose) ~= "function" then
        return pose
    end

    local ok = pcall(vr.get_pose, index, pos, rot)
    if not ok then
        return pose
    end

    numerics.copy_vector(pose.position, pos)

    -- 复制成独立小表，避免 head/left/right 共用 userdata 时互相覆盖。
    local quaternion = {
        x = rot.x or 0.0,
        y = rot.y or 0.0,
        z = rot.z or 0.0,
        w = rot.w or 1.0,
    }
    pose.rotation = quaternion
    numerics.quaternion_to_axes(quaternion, pose)
    return pose
end

-- is_action_active(action, source)：OpenXR 分支把 source 当作 Hand 枚举（VR.cpp）。
local function action_active(vr, action_handle, source_handle)
    if vr == nil
        or not compat.is_valid_handle(action_handle)
        or not is_valid_input_source(source_handle)
        or type(vr.is_action_active) ~= "function"
    then
        return 0.0
    end

    local ok, value = pcall(vr.is_action_active, action_handle, source_handle)
    if ok and value == true then
        return 1.0
    end
    return 0.0
end

local function update_axis(out_axis, source)
    out_axis.x = (source and source.x) or 0.0
    out_axis.y = (source and source.y) or 0.0
    return out_axis
end

local function copy_controller_position(target, pose)
    if target ~= nil and pose ~= nil and pose.position ~= nil then
        numerics.copy_vector(target, pose.position)
    end
end

function environment:refreshHandles()
    self.vr = compat.get_vr() or self.vr
    self.state.hasVrmod = self.vr ~= nil
    if self.vr == nil then
        self.state.runtimeName = "unavailable"
        self.state.isOpenXR = false
        openxr_runtime_active = false
        self.state.handleStatus.leftJoystick = false
        self.state.handleStatus.rightJoystick = false
        self.state.handleStatus.trigger = false
        self.state.handleStatus.grip = false
        self.state.handleStatus.aButton = false
        self.state.handleStatus.bButton = false
        self.state.handleStatus.joystickClick = false
        return false
    end

    local vr = self.vr

    self.state.isOpenXR = vr_call(vr, "is_openxr") == true
    if self.state.isOpenXR then
        self.state.runtimeName = "openxr"
    elseif vr_call(vr, "is_openvr") == true then
        self.state.runtimeName = "openvr"
    else
        self.state.runtimeName = "unavailable"
    end

    -- 同步给 is_valid_input_source 的 upvalue：OpenXR 下 nil source（左手）合法，需放行。
    openxr_runtime_active = self.state.isOpenXR

    -- tracked device 索引（用于 get_pose）
    self.handles.hmd_index = vr_call(vr, "get_hmd_index")
    self.handles.left_index = vr_call(vr, "get_left_controller_index")
    self.handles.right_index = vr_call(vr, "get_right_controller_index")
    self.state.controllerIndices[1] = self.handles.left_index or 0
    self.state.controllerIndices[2] = self.handles.right_index or 0

    -- input source 句柄（用于 is_action_active / get_joystick_axis / haptics）
    self.handles.left = vr_call(vr, "get_left_joystick_source")
    self.handles.right = vr_call(vr, "get_right_joystick_source")

    -- action 句柄
    self.handles.trigger = vr_call(vr, "get_action_handle", ACTION_PATHS.trigger)
    self.handles.grip = vr_call(vr, "get_action_handle", ACTION_PATHS.grip)
    self.handles.joystick_click = vr_call(vr, "get_action_handle", ACTION_PATHS.joystick_click)
    self.handles.a_button_left = vr_call(vr, "get_action_handle", ACTION_PATHS.a_button_left)
    self.handles.a_button_right = vr_call(vr, "get_action_handle", ACTION_PATHS.a_button_right)
    self.handles.b_button_left = vr_call(vr, "get_action_handle", ACTION_PATHS.b_button_left)
    self.handles.b_button_right = vr_call(vr, "get_action_handle", ACTION_PATHS.b_button_right)

    self.state.handleStatus.leftJoystick = is_valid_input_source(self.handles.left)
    self.state.handleStatus.rightJoystick = is_valid_input_source(self.handles.right)
    self.state.handleStatus.trigger = compat.is_valid_handle(self.handles.trigger)
    self.state.handleStatus.grip = compat.is_valid_handle(self.handles.grip)
    self.state.handleStatus.aButton = compat.is_valid_handle(self.handles.a_button_right)
        or compat.is_valid_handle(self.handles.a_button_left)
    self.state.handleStatus.bButton = compat.is_valid_handle(self.handles.b_button_right)
        or compat.is_valid_handle(self.handles.b_button_left)
    self.state.handleStatus.joystickClick = compat.is_valid_handle(self.handles.joystick_click)
    return true
end

function environment:applyTouchHaptics(left_hand, duration, frequency, amplitude)
    if not self:refreshHandles() then
        self.state.lastHaptic.success = false
        self.state.lastHaptic.api = "none"
        self.state.lastHaptic.reason = "refresh_handles_failed"
        return false
    end

    local hand
    if left_hand then
        hand = self.handles.left
    else
        hand = self.handles.right
    end
    local haptic_api = "trigger_haptic_vibration"
    local haptic_method = self.vr ~= nil and self.vr.trigger_haptic_vibration or nil

    local resolved_duration = math.max(0.0, tonumber(duration) or 0.0)
    local resolved_frequency = math.max(0.0, tonumber(frequency) or 0.0)
    local resolved_amplitude = math.min(1.0, math.max(0.0, tonumber(amplitude) or 0.0))

    if not is_valid_input_source(hand) or type(haptic_method) ~= "function" then
        self.state.lastHaptic.success = false
        self.state.lastHaptic.leftHand = left_hand and true or false
        self.state.lastHaptic.duration = resolved_duration
        self.state.lastHaptic.frequency = resolved_frequency
        self.state.lastHaptic.amplitude = resolved_amplitude
        self.state.lastHaptic.api = type(haptic_method) == "function" and haptic_api or "none"
        self.state.lastHaptic.reason = not is_valid_input_source(hand) and "joystick_handle_missing" or "haptic_api_missing"
        return false
    end

    -- UEVR: trigger_haptic_vibration(seconds_from_now, duration, frequency, amplitude, source)（点式调用，无 self）。
    local ok = pcall(haptic_method, 0.0, resolved_duration, resolved_frequency, resolved_amplitude, hand)
    self.state.lastHaptic.success = ok and true or false
    self.state.lastHaptic.leftHand = left_hand and true or false
    self.state.lastHaptic.duration = resolved_duration
    self.state.lastHaptic.frequency = resolved_frequency
    self.state.lastHaptic.amplitude = resolved_amplitude
    self.state.lastHaptic.api = haptic_api
    self.state.lastHaptic.reason = ok and "ok" or (haptic_api .. "_failed")
    return ok
end

function environment:setInputBackend(backend)
    return self.input.setBackend(backend)
end

function environment:syncControllerState()
    local state = self.state
    copy_controller_position(state.leftController, state.leftTouchPose)
    copy_controller_position(state.rightController, state.rightTouchPose)
    state.headController.standingHeight = state.standingHeight
    return true
end

function environment:calibrateState()
    local state = self.state
    if not state.isMounted then
        return false
    end

    state.standingHeight = state.headPose.position.y or state.standingHeight
    state.rollCenter = numerics.get_roll(state.headPose)
    self:syncControllerState()
    state.calibrated = true
    return true
end

function environment:recenterVRSpace()
    if not self:refreshHandles() or self.vr == nil or not self.state.isMounted then
        return false
    end

    -- UEVR 直接提供 recenter_view()，等价于游戏内的重新居中。
    if type(self.vr.recenter_view) == "function" then
        local ok = pcall(self.vr.recenter_view)
        if ok then
            return true
        end
    end

    -- 退路：用 HMD 当前水平位置 + 原 standing origin 的高度重设 standing origin。
    if type(self.vr.set_standing_origin) ~= "function"
        or type(self.vr.get_standing_origin) ~= "function"
    then
        return false
    end

    local origin = compat.new_vector3f()
    if origin == nil then
        return false
    end

    -- get_standing_origin(out_origin) 也是出参式接口。
    if not pcall(self.vr.get_standing_origin, origin) then
        return false
    end

    local head_pos = pose_buffers.head.pos
    local head_rot = pose_buffers.head.rot
    if head_pos ~= nil and head_rot ~= nil and self.handles.hmd_index ~= nil then
        if pcall(self.vr.get_pose, self.handles.hmd_index, head_pos, head_rot) then
            origin.x = head_pos.x
            origin.z = head_pos.z
        end
    end

    local ok = pcall(self.vr.set_standing_origin, origin)
    return ok
end

function environment:reset()
    -- reset() in VRCompanion.py recenters VR space, stores standing height,
    -- refreshes controller baselines, clears roll calibration, and resets runtime helpers.
    self:sampleVRState()
    self:recenterVRSpace()
    self:sampleVRState()
    self:calibrateState()

    if self.gestureSets ~= nil then
        local current = self.gestureSets:getCurrentGestureSet()
        if current ~= nil then
            current:reset()
        end
    end

    self.actions.resetActiveActions()
    self.input.releaseAll()

    if self.gamepad ~= nil and type(self.gamepad.releaseAll) == "function" then
        self.gamepad.releaseAll()
    end

    if self.vrToMouse ~= nil and self.vrToMouse.reset ~= nil then
        self.vrToMouse:reset()
    end
    if self.hapticPlayer ~= nil and self.hapticPlayer.clear ~= nil then
        self.hapticPlayer:clear()
    end

    self.time.accumulator = 0.0
    return self.state.calibrated
end

function environment:updateTime(current_time, delta_time)
    local now = current_time or os.clock()
    local delta = delta_time
    if delta == nil then
        if self.time._last_clock ~= nil then
            delta = now - self.time._last_clock
        else
            delta = self.updateFrequency
        end
    end
    if delta < 0.0 then
        delta = self.updateFrequency
    end
    self.time.current = now
    self.time.delta = delta
    self.time._last_clock = now
    return now, delta
end

function environment:sampleVRState()
    local state = self.state
    if not self:refreshHandles() then
        state.isMounted = false
        state.usingControllers = false
        state.calibrated = false
        return state
    end

    local vr = self.vr
    state.isMounted = vr_call(vr, "is_hmd_active") == true
    state.usingControllers = vr_call(vr, "is_using_controllers") == true
    if not state.isMounted then
        state.calibrated = false
        return state
    end

    update_pose(vr, self.handles.hmd_index, state.headPose, pose_buffers.head)
    update_pose(vr, self.handles.left_index, state.leftTouchPose, pose_buffers.left)
    update_pose(vr, self.handles.right_index, state.rightTouchPose, pose_buffers.right)

    if not state.calibrated then
        state.standingHeight = state.headPose.position.y or 0.0
        state.rollCenter = numerics.get_roll(state.headPose)
        state.headController.standingHeight = state.standingHeight
    end

    -- VR.cpp：runtime 未 loaded 时 is_action_active / get_joystick_axis 恒为 false/零。
    if vr_call(vr, "is_runtime_ready") ~= true then
        state.leftStickAxes.x = 0.0
        state.leftStickAxes.y = 0.0
        state.rightStickAxes.x = 0.0
        state.rightStickAxes.y = 0.0
        state.leftStick = 0.0
        state.rightStick = 0.0
        state.leftTrigger = 0.0
        state.rightTrigger = 0.0
        state.leftGrip = 0.0
        state.rightGrip = 0.0
        state.x = 0.0
        state.y = 0.0
        state.a = 0.0
        state.b = 0.0
        return state
    end

    self:sampleStickAxis(self.handles.left, axis_buffers.left, state.leftStickAxes)
    self:sampleStickAxis(self.handles.right, axis_buffers.right, state.rightStickAxes)

    local left_source = self.handles.left
    local right_source = self.handles.right
    state.leftStick = action_active(vr, self.handles.joystick_click, left_source)
    state.rightStick = action_active(vr, self.handles.joystick_click, right_source)
    state.leftTrigger = action_active(vr, self.handles.trigger, left_source)
    state.rightTrigger = action_active(vr, self.handles.trigger, right_source)
    state.leftGrip = action_active(vr, self.handles.grip, left_source)
    state.rightGrip = action_active(vr, self.handles.grip, right_source)
    -- A/B 在 UEVR 是左右手独立 action：X/Y = 左手 A/B，A/B = 右手 A/B。
    state.x = action_active(vr, self.handles.a_button_left, left_source)
    state.y = action_active(vr, self.handles.b_button_left, left_source)
    state.a = action_active(vr, self.handles.a_button_right, right_source)
    state.b = action_active(vr, self.handles.b_button_right, right_source)

    return state
end

function environment:sampleStickAxis(source_handle, buffer, out_axis)
    out_axis.x = 0.0
    out_axis.y = 0.0
    local vr = self.vr
    if vr == nil
        or buffer == nil
        or not is_valid_input_source(source_handle)
        or type(vr.get_joystick_axis) ~= "function"
    then
        return out_axis
    end

    -- get_joystick_axis(source, out_axis) 出参填充 UEVR_Vector2f（API.h / PluginLoader.cpp）。
    if pcall(vr.get_joystick_axis, source_handle, buffer) then
        out_axis.x = buffer.x or 0.0
        out_axis.y = buffer.y or 0.0
    end
    return out_axis
end

function environment:getVRState()
    return self.state
end

function environment:getEnhancer()
    local enhancer = rawget(_G, "VR_ENHANCER")
    if type(enhancer) == "table" then
        return enhancer
    end

    return nil
end

function environment:publishEnhancer(enhancer)
    if type(enhancer) ~= "table" then
        return nil
    end
    _G.VR_ENHANCER = enhancer
    return enhancer
end

function environment:installHapticFeedbackManager(enhancer)
    local ok, hapticFeedbackModule = pcall(require, "UEVR_10_HapticFeedback")
    if ok and type(hapticFeedbackModule) == "table" and type(hapticFeedbackModule.ensureInstalled) == "function" then
        hapticFeedbackModule.ensureInstalled(enhancer)
    end
end

function environment:attachEnhancerRuntime(enhancer)
    if type(enhancer) ~= "table" then
        return false
    end

    self:publishEnhancer(enhancer)
    self:installHapticFeedbackManager(enhancer)
    if enhancer._runtimeHooksInstalled or rawget(_G, "VR_RUNTIME_HOOKS_INSTALLED") then
        enhancer._runtimeHooksInstalled = true
        return true
    end

    -- UEVR 主时钟用引擎 tick（每帧、含 delta）；on_frame 作为兜底，防止某些情况下引擎 tick 停摆。
    compat.on_pre_engine_tick(function(_, _)
        enhancer:tick("pre_engine_tick")
    end)

    compat.on_frame(function()
        local now = os.clock()

        if enhancer._fallback_active then
            if enhancer._last_tick_source == "pre_engine_tick" and (now - enhancer._last_tick_at) <= 0.2 then
                enhancer._fallback_active = false
                return
            end

            enhancer:tick("on_frame")
            return
        end

        -- 引擎 tick 可能在个别版本停摆；保留 on_frame 兜底。
        if enhancer._last_tick_at == 0.0 or (now - enhancer._last_tick_at) > 0.1 then
            enhancer._fallback_active = true
            enhancer:tick("on_frame")
        end
    end)

    enhancer._runtimeHooksInstalled = true
    _G.VR_RUNTIME_HOOKS_INSTALLED = true
    return true
end

function environment:setHapticFeedbackEnabled(enabled)
    self.hapticFeedbackEnabled = enabled ~= false
    if self.gestureSets ~= nil and type(self.gestureSets._context) == "table" then
        self.gestureSets._context.haptic_player = self.hapticFeedbackEnabled and self.hapticPlayer or nil
    end
    return self.hapticFeedbackEnabled
end

function environment:createGestureSets(inventory)
    self.gestureSets = self.gestures.GestureSets.new(inventory, {
        haptic_player = self.hapticFeedbackEnabled ~= false and self.hapticPlayer or nil,
        touch_haptics_player = self.touchHapticsPlayer,
        getVRState = function()
            return environment.state
        end,
    })
    self.gestureTracker = self.gestureSets.defaultGestureSet
    if self.defaultHaptics ~= nil then
        self.haptics.applyCompanionGestureDefaults(self.gestureTracker, self.defaultHaptics)
    end
    return self.gestureSets
end

function environment:initialize(options)
    if self._initialized then
        if options and options.hapticFeedbackEnabled ~= nil then
            self:setHapticFeedbackEnabled(options.hapticFeedbackEnabled)
        end
        return self
    end

    self.input.setTimeProvider(function()
        return environment.time.current
    end)

    -- 注册 XInput 虚拟手柄回调，使 gamepad.Press 注入的按键能被游戏读取。
    if self.gamepad ~= nil and type(self.gamepad.init) == "function" then
        self.gamepad.init()
    end

    if options and options.inputBackend then
        self:setInputBackend(options.inputBackend)
    elseif _G.VRInputBackend ~= nil then
        self:setInputBackend(_G.VRInputBackend)
    end

    if options and options.hapticFeedbackEnabled ~= nil then
        self.hapticFeedbackEnabled = options.hapticFeedbackEnabled ~= false
    elseif rawget(_G, "VR_HAPTIC_FEEDBACK_ENABLED") ~= nil then
        self.hapticFeedbackEnabled = rawget(_G, "VR_HAPTIC_FEEDBACK_ENABLED") ~= false
    else
        self.hapticFeedbackEnabled = true
    end

    self.touchHapticsPlayer = self.haptics.TouchHapticsPlayer.new(self)
    self.hapticPlayer = self.haptics.HapticPlayer.new(self.touchHapticsPlayer)
    self.defaultHaptics = self.haptics.createCompanionDefaults(self.touchHapticsPlayer)
    if self.haptics.registerCompanionHapticFeedback ~= nil and self.hapticFeedbackEnabled ~= false then
        self.haptics.registerCompanionHapticFeedback(self.hapticPlayer)
    end
    self.vrToMouse = self.input.VRToMouse.new(self)
    self:createGestureSets(nil)
    self:setHapticFeedbackEnabled(self.hapticFeedbackEnabled)
    self._initialized = true
    _G.VREnvironment = self
    return self
end

function environment:tick(current_time, delta_time)
    if not self._initialized then
        self:initialize()
    end
    self:updateTime(current_time, delta_time)
    if self.input ~= nil and type(self.input.updatePending) == "function" then
        self.input.updatePending(self.time.current)
    end
    self:sampleVRState()
    if not self.state.isMounted then
        return
    end
    if not self.state.calibrated then
        self:calibrateState()
    end

    local logical_delta = self.time.delta
    if self.updateFrequency > 0.0 then
        self.time.accumulator = self.time.accumulator + self.time.delta
        if self.time.accumulator < self.updateFrequency then
            return
        end
        logical_delta = self.time.accumulator
        self.time.accumulator = 0.0
    end

    if self.gestureSets ~= nil then
        self.gestureSets:update(self.time.current, logical_delta, self.state)
    end
    if self.vrToMouse ~= nil then
        self.vrToMouse:update(self.time.current, logical_delta)
    end
    if self.hapticPlayer ~= nil then
        self.hapticPlayer:update(logical_delta)
    end
    self:syncControllerState()
end

package.loaded[module_name] = environment

return environment