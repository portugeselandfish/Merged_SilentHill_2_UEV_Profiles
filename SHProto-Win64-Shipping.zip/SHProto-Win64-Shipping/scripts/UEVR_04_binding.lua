local module_name = "UEVR_04_binding"
if package.loaded[module_name] ~= nil then
    return package.loaded[module_name]
end

-- UEVR_04_binding.lua
-- 虚拟 Xbox 手柄输入层，与 UEVR_04_input（键鼠 SimInput）同级。
-- 手势/脚本通过 GamepadPress 注入 XInput；UEVR 自身仍负责 VR 物理按键 → 手柄的默认映射。

local gamepad = {}

local XINPUT = {
    GAMEPAD_A = 0x1000,
    GAMEPAD_B = 0x2000,
    GAMEPAD_X = 0x4000,
    GAMEPAD_Y = 0x8000,
    GAMEPAD_RIGHT_SHOULDER = 0x0100,
    GAMEPAD_LEFT_SHOULDER = 0x0080,
    GAMEPAD_LEFT_THUMB = 0x0040,
    GAMEPAD_RIGHT_THUMB = 0x0020,
    GAMEPAD_DPAD_UP = 0x0001,
    GAMEPAD_DPAD_DOWN = 0x0002,
    GAMEPAD_DPAD_LEFT = 0x0004,
    GAMEPAD_DPAD_RIGHT = 0x0008,
    GAMEPAD_START = 0x0010,
    GAMEPAD_BACK = 0x0020,
}

-- 对外常量：gamepad.Button.A 等（与 input.Key 用法一致）
local Button = {
    A = "a_button",
    B = "b_button",
    X = "x_button",
    Y = "y_button",
    LeftShoulder = "left_shoulder",
    RightShoulder = "right_shoulder",
    LeftStickPress = "left_stick_press",
    RightStickPress = "right_stick_press",
    DpadUp = "dpad_up",
    DpadDown = "dpad_down",
    DpadLeft = "dpad_left",
    DpadRight = "dpad_right",
    Start = "start_button",
    Back = "back_button",
    LeftTrigger = "left_trigger",
    RightTrigger = "right_trigger",
}

local button_specs = {
    a_button = { constant = XINPUT.GAMEPAD_A, type = "button" },
    b_button = { constant = XINPUT.GAMEPAD_B, type = "button" },
    x_button = { constant = XINPUT.GAMEPAD_X, type = "button" },
    y_button = { constant = XINPUT.GAMEPAD_Y, type = "button" },
    left_shoulder = { constant = XINPUT.GAMEPAD_LEFT_SHOULDER, type = "button" },
    right_shoulder = { constant = XINPUT.GAMEPAD_RIGHT_SHOULDER, type = "button" },
    left_stick_press = { constant = XINPUT.GAMEPAD_LEFT_THUMB, type = "button" },
    right_stick_press = { constant = XINPUT.GAMEPAD_RIGHT_THUMB, type = "button" },
    dpad_up = { constant = XINPUT.GAMEPAD_DPAD_UP, type = "button" },
    dpad_down = { constant = XINPUT.GAMEPAD_DPAD_DOWN, type = "button" },
    dpad_left = { constant = XINPUT.GAMEPAD_DPAD_LEFT, type = "button" },
    dpad_right = { constant = XINPUT.GAMEPAD_DPAD_RIGHT, type = "button" },
    start_button = { constant = XINPUT.GAMEPAD_START, type = "button" },
    back_button = { constant = XINPUT.GAMEPAD_BACK, type = "button" },
    left_trigger = { stateField = "bLeftTrigger", type = "trigger" },
    right_trigger = { stateField = "bRightTrigger", type = "trigger" },
}

local TRIGGER_MAX = 255
local virtual_refcount = {}
local is_enabled = true
local is_initialized = false

local function resolve_button_name(value)
    if value == nil then
        return nil
    end
    if type(value) == "string" then
        if button_specs[value] ~= nil then
            return value
        end
        return Button[value]
    end
    return nil
end

local function normalize_buttons(buttons)
    if buttons == nil then
        return {}
    end

    local source = buttons
    if type(source) ~= "table" then
        source = { source }
    elseif source[1] == nil then
        source = { source }
    end

    local resolved = {}
    for _, entry in ipairs(source) do
        local name = resolve_button_name(entry)
        if name ~= nil then
            resolved[#resolved + 1] = name
        end
    end
    return resolved
end

local function press_button(state, constant)
    state.Gamepad.wButtons = state.Gamepad.wButtons | constant
end

local function set_trigger(state, field, value)
    state.Gamepad[field] = value
end

function gamepad.setVirtualButton(button_name, pressed)
    local name = resolve_button_name(button_name)
    if name == nil then
        return
    end

    local count = virtual_refcount[name] or 0
    if pressed then
        virtual_refcount[name] = count + 1
    else
        count = math.max(0, count - 1)
        if count == 0 then
            virtual_refcount[name] = nil
        else
            virtual_refcount[name] = count
        end
    end
end

function gamepad.clearVirtualButtons()
    virtual_refcount = {}
end

local function apply_virtual_buttons(state)
    for name, count in pairs(virtual_refcount) do
        if count > 0 then
            local spec = button_specs[name]
            if spec ~= nil and spec.type == "button" then
                press_button(state, spec.constant)
            elseif spec ~= nil and spec.type == "trigger" then
                set_trigger(state, spec.stateField, TRIGGER_MAX)
            end
        end
    end
end

function gamepad.setEnabled(enabled)
    is_enabled = enabled ~= false
end

function gamepad.isEnabled()
    return is_enabled
end

function gamepad.init()
    if is_initialized then
        return
    end

    if uevr ~= nil and uevr.sdk ~= nil and uevr.sdk.callbacks ~= nil then
        uevr.sdk.callbacks.on_xinput_get_state(function(_, _, state)
            if is_enabled and state ~= nil and state.Gamepad ~= nil then
                apply_virtual_buttons(state)
            end
        end)
        is_initialized = true
    end
end

function gamepad.isInitialized()
    return is_initialized
end

function gamepad.releaseAll()
    gamepad.clearVirtualButtons()
end

local GamepadPress = {}
GamepadPress.__index = GamepadPress

function GamepadPress.new(buttons)
    return setmetatable({
        _buttons = normalize_buttons(buttons),
        _pressed = false,
        haptics = nil,
    }, GamepadPress)
end

function GamepadPress:getCurrentHaptics()
    return self.haptics
end

function GamepadPress:enter(_, _)
    if self._pressed then
        return true
    end
    for _, name in ipairs(self._buttons) do
        gamepad.setVirtualButton(name, true)
    end
    self._pressed = true
    return true
end

function GamepadPress:update(_)
end

function GamepadPress:leave()
    if not self._pressed then
        return
    end
    for _, name in ipairs(self._buttons) do
        gamepad.setVirtualButton(name, false)
    end
    self._pressed = false
end

function GamepadPress:reset()
    self:leave()
end

gamepad.Button = Button
gamepad.XINPUT = XINPUT
gamepad.Press = GamepadPress

_G.VRGamepad = gamepad

package.loaded[module_name] = gamepad

return gamepad
