--修改说明
--修改了挥舞阈值

local uevrUtils = require('libs/uevr_utils')

local M = {}

-- 近战系统禁用开关
local isDisabled  = false
function M.disable(val)
    isDisabled = val

    if val then
        -- 禁用近战的同时，恢复角色的根运动（Root Motion），避免角色卡住
        local animInstance = uevrUtils.getValid(pawn, {"Mesh", "AnimScriptInstance"})
        if animInstance then
        	animInstance:SetRootMotionMode(2) -- Everything
            M.print("Re-enabled root motion")
        end
    end
end

-- 日志等级控制
local currentLogLevel = LogLevel.Error
function M.setLogLevel(val)
	currentLogLevel = val
end
function M.print(text, logLevel)
	if logLevel == nil then logLevel = LogLevel.Debug end
	if logLevel <= currentLogLevel then
		uevrUtils.print("[melee] " .. text, logLevel)
	end
end

-- The following code courtesy of Praydog
-- 获取 UEVR API 和 VR 参数
local api = uevr.api
local vr = uevr.params.vr

-- 预加载游戏中关键的类引用，用于后续通过反射操作
local SHAnimCombatSubcomp_c = uevrUtils.find_required_object("Class /Script/SHProto.SHAnimCombatSubcomp")
local AnimNotify_MeleeAttackCheck_c = uevrUtils.find_required_object("Class /Script/SHProto.AnimNotify_MeleeAttackCheck")
local AnimNotify_ModifyCombatInputMode_c = uevrUtils.find_required_object("Class /Script/SHProto.AnimNotify_ModifyCombatInputMode")
local AnimNotifyEventReference_c = uevrUtils.find_required_object("ScriptStruct /Script/Engine.AnimNotifyEventReference")
local SHMeleeBaseDamage_c = uevrUtils.find_required_object("Class /Script/SHProto.SHMeleeBaseDamage")
local DamageType_c = uevrUtils.find_required_object("Class /Script/Engine.DamageType")
local SHItemWeaponMelee_c = uevrUtils.find_required_object("Class /Script/SHProto.SHItemWeaponMelee")

-- 可复用的动画通知引用结构体，用于在触发攻击时传递参数
local reusable_anim_notify_ref = StructObject.new(AnimNotifyEventReference_c)

-- 缓存的近战动画 Montage（关卡序列），找到后反复使用
local melee_montage = nil

-- 动画通知的虚表函数索引，用于直接调用 Notify 函数
local ANIMNOTIFY_NOTIFY_VTABLE_INDEX = 88

-- 近战武器伤害类型在内存中的偏移地址
-- 该偏移用于将伤害类型写入武器对象，游戏据此判定命中反应
local MELEE_WEAPON_DAMAGE_TYPE_OFFSET = 0x6D8 -- LightEffect + 0x28, might be a way of automating this

-- 缓存的动画通知对象引用
local last_anim_notify_melee_obj = nil
local last_anim_notify_modify_combat_input_obj = nil

-- UE4 基础类引用
local AnimMontage_c = api:find_uobject("Class /Script/Engine.AnimMontage")
local UClass_c = api:find_uobject("Class /Script/CoreUObject.Class")

-- 近战攻击的槽位名称（用于在动画蓝图中定位攻击插槽）
local melee_attack_name = kismet_string_library:Conv_StringToName("MeleeAttack")

-- 标记最近是否触发过近战（用于防止重复触发）
local triggered_melee_recently = false

-- ============================================================
-- 近战系统核心状态数据
-- ============================================================
local melee_data = {
    cooldown_time = 0.0,              -- 攻击冷却剩余时间，防止过快连击
    accumulated_time = 0.0,           -- 累计时间，用于与上次攻击时间比对
    last_tried_melee_time = 1000.0,   -- 上次尝试近战的累计时间点（初始值极大，确保首次可攻击）
    right_hand_pos_raw = UEVR_Vector3f.new(),  -- 右手控制器原始位置（UEVR 数据）
    right_hand_q_raw = UEVR_Quaternionf.new(), -- 右手控制器原始旋转（UEVR 数据）
    right_hand_pos = Vector3f.new(0, 0, 0),   -- 右手控制器位置（转换为游戏内坐标）
    last_right_hand_raw_pos = Vector3f.new(0, 0, 0), -- 上一帧右手位置，用于计算速度
    last_time_messed_with_attack_request = 0.0, -- 上次干预引擎攻击请求的时间
    last_enemy_hit_time = 0.0,       -- 上次命中敌人的时间
    root_motion_needs_reset = true,  -- 是否需要重置根运动状态
    known_damage_types = {},         -- 已发现的伤害类型类列表
    damage_type_dict = {},           -- 伤害类型名称 -> 类 的映射字典
    last_weapon = nil,               -- 上次使用的近战武器引用
    last_repopulate_attempt = 0.0,   -- 上次重新填充伤害类型的时间
    first = true,                    -- 首帧标记
    enemy_combo_index = 0,           -- 敌人连击索引（0-2 循环，用于切换伤害类型）
    hit_enemy = false,               -- 当前攻击是否命中了敌人
}

-- ============================================================
-- 伤害类型发现与缓存
-- ============================================================

--- 扫描并缓存游戏中所有可用的伤害类型
-- 游戏的伤害类型（如 IronPipeDamage、PistolDamage 等）继承自 DamageType 基类
-- 此函数遍历所有 DamageType 对象，建立名称到类的映射
local function populate_damage_types()
    if DamageType_c == nil or #melee_data.known_damage_types > 0 then
        return
    end

    local damage_types = DamageType_c:get_objects_matching(true) -- Include defaults

    for k, v in pairs(damage_types) do
        --if v:as_struct() ~= nil then
            M.print("Found damage type: " .. v:get_full_name())
            local c = v:get_class()
            table.insert(melee_data.known_damage_types, c)
            melee_data.damage_type_dict[c:get_fname():to_string()] = c
        --end
    end

    melee_data.last_repopulate_attempt = os.clock()
end

--- 根据伤害类型名称查找对应的类引用
-- 支持缓存失效自动重查（超过 1 秒未命中则重新扫描）
-- @param name 伤害类型名称（如 "IronPipeDamage_C"）
-- @return 伤害类型的 UClass 引用
local function lookup_damage_type(name)
    populate_damage_types()

    local v = melee_data.damage_type_dict[name]

    if v ~= nil and UEVR_UObjectHook.exists(v) and v:is_a(UClass_c) and v:get_class_default_object():is_a(DamageType_c) then
        return v
    end

    local now = os.clock()

    -- 缓存失效：超过 1 秒则清空重新填充
    if now - melee_data.last_repopulate_attempt > 1.0 then
        melee_data.known_damage_types = {}
        melee_data.damage_type_dict = {}
        populate_damage_types()
    end

    return melee_data.damage_type_dict[name]
end

-- ============================================================
-- 近战事件回调
-- ============================================================

-- 监听游戏引擎发出的近战相关事件
-- OnMeleeTraceSuccess: 近战碰撞检测成功（命中敌人/玻璃/环境）
-- OnMeleeHitLeg: 命中敌人腿部，触发膝盖废弹（kneecapping）机制
uevr.sdk.callbacks.on_lua_event(function(event_name, event_string)
    -- if isDisabled then
    --     return
    -- end

    M.print("Lua event received: " .. event_name .. " with string: " .. event_string)

    -- 近战 Trace 检测成功回调
    if event_name == "OnMeleeTraceSuccess" then
        local now = os.clock()

        -- 重置累计计时，准备下一次攻击判定
        melee_data.accumulated_time = 0.0
        melee_data.last_tried_melee_time = 0.0

        if event_string == "Enemy" then
            -- 命中敌人：管理连击计数器
            -- 1 秒内再次命中则连击 +1（循环 0-1-2），否则重置
            if math.abs(now - melee_data.last_enemy_hit_time) > 1.0 then
                if melee_data.enemy_combo_index ~= 1 then
                    M.print("Combo reset")
                end
                melee_data.enemy_combo_index = 0
            else
                melee_data.enemy_combo_index = ((melee_data.enemy_combo_index + 1) % 3)
                M.print("Combo index: " .. tostring(melee_data.enemy_combo_index))
            end

            -- 命中敌人后设置较长的冷却（0.5 秒），防止持续连击
            melee_data.cooldown_time = 0.5
            melee_data.last_enemy_hit_time = now
            melee_data.hit_enemy = true

        elseif event_string == "Glass" then
            -- 命中玻璃/可破坏物：中等冷却
            melee_data.cooldown_time = 0.5
        else
            -- 命中环境/其他：短冷却（0.033 秒 ≈ 1 帧），允许快速连续挥砍
            melee_data.cooldown_time = 0.033
        end

        -- 重置上次尝试时间为极大值，确保下次挥舞能立即触发
        melee_data.last_tried_melee_time = 1000.0

        -- 使用控制器时触发触觉反馈
        if vr.is_using_controllers() then
            vr.trigger_haptic_vibration(0, 0.1, 0.5, 1.0, vr.get_right_joystick_source())

            triggered_melee_recently = true
        end

    -- 命中腿部：切换伤害类型为手枪伤害，实现"膝盖废弹"效果
    elseif event_name == "OnMeleeHitLeg" then
        if melee_data.last_weapon ~= nil then
            local pistol_damage = lookup_damage_type("PistolDamage_C")

            if pistol_damage ~= nil then
                -- 将伤害类型写入武器对象，使游戏引擎使用手枪伤害而非近战伤害
                -- 这样命中腿部时敌人有概率倒地
---@diagnostic disable-next-line: undefined-field
                melee_data.last_weapon:write_qword(MELEE_WEAPON_DAMAGE_TYPE_OFFSET, pistol_damage:get_address())
            end
        end
    end
end)

-- ============================================================
-- 主循环：每引擎帧执行的近战逻辑
-- ============================================================
uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
    if isDisabled then
        return
    end

    melee_data.last_weapon = nil

    -- if not right_hand_component or not left_hand_component then
    --     return
    -- end

    local now = os.clock()

    -- 读取右手控制器的位置和旋转（UEVR 提供的原始数据）
    vr.get_pose(vr.get_right_controller_index(), melee_data.right_hand_pos_raw, melee_data.right_hand_q_raw)

    -- 复制位置数据（避免创建新的 userdata 对象以减少 GC 压力）
    melee_data.right_hand_pos:set(melee_data.right_hand_pos_raw.x, melee_data.right_hand_pos_raw.y, melee_data.right_hand_pos_raw.z)

    -- 首帧初始化：将上一帧位置设为当前位置，避免首帧速度突变
    if melee_data.first then
        melee_data.last_right_hand_raw_pos:set(melee_data.right_hand_pos.x, melee_data.right_hand_pos.y, melee_data.right_hand_pos.z)
        melee_data.first = false
    end

    -- 计算右手移动速度（当前位置 - 上一帧位置） / deltaTime
    local velocity = (melee_data.right_hand_pos - melee_data.last_right_hand_raw_pos) * (1 / delta)

    -- 更新上一帧位置记录（原地修改，不创建新对象）
    melee_data.last_right_hand_raw_pos.x = melee_data.right_hand_pos_raw.x
    melee_data.last_right_hand_raw_pos.y = melee_data.right_hand_pos_raw.y
    melee_data.last_right_hand_raw_pos.z = melee_data.right_hand_pos_raw.z

    -- 累计干预攻击请求的时间
    melee_data.last_time_messed_with_attack_request = melee_data.last_time_messed_with_attack_request + delta

    -- 获取本地玩家角色（Pawn）
    local pawn = api:get_local_pawn(0)

    if pawn == nil then
        return
    end

    -- --------------------------------------------------------
    -- 1. 查找近战动画 Montage
    -- 在所有 AnimMontage 中搜索名为
    -- "James_SideAttacks_GroundAttack_UpDown" 的动画资源
    -- 这是 Silent Hill 2 重制版中角色 James 的近战攻击动画
    -- --------------------------------------------------------
    melee_montage = uevrUtils.getValid(melee_montage)
    if melee_montage == nil or not UEVR_UObjectHook.exists(melee_montage) or not melee_montage:is_a(AnimMontage_c) then
        local montages = AnimMontage_c:get_objects_matching(false)

        for i, v in ipairs(montages) do
            --if v:get_fname():to_string():find("BreakingWall") then
            if v:get_fname():to_string() == "James_SideAttacks_GroundAttack_UpDown" then
            --if v:get_fname():to_string() == "James_StealthAttack_Hit1_v2" then
                melee_montage = v
                M.print("Found montage")
                break
            end
        end
    end

    -- --------------------------------------------------------
    -- 2. 查找近战攻击检查的 AnimNotify 对象
    -- AnimNotify 是 UE4 动画系统的通知机制
    -- 当动画播放到特定帧时触发，用于执行碰撞检测和伤害计算
    -- 这里找到 melee_montage 绑定的 AnimNotify_MeleeAttackCheck 对象
    -- --------------------------------------------------------
    if AnimNotify_MeleeAttackCheck_c ~= nil and (not last_anim_notify_melee_obj or not UEVR_UObjectHook.exists(last_anim_notify_melee_obj) or not last_anim_notify_melee_obj:is_a(AnimNotify_MeleeAttackCheck_c)) then
        local anim_notifies = AnimNotify_MeleeAttackCheck_c:get_objects_matching(false)

        for i, v in ipairs(anim_notifies) do
            if v:get_outer() == melee_montage then
                last_anim_notify_melee_obj = v
                M.print("Found melee notify obj @ " .. v:get_full_name())
                break
            end
        end
    end

    -- --------------------------------------------------------
    -- 3. 查找战斗输入模式修改的 AnimNotify
    -- --------------------------------------------------------
    if AnimNotify_ModifyCombatInputMode_c ~= nil and (not last_anim_notify_modify_combat_input_obj or not UEVR_UObjectHook.exists(last_anim_notify_modify_combat_input_obj) or not last_anim_notify_modify_combat_input_obj:is_a(AnimNotify_ModifyCombatInputMode_c)) then
        last_anim_notify_modify_combat_input_obj = AnimNotify_ModifyCombatInputMode_c:get_class_default_object() -- Will this work? let's find out

        if last_anim_notify_modify_combat_input_obj then
            M.print("Got combat input notify obj")
        end
    end

    -- 填充伤害类型缓存
    populate_damage_types()

    -- --------------------------------------------------------
    -- 4. 近战攻击期间禁用 Root Motion（根运动）
    -- VR 模式下，角色的位移应由玩家的物理移动驱动
    -- 而非由动画的 Root Motion 自动驱动，否则会导致角色"被动画拉着走"
    -- --------------------------------------------------------
    if melee_montage ~= nil and melee_montage.bEnableRootMotionTranslation ~= nil then --and is_allowing_vr_mode then
        -- 禁用近战动画的根运动翻译
        melee_montage.bEnableRootMotionTranslation = false
        --[[melee_montage.bEnableRootMotionTranslation = false
        melee_montage.bEnableRootMotionRotation = false
        melee_montage.RootMotionRootLock = 0]]

        local mesh = pawn.Mesh
        local combat = pawn.Combat

        -- 重置战斗输入模式，防止进入"软锁"状态
        if combat then
            if combat:read_byte(0x152) == 1 then
                M.print("Combat input mode is 1")
                combat:write_byte(0x152, 0) -- Reset combat input mode so we don't softlock
            end
        end

        if mesh then
            local animation = pawn.Animation
            local anim_instance = mesh.AnimScriptInstance
            local weapon = anim_instance and anim_instance:GetEquippedWeapon() or nil
            local has_melee_weapon = weapon ~= nil and weapon:is_a(SHItemWeaponMelee_c)

            -- --------------------------------------------------------
            -- 4a. 根据当前动画状态动态切换 Root Motion 模式
            --     - 播放近战攻击时 → IgnoreRootMotion（忽略根运动）
            --     - 非近战攻击时 → RootMotionFromMontagesOnly（仅动画蒙太奇提供根运动）
            -- --------------------------------------------------------
            if anim_instance then
                -- "Is Playing Melee Attack" 是游戏自定义的反射函数，
                -- 用于判断当前是否正在播放近战攻击动画
                local is_playing_melee_attack = has_melee_weapon and anim_instance["Is Playing Melee Attack"](anim_instance, {}, {}, {}, {}, {}) or false
                if is_playing_melee_attack or anim_instance:Montage_IsPlaying(melee_montage) then
                    anim_instance:SetRootMotionMode(1) -- IgnoreRootMotion
                    melee_data.root_motion_needs_reset = true
                elseif melee_data.root_motion_needs_reset then
                    -- 非近战攻击状态下恢复根运动
                    anim_instance:SetRootMotionMode(3) -- RootMotionFromMontagesOnly
                    melee_data.root_motion_needs_reset = false
                end
            end

            -- --------------------------------------------------------
            -- 5. 核心：近战挥舞检测与攻击触发
            -- --------------------------------------------------------
            if has_melee_weapon and last_anim_notify_melee_obj then
                melee_data.last_weapon = weapon
                local combat_anim_subcomp = animation:FindSubcomponentByClass(SHAnimCombatSubcomp_c)

                -- --------------------------------------------------------
                -- 5a. 拦截并跳过引擎原生的近战攻击动画播放
                --     当玩家按下攻击按钮时，游戏会自动播放近战 Montage
                --     我们需要将动画直接推进到最后一帧，从而"跳过"引擎的动画播放
                --     这样攻击效果由我们手动触发（通过 AnimNotify）
                -- --------------------------------------------------------
                if melee_data.last_time_messed_with_attack_request >= 0.1 and not triggered_melee_recently and combat_anim_subcomp and vr.is_using_controllers() then
                    local attack = combat_anim_subcomp.Attack
                    if attack then
                        local animdata = attack.PlayAnimationData

                        if animdata then
                            local current_montage = attack.CurrentMontage

                            -- 如果引擎正在播放某个攻击 Montage，则干预它
                            if current_montage and attack:IsPlaying() then
                                local input_data = attack.InputData
                                if input_data ~= nil then --or (input_data:get_full_name():find("BreakingWall") == nil and input_data:get_full_name():find("Chainsaw") == nil) then
                                    local montageName = input_data:get_full_name()

                                    -- 忽略 BreakingWall（破门）和 Chainsaw（电锯）动画
                                    -- 对其他所有近战攻击动画进行"快进"处理
                                    if montageName:find("BreakingWall") == nil and montageName:find("Chainsaw") == nil then
                                        -- 将淡入淡出时间设为 0，实现无过渡切换
                                        animdata.BlendInTime = 0.0
                                        animdata.BlendOutTime = 0.0
                                        -- 将动画直接设置到最后一帧（跳过所有中间帧）
                                        anim_instance:Montage_SetPosition(current_montage, current_montage:GetPlayLength())

                                        melee_data.last_time_messed_with_attack_request = 0.0
                                    end

                                    -- 电锯特殊处理：保持播放但禁用根运动
                                    if montageName:find("Chainsaw") ~= nil then
                                        anim_instance:SetRootMotionMode(2) -- IgnoreRootMotion
                                        melee_data.root_motion_needs_reset = true
                                    end
                                end
                            end
                        end
                    end
                end

                -- --------------------------------------------------------
                -- 5b. 触发近战攻击的核心条件判定
                --     条件 A：累计时间 > 0.1 秒，重置"最近触发"标记
                --     条件 B：挥动手柄速度 >= 4.0（快速挥动）
                --     条件 C：满足时间窗口条件（上次攻击后 0.1 秒内）
                -- --------------------------------------------------------
                if melee_data.accumulated_time > 0.1 then
                    triggered_melee_recently = false
                end

                melee_data.accumulated_time = melee_data.accumulated_time + delta

                -- 冷却计时递减
                if melee_data.cooldown_time > 0.0 then
                    melee_data.cooldown_time = melee_data.cooldown_time - delta
                end

                -- 计算右手挥舞速度
                local vel_len = velocity:length()
                local swinging_fast = vel_len >= 4.0

                -- 攻击触发条件：
                -- 1. 冷却已结束
                -- 2. 正在快速挥动手柄 或 处于攻击时间窗口内
                if melee_data.cooldown_time <= 0.0 and (swinging_fast or math.abs(melee_data.accumulated_time - melee_data.last_tried_melee_time) < 0.1) then
                    if combat_anim_subcomp then
                        local attack = combat_anim_subcomp.Attack
                        -- 确保当前没有正在播放的攻击动画
                        if attack and attack.CurrentMontage == nil and attack.InputData == nil then
                            if last_anim_notify_melee_obj then
                                -- 快速挥动时记录攻击时间点
                                if swinging_fast then
                                    melee_data.last_tried_melee_time = melee_data.accumulated_time
                                end

                                melee_data.hit_enemy = false

                                -- --------------------------------------------------------
                                -- 5c. 手动设置攻击参数并播放近战 Montage
                                --     将 melee_montage 设为当前攻击动画
                                -- --------------------------------------------------------
                                attack.CurrentMontage = melee_montage
                                attack.InputData = melee_montage

                                local animdata = attack.PlayAnimationData

                                if animdata then
                                    animdata.SlotName = melee_attack_name
                                    --attack:PlayOrOverwriteRequest(0.0, animdata, temp_vec3:set(0, 0, 0))
                                end

                                -- 确保 Montage 正在播放
                                if not anim_instance:Montage_IsPlaying(melee_montage) then
                                    anim_instance:Montage_Play(melee_montage, 1.0, 0, 0.0, false)
                                end

                                -- --------------------------------------------------------
                                -- 5d. 直接调用 AnimNotify 的虚函数执行碰撞检测和伤害
                                --     AnimNotify 的 Notify 函数包含游戏内置的：
                                --     - Trace 射线检测（碰撞检测）
                                --     - 伤害计算与应用
                                --     - 命中反应触发
                                --     通过 DANGEROUS_call_member_virtual 绕过正常的动画通知流程
                                -- --------------------------------------------------------

                                -- 构造 AnimNotifyEventReference，设置 Notify 对象指针
                                reusable_anim_notify_ref:write_qword(0x10, last_anim_notify_melee_obj:get_address()) -- 0x10 is the offset of Notify
                                reusable_anim_notify_ref.NotifySource = mesh

                                -- 保存并替换 MeshContext（动画通知的网格上下文）
                                local last_mesh_context = last_anim_notify_melee_obj:read_qword(0x30) -- 0x30 is the offset of MeshContext
                                last_anim_notify_melee_obj:write_qword(0x30, mesh:get_address()) -- 0x30 is the offset of MeshContext

                                -- --------------------------------------------------------
                                -- 5e. 设置伤害类型并执行攻击
                                --     依次尝试两种伤害类型：
                                --     1. Wdp_Combo_L{index+1}_DamageType_C：连击伤害（可使敌人眩晕/踉跄）
                                --     2. IronPipeDamage_C：铁管伤害（可破坏可破坏墙壁）
                                --     对每种伤害类型：
                                --     - 写入武器的伤害类型指针
                                --     - 设置 bIsGroundHit 允许攻击击中地面
                                --     - 调用 AnimNotify 的 Notify 虚函数执行 Trace 和伤害
                                --     - 如果命中敌人则停止尝试
                                -- --------------------------------------------------------
                                local damage_type_strs = {
                                    "Wdp_Combo_L" .. tostring(melee_data.enemy_combo_index + 1) .. "_DamageType_C", -- 连击伤害，使敌人踉跄
                                    "IronPipeDamage_C" -- 铁管伤害，可破坏墙壁
                                }
                                local damage_type = nil

                                for _, dtype_str in ipairs(damage_type_strs) do
                                    damage_type = lookup_damage_type(dtype_str)

                                    if damage_type == nil then
                                        M.print("Failed to find damage type: " .. dtype_str)
                                    else
                                        local defobj = damage_type:get_class_default_object()
                                        -- 如果是近战伤害基类，设置允许击中地面
                                        if defobj:is_a(SHMeleeBaseDamage_c) then
                                            defobj.bIsGroundHit = true -- Lets attacks hit the ground
                                        end
                                        -- 将伤害类型地址写入武器对象
                                        if weapon ~= nil then
                                            weapon:write_qword(MELEE_WEAPON_DAMAGE_TYPE_OFFSET, damage_type:get_address())
                                        end
                                    end

                                    -- 【核心】直接调用 AnimNotify 的 Notify 虚函数
                                    -- 这是整个近战系统的关键：
                                    -- 游戏原本通过动画帧到达时自动触发 Notify
                                    -- 我们通过虚表调用直接执行，跳过动画时间的限制
                                    -- 该函数内部执行：
                                    --   1. Trace（射线）碰撞检测
                                    --   2. 伤害类型判定与伤害值计算
                                    --   3. 命中反应（如敌人踉跄、倒地）
                                    --   4. 发送 OnMeleeTraceSuccess 事件回调
                                    local pcall_res = pcall(function()
                                        last_anim_notify_melee_obj:DANGEROUS_call_member_virtual(ANIMNOTIFY_NOTIFY_VTABLE_INDEX + 1, mesh, melee_montage, reusable_anim_notify_ref)
                                    end)

                                    if not pcall_res then
                                        M.print("Failed to call melee notify")
                                    end

                                    -- 如果已命中敌人，不再尝试第二种伤害类型
                                    if melee_data.hit_enemy then
                                        break
                                    end
                                end

                                -- 攻击完成后清理：将武器伤害类型重置为 0
                                if weapon ~= nil then
                                    weapon:write_qword(MELEE_WEAPON_DAMAGE_TYPE_OFFSET, 0)
                                end

                                -- 恢复 MeshContext 到原始值
                                last_anim_notify_melee_obj:write_qword(0x30, last_mesh_context)

                                -- --------------------------------------------------------
                                -- 5f. 重置攻击请求状态
                                --     清除 CurrentMontage 和 InputData，
                                --     确保引擎不会自行播放攻击动画
                                -- --------------------------------------------------------
                                attack.CurrentMontage = nil
                                attack.InputData = nil

                                -- 未触发过近战则发出轻微触觉反馈
                                if not triggered_melee_recently then
                                    vr.trigger_haptic_vibration(0, 0.1, 0.1, 0.1, vr.get_right_joystick_source()) -- Very light vibration
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)

return M