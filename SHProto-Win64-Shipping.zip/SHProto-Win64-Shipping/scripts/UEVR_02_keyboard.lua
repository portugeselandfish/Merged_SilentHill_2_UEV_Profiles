local module_name = "UEVR_02_keyboard"
if package.loaded[module_name] ~= nil then
    return package.loaded[module_name]
end

-- UEVR_02_keyboard.lua
-- VK/ScanCode key table plus reference-counted KeyboardWrapper for shared key holds.
local keyboard_input = {}

local VK = {
    D1 = 0x31, KEY_1 = 0x31, ["1"] = 0x31,
    D2 = 0x32, KEY_2 = 0x32, ["2"] = 0x32,
    D3 = 0x33, KEY_3 = 0x33, ["3"] = 0x33,
    D4 = 0x34, KEY_4 = 0x34, ["4"] = 0x34,
    D5 = 0x35, KEY_5 = 0x35, ["5"] = 0x35,
    D6 = 0x36, KEY_6 = 0x36, ["6"] = 0x36,
    D7 = 0x37, KEY_7 = 0x37, ["7"] = 0x37,
    D8 = 0x38, KEY_8 = 0x38, ["8"] = 0x38,
    D9 = 0x39, KEY_9 = 0x39, ["9"] = 0x39,
    D0 = 0x30, KEY_0 = 0x30, ["0"] = 0x30,

    Minus = 0xBD, OEM_Minus = 0xBD, Hyphen = 0xBD, ["-"] = 0xBD,
    Equals = 0xBB, OEM_Plus = 0xBB, ["="] = 0xBB,

    Q = 0x51,
    W = 0x57,
    E = 0x45,
    R = 0x52,
    T = 0x54,
    Y = 0x59,
    U = 0x55,
    I = 0x49,
    O = 0x4F,
    P = 0x50,
    LeftBracket = 0xDB, LBracket = 0xDB, OEM_4 = 0xDB, ["["] = 0xDB,
    RightBracket = 0xDD, RBracket = 0xDD, OEM_6 = 0xDD, ["]"] = 0xDD,

    A = 0x41,
    S = 0x53,
    D = 0x44,
    F = 0x46,
    G = 0x47,
    H = 0x48,
    J = 0x4A,
    K = 0x4B,
    L = 0x4C,
    Semicolon = 0xBA, OEM_1 = 0xBA, [";"] = 0xBA,
    Apostrophe = 0xDE, Quote = 0xDE, OEM_7 = 0xDE, ["'"] = 0xDE,
    Grave = 0xC0, BackTick = 0xC0, OEM_3 = 0xC0, US_Grave = 0xC0, ["`"] = 0xC0,
    Backslash = 0xDC, BackSlash = 0xDC, OEM_5 = 0xDC, ["\\"] = 0xDC,

    Z = 0x5A,
    X = 0x58,
    C = 0x43,
    V = 0x56,
    B = 0x42,
    N = 0x4E,
    M = 0x4D,
    Comma = 0xBC, OEM_Comma = 0xBC, [","] = 0xBC,
    Period = 0xBE, OEM_Period = 0xBE, ["."] = 0xBE,
    Slash = 0xBF, OEM_2 = 0xBF, ["/"] = 0xBF,

    Multiply = 0x6A, NumMultiply = 0x6A, NumPadMultiply = 0x6A, NUMPADMULTIPLY = 0x6A, ["Num *"] = 0x6A,
    Subtract = 0x6D, NumSubtract = 0x6D, NumPadSubtract = 0x6D, NUMPADSUBTRACT = 0x6D, ["Num -"] = 0x6D,
    Add = 0x6B, NumAdd = 0x6B, NumPadAdd = 0x6B, NUMPADADD = 0x6B, ["Num +"] = 0x6B,
    IntlBackslash = 0xE2, OEM_102 = 0xE2, NonUSBackslash = 0xE2,

    Escape = 0x1B, ESCAPE = 0x1B, Esc = 0x1B,
    Backspace = 0x08, BACK = 0x08,
    Tab = 0x09, TAB = 0x09,
    Enter = 0x0D, RETURN = 0x0D,
    NumPadEnter = 0x0D, NUMPADENTER = 0x0D, NumEnter = 0x0D,
    Control = 0x11, Ctrl = 0x11,
    LeftControl = 0xA2, LeftCtrl = 0xA2, LCONTROL = 0xA2,
    RightControl = 0xA3, RightCtrl = 0xA3, RCONTROL = 0xA3,
    Shift = 0x10,
    LeftShift = 0xA0, LShift = 0xA0, LSHIFT = 0xA0,
    RightShift = 0xA1, RShift = 0xA1, RSHIFT = 0xA1,
    Alt = 0x12,
    LeftAlt = 0xA4, LMenu = 0xA4, LMENU = 0xA4,
    RightAlt = 0xA5, RMenu = 0xA5, RMENU = 0xA5,
    Space = 0x20, SPACE = 0x20,
    CapsLock = 0x14, Capital = 0x14, ["Caps Lock"] = 0x14,

    F1 = 0x70,
    F2 = 0x71,
    F3 = 0x72,
    F4 = 0x73,
    F5 = 0x74,
    F6 = 0x75,
    F7 = 0x76,
    F8 = 0x77,
    F9 = 0x78,
    F10 = 0x79,
    F11 = 0x7A,
    F12 = 0x7B,
    F13 = 0x7C,
    F14 = 0x7D,
    F15 = 0x7E,
    F16 = 0x7F,
    F17 = 0x80,
    F18 = 0x81,
    F19 = 0x82,
    F20 = 0x83,
    F21 = 0x84,
    F22 = 0x85,
    F23 = 0x86,
    F24 = 0x87,

    Pause = 0x13,
    ScrollLock = 0x91, ["Scroll Lock"] = 0x91,
    PrintScreen = 0x2C, Snapshot = 0x2C, SysReq = 0x2C, ["Sys Req"] = 0x2C,

    NumPad7 = 0x67, NUMPAD7 = 0x67, ["Num 7"] = 0x67,
    NumPad8 = 0x68, NUMPAD8 = 0x68, ["Num 8"] = 0x68,
    NumPad9 = 0x69, NUMPAD9 = 0x69, ["Num 9"] = 0x69,
    NumPad4 = 0x64, NUMPAD4 = 0x64, ["Num 4"] = 0x64,
    NumPad5 = 0x65, NUMPAD5 = 0x65, ["Num 5"] = 0x65,
    NumPad6 = 0x66, NUMPAD6 = 0x66, ["Num 6"] = 0x66,
    NumPad1 = 0x61, NUMPAD1 = 0x61, ["Num 1"] = 0x61,
    NumPad2 = 0x62, NUMPAD2 = 0x62, ["Num 2"] = 0x62,
    NumPad3 = 0x63, NUMPAD3 = 0x63, ["Num 3"] = 0x63,
    NumPad0 = 0x60, NUMPAD0 = 0x60, ["Num 0"] = 0x60,
    Decimal = 0x6E, NumDecimal = 0x6E, NumPadDecimal = 0x6E, NUMPADDECIMAL = 0x6E, ["Num Del"] = 0x6E,
    Insert = 0x2D, INSERT = 0x2D,
    Delete = 0x2E, DELETE = 0x2E,
    Home = 0x24, HOME = 0x24,
    ["End"] = 0x23, END = 0x23,
    PageUp = 0x21, PRIOR = 0x21,
    PageDown = 0x22, NEXT = 0x22,
    Left = 0x25, LEFT = 0x25,
    Up = 0x26, UP = 0x26,
    Right = 0x27, RIGHT = 0x27,
    Down = 0x28, DOWN = 0x28,
    Divide = 0x6F, NumDivide = 0x6F, NumPadDivide = 0x6F, NUMPADDIVIDE = 0x6F,
}

local Key = VK

local VKToName = {
    [0x31] = "1", [0x32] = "2", [0x33] = "3", [0x34] = "4", [0x35] = "5",
    [0x36] = "6", [0x37] = "7", [0x38] = "8", [0x39] = "9", [0x30] = "0",
    [0xBD] = "-", [0xBB] = "=",
    [0x51] = "Q", [0x57] = "W", [0x45] = "E", [0x52] = "R", [0x54] = "T",
    [0x59] = "Y", [0x55] = "U", [0x49] = "I", [0x4F] = "O", [0x50] = "P",
    [0xDB] = "[", [0xDD] = "]",
    [0x41] = "A", [0x53] = "S", [0x44] = "D", [0x46] = "F", [0x47] = "G",
    [0x48] = "H", [0x4A] = "J", [0x4B] = "K", [0x4C] = "L",
    [0xBA] = ";", [0xDE] = "'", [0xC0] = "`", [0xDC] = "\\",
    [0x5A] = "Z", [0x58] = "X", [0x43] = "C", [0x56] = "V", [0x42] = "B",
    [0x4E] = "N", [0x4D] = "M", [0xBC] = ",", [0xBE] = ".", [0xBF] = "/",
    [0x6A] = "Num *", [0x6D] = "Num -", [0x6B] = "Num +", [0xE2] = "IntlBackslash",
    [0x1B] = "Escape", [0x08] = "Backspace", [0x09] = "Tab", [0x0D] = "Enter",
    [0x11] = "Control", [0xA2] = "LeftControl", [0xA3] = "RightControl",
    [0x10] = "Shift", [0xA0] = "LeftShift", [0xA1] = "RightShift",
    [0x12] = "Alt", [0xA4] = "LeftAlt", [0xA5] = "RightAlt",
    [0x20] = "Space", [0x14] = "CapsLock",
    [0x70] = "F1", [0x71] = "F2", [0x72] = "F3", [0x73] = "F4", [0x74] = "F5",
    [0x75] = "F6", [0x76] = "F7", [0x77] = "F8", [0x78] = "F9", [0x79] = "F10",
    [0x7A] = "F11", [0x7B] = "F12", [0x7C] = "F13", [0x7D] = "F14", [0x7E] = "F15",
    [0x7F] = "F16", [0x80] = "F17", [0x81] = "F18", [0x82] = "F19", [0x83] = "F20",
    [0x84] = "F21", [0x85] = "F22", [0x86] = "F23", [0x87] = "F24",
    [0x13] = "Pause", [0x91] = "ScrollLock", [0x2C] = "PrintScreen",
    [0x67] = "NumPad7", [0x68] = "NumPad8", [0x69] = "NumPad9",
    [0x64] = "NumPad4", [0x65] = "NumPad5", [0x66] = "NumPad6",
    [0x61] = "NumPad1", [0x62] = "NumPad2", [0x63] = "NumPad3",
    [0x60] = "NumPad0", [0x6E] = "Decimal",
    [0x2D] = "Insert", [0x2E] = "Delete", [0x24] = "Home", [0x23] = "End",
    [0x21] = "PageUp", [0x22] = "PageDown", [0x25] = "Left", [0x26] = "Up",
    [0x27] = "Right", [0x28] = "Down", [0x6F] = "Divide",
}

local VKToScan = {
    [0x31] = 0x02, [0x32] = 0x03, [0x33] = 0x04, [0x34] = 0x05, [0x35] = 0x06,
    [0x36] = 0x07, [0x37] = 0x08, [0x38] = 0x09, [0x39] = 0x0A, [0x30] = 0x0B,
    [0xBD] = 0x0C, [0xBB] = 0x0D,
    [0x51] = 0x10, [0x57] = 0x11, [0x45] = 0x12, [0x52] = 0x13, [0x54] = 0x14,
    [0x59] = 0x15, [0x55] = 0x16, [0x49] = 0x17, [0x4F] = 0x18, [0x50] = 0x19,
    [0xDB] = 0x1A, [0xDD] = 0x1B,
    [0x41] = 0x1E, [0x53] = 0x1F, [0x44] = 0x20, [0x46] = 0x21, [0x47] = 0x22,
    [0x48] = 0x23, [0x4A] = 0x24, [0x4B] = 0x25, [0x4C] = 0x26,
    [0xBA] = 0x27, [0xDE] = 0x28, [0xC0] = 0x29, [0xDC] = 0x2B,
    [0x5A] = 0x2C, [0x58] = 0x2D, [0x43] = 0x2E, [0x56] = 0x2F, [0x42] = 0x30,
    [0x4E] = 0x31, [0x4D] = 0x32, [0xBC] = 0x33, [0xBE] = 0x34, [0xBF] = 0x35,
    [0x6A] = 0x37, [0x6D] = 0x4A, [0x6B] = 0x4E, [0xE2] = 0x56,
    [0x1B] = 0x01, [0x08] = 0x0E, [0x09] = 0x0F, [0x0D] = 0x1C,
    [0x11] = 0x1D, [0xA2] = 0x1D, [0xA3] = 0xE01D,
    [0x10] = 0x2A, [0xA0] = 0x2A, [0xA1] = 0x36,
    [0x12] = 0x38, [0xA4] = 0x38, [0xA5] = 0xE038,
    [0x20] = 0x39, [0x14] = 0x3A,
    [0x70] = 0x3B, [0x71] = 0x3C, [0x72] = 0x3D, [0x73] = 0x3E, [0x74] = 0x3F,
    [0x75] = 0x40, [0x76] = 0x41, [0x77] = 0x42, [0x78] = 0x43, [0x79] = 0x44,
    [0x7A] = 0x57, [0x7B] = 0x58,
    [0x13] = 0x45, [0x91] = 0x46, [0x2C] = 0xE037,
    [0x67] = 0x47, [0x68] = 0x48, [0x69] = 0x49,
    [0x64] = 0x4B, [0x65] = 0x4C, [0x66] = 0x4D,
    [0x61] = 0x4F, [0x62] = 0x50, [0x63] = 0x51,
    [0x60] = 0x52, [0x6E] = 0x53,
    [0x2D] = 0xE052, [0x2E] = 0xE053, [0x24] = 0xE047, [0x23] = 0xE04F,
    [0x21] = 0xE049, [0x22] = 0xE051, [0x25] = 0xE04B, [0x26] = 0xE048,
    [0x27] = 0xE04D, [0x28] = 0xE050, [0x6F] = 0xE035,
}

local ScanCode = {}
local ScanToVK = {}
for name, vk_code in pairs(VK) do
    local scan_code = VKToScan[vk_code]
    if scan_code ~= nil then
        ScanCode[name] = scan_code
    end
end
for vk_code, scan_code in pairs(VKToScan) do
    ScanToVK[scan_code] = vk_code
end

local function resolve_key(value)
    if value == nil then
        return nil
    end

    if type(value) == "number" then
        return VKToScan[value] or value
    end

    if type(value) == "string" then
        local vk_code = VK[value]
        if vk_code ~= nil then
            return VKToScan[vk_code] or vk_code
        end
    end

    return nil
end

local function resolve_virtual_key(value)
    if value == nil then
        return nil
    end

    if type(value) == "number" then
        if VKToName[value] ~= nil then
            return value
        end
        return ScanToVK[value]
    end

    if type(value) == "string" then
        return VK[value]
    end

    return nil
end

local function describe_virtual_key(value)
    local vk_code = resolve_virtual_key(value)
    if vk_code == nil then
        return "unknown"
    end

    return VKToName[vk_code] or ("VK_" .. tostring(vk_code))
end

local MouseButton = {
    Left = 1,
    Right = 2,
    Middle = 4,
    X1 = 3,
    X2 = 4,
    WheelDown = 8,
    WheelUp = 16,
}

local MouseFlags = {
    MOVE = 0x0001,
    LEFTDOWN = 0x0002,
    LEFTUP = 0x0004,
    RIGHTDOWN = 0x0008,
    RIGHTUP = 0x0010,
    MIDDLEDOWN = 0x0020,
    MIDDLEUP = 0x0040,
    XDOWN = 0x0080,
    XUP = 0x0100,
    WHEEL = 0x0800,
    HWHEEL = 0x1000,
}

local WM = {
    MOUSEMOVE = 0x0200,
    LBUTTONDOWN = 0x0201,
    LBUTTONUP = 0x0202,
    RBUTTONDOWN = 0x0204,
    RBUTTONUP = 0x0205,
    MBUTTONDOWN = 0x0207,
    MBUTTONUP = 0x0208,
    MOUSEWHEEL = 0x020A,
}

local function describe_mouse_button(button)
    if button == MouseButton.Left then
        return "mouse left"
    end
    if button == MouseButton.Right then
        return "mouse right"
    end
    if button == MouseButton.Middle then
        return "mouse middle"
    end
    if button == MouseButton.X1 then
        return "mouse x1"
    end
    if button == MouseButton.X2 then
        return "mouse x2"
    end
    if button == MouseButton.WheelDown then
        return "mouse wheel down"
    end
    if button == MouseButton.WheelUp then
        return "mouse wheel up"
    end
    return "mouse " .. tostring(button)
end

keyboard_input.VK = VK
keyboard_input.ScanCode = ScanCode
keyboard_input.Key = Key
keyboard_input.VKToScan = VKToScan
keyboard_input.MouseButton = MouseButton
keyboard_input.MouseFlags = MouseFlags
keyboard_input.WM = WM
keyboard_input.resolveKey = resolve_key
keyboard_input.resolveVirtualKey = resolve_virtual_key
keyboard_input.describeVirtualKey = describe_virtual_key
keyboard_input.describeMouseButton = describe_mouse_button

local KeyboardWrapper = {}
KeyboardWrapper.__index = KeyboardWrapper

local function default_backend_call(_, _)
    return false
end

local function normalize_backend(backend)
    backend = backend or {}
    if backend.keyDown == nil then
        backend.keyDown = default_backend_call
    end
    if backend.keyUp == nil then
        backend.keyUp = default_backend_call
    end
    if backend.tapKey == nil then
        backend.tapKey = nil
    end
    return backend
end

local RELEASE_REPEAT_COUNT = 3
local RELEASE_REPEAT_INTERVAL = 0.05

function KeyboardWrapper.new(backend)
    return setmetatable({
        backend = normalize_backend(backend),
        keys = {},
        pending_releases = {},
    }, KeyboardWrapper)
end

function KeyboardWrapper:setBackend(backend)
    self.backend = normalize_backend(backend)
end

function KeyboardWrapper:setKeyDown(key)
    self.pending_releases[key] = nil
    local current = self.keys[key] or 0
    if current == 0 then
        self.keys[key] = 1
        self.backend:keyDown(key)
        return true
    end

    self.keys[key] = current + 1
    return false
end

function KeyboardWrapper:setKeyUp(key)
    local current = self.keys[key]
    if current == nil or current == 0 then
        return false
    end

    if current > 1 then
        self.keys[key] = current - 1
        return false
    end

    self.keys[key] = 0
    self.backend:keyUp(key)
    self.pending_releases[key] = {
        remaining = RELEASE_REPEAT_COUNT - 1,
        next_time = os.clock() + RELEASE_REPEAT_INTERVAL,
    }
    return true
end

function KeyboardWrapper:update(current_time)
    for key, pending in pairs(self.pending_releases) do
        if current_time >= pending.next_time then
            if self.keys[key] == 0 then
                self.backend:keyUp(key)
                pending.remaining = pending.remaining - 1
            end
            if pending.remaining <= 0 or self.keys[key] ~= 0 then
                self.pending_releases[key] = nil
            else
                pending.next_time = current_time + RELEASE_REPEAT_INTERVAL
            end
        end
    end
end

function KeyboardWrapper:setPressed(key)
    if self.backend.tapKey ~= nil then
        self.backend:tapKey(key)
        return true
    end

    self:setKeyDown(key)
    self:setKeyUp(key)
    return true
end

function KeyboardWrapper:reset()
    for key, count in pairs(self.keys) do
        if count ~= nil and count > 0 then
            self.keys[key] = 0
            self.backend:keyUp(key)
        end
    end
end

keyboard_input.KeyboardWrapper = KeyboardWrapper

_G.Key = _G.Key or Key
_G.VRKeyboardInput = keyboard_input

package.loaded[module_name] = keyboard_input

return keyboard_input