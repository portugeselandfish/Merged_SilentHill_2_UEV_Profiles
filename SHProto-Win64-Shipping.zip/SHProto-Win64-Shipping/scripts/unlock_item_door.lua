--[[
  Item Door (unlock_item_door) 主模块
  - 对应计划 plans/sh2_unlock_item_door_plan.md
  - 方案B 已确认：spawn 真实钥匙走 ItemBase_BP_C + Deferred 写 ItemData（用门 UnlockItem 自带 DataTable+RowName），
    引擎 FindRow 出真实钥匙 mesh + SHItemAudioComponent，无需手动映射表。
  - Phase 1 落地：L1 道具门缓存 + L2 3m 过滤 + 道具已获取检查（has_item）。
  - 日志：走 _G.ITEM_DOOR_DIAG_WRITE_LOG（由 diagnose_item_door 暴露，受其 Enable Logging 开关管理），
    标记 [ITEM_DOOR]。不得直接 print 到 UEVR 控制台。
--[[修改说明（性能审计，2026-09-01）：
1. begin_insert 移除 cache MISS 时的 load_doorattachment_mesh 兜底全图枚举。
   依据：spawn 阶段已缓存 doorattachment 变体（spawn_variant_cache[actor]），insert 不会 MISS；
   若变体真不存在，spawn 期已枚举找过且失败，MISS 再枚举一遍同样找不到，属恒无收益死代码。
   注释后 insert 直接复用 spawn 变体缓存，消除插钥匙环节潜在的全图扫描卡顿，不影响现有功能。
]]
--[[
  Item Door (unlock_item_door) 主模块
--[[修改说明（Phase 4a：拧钥匙 + 解锁门，2026-08-18 实施，对齐计划 §5/§9 Phase 4a）：
1. GrabPhase 新增 Rotating/Unlocked 两态；插入落座时 Grip 仍按住 → 挂附左手（幂等）+
   直接 begin_rotate（插入、拧钥匙一气呵成，不要求松手重按，用户拍板）。
2. 拧转数学完全对齐 unlock_door ROTATING（照抄 + math_lib，不封装）：
   左手 Pitch delta × sensitivity(3.0) → 只允许逆时针（正 delta 归零）→ clamp ≤90° →
   rotatorFromAxisAndAngle + composeRotators 写钥匙 root 旋转（位置钉死落座点，停 tick_seated 防打架 G5）。
3. Grip 松开即脱附（用户 2026-08-18 拍板：grip 才是明确的松开意图，detach 不做距离检测）：
   Rotating 松手未拧到位 → 回弹动画（钥匙自转回 0°，手已脱附不跟随）→ 回 Seated；
   Seated 手已脱附 + Grip 按下沿 + 手近钥匙(GRAB_DISTANCE_CM=20) → 重挂附 + 直接重拧（G2 重抓路径）。
4. 拧到位（progress≥1，rotate_completed 防重）→ eventFeedback.play_latch_haptic（11号文件震动）
   + apply_unlock 复用 unlock_door.unlock_door_directly（SetLocked(false,true) 直解；
   RemoveItem/LoadAndTrySetKeyMesh/finalize 销毁属 4b 暂缓，临时钥匙钉死保留）。
5. 音效 Play_Key_Unlock 走 libs/audio（register_event 幂等 + play_segment，开始拧时播，对齐
   unlock_door begin_rotate 末尾；时长优先查 Wwise MaximumDuration，失败兜底 2s；
   on_grab_tick 每帧 audio.tick，pistol/rifle/shotgun 同模式）。
6. 拧到位后松手 → Unlocked（过渡态）→ 清抓取状态回 Idle（spawned_keys 条目保留）。
]]
--[[修改说明（Phase 3 收尾：插入期左手跟随钥匙，§7.1，2026-08-18）：
1. begin_insert 进入 Inserting 时零偏移挂附左手到钥匙 root（unlock_door 式直接回调
   executeUEVRCallbacks("on_accessory_attach")，底层 hands.lua attachHandToTarget），
   手随钥匙一起滑入、落座后跟随滑块重钉——"手跟钥匙"。
2. 脱附仅两条路径：① Inserting/Seated 期松开左 Grip（手恢复正常追踪，钥匙状态不变）；
   ② grab_reset 异常路径（过场/actor 丢失/换关）统一自动脱附。
   Seated 后不强制脱附：只要左 Grip 按住就一直吸附，为 Phase 4 拧钥匙"一气呵成"留路。
3. M.init 热重载强制脱附一次（防旧 state 无标记导致手永久挂在已销毁的旧钥匙 actor 上）。
4. 诊断日志标记 [HAND-FOLLOW]，走 ITEM_DOOR_DIAG_WRITE_LOG 通道，不写 UEVR 控制台。
]]
--[[修改说明（钥匙偏移持久化：主脚本自管整表，对齐 RE9 save_spawn/load_spawn）：
1. 主脚本自管 data/keys.json：内存 state.key_offsets 是"每把钥匙一条"的整表；
   新增条目：钥匙首次被抓取（get_key_offset 惰性建）即建默认(0,0,0)并落盘。
2. 加载 load_key_offsets() 仅在 json 全局就绪后执行，且只合并不覆盖已有内存，
   避免"早期加载失败→回填默认→重启把已有数据重置为 0,0,0"的旧 bug。
3. 钥匙偏移 configui 面板（Item Door Key Offset）：2026-08-21 恢复（用户要求保留滑块 UI），
   经 main.lua 开发者模式门控注册；偏移真源仍是 data/keys.json（主脚本自管整表）。
]]

--[[修改说明（性能优化，2026-08-31，仅热路径去开销，不改功能语义）：
1. ensure_key_offsets 的非法键清理（空键/非字符串键）从"每次 get_key_offset 都全表扫描"
   改为一次性校验（首次访问/磁盘合并后跑一次），Seated/Holding 每帧 2~4 次的 O(N) 遍历归零。
2. door_spawn_allowed 的背包检查改用 L2 快照字段 e.has_item（update_item_door_l2 同一秒已算过），
   消除对同一扇门每秒 2 次的 HasItem 引擎调用。
3. apply_key_hand_offset 增加脏检查：偏移值与上次写入一致则跳过 2 次组件属性引擎写；
   失效点：begin_grab_from_cache / grab_reset / begin_insert / drop_key_at_home（后两者归零相对变换）。
4. poll_variant_swap 增加 state.variant_pending 待检查计数，全部换装完成后整帧直接 return，
   不再每帧空转遍历 spawned_keys；spawn/销毁处置 nil 触发下帧重数一次。
]]--

--[[修改说明（2026-09-04，统一 pawn 检测，方案A）：
1. pawn 变化检测从本文件上移到 main.lua（check_pawn_globally 广播 on_pawn_changed）。
2. 本文件 check_pawn_invalidation 改为只驱动 L1 重建调度（5s 延迟 + 0 条目 2s 重试）+ 类预热，不再 get_local_pawn。
3. 新增 M.on_pawn_changed(reason)：pawn_nil 清 pending/retry；pawn_changed/level_change 调度重建。
4. M.on_level_change 改为转发 on_pawn_changed("level_change")。不新增诊断日志。
]]--

local uevrUtils = require("libs/uevr_utils")
local uevrLib = require("libs.core.uevr_lib") -- 仅用其 clearClassCache（定向查询失败时清 nil 坏缓存）
local reload_tools = require("libs/reload_tools")
local attachments = require("libs/attachments")   -- 附件挂载/卸载（attachToMesh / detachSingleAttachment）
local spin = require("libs/spin")   -- 通用沿世界 Z 轴自转动画工具
local controllers = require("libs/controllers")  -- 手部控制器
local hands = require("libs/hands")              -- 手部动画/姿势
local configui = require("libs/configui")        -- 配置面板（hand type 判定用）
local ik = require("libs/ik")                    -- IK 骨骼控制
local math_lib = require("libs.core.math_lib")   -- 数学库（四元数/子世界变换）
local audio = require("libs/audio")             -- Wwise 段落播放器（Phase 4a 拧钥匙音效）
local vr_globals = require("UEVR_00_init_globals") -- 全局变量注册表（isLeftGripHeld）
local remote_grab = require("remote_grab")  -- 复用其 rt_* 纯工具（左手解析/手位世界坐标/插值/附着选项）
local unlock_door = nil
pcall(function()
    unlock_door = require("unlock_door")  -- 复用其左手真实位置暴露（VR 控制器位置，非 IK 小臂）
end)
local eventFeedback = nil
pcall(function()
    eventFeedback = require("UEVR_11_EventFeedback") -- 触觉反馈
end)

local M = {}

-- =============================================================================
-- 常量
-- =============================================================================
local ITEM_DOOR_PREFIXES = {
    "DA_SingleDoor_Lock_",
    "DA_DoubleDoor_Lock_",
}
local SCAN_INTERVAL_MS = 1000      -- L2 3m 近距筛选间隔
local SCAN_RANGE_CM = 300          -- 3m（以玩家为中心）
local L1_REBUILD_DELAY_S = 5.0     -- Pawn 生命周期触发 L1 重建延迟
local L1_RETRY_DELAY_S = 2.0       -- 0 条目时重试间隔（对齐 unlock_door.lua 5s+2s 机制）
local L1_RETRY_MAX = 2              -- L1 为 0 条目时持久重试上限：扫到 0 持续重试至 2 次，扫出 >0 提前停止
-- Phase 2 spawn（本次仅目测偏移，不做抓取）
local SPAWN_ABOVE_LOCK_CM = 20     -- 门锁上方 20cm（锁 actor 本地 up 轴）
local KEY_SPIN_PERIOD_S = 5.0      -- 钥匙生成后沿世界 Z 轴自转一圈秒数
local ITEM_BASE_CLASS_PATH = "BlueprintGeneratedClass /Game/Game/Gameplay/Interactions/Items/ItemBase_BP.ItemBase_BP_C"
-- Phase 2 远程抓取（复用 remote_grab 范式，不做射线）
local GRAB_DISTANCE_CM = 20        -- 左手 hand_l_bn 与钥匙距离阈值（cm）
local FLIGHT_DURATION = 0.3        -- 钥匙飞行召回时长（秒）
local LEFT_ATTACH_SOCKET = "hand_l_bn"  -- 左手附着插槽名
-- Phase 3 插入（钥匙从手滑入锁孔）
local INSERT_TRIGGER_DISTANCE_CM = 10  -- Holding 期手持钥匙距锁孔阈值，小于则自动触发插入
local INSERT_TRACK_LEN_CM = 5         -- 插入通道长度：终点沿插入反向再向外延伸的长度（cm）
-- 最终落点沿插入反向（朝玩家）拉回的长度（cm，默认 6）。每把钥匙可在 keys.json 的 pullback 字段单独配置。
local KEY_PULLBACK_DEFAULT_CM = 0
local INSERT_DURATION = 0.5          -- 插入滑入时长（秒）【临时放慢便于观察插入方向，校准后改回 1.0】
-- 插入期手部挂附偏移组：手网格相对钥匙 root 的本地位置(loc, cm)与旋转(rot, 度 {pitch,yaw,roll})。
-- 只作用于手网格自身 RelativeTransform（hands.lua attachHandToTarget），钥匙位姿不受影响。
-- 2026-08-20：零偏移时手被锁孔朝向绑架导致插入后前后反转；此组经诊断滑块调校定稿（用户拍板）。
-- UE 绕轴：pitch=绕 Y、yaw=绕 Z、roll=绕 X。
local HAND_ATTACH_OFFSET = {
    loc = { -6.25, 2.25, -1.375 },
    rot = { 45, -176.625, 4.5 },
}
-- 每把钥匙手部偏移默认值（复用 unlock_door 拧钥匙手势偏移）
local DEFAULT_KEY_OFFSET = { loc = { -0.250, -1.250, 6.125 }, rot = { 87.750, 121.500, -6.750 } }
-- Phase 4a 拧钥匙常量（对齐 unlock_door ROTATING；sensitivity 对齐其 M_DIAGNOSTIC 默认 3.0）
local KEY_ROTATE_THRESHOLD_DEG = 90     -- 转够 90° 解锁
local KEY_ROTATE_SENSITIVITY = 3.0      -- 手 Pitch → 有效转角放大系数（手拧 30° → 有效 90°）
-- 拧转开始阈值：手逆时针有效转角（×sensitivity，与 90° 完成同口径）超 10° 才视为真正开始拧，
-- 此时才播"拧钥匙音效"，过滤落座瞬间手的微小抖动（复用 effective_delta，不新增底层数学工具）
local KEY_ROTATE_START_THRESHOLD_DEG = 10
local KEY_ROTATE_RETURN_S = 0.15        -- 未拧到位松手回弹时长（对齐 unlock_door RETURN_DURATION）
-- Phase 4b finalize：LoadAndTrySetKeyMesh 异步就绪轮询超时兜底（G4；实测就绪 ~21ms，此值极大余量）
local FINALIZE_READY_TIMEOUT_S = 2.0
-- Phase 4a 音效（libs/audio；事件路径与 unlock_door play_key_unlock_sound 一致）
local KEY_UNLOCK_AUDIO_KEY = "item_door_key_unlock"
local KEY_UNLOCK_EVENT = "Play_Key_Unlock"
local KEY_UNLOCK_EVENT_PATH = "/Game/WWiseAudio/Events/Enviro/Doors/Play_Key_Unlock.Play_Key_Unlock"
local KEY_UNLOCK_AUDIO_FALLBACK_S = 2.0 -- MaximumDuration 查询失败时的播放时长兜底
-- 抓取阶段枚举
local GrabPhase = {
    Idle = "idle",        -- 空闲：钥匙在原地自转，等待接近/抓取
    Flying = "flying",    -- 飞行：钥匙从当前位置插值飞到左手
    Holding = "holding",  -- 持有：钥匙附着左手（松手不再飞回，一直粘在手上）
    Inserting = "inserting",  -- 插入：钥匙沿固定通道滑入锁孔
    Seated = "seated",    -- 已插入：钥匙钉死在锁孔位（Phase 4a 起兼作"拧转等待态"）
    Rotating = "rotating",   -- 拧钥匙：绕锁孔 Y 轴逆时针拧 90°（Phase 4a，对齐 unlock_door ROTATING）
    Unlocked = "unlocked",   -- 已解锁过渡态：拧到位松手 → 清抓取状态回 Idle（finalize 属 4b）
}

-- =============================================================================
-- 状态（持久化到全局：热重载复用同一 state，避免 interval 重复注册 / actor 泄漏）
-- =============================================================================
local state = rawget(_G, "__SH2_UNLOCK_ITEM_DOOR_STATE")
if type(state) ~= "table" then
    state = {
        enabled = true,
        -- L1 全图道具门缓存（关卡加载时构建，不做距离过滤）
        door_cache = nil,
        door_cache_valid = false,
        -- L2 3m 内缓存（每秒更新）
        cached_doors = {},
        -- Phase 2 已 spawn 的钥匙表演体（door_name -> { actor, t_spawn }，仅偏移目测用）
        spawned_keys = {},
        -- spawn 期已解析的门挂变体 mesh 缓存（actor -> StaticMesh）：生成钥匙时拿到一次，
        -- 插钥匙（begin_insert）直接复用，跳过 load_doorattachment_mesh 重复查找（含全图枚举兜底）
        spawn_variant_cache = {},
        -- Phase 2 钥匙 spawn 本地三轴偏移（cm，只影响 position，rotation 保持锁朝向）
        -- right=-5 = pullback 方向整体挪 5cm（锁孔本地 -Y，与 insert_end_point 同轴；2026-08-17 用户拍板，全钥匙统一）
        spawn_offset = { forward = 0, right = 5, up = 20 },
        -- Phase 2 钥匙 spawn 旋转偏移（度，叠加到基准旋转，控制钥匙朝向）
        spawn_rot_offset = { pitch = 0, yaw = 0, roll = 90 },
        -- Pawn 生命周期 / L1 重建调度
        last_pawn_ref = nil,
        l1_rebuild_pending = false,
        l1_rebuild_time = 0,
        l1_retry_pending = false,
        l1_retry_time = 0,
        -- 类预热（2026-09-03 卡顿修复）：session 首次 spawn 的 get_class 阻塞加载（~160ms）提前消化
        class_warmup_pending = false,
        class_warmup_done = false,
        class_warmup_time = 0,
        class_warmup_tries = 0,
        -- 注册标记（热重载不重复挂）
        interval_registered = false,
        -- 代际计数器：热重载自增，旧 interval 闭包捕获旧 gen，校验不匹配即失效（防残留叠加）
        gen = 0,
        -- Phase 2 远程抓取状态
        grab_phase = GrabPhase.Idle,     -- 抓取阶段 idle/flying/holding
        last_grip_pressed = false,       -- 左 Grip 上一帧按住状态（边沿检测）
        grab_door_name = nil,            -- 当前抓取/持有钥匙所属门名
        grab_key_name = nil,             -- 当前钥匙配置键名（UnlockItem.RowName）
        grab_actor = nil,                -- 当前抓取/持有对应的 Itembase actor
        flight_start_t = nil,            -- 飞行开始时间
        flight_start_loc = nil,          -- 飞行起点位置
        flight_start_rot = nil,          -- 飞行起点旋转
        flight_end_loc = nil,            -- 飞行终点位置
        flight_end_rot = nil,            -- 飞行终点旋转
        pawn_tick_registered = false,    -- postEngineTick 每帧 grab tick 是否已注册
        -- 每把钥匙手部偏移配置（惰性按需创建，写回 JSON）
        key_offsets = nil,               -- { [key_name] = { loc={..}, rot={..} }, default=... }
        -- 钥匙偏移面板当前编辑钥匙（nil = default；抓取钥匙时自动切换）
        diag_key = nil,
        -- Phase 3 收尾（§7.1）：插入期左手吸附钥匙标记（热重载持久，防中途重载后标记丢失）
        hand_attached_to_key = false,
        -- Phase 4a：拧钥匙（Rotating）状态（begin_rotate 时重置）
        rotate_axis = nil,                -- 旋转轴（锁孔 KeyStaticMesh local Y 世界向量）
        rotate_body_rot = nil,            -- 旋转基准（落座旋转）
        rotate_start_pitch = 0,           -- 拧转开始时左手 Pitch 基准
        rotate_started = false,           -- 拧已真正开始（有效转角超阈值才置真，决定是否播拧转音效）
        rotate_progress = 0,              -- 拧转进度 0~1
        rotate_completed = false,         -- 拧到位标记（防重复 apply_unlock）
        rotate_returning = false,         -- 未拧到位松手回弹动画中
        rotate_return_start_t = 0,        -- 回弹开始时刻
        rotate_return_start_progress = 0, -- 回弹起始进度
        -- Phase 4b finalize（松开左 Grip 触发；顺序不可换 G3）
        finalize_started = false,         -- finalize 已启动（防重复 begin）
        finalize_lock = nil,              -- 门锁 actor（LoadAndTrySetKeyMesh 目标）
        finalize_temp = nil,              -- 待销毁临时钥匙 actor
        finalize_row = nil,               -- RowName（RemoveItem 用）
        finalize_key = nil,               -- spawned_keys 条目键（= grab_door_name）
        finalize_t0 = nil,                -- finalize 启动时刻（异步就绪超时 G4 基准）
        -- Phase 4b 跟随（拧到位即启动，非松手后）：表演体每帧跟随锁孔 KeyStaticMesh 组件位姿。
        -- 门解锁后可能被推开（组件随门动），真钥匙 mesh 此时未渲染但组件位置可读——表演体贴着组件走，
        -- 松手 finalize 挂真钥匙、就绪销毁表演体，全程无缝（保持相对姿态，零跳变）。
        follow_sm = nil,                 -- 跟随目标：锁孔 KeyStaticMesh 组件
        follow_local_pos = nil,          -- 表演体相对组件的本地位置偏移（启动时快照）
        follow_local_rot = nil,          -- 表演体相对组件的本地旋转偏移（启动时快照）
        follow_started = false,          -- 跟随已启动
        -- Holding 松手 → 钥匙插值飞回 spawn 原位（复用 rt_tick_flight；否则 Holding 态残留挡住抓下一把，见 edge_released 缺项）
        flight_return_home = false,      -- 是否在飞回原位（true 时 tick_grab_flying 以 spawn 原位为终点）
        flight_home_pos = nil,           -- 钥匙 spawn 原位（world 位置）
        flight_home_rot = nil,           -- 钥匙 spawn 原位（world 旋转）
        -- Phase 5 前置检查：spawn 拦截原因记录（door_name -> reason；仅变化时打日志防 1s 刷屏）
        spawn_block = {},
    }
    _G.__SH2_UNLOCK_ITEM_DOOR_STATE = state
end

-- 硬编滚动：每次加载强制 roll=90（覆盖历史持久化值，保证钥匙朝向一致）
if state.spawn_rot_offset == nil then state.spawn_rot_offset = { pitch = 0, yaw = 0, roll = 0 } end
state.spawn_rot_offset.roll = 90
-- 热重载守卫：旧 state 无新字段时补建
if state.spawn_block == nil then state.spawn_block = {} end
if state.follow_started == nil then state.follow_started = false end
if state.flight_return_home == nil then state.flight_return_home = false end

-- =============================================================================
-- 日志（受诊断脚本开关管理，禁止刷屏）
-- =============================================================================
local function log(tag, msg)
    local fn = rawget(_G, "ITEM_DOOR_DIAG_WRITE_LOG")
    if fn ~= nil then
        pcall(fn, string.format("[%s] %s", tag, msg))
    end
end

-- =============================================================================
-- 工具
-- =============================================================================
local function distance_sq(a, b)
    if a == nil or b == nil then return math.huge end
    local dx = (a.X or 0) - (b.X or 0)
    local dy = (a.Y or 0) - (b.Y or 0)
    local dz = (a.Z or 0) - (b.Z or 0)
    return dx * dx + dy * dy + dz * dz
end

-- 左手 grip 按下判定：主链路 09 gripLeft.enter/leave（g_left_grip_held），
-- fallback 读 VREnvironment.state.leftGrip 原始值（>0.5 视为按下）。
-- 与 unlock_door.is_left_grip_pressed 同构，避免 gripLeft 手势未触发时漏判。
local function is_left_grip_pressed()
    if vr_globals ~= nil and type(vr_globals.isLeftGripHeld) == "function" then
        if vr_globals.isLeftGripHeld() == true then
            return true
        end
    end
    local env = rawget(_G, "VREnvironment")
    if type(env) == "table" then
        local left_grip = env.state and env.state.leftGrip
        if left_grip == true then
            return true
        end
        if type(left_grip) == "number" and left_grip > 0.5 then
            return true
        end
    end
    return false
end

-- 判读 Actor 类名是否道具门
local function is_item_door_actor(actor_name)
    if actor_name == nil then return false end
    for _, p in ipairs(ITEM_DOOR_PREFIXES) do
        if string.find(actor_name, p, 1, true) then
            return true
        end
    end
    return false
end

-- 读取 UnlockItem（FDataTableRowHandle）的 RowName / DataTable
-- RowName 是 FName 属性：UEVR 返回 userdata（非 Lua 字符串），必须在读取边界转字符串；
-- 否则以 userdata 作 state.key_offsets 的键，json.dump_file 会序列化成 ""（空键 bug 根因）。
-- 引擎调用处（写 ItemData.RowName / HasItem）需用 uevrUtils.fname_from_string 转回 FName。
local function read_unlock_item(actor)
    local handle = nil
    pcall(function() handle = actor["UnlockItem"] end)
    if handle == nil then return nil end
    local row_name = nil
    local dt = nil
    pcall(function()
        local rn = handle.RowName
        if rn ~= nil then
            if type(rn.to_string) == "function" then
                rn = rn:to_string()
            end
            row_name = tostring(rn)
        end
    end)
    pcall(function() dt = handle.DataTable end)
    return { row_name = row_name, data_table = dt }
end

-- 读取门锁 KeyStaticMesh 是否 nil（nil = 门锁为空，需道具解锁）
local function read_key_mesh(actor)
    local mc = nil
    pcall(function() mc = actor["KeyStaticMesh"] end)
    if mc == nil then
        return nil
    end
    local sm = nil
    pcall(function() sm = mc.StaticMesh end)
    return sm
end

-- 读取 HasUnlockItemAlready（是否已解锁挂钥匙）
local function read_has_unlock_already(actor)
    local v = nil
    pcall(function() v = actor["HasUnlockItemAlready"] end)
    return v == true
end

-- =============================================================================
-- L1：全图道具门缓存（仅关卡加载时构建）
-- 筛选：Actor 类名匹配 + UnlockItem.RowName 非空（占位行 DaOnly_Universal/DAOnly_TestKey/None 排除）
-- =============================================================================
local function build_item_door_cache()
    if not state.enabled then return end
    state.l1_build_t0 = os.clock() -- 卡顿排查 2026-09-03：重建耗时统计

    -- =========================================================================
    -- L1 扫描（性能优化 2026-08-30，v2）：BP 基类定向查询实机返回 0 实例（DIAG: EMPTY TABLE，
    -- UObjectHook get_objects_by_class 对 BP 基类不含子类实例），改查原生 C++ 基类
    -- SHDoorAttachment——所有门锁最终继承它（事实表 §10.5.1），原生类查询含子类
    -- （unlock_door 的 SHSlidingDoor 同模式已实机验证），再按 DA_*_Lock_* 前缀过滤。
    -- =========================================================================
    local ITEM_DOOR_BASE_NATIVE = "Class /Script/SHProto.SHDoorAttachment"

    local matches = {}
    local any_failed = false
    local actors = nil
    local query_ok = pcall(function() actors = uevrUtils.find_all_of(ITEM_DOOR_BASE_NATIVE, false) end)
    if not query_ok or actors == nil then
        any_failed = true
        log("INFO", string.format("[ITEM_DOOR] L1 scan DIAG: %s → %s",
            ITEM_DOOR_BASE_NATIVE, query_ok and "NIL (class resolve failed)" or "QUERY ERROR"))
        pcall(function() uevrLib.clearClassCache(ITEM_DOOR_BASE_NATIVE) end)
    else
        if #actors == 0 then
            log("INFO", string.format("[ITEM_DOOR] L1 scan DIAG: %s → EMPTY TABLE", ITEM_DOOR_BASE_NATIVE))
        end
        for _, actor in ipairs(actors) do
            local actor_name = nil
            pcall(function() actor_name = actor:get_full_name() end)
            if actor_name == nil or not is_item_door_actor(actor_name) then
                goto continue_door
            end
            local ui = read_unlock_item(actor)
            if ui == nil or ui.row_name == nil then goto continue_door end
            local rn = tostring(ui.row_name)
            -- 排除占位行（门饰表 / 测试钥匙）
            if rn == "None" or rn == "DaOnly_Universal" or rn == "DAOnly_TestKey" then
                goto continue_door
            end
            table.insert(matches, {
                actor = actor,
                name = actor_name,
                row_name = ui.row_name,
                data_table = ui.data_table,
                key_mesh = read_key_mesh(actor),          -- nil = 门锁空，需道具解锁
                has_unlock_already = read_has_unlock_already(actor),
            })
            ::continue_door::
        end
    end
    if any_failed then
        log("INFO", "[ITEM_DOOR] L1 scan: door attachment class query FAILED (nil/error)")
    end

    state.door_cache = matches
    state.door_cache_valid = true
    -- 2026-09-03 卡顿排查：L1 重建是全 Actor 枚举（审计口径的重操作），记录耗时定位周期性卡顿
    log("INFO", string.format("[ITEM_DOOR] L1 cache built: %d item doors (took %.1fms, reason=%s)",
        #matches, (os.clock() - (state.l1_build_t0 or os.clock())) * 1000, tostring(state.l1_build_reason or "unknown")))
end

-- =============================================================================
-- L2：每秒从 L1 筛选 3m 内道具门，并对每扇做道具已获取判定（has_item）
-- =============================================================================
local function update_item_door_l2()
    if not state.door_cache_valid or state.door_cache == nil then return end

    local pawn = uevrUtils.get_local_pawn()
    if pawn == nil then return end
    local pawn_loc = nil
    pcall(function()
        if pawn.K2_GetActorLocation ~= nil then pawn_loc = pawn:K2_GetActorLocation() end
    end)
    if pawn_loc == nil then return end

    local results = {}
    local range_sq = SCAN_RANGE_CM * SCAN_RANGE_CM
    for _, entry in ipairs(state.door_cache) do
        local loc = nil
        pcall(function()
            if entry.actor ~= nil and entry.actor.K2_GetActorLocation ~= nil then
                loc = entry.actor:K2_GetActorLocation()
            end
        end)
        if loc == nil then goto continue_l2 end
        local dist_sq = distance_sq(loc, pawn_loc)
        if dist_sq <= range_sq then
            table.insert(results, {
                actor = entry.actor,
                name = entry.name,
                row_name = entry.row_name,
                data_table = entry.data_table,
                key_mesh = entry.key_mesh,
                has_unlock_already = entry.has_unlock_already,
                dist_to_pawn_cm = math.sqrt(dist_sq),
                has_item = M.has_item(entry.row_name),
            })
        end
        ::continue_l2::
    end
    state.cached_doors = results
end

-- =============================================================================
-- Phase 2（部分）：为 L2 内道具门在锁上方 20cm 生成钥匙表演体（仅目测偏移，不做抓取）
-- 方案B：Deferred spawn ItemBase_BP_C + 先写 ItemData（表+行同属 UnlockItem）→ Finish，
--        引擎 BeginPlay 读 ItemData 出真实钥匙 mesh（异步 ~3s 流式加载）
-- =============================================================================
-- 从 rotator（pitch/yaw/roll 度）计算世界 up（UE 旋转矩阵 Z 行）
local function up_from_rot(r)
    local cy, sy = math.cos(math.rad(r.Yaw or 0)), math.sin(math.rad(r.Yaw or 0))
    local cr, sr = math.cos(math.rad(r.Roll or 0)), math.sin(math.rad(r.Roll or 0))
    local cp, sp = math.cos(math.rad(r.Pitch or 0)), math.sin(math.rad(r.Pitch or 0))
    return {
        X = cr * sp * cy + sr * sy,
        Y = cr * sp * sy - sr * cy,
        Z = cr * cp,
    }
end

-- 世界 forward（UE 旋转矩阵 X 行）
local function fwd_from_rot(r)
    local cy, sy = math.cos(math.rad(r.Yaw or 0)), math.sin(math.rad(r.Yaw or 0))
    local cp, sp = math.cos(math.rad(r.Pitch or 0)), math.sin(math.rad(r.Pitch or 0))
    return { X = cy * cp, Y = sy * cp, Z = -sp }
end

-- 世界 right（UE 旋转矩阵 Y 行）
local function right_from_rot(r)
    local cy, sy = math.cos(math.rad(r.Yaw or 0)), math.sin(math.rad(r.Yaw or 0))
    local cr, sr = math.cos(math.rad(r.Roll or 0)), math.sin(math.rad(r.Roll or 0))
    local cp, sp = math.cos(math.rad(r.Pitch or 0)), math.sin(math.rad(r.Pitch or 0))
    return {
        X = -sy * cr + cy * sp * sr,
        Y = cy * cr + sy * sp * sr,
        Z = cp * sr,
    }
end

-- 计算钥匙 spawn 点：基准 = 锁 actor 的 KeyStaticMesh 组件（位置 + 本地 forward/right/up 轴）
-- 钥匙该放的位置就是 KeyStaticMesh 处（锁 actor 坐标即钥匙 mesh 坐标），无需导航门体 DoorMesh。
-- 三轴偏移均用 KeyStaticMesh 本地轴（稳定，不随玩家位置变化）。
-- 返回 (pos, rot)；rot 为 KeyStaticMesh 组件旋转（钥匙朝向跟随）。
local function lock_spawn_point(entry)
    -- 偏移为锁孔本地轴；right=-5 = pullback 方向整体挪 5cm（与 insert_end_point 的 -right 同轴，2026-08-17 用户拍板，全钥匙统一）
    local ofs = state.spawn_offset or { forward = 0, right = -5, up = 20 }

    -- 基准：锁 actor 的 KeyStaticMesh 组件位置 + 旋转
    local base = nil
    local rot = nil
    pcall(function()
        local mc = entry.actor["KeyStaticMesh"]
        if mc ~= nil then
            base = reload_tools.get_component_world_location(mc)
            rot = reload_tools.get_component_world_rotation(mc)
        end
    end)
    -- 回退：无 KeyStaticMesh 用锁 actor 自身位置/旋转
    local actor_rot = nil
    if base == nil then
        pcall(function()
            if entry.actor.K2_GetActorLocation ~= nil then base = entry.actor:K2_GetActorLocation() end
        end)
        pcall(function()
            if entry.actor.K2_GetActorRotation ~= nil then actor_rot = entry.actor:K2_GetActorRotation() end
        end)
    end
    if base == nil then return nil, nil end
    rot = rot or actor_rot or { Pitch = 0, Yaw = 0, Roll = 0 }

    -- 应用 rotation 滑块偏移（pitch/yaw/roll 度，叠加到基准旋转，仅控制钥匙朝向）
    local rot_ofs = state.spawn_rot_offset or { pitch = 0, yaw = 0, roll = 0 }
    local final_rot = {
        Pitch = (rot.Pitch or 0) + (rot_ofs.pitch or 0),
        Yaw = (rot.Yaw or 0) + (rot_ofs.yaw or 0),
        Roll = (rot.Roll or 0) + (rot_ofs.roll or 0),
    }

    -- 位置偏移轴用【未加旋转偏移的】基准旋转 rot：保证 up/forward/right 方向不随 roll 偏移旋转，
    -- 否则 roll=90 会把 up=20 的偏移转到水平方向导致钥匙偏离门锁而看不见。
    local f = fwd_from_rot(rot)
    local r = right_from_rot(rot)
    local u = up_from_rot(rot)

    return {
        X = (base.X or 0) + f.X * (ofs.forward or 0) + r.X * (ofs.right or 0) + u.X * (ofs.up or 0),
        Y = (base.Y or 0) + f.Y * (ofs.forward or 0) + r.Y * (ofs.right or 0) + u.Y * (ofs.up or 0),
        Z = (base.Z or 0) + f.Z * (ofs.forward or 0) + r.Z * (ofs.right or 0) + u.Z * (ofs.up or 0),
    }, final_rot
end

-- Phase 3: 纯锁孔位（无 spawn_offset）。返回 KeyStaticMesh 组件世界位置 + 旋转（钥匙插入终点/朝向基准）。
local function lock_seat_point(entry)
    local pos, rot = nil, nil
    pcall(function()
        local mc = entry.actor["KeyStaticMesh"]
        if mc ~= nil then
            pos = reload_tools.get_component_world_location(mc)
            rot = reload_tools.get_component_world_rotation(mc)
        end
    end)
    if pos == nil then return nil, nil end
    if rot == nil then rot = { Pitch = 0, Yaw = 0, Roll = 0 } end
    return pos, rot
end

-- Phase 3 共享：最终停止点/距离检测点 = 锁孔位(seat) + 插入反向(-axis) 按 pullback 拉回玩家侧。
-- 插入轴用锁孔 mesh 本地 Y 取反（与 begin_insert 保持一致）。pullback 由调用点按该钥匙配置传入。
-- 返回 end_loc 或 nil（无 KeyStaticMesh）。
local function insert_end_point(entry, pullback)
    local seat_loc, seat_rot = lock_seat_point(entry)
    if seat_loc == nil then return nil end
    local pb = tonumber(pullback) or KEY_PULLBACK_DEFAULT_CM
    local axis0 = right_from_rot(seat_rot)
    local axis = { X = -axis0.X, Y = -axis0.Y, Z = -axis0.Z }
    if axis == nil then axis = { X = 0, Y = 0, Z = 1 } end
    return {
        X = seat_loc.X - axis.X * pb,
        Y = seat_loc.Y - axis.Y * pb,
        Z = seat_loc.Z - axis.Z * pb,
    }
end

-- 获取 Itembase 的 Mesh 组件（供钥匙视觉位姿读取；必须在 get_key_visual_rot 之前定义）
local function get_itembase_mesh(actor)
    local comp = nil
    pcall(function() comp = actor["Mesh"] end)
    return uevrUtils.getValid(comp)
end

-- 钥匙视觉旋转 = ItemMesh 组件世界旋转（可无，回退零旋转）
local function get_key_visual_rot(actor)
    if actor == nil then return nil end
    local mesh = get_itembase_mesh(actor)
    if mesh ~= nil then
        local rot = nil
        pcall(function() rot = reload_tools.get_component_world_rotation(mesh) end)
        if rot ~= nil then return rot end
    end
    local rot = nil
    pcall(function()
        if actor.K2_GetActorRotation ~= nil then rot = actor:K2_GetActorRotation() end
    end)
    return rot
end

-- 前向声明：定义在下方（begin_insert 之前）；spawn 换装需要提前调用（2026-08-17 全程变体方案）
local load_doorattachment_mesh

-- 为单扇门 spawn 钥匙表演体，返回 actor（失败返回 nil）
-- 2026-09-03 分段计时：total/pre/engine/variant/swap，定位 spawn 帧卡顿究竟花在哪一段
function M.spawn_key_for_door(entry)
    if entry == nil or entry.actor == nil or entry.data_table == nil or entry.row_name == nil then
        return nil
    end
    local t_begin = os.clock()
    local spawn_pos, spawn_rot = lock_spawn_point(entry)
    if spawn_pos == nil then return nil end

    local world = nil
    pcall(function() world = uevrUtils.get_world() end)
    if world == nil then return nil end
    local Statics = nil
    pcall(function() Statics = uevrUtils.find_default_instance("Class /Script/Engine.GameplayStatics") end)
    if Statics == nil then return nil end
    local cls = uevrUtils.get_class(ITEM_BASE_CLASS_PATH, true)
    if cls == nil then return nil end
    local t_pre = os.clock()

    local spawn_tf = reload_tools.make_spawn_transform(spawn_pos, spawn_rot)
    local actor = nil
    pcall(function()
        actor = Statics:BeginDeferredActorSpawnFromClass(world, cls, spawn_tf, 1, nil)
    end)
    if actor == nil then return nil end
    -- 写 ItemData（deferred 窗口内，BeginPlay 前；row_name 已是字符串，FName 属性写入需转回）
    pcall(function()
        actor.ItemData.DataTable = entry.data_table
        actor.ItemData.RowName = uevrUtils.fname_from_string(entry.row_name)
    end)
    pcall(function() Statics:FinishSpawningActor(actor, spawn_tf) end)
    local t_engine = os.clock()
    -- 生成后沿世界 Z 轴缓慢自转（纯展示动画，便于观察钥匙朝向/位置）
    spin.start(actor, KEY_SPIN_PERIOD_S)
    -- 2026-08-17 全程变体：spawn 后立即尝试换装（BeginPlay 同步挂本体时第 0 帧即变体，零跳变）；
    -- 引擎异步挂载时此处 no-op，由 update_spawned_keys 逐帧轮询兜底（本体可见 ≤ 一帧间隔）
    local variant0, variant_src = load_doorattachment_mesh(actor, entry)
    local t_variant = os.clock()
    -- 2026-09-03 诊断：每次 spawn key 打印 doorattachment 命中的具体路径（走 diagnose_item_door.log，受 Enable Logging 总开关管理）
    log("ITEM_DOOR", string.format("[SPAWN-VARIANT] %s immediate path=%s",
        tostring(entry.row_name), tostring(variant_src or "no_mesh")))
    if variant0 ~= nil then
        -- 缓存变体 mesh（actor-keyed）：begin_insert 直接复用，避免插钥匙时重复全图查找
        state.spawn_variant_cache[actor] = variant0
        local mcomp0 = get_itembase_mesh(actor)
        if mcomp0 ~= nil then
            local ok0 = false
            pcall(function() ok0 = mcomp0:SetStaticMesh(variant0) end)
            log("ITEM_DOOR", string.format("[SPAWN] immediate variant swap ok=%s", tostring(ok0)))
        end
    end
    local t_end = os.clock()
    -- 分段耗时（ms）：pre=锁点/世界/类查询，engine=Begin+Finish spawn（含 BeginPlay），variant=变体解析走廊，swap=SetStaticMesh
    log("ITEM_DOOR", string.format("[SPAWN-TIMING] %s total=%.1fms pre=%.1fms engine=%.1fms variant=%.1fms swap=%.1fms",
        tostring(entry.row_name),
        (t_end - t_begin) * 1000, (t_pre - t_begin) * 1000,
        (t_engine - t_pre) * 1000, (t_variant - t_engine) * 1000,
        (t_end - t_variant) * 1000))
    return actor
end

-- 每帧变体换装轮询（2026-08-17）：引擎异步挂上本体 mesh 的当帧立即换装 doorattachment 变体。
-- 由 on_grab_tick（postEngineTick 每帧）驱动；1s interval 粒度太粗（用户实测"过 1 秒跳变"即此因）。
-- mesh 未挂上则静默跳过；换装后 mesh_checked 置位不再进入。
-- 性能优化 2026-08-31（#4）：state.variant_pending 记"未 mesh_checked 且 actor 有效"的条数，
-- 归零后整帧直接 return，不再每帧空转遍历；spawn/销毁处置 nil 触发下帧重数一次（1s 事件级开销）。
local function poll_variant_swap()
    if state.spawned_keys == nil then return end
    local pending = state.variant_pending
    if pending == nil then
        pending = 0
        for _, rec in pairs(state.spawned_keys) do
            if not rec.mesh_checked and rec.actor ~= nil then
                pending = pending + 1
            end
        end
        state.variant_pending = pending
    end
    if pending <= 0 then return end
    for key, rec in pairs(state.spawned_keys) do
        if not rec.mesh_checked and rec.actor ~= nil then
            local mesh_name = nil
            pcall(function()
                if rec.actor.Mesh ~= nil and rec.actor.Mesh.StaticMesh ~= nil then
                    mesh_name = rec.actor.Mesh.StaticMesh:get_full_name()
                end
            end)
            if mesh_name ~= nil then
                rec.mesh_checked = true
                if state.variant_pending ~= nil and state.variant_pending > 0 then
                    state.variant_pending = state.variant_pending - 1
                end
                log("ITEM_DOOR", string.format("[SPAWN] mesh check %s -> %s", tostring(key), mesh_name))
                -- 2026-08-17 用户拍板：全程用 doorattachment 变体（本体插入轨道斜着别扭，观感不重要）。
                -- 换装后悬浮/飞行/手持/插入/落座全程变体；已是变体时 load 内部幂等返回。
                local variant, variant_src = load_doorattachment_mesh(rec.actor, rec.entry)
                -- 2026-09-03 诊断：poll 兜底换装（spawn 即时换装因引擎异步挂载 no-op 时，实际命中发生在这里）
                log("ITEM_DOOR", string.format("[SPAWN-VARIANT] %s poll path=%s",
                    tostring(key), tostring(variant_src or "nil")))
                if variant ~= nil then
                    local mcomp = get_itembase_mesh(rec.actor)
                    if mcomp ~= nil then
                        local ok = false
                        pcall(function() ok = mcomp:SetStaticMesh(variant) end)
                        log("ITEM_DOOR", string.format("[SPAWN] variant swap %s ok=%s", tostring(key), tostring(ok)))
                    end
                end
            end
        end
    end
end

-- =============================================================================
-- Phase 5 前置检查：门已解锁 / 背包无道具 → 不生成钥匙
--   ① 门已解锁（三信号任一命中即拦截）：
--      a) L1 快照 key_mesh ~= nil —— 关卡加载时真钥匙已挂（LoadAndTrySetKeyMesh 只在解锁后
--         才挂 mesh，diag KEYIT 实测：锁着调超时不挂、解锁后 ~21ms 就绪），设计器预解锁门；
--      b) L1 快照 has_unlock_already == true —— 引擎原生 HasUnlockItemAlready 标记；
--      c) 实时 IsLocked() == false —— 导航成功且门未锁（finalize 后 SetLocked(false) 即时生效）。
--      导航失败（door_lock nil）不拦截：无法判定时保持旧行为，避免门结构异常导致永不生成。
--   ② 背包无道具：e.has_item（L2 快照，update_item_door_l2 每秒算一次 HasItem）。
--   跳过检查的强制生成：diag 面板 Force Spawn Key → M.force_spawn_key()。
-- =============================================================================
local function door_spawn_allowed(e)
    -- ①a / ①b：L1 快照（关卡加载时预解锁的门）
    if e.key_mesh ~= nil or e.has_unlock_already == true then
        return false, "door unlocked (snapshot)"
    end
    -- ①c：实时锁状态（begin_rotate 同款导航 + IsLocked）
    local key_sm = nil
    pcall(function() key_sm = e.actor["KeyStaticMesh"] end)
    if key_sm ~= nil and unlock_door ~= nil and type(unlock_door.navigate_to_door_lock) == "function" then
        local door_lock = nil
        pcall(function() door_lock = unlock_door.navigate_to_door_lock(key_sm) end)
        if door_lock ~= nil then
            local locked = false
            pcall(function() locked = (door_lock:IsLocked() == true) end)
            if not locked then
                return false, "door unlocked (IsLocked)"
            end
        end
    end
    -- ② 背包道具（性能优化 2026-08-31：直接用 L2 快照字段 e.has_item——update_item_door_l2
    -- 与本函数同由 1s interval 驱动且同秒已算过 HasItem，不再二次引擎调用）
    if e.row_name == nil or e.has_item ~= true then
        return false, "no item"
    end
    return true, nil
end

-- 记录 spawn 拦截原因，仅变化时打日志（update_spawned_keys 每秒跑，防刷屏）
local function note_spawn_block(key, reason)
    local prev = state.spawn_block[key]
    if prev == reason then return end
    state.spawn_block[key] = reason
    if reason ~= nil then
        log("ITEM_DOOR", string.format("[SPAWN] blocked %s (%s)", tostring(key), tostring(reason)))
    end
end

-- 确保 L2 内道具门都已 spawn 钥匙；已离开 L2 的门销毁其钥匙
function M.update_spawned_keys()
    if not state.cached_doors then return end
    local in_l2 = {}
    for _, e in ipairs(state.cached_doors) do
        local key = e.name
        in_l2[key] = true
        local existing = state.spawned_keys[key]
        if existing == nil or existing.actor == nil then
            -- Phase 5 前置检查：门已解锁 / 背包无道具 → 不生成（Force Spawn 可跳过）
            local allowed, why = door_spawn_allowed(e)
            if not allowed then
                note_spawn_block(key, why)
            else
                note_spawn_block(key, nil)
                local actor = M.spawn_key_for_door(e)
                if actor ~= nil then
                    state.spawned_keys[key] = { actor = actor, t_spawn = os.clock(), mesh_checked = false, entry = e, row_name = e.row_name }
                    state.variant_pending = nil -- #4 计数失效：新增待检查条目，下帧重数
                    log("ITEM_DOOR", string.format("[SPAWN] key spawned for %s (Row=%s)", tostring(key), tostring(e.row_name)))
                end
            end
        end
    end
    -- 清理已离开 L2 的门（跳过当前被抓取/持有的钥匙，避免抓取中销毁）
    -- 诊断批量模式（diag_spawn_all，2026-09-03）：force_spawn_key_all 置位后跳过"离开 L2 销毁"，
    -- 全图钥匙保留供 Scan Key Variants 采集资产路径；clear_spawned_keys 解除并统一清空。
    if state.diag_spawn_all ~= true then
        for key, entry in pairs(state.spawned_keys) do
            if not in_l2[key] then
                if entry.actor ~= nil and entry.actor ~= state.grab_actor then
                    spin.stop(entry.actor)
                    state.spawn_variant_cache[entry.actor] = nil -- 同步清变体缓存
                    pcall(function() uevrUtils.destroy_actor(entry.actor) end)
                    log("ITEM_DOOR", "[SPAWN] key destroyed (left L2): " .. tostring(key))
                end
                state.spawned_keys[key] = nil
                state.variant_pending = nil -- #4 计数失效：条目移除，下帧重数
            end
        end
    end
end

-- 清空所有已 spawn 的钥匙（热重载/初始化清理用；同时解除诊断批量保留模式）
function M.clear_spawned_keys()
    state.diag_spawn_all = nil -- 解除 force_spawn_key_all 的"跳过离开 L2 销毁"保留模式
    for key, entry in pairs(state.spawned_keys) do
        if entry.actor ~= nil then
            spin.stop(entry.actor)
            state.spawn_variant_cache[entry.actor] = nil -- 同步清变体缓存（防死引用）
            pcall(function() uevrUtils.destroy_actor(entry.actor) end)
        end
        state.spawned_keys[key] = nil
    end
    state.variant_pending = nil -- #4 计数失效：整表已清，下帧重数（热重载 M.init 必经此路径）
end

-- =============================================================================
-- 诊断脚本专用接口（diag 面板 Force Spawn Key 按钮；跳过 door_spawn_allowed 前置检查）
-- =============================================================================
function M.force_spawn_key()
    if not state.cached_doors then return 0 end
    local count = 0
    for _, e in ipairs(state.cached_doors) do
        local key = e.name
        local existing = state.spawned_keys[key]
        if existing == nil or existing.actor == nil then
            note_spawn_block(key, nil)
            local actor = M.spawn_key_for_door(e)
            if actor ~= nil then
                state.spawned_keys[key] = { actor = actor, t_spawn = os.clock(), mesh_checked = false, entry = e, row_name = e.row_name }
                state.variant_pending = nil -- #4 计数失效：新增待检查条目，下帧重数
                log("ITEM_DOOR", string.format("[FORCE-SPAWN] key spawned for %s (Row=%s)", tostring(key), tostring(e.row_name)))
                count = count + 1
            end
        end
    end
    return count
end

-- =============================================================================
-- 诊断脚本专用接口（diag 面板 Spawn All Keys (L1) 按钮）
-- 无视距离：遍历 L1 全图缓存（state.door_cache）为全部道具门 spawn 钥匙表演体，
-- 跳过 door_spawn_allowed 前置检查。目的：强制流式加载全图钥匙本体 mesh，
-- 供 diag Scan Key Variants 采集本体/变体资产路径（无需跑到每扇门 3m 内）。
-- 副作用：置 state.diag_spawn_all = true，update_spawned_keys 跳过"离开 L2 销毁"，
-- 钥匙持续保留；clear_spawned_keys 解除并清空。
-- 返回：成功 spawn 数量；-1 = L1 缓存未构建（先点 diag Test L1 Cache）。
-- =============================================================================
function M.force_spawn_key_all()
    if not state.door_cache_valid or state.door_cache == nil then return -1 end
    state.diag_spawn_all = true
    local count = 0
    for _, e in ipairs(state.door_cache) do
        local key = e.name
        local existing = state.spawned_keys[key]
        if existing == nil or existing.actor == nil then
            local actor = M.spawn_key_for_door(e)
            if actor ~= nil then
                state.spawned_keys[key] = { actor = actor, t_spawn = os.clock(), mesh_checked = false, entry = e, row_name = e.row_name }
                state.variant_pending = nil -- #4 计数失效：新增待检查条目，下帧重数
                log("ITEM_DOOR", string.format("[FORCE-SPAWN-ALL] key spawned for %s (Row=%s)", tostring(key), tostring(e.row_name)))
                count = count + 1
            end
        end
    end
    return count
end

-- 当前已生成钥匙视图（diag 面板打印用）
function M.get_spawned_keys_diag()
    local list = {}
    for key, entry in pairs(state.spawned_keys) do
        local age_s = -1
        if entry.t_spawn ~= nil then
            age_s = os.clock() - entry.t_spawn
        end
        list[#list + 1] = { name = key, actor = entry.actor, age_s = age_s }
    end
    return list
end

-- =============================================================================
-- 诊断脚本专用接口（diag 面板 Test L1/L2 Cache、Spawn Snapshot 按钮，仅手动触发读取，
-- 自身不打印；主脚本 L1/L2 真实状态此前不可观测的根因即这几个导出缺失）
-- =============================================================================
-- 强制重建 L1 + L2 并返回 L1 全表（diag Test L1 Cache 按钮）
function M.force_rebuild_l1()
    build_item_door_cache()
    update_item_door_l2()
    return state.door_cache or {}
end

-- L1/L2 缓存状态摘要（diag Test L2 Cache 按钮首行）
function M.get_l1_diag()
    return {
        l1_valid = state.door_cache_valid,
        l1_count = (state.door_cache ~= nil) and #state.door_cache or 0,
        cached_count = (state.cached_doors ~= nil) and #state.cached_doors or 0,
    }
end

-- 当前 L2 缓存视图（diag Test L2 Cache 列表 / pick_target_door）
function M.get_cached_item_doors()
    return state.cached_doors or {}
end

-- 手动快照：L2 各门的锁孔位/spawn 位/玩家位（diag Spawn Snapshot 按钮，返回行列表）
function M.snapshot_spawn_positions()
    local lines = {}
    local pawn = uevrUtils.get_local_pawn()
    local pawn_loc = nil
    if pawn ~= nil then
        pcall(function()
            if pawn.K2_GetActorLocation ~= nil then pawn_loc = pawn:K2_GetActorLocation() end
        end)
    end
    local fmt_vec = function(v)
        if v == nil then return "<nil>" end
        return string.format("(%.1f, %.1f, %.1f)", v.X or 0, v.Y or 0, v.Z or 0)
    end
    lines[#lines + 1] = string.format("pawn loc: %s", fmt_vec(pawn_loc))
    for _, e in ipairs(state.cached_doors or {}) do
        local seat = lock_seat_point(e)
        local sp = lock_spawn_point(e)
        lines[#lines + 1] = string.format("%s | Row=%s | dist=%.1fcm | seat=%s | spawn=%s",
            tostring(e.name), tostring(e.row_name), e.dist_to_pawn_cm or -1,
            fmt_vec(seat), fmt_vec(sp))
    end
    return lines
end

-- 玩家道具持有检查（Phase 0 已确认路径）
-- =============================================================================
-- 导航：本地 pawn.Items → USHCharacterPlayItemsComponent（pistol_reload.lua 已用 pawn.Items.ItemExecutive 验证该字段）
-- 判定：优先 HasItem(row_name)（C++ 方法 SHProto.hpp L7533，若为 UEVR 反射 UFUNCTION 则直接调用）；
--       否则读 CollectedItems TArray（FSHCollectedItemData: ItemRowName + Quantity，SHProto.hpp L887/L7505）按 ItemRowName 匹配
function M.has_item(row_name)
    if row_name == nil then
        return false
    end
    local pawn = nil
    pcall(function() pawn = uevrUtils.get_local_pawn() end)
    if pawn == nil then
        return false
    end
    local comp = nil
    pcall(function() comp = uevrUtils.getValid(pawn, {"Items"}) end)
    if comp == nil then
        return false
    end
    local target = tostring(row_name)
    -- ① HasItem()（row_name 为字符串，FName 参数需转回）
    if comp.HasItem ~= nil then
        local ok, r = pcall(function() return comp:HasItem(uevrUtils.fname_from_string(row_name)) end)
        if ok then
            return r == true
        end
    end
    -- ② CollectedItems 兜底
    local found = false
    pcall(function()
        local items = comp.CollectedItems
        if items ~= nil then
            for i = 1, #items do
                local it = items[i]
                local it_name = nil
                pcall(function() it_name = tostring(it.ItemRowName) end)
                if it_name == target then
                    found = true
                    break
                end
            end
        end
    end)
    return found
end

-- 消耗背包道具（USHCharacterPlayItemsComponent:RemoveItem(RowName,1,...)）
-- Phase 4b finalize 调用；row_name 支持字符串/FName。
function M.remove_item(row_name)
    if row_name == nil then return false end
    local pawn = nil
    pcall(function() pawn = uevrUtils.get_local_pawn() end)
    if pawn == nil then return false end
    local comp = nil
    pcall(function() comp = uevrUtils.getValid(pawn, {"Items"}) end)
    if comp == nil then return false end
    if comp.RemoveItem == nil then
        log("ITEM_DOOR", "[REMOVE] Items.RemoveItem not exposed")
        return false
    end
    -- RemoveItem 返回 void（diag 实测：调用后 HasItem true→false 消耗生效），
    -- 不能用返回值判成败，调用不抛错即视为成功。
    local ok = false
    pcall(function()
        comp:RemoveItem(uevrUtils.fname_from_string(row_name), 1, false)
        ok = true
    end)
    log("ITEM_DOOR", string.format("[REMOVE] RemoveItem called ok=%s Row=%s (void 返回，实耗以 HasItem 复核)",
        tostring(ok), tostring(row_name)))
    return ok
end

-- =============================================================================
-- Pawn 生命周期检测 + L1 重建调度（统一 5s 延迟 + 0 条目 2s 重试）
-- =============================================================================
local function check_pawn_invalidation()
    -- pawn 变化检测已统一到 main.lua（check_pawn_globally），经 M.on_pawn_changed 喂入；
    -- 此函数改为驱动 L1 重建调度（到期重建 + 0 条目重试）+ 类预热，不再 get_local_pawn。

    -- 首次重建：延迟 L1_REBUILD_DELAY_S（pawn/关卡变化经 on_pawn_changed 置位后执行）
    if state.l1_rebuild_pending and os.clock() - state.l1_rebuild_time > L1_REBUILD_DELAY_S then
        build_item_door_cache()
        update_item_door_l2()
        state.l1_rebuild_pending = false
        pcall(M.refresh_config_ui)  -- L1 重建后刷新钥匙偏移下拉菜单（合并新发现的 row_name）
        if (state.door_cache == nil or #state.door_cache == 0) then
            state.l1_retry_pending = true
            state.l1_retry_time = os.clock()
            state.l1_retry_count = 0
        end
    end

    -- 持久重试（对齐 unlock_door.lua）：L1 仍为 0 条目时每 L1_RETRY_DELAY_S 秒再扫一次，
    -- 最多 L1_RETRY_MAX 次——子关卡流送慢时单次重试不够，需持续到扫到或达上限。
    if state.l1_retry_pending and os.clock() - state.l1_retry_time > L1_RETRY_DELAY_S then
        state.l1_build_reason = "l1_retry" -- 卡顿排查 2026-09-03
        build_item_door_cache()
        update_item_door_l2()
        state.l1_retry_count = (state.l1_retry_count or 0) + 1
        pcall(M.refresh_config_ui)  -- 重试重建后刷新下拉菜单
        local found = state.door_cache ~= nil and #state.door_cache or 0
        if found > 0 or state.l1_retry_count >= L1_RETRY_MAX then
            state.l1_retry_pending = false
        else
            state.l1_retry_time = os.clock() -- 继续 L1_RETRY_DELAY_S 秒后再试
        end
    end

    -- 类预热调度（2026-09-03 卡顿修复，用户批准）：L1 已有门且未预热过 → 2 秒后预解析
    -- ItemBase_BP 类。否则 session 首次走近门时 get_class(path, true) 阻塞加载 ~160ms。
    -- 预热时刻选在进图+L1 就绪+2s（流送高峰已过），卡在这一帧体感远轻于卡在 spawn 帧。
    if not state.class_warmup_done and not state.class_warmup_pending
        and state.door_cache ~= nil and #state.door_cache > 0 then
        state.class_warmup_pending = true
        state.class_warmup_time = os.clock() + 2.0
    end

    -- 类预热执行：get_class 阻塞加载一次即进内存缓存（spawn 链路 L605 同函数，之后秒回）；
    -- 失败重试最多 3 次（间隔 2s），仍失败放弃（保持原行为：首次 spawn 时兜底加载）
    if state.class_warmup_pending and os.clock() >= state.class_warmup_time then
        state.class_warmup_pending = false
        state.class_warmup_tries = state.class_warmup_tries + 1
        local t0 = os.clock()
        local cls = uevrUtils.get_class(ITEM_BASE_CLASS_PATH, true)
        local ms = (os.clock() - t0) * 1000
        if cls ~= nil then
            state.class_warmup_done = true
            log("ITEM_DOOR", string.format("[CLASS-WARMUP] ok (took %.1fms, try #%d)", ms, state.class_warmup_tries))
        elseif state.class_warmup_tries >= 3 then
            state.class_warmup_done = true
            log("ITEM_DOOR", string.format("[CLASS-WARMUP] gave up after %d tries (class load failed)", state.class_warmup_tries))
        else
            state.class_warmup_pending = true
            state.class_warmup_time = os.clock() + 2.0
        end
    end
end

-- 供 interval 闭包从全局 M 动态调用的导出（热重载后闭包拿到最新函数，避免旧闭包残留）
function M.check_pawn_invalidation()
    check_pawn_invalidation()
end

function M.update_l2()
    update_item_door_l2()
end

-- 统一 pawn 检测入口（main.lua check_pawn_globally 广播调用）。
-- reason：pawn_changed / level_change → 调度 L1 重建；pawn_nil → 清理 pending/retry 防缓存僵死。
---@param reason string
function M.on_pawn_changed(reason)
    if reason == "pawn_nil" then
        state.l1_rebuild_pending = false
        state.l1_retry_pending = false
        return
    end
    state.l1_rebuild_pending = true
    state.l1_build_reason = (reason == "level_change") and "level_change" or "pawn_changed" -- 卡顿排查 2026-09-03
    state.l1_rebuild_time = os.clock()
    state.l1_retry_pending = false
    state.l1_retry_count = 0
end

-- main.lua 关卡切换兜底（统一走 on_pawn_changed("level_change")，因 pawn 引用可能未变化）。
function M.on_level_change(level)
    M.on_pawn_changed("level_change")
end

-- 过场/过门动画结束：立即重建一次（对齐 remote_grab，2026-09-05 用户定案）。
-- 由每帧 on_grab_tick 顶层 l1_cutscene_once 分支立即消费（不走 1s interval，保证"立即"），
-- 建出几条就是几条；即便建出 0 条也【不】进入 2s 重试——与常规 pawn/关卡重建路径独立。
-- 注意：main.lua L601 有 pcall 包裹，本函数仅置标志、不 build（build 在 on_grab_tick），故不上抛。
---@param isInCutscene boolean
function M.on_cutscene_change(isInCutscene)
    if isInCutscene ~= false then
        return
    end
    state.l1_cutscene_once = true
end

-- =============================================================================
-- 生命周期
-- =============================================================================
function M.init()
    -- 热重载清理：若重载前左手仍吸附在旧钥匙 actor 上（旧 state 可能无标记），
    -- 强制发一次 detach 恢复手部追踪（restoreHandSnapshot 无快照时 no-op，重复调用安全）；
    -- 随后销毁旧钥匙 actor，避免手挂在已销毁对象上。
    pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_detach", Handed.Left)
    end)
    state.hand_attached_to_key = false
    -- Phase 4a：拧转状态默认值（热重载旧 state 无这些字段时补齐，防 nil 比较）
    state.rotate_axis = nil
    state.rotate_body_rot = nil
    state.rotate_start_pitch = 0
    state.rotate_started = false
    state.rotate_progress = 0
    state.rotate_completed = false
    state.rotate_returning = false
    state.rotate_return_start_t = 0
    state.rotate_return_start_progress = 0
    -- Phase 4a：注册拧钥匙音效（register_event 幂等，热重载重复调用安全，pistol 同模式）
    if audio ~= nil and type(audio.register_event) == "function" then
        audio.register_event(KEY_UNLOCK_AUDIO_KEY, KEY_UNLOCK_EVENT, KEY_UNLOCK_EVENT_PATH)
    end
    -- 热重载清理：先销毁所有已生成的钥匙 actor（避免每次热重载叠加出新钥匙），
    -- 再清空 L1/L2 缓存，并显式调度 L1 重建（因 pawn 检测已上移 main，热重载时 pawn 未变不会广播，须自行触发）。
    M.clear_spawned_keys()
    state.door_cache = nil
    state.door_cache_valid = false
    state.cached_doors = {}
    state.last_pawn_ref = nil
    M.on_pawn_changed("pawn_changed") -- 热重载强制重建（5s 延迟后由本模块 1s interval 执行）

    -- interval 只注册一次。闭包不捕获 local M/state，而是每次从全局读取，
    -- 保证热重载后（require 重跑产生新 M）仍由【唯一】的 interval 驱动最新代码，
    -- 不会因旧闭包残留而叠加生成钥匙。
    if not state.interval_registered then
        uevrUtils.setInterval(SCAN_INTERVAL_MS, function()
            local sv = rawget(_G, "__SH2_UNLOCK_ITEM_DOOR_STATE")
            local m = rawget(_G, "__sh2_unlock_item_door_module")
            if type(sv) ~= "table" or type(m) ~= "table" then return end
            if type(m.check_pawn_invalidation) == "function" then m.check_pawn_invalidation() end
            if type(m.update_l2) == "function" then m.update_l2() end
            if type(m.update_spawned_keys) == "function" then m.update_spawned_keys() end
        end)
        state.interval_registered = true
    end

    -- 每帧 grab tick（左 Grip 边沿 + 抓取状态机）：照抄 remote_grab 的 postEngineTick 间接调用模式。
    -- 全局函数 + pcall 间接调用，热重载后（require 重跑产生新 M）仍由唯一回调驱动最新代码，
    -- 不会重复注册。与上面 1s interval（管 L2/钥匙生成）并存。
    if not state.pawn_tick_registered then
        uevrUtils.registerPostEngineTickCallback(function()
            local fn = rawget(_G, "__sh2_unlock_item_door_on_tick")
            if type(fn) == "function" then
                pcall(fn)
            end
        end)
        state.pawn_tick_registered = true
    end
    _G.__sh2_unlock_item_door_on_tick = function()
        local m = rawget(_G, "__sh2_unlock_item_door_module")
        if type(m) == "table" and type(m.on_grab_tick) == "function" then
            m.on_grab_tick()
        end
    end

    _G.__sh2_unlock_item_door_module = M
    return M
end

-- =============================================================================
-- Phase 2 远程抓取（仅抓取到手持；松手 → 钥匙飞回原位恢复自转 → 可重抓）
-- 复用 remote_grab 范式：距离检测 + 左 Grip 边沿 → spin.stop → 飞行 lerp → attach 左手
-- 不做激光射线；严禁改 reload_hooks.lua（靠占用门控避免与手电/其他功能冲突）
-- =============================================================================

-- 占用判定用全局键（与 remote_grab 一致）
local KEY_HEAL_LEFT = (vr_globals.KEYS and vr_globals.KEYS.heal_left_prop_active) or "g_heal_left_prop_active"
local KEY_MAG_LEFT = (vr_globals.KEYS and vr_globals.KEYS.mag_in_left_hand) or "g_mag_in_left_hand"
local KEY_PROP_ACTIVE = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_left_prop_active) or "g_remote_grab_left_prop_active"

-- 复用的命中结果缓冲（避免每帧分配新对象）
local reusable_hit = rawget(_G, "reusable_hit_result")

-- 钥匙偏移持久化由主脚本自管整表（load_key_offsets / persist_key_offsets），见下方区块。

-- =============================================================================
-- 每把钥匙手部偏移配置（运行时内存整表真源；主脚本自管 data/keys.json 持久化）
-- =============================================================================
-- 钥匙偏移持久化文件（json.dump_file/load_file 默认落到 data/ 目录）
local KEY_OFFSETS_JSON = "keys.json"

-- 前向声明（ensure_key_offsets / get_key_offset 内调用，定义在下方）
local load_key_offsets
local persist_key_offsets
-- 整表只从磁盘加载一次（用于"json 未就绪时先跳过、就绪后再加载"的防重置守卫）
local key_offset_loaded = false
-- 非法键校验只跑一次（性能优化 2026-08-31：原先每次 get_key_offset 都全表扫描，
-- 处于 Seated/Holding 每帧热路径；磁盘合并后重跑一次，热重载本局部量自动复位）
local key_offsets_validated = false

local function default_key_offsets()
    return {
        default = {
            loc = { DEFAULT_KEY_OFFSET.loc[1], DEFAULT_KEY_OFFSET.loc[2], DEFAULT_KEY_OFFSET.loc[3] },
            rot = { DEFAULT_KEY_OFFSET.rot[1], DEFAULT_KEY_OFFSET.rot[2], DEFAULT_KEY_OFFSET.rot[3] },
            pullback = KEY_PULLBACK_DEFAULT_CM,
            ins = { 0, 0, 0 },
        },
    }
end

local function ensure_key_offsets()
    if state.key_offsets == nil then
        state.key_offsets = default_key_offsets()
    end
    -- 整表只从磁盘加载一次：json 未就绪时先跳过，就绪后随首次访问自动完成
    if not key_offset_loaded then
        key_offset_loaded = true
        load_key_offsets()
        key_offsets_validated = false -- 磁盘合并后需重跑一次键合法性校验
    end
    -- 性能优化 2026-08-31：非法键清理改为一次性（首访/磁盘合并后），
    -- 不再每次读取都全表扫描（Seated/Holding 每帧 2~4 次读取的热路径）。
    if not key_offsets_validated then
        key_offsets_validated = true
        -- 清理非法空键（旧数据可能写入过 ""），避免滑块误写与下拉混乱
        if state.key_offsets[""] ~= nil then
            state.key_offsets[""] = nil
            log("ITEM_DOOR", "[KEYOFF] removed invalid empty key")
        end
        -- 清理非字符串键（旧 bug：FName userdata 作键，json 落盘成 ""；热重载残留的运行时 state 同样需要清）
        for k in pairs(state.key_offsets) do
            if type(k) ~= "string" then
                state.key_offsets[k] = nil
                log("ITEM_DOOR", string.format("[KEYOFF] removed invalid non-string key (type=%s)", type(k)))
            end
        end
    end
    if state.key_offsets.default == nil then
        state.key_offsets.default = default_key_offsets().default
    end
    return state.key_offsets
end

local function get_default_offset()
    local cfg = ensure_key_offsets()
    if cfg.default == nil then
        cfg.default = default_key_offsets().default
    end
    return cfg.default
end

-- 获取某把钥匙的偏移配置（首次抓取若无条目 → 用 default 惰性建条目并整表落盘）
local function get_key_offset(key_name)
    if key_name == nil or key_name == "" then
        return get_default_offset()
    end
    local cfg = ensure_key_offsets()
    if cfg[key_name] == nil then
        local def = get_default_offset()
        cfg[key_name] = {
            loc = { def.loc[1], def.loc[2], def.loc[3] },
            rot = { def.rot[1], def.rot[2], def.rot[3] },
            pullback = tonumber(def.pullback) or KEY_PULLBACK_DEFAULT_CM,
            ins = { 0, 0, 0 },
        }
        log("ITEM_DOOR", string.format("[KEYOFF] lazy-created offset entry for %s", tostring(key_name)))
        persist_key_offsets()
    end
    return cfg[key_name]
end

-- 读取某把钥匙（row_name）的 pullback 落点拉回距离（cm）；无配置回退默认 6cm。
local function key_pullback(row_name)
    local pb = KEY_PULLBACK_DEFAULT_CM
    if row_name ~= nil then
        local ofs = get_key_offset(row_name)
        if ofs ~= nil and ofs.pullback ~= nil then
            pb = tonumber(ofs.pullback) or KEY_PULLBACK_DEFAULT_CM
        end
    end
    return pb
end

-- 读取某把钥匙（row_name）的插入旋转偏移 ins={pitch,yaw,roll}（度，叠加在锁坯 KeyStaticMesh 旋转之上）。
-- 无配置回退 {0,0,0}。返回新表，禁止改原表。
local function key_insert_rot(row_name)
    local o = { 0, 0, 0 }
    if row_name ~= nil then
        local ofs = get_key_offset(row_name)
        if ofs ~= nil and type(ofs.ins) == "table" then
            o[1] = tonumber(ofs.ins[1]) or 0
            o[2] = tonumber(ofs.ins[2]) or 0
            o[3] = tonumber(ofs.ins[3]) or 0
        end
    end
    return o
end

-- 从 data/keys.json 加载全部钥匙偏移，合并回内存整表（只新增/覆盖，不清空已有），
-- 并存 json 未就绪时安全跳过，绝不因加载失败而回填默认覆盖已有数据。
load_key_offsets = function()
    if type(json) ~= "table" then
        log("ITEM_DOOR", "[KEYOFF] json not ready yet, skip loading key offsets")
        return 0
    end
    local ok, data = pcall(json.load_file, KEY_OFFSETS_JSON)
    if not ok or type(data) ~= "table" then
        log("ITEM_DOOR", "[KEYOFF] no keys.json to load (keep in-memory defaults)")
        return 0
    end
    if state.key_offsets == nil then
        state.key_offsets = default_key_offsets()
    end
    local count = 0
    for k, entry in pairs(data) do
        if k ~= nil and k ~= "" and type(entry) == "table" then
            local loc = { 0, 0, 0 }
            local rot = { 0, 0, 0 }
            if type(entry.loc) == "table" then
                for i = 1, 3 do loc[i] = tonumber(entry.loc[i]) or 0 end
            end
            if type(entry.rot) == "table" then
                for i = 1, 3 do rot[i] = tonumber(entry.rot[i]) or 0 end
            end
            local ins = { 0, 0, 0 }
            if type(entry.ins) == "table" then
                for i = 1, 3 do ins[i] = tonumber(entry.ins[i]) or 0 end
            end
            state.key_offsets[k] = { loc = loc, rot = rot, pullback = tonumber(entry.pullback) or KEY_PULLBACK_DEFAULT_CM, ins = ins }
            count = count + 1
            log("ITEM_DOOR", string.format("[KEYOFF-LOAD] accepted key=\"%s\" loc=(%.2f,%.2f,%.2f)", tostring(k), loc[1], loc[2], loc[3]))
        else
            log("ITEM_DOOR", string.format("[KEYOFF-LOAD] SKIP key=%s type=%s", tostring(k), type(k)))
        end
    end
    log("ITEM_DOOR", string.format("[KEYOFF] loaded %d key offset entries from %s", count, KEY_OFFSETS_JSON))
    -- 注：合法的非法键（""）清理交给 ensure_key_offsets / persist_key_offsets，加载只做纯合并。
    return count
end

-- 整表落盘：把内存里全部钥匙偏移写回 data/keys.json（空键不落盘）。
persist_key_offsets = function()
    if type(json) ~= "table" then return end
    local cfg = ensure_key_offsets()
    local out = {}
    for k, entry in pairs(cfg) do
        if k ~= nil and k ~= "" and type(entry) == "table" then
            out[k] = {
                loc = { tonumber(entry.loc and entry.loc[1]) or 0, tonumber(entry.loc and entry.loc[2]) or 0, tonumber(entry.loc and entry.loc[3]) or 0 },
                rot = { tonumber(entry.rot and entry.rot[1]) or 0, tonumber(entry.rot and entry.rot[2]) or 0, tonumber(entry.rot and entry.rot[3]) or 0 },
                pullback = tonumber(entry.pullback) or KEY_PULLBACK_DEFAULT_CM,
                ins = { tonumber(entry.ins and entry.ins[1]) or 0, tonumber(entry.ins and entry.ins[2]) or 0, tonumber(entry.ins and entry.ins[3]) or 0 },
            }
        else
            log("ITEM_DOOR", string.format("[KEYOFF-PERSIST] SKIP key=%s type=%s nil=%s empty=%s",
                tostring(k), type(k), tostring(k == nil), tostring(k == "")))
        end
    end
    local ok, err = pcall(json.dump_file, KEY_OFFSETS_JSON, out, 4)
    if not ok then
        log("ITEM_DOOR", string.format("[KEYOFF] persist failed: %s", tostring(err)))
    else
        log("ITEM_DOOR", "[KEYOFF-PERSIST] write OK")
    end
end

-- 设置 actor 世界位置/旋转（飞行插值时写回）
-- 注意：必须对 root 组件用组件级 K2_SetWorldLocation，而非 Actor 级 K2_SetActorLocation
--      （后者对 ItemBase_BP_C 蓝图 Actor 不生效，root 会停在原位，导致坐标无法覆盖到手位置）
-- 另：K2_SetWorldLocation 必须传有效 HitResult（reusable_hit，与 remote_grab 共用），
--      传 nil 时该引擎版本会静默忽略设置，导致 holding 期 root 卡住不动（飞行阶段之所以能移动，
--      是因为 remote_grab.set_prop_world_pose 内传入了 reusable_hit）。
local function set_actor_world_pose(actor, loc, rot)
    if actor == nil or loc == nil then return end
    local root = reload_tools.get_actor_root(actor)
    if root == nil then return end
    pcall(function()
        root:K2_SetWorldLocation(uevrUtils.vector(loc.X, loc.Y, loc.Z), false, reusable_hit, false)
        if rot ~= nil then
            root:K2_SetWorldRotation(uevrUtils.rotator(rot.Pitch, rot.Yaw, rot.Roll), false, reusable_hit, false)
        end
    end)
end

-- 解析左手组件（按手部类型选择控制器/手组件/IK 网格）：复用 remote_grab.rt_resolve_left_hand_component
local function resolve_left_hand_component()
    if remote_grab ~= nil and type(remote_grab.rt_resolve_left_hand_component) == "function" then
        return remote_grab.rt_resolve_left_hand_component()
    end
    return nil
end

-- 左手手部世界位置/旋转
-- 优先用 unlock_door.get_left_hand_world()：unlock_door 基于 VR 控制器定位，
-- 即玩家真实手柄/手的位置；而 remote_grab 在 IKArms 模式解析到 IK 手臂网格（小臂），
-- 钥匙会飞到小臂。故手位统一走 unlock_door 暴露的控制器位置。
local function get_left_hand_socket_world()
    -- 优先：unlock_door 暴露的左手真实位置（VR 控制器）
    if unlock_door ~= nil and type(unlock_door.get_left_hand_world) == "function" then
        local loc, rot = unlock_door.get_left_hand_world()
        if loc ~= nil then
            return loc, rot
        end
    end
    -- 回退：remote_grab socket 版本（读 hand_l_bn 插槽，即视觉手部位置）
    if remote_grab ~= nil and type(remote_grab.rt_get_left_hand_socket_world) == "function" then
        local loc, rot = remote_grab.rt_get_left_hand_socket_world()
        if loc ~= nil then
            return loc, rot
        end
    end
    if remote_grab ~= nil and type(remote_grab.rt_get_left_hand_world) == "function" then
        local loc, rot = remote_grab.rt_get_left_hand_world()
        if loc ~= nil then
            return loc, rot
        end
    end
    return nil, nil
end

-- 左手是否持有手电（light_type==2 且存在有效 SHFlashlight）
local function left_hand_holds_flashlight()
    local ok_type, light_type = pcall(configui.getValue, "light_type")
    if not ok_type or (light_type or 0) ~= 2 then return false end
    local pawn = uevrUtils.get_local_pawn()
    if pawn == nil then return false end
    local eq = {}
    pcall(function()
        local v = uevrUtils.getValid(pawn, { "Items", "EquipmentActors" })
        if v ~= nil then eq = v end
    end)
    if #eq == 0 then return false end
    local flash_cls = nil
    pcall(function() flash_cls = uevrUtils.get_class("Class /Script/SHProto.SHFlashlight") end)
    if flash_cls == nil then return false end
    for _, actor in ipairs(eq) do
        local is_flash = false
        pcall(function() is_flash = actor:is_a(flash_cls) end)
        if is_flash then return true end
    end
    return false
end

-- 左手是否被其他功能占用（拒抓清单）
local function left_hand_occupied()
    if left_hand_holds_flashlight() then return true end
    if rawget(_G, KEY_HEAL_LEFT) == true then return true end
    if rawget(_G, KEY_MAG_LEFT) == true then return true end
    if rawget(_G, KEY_PROP_ACTIVE) == true then return true end
    return false
end

-- 附着选项：复用 remote_grab.rt_make_attach_options
local function make_attach_options()
    if remote_grab ~= nil and type(remote_grab.rt_make_attach_options) == "function" then
        return remote_grab.rt_make_attach_options()
    end
    return {
        detachFromOriginOnGrip = true,
        maintainWorldPositionOnDetachFromOrigin = false,
        detachFromParentOnRelease = true,
        maintainWorldPositionOnDetachFromParent = false,
        reattachToOriginOnRelease = false,
        restoreTransformToOriginOnReattach = false,
        useZeroTransformOnReattach = false,
        allowChildVisibilityHandling = false,
        allowChildHiddenInGameHandling = false,
        allowRenderInMainPassHandling = false,
    }
end

-- 性能优化 2026-08-31（#3 脏检查缓存）：上次成功写入 Mesh 相对变换的钥匙偏移快照。
-- 值未变则 apply_key_hand_offset 跳过 2 次组件属性引擎写（Holding 每帧热路径）。
-- 失效点（外部改写了 Mesh 相对变换 / 换了抓取会话）：begin_grab_from_cache、grab_reset、
-- begin_insert（归零）、drop_key_at_home（归零）。热重载本局部量自动复位为 nil。
local last_hand_offset = nil  -- { key_name, loc = {x,y,z}, rot = {p,y,r} }

-- 把当前钥匙的手部偏移（loc + rot）应用到其 Mesh 组件相对变换
local function apply_key_hand_offset(actor, key_name)
    if actor == nil then return end
    local comp = nil
    pcall(function() comp = actor["Mesh"] end)
    comp = uevrUtils.getValid(comp)
    if comp == nil then return end
    local ofs = get_key_offset(key_name)
    -- 脏检查：偏移值与上次写入完全一致则跳过引擎写（滑块改值能被比较捕获）
    local last = last_hand_offset
    if last ~= nil and last.key_name == key_name
        and last.loc[1] == ofs.loc[1] and last.loc[2] == ofs.loc[2] and last.loc[3] == ofs.loc[3]
        and last.rot[1] == ofs.rot[1] and last.rot[2] == ofs.rot[2] and last.rot[3] == ofs.rot[3] then
        return
    end
    local ok = false
    pcall(function()
        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(ofs.loc[1], ofs.loc[2], ofs.loc[3]))
        uevrUtils.set_component_relative_rotation(comp, uevrUtils.rotator(ofs.rot[1], ofs.rot[2], ofs.rot[3]))
        ok = true
    end)
    if ok then
        last_hand_offset = {
            key_name = key_name,
            loc = { ofs.loc[1], ofs.loc[2], ofs.loc[3] },
            rot = { ofs.rot[1], ofs.rot[2], ofs.rot[3] },
        }
    end
end

-- 钥匙视觉位置 = ItsemMesh 组件世界位置（actor 根位置与可见 Mesh 可能不一致，距离检测必须用 Mesh）
local function get_key_visual_world(actor)
    if actor == nil then return nil end
    local mesh = get_itembase_mesh(actor)
    if mesh ~= nil then
        local loc = nil
        pcall(function() loc = reload_tools.get_component_world_location(mesh) end)
        if loc ~= nil then return loc end
    end
    -- 回退：actor 根位置
    local loc = nil
    pcall(function()
        if actor.K2_GetActorLocation ~= nil then loc = actor:K2_GetActorLocation() end
    end)
    return loc
end

-- =============================================================================
-- 抓取状态机
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Phase 3 收尾（§7.1，2026-08-18 实施）：插入期左手跟随钥匙
-- unlock_door 式直接回调：executeUEVRCallbacks("on_accessory_attach") 挂钥匙 root，
-- 底层走 hands.lua attachHandToTarget（saveHandSnapshot + K2_AttachTo + 相对变换）。
-- 时机：begin_insert 进入 Inserting 时零偏移挂附（手随钥匙一起滑入）。
-- 脱附（仅两条路径，钥匙状态均不受影响）：
--   ① Inserting/Seated 期松开左 Grip（edge_released）→ 手恢复正常追踪，钥匙继续滑入/落座；
--   ② grab_reset 异常路径（过场/actor 丢失/换关）→ 统一自动脱附。
-- Seated 后【不强制脱附】：只要左 Grip 按住就一直吸附，为 Phase 4 拧钥匙
-- "插入、拧钥匙一气呵成"留路（用户 2026-08-18 拍板）。
-- -----------------------------------------------------------------------------
local function detach_hand_from_key(reason)
    if not state.hand_attached_to_key then return end
    state.hand_attached_to_key = false
    pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_detach", Handed.Left)
    end)
    -- 对齐 unlock_door remove_grip_anim：脱附即清抓握手势（手已离开钥匙，不再保持 pull_lock）
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, nil)
    end)
    log("ITEM_DOOR", "[HAND-FOLLOW] detach (" .. tostring(reason) .. ")")
end

local function attach_hand_to_key(actor, reason)
    if state.hand_attached_to_key then return end
    if actor == nil then return end
    -- 仅左 Grip 按住时吸附：若插入触发时 Grip 已松开（Holding 期松手钥匙仍粘手的既有行为），
    -- 不吸附——否则 edge_released 永不触发，手会永久挂在钥匙上（用户拍板"没松开才一直吸附"）
    if not is_left_grip_pressed() then return end
    local root = reload_tools.get_actor_root(actor)
    if root == nil then return end
    state.hand_attached_to_key = true
    pcall(function()
        -- 挂附瞬间钥匙 root ≈ 手位（Holding 期每帧覆盖所致），后续 tick_insert/tick_seated 驱动 root，
        -- 手挂在 root 上自动跟随（"手跟钥匙"）。偏移组 HAND_ATTACH_OFFSET 只作用于手网格相对变换，
        -- 钥匙位姿不受影响（位置 loc cm、旋转 rot 度，调校定稿 2026-08-20）。
        uevrUtils.executeUEVRCallbacks("on_accessory_attach",
            Handed.Left, root, nil, 0, HAND_ATTACH_OFFSET.loc, HAND_ATTACH_OFFSET.rot)
    end)
    -- Phase 4a：吸附即设抓握手势（对齐 unlock_door apply_grip_anim = attach + setHoldingAttachment）。
    -- 正常路径（Holding→Inserting）已是 pull_lock，此处幂等 no-op；
    -- G2 重抓/落座补挂附路径（手曾脱附、手势已清）靠此行恢复拧钥匙手势。
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, "pull_lock")
    end)
    log("ITEM_DOOR", string.format("[HAND-FOLLOW] attach (%s) loc=(%.2f,%.2f,%.2f) rot=(%.1f,%.1f,%.1f)",
        tostring(reason),
        HAND_ATTACH_OFFSET.loc[1], HAND_ATTACH_OFFSET.loc[2], HAND_ATTACH_OFFSET.loc[3],
        HAND_ATTACH_OFFSET.rot[1], HAND_ATTACH_OFFSET.rot[2], HAND_ATTACH_OFFSET.rot[3]))
end

-- 清空抓取跟踪状态（不销毁 spawned_keys 中的 actor）
local function grab_reset(reason)
    last_hand_offset = nil -- #3 脏检查缓存失效（换抓取会话，防跨会话误跳过引擎写）
    -- 异常路径统一脱附左手（过场/actor 丢失/换关等；未吸附时 no-op）
    detach_hand_from_key(reason)
    state.grab_phase = GrabPhase.Idle
    state.grab_door_name = nil
    state.grab_key_name = nil
    state.grab_actor = nil
    state.flight_start_t = nil
    state.flight_start_loc = nil
    state.flight_start_rot = nil
    state.flight_end_loc = nil
    state.flight_end_rot = nil
    state.insert_state = nil
    state.insert_seat_loc = nil
    state.insert_seat_rot = nil
    state.insert_entry = nil
    state.insert_base_rot = nil
    state.insert_door_mesh = nil
    state.insert_mesh_swapped = nil
    -- Phase 4a：清拧转状态
    state.rotate_axis = nil
    state.rotate_body_rot = nil
    state.rotate_start_pitch = 0
    state.rotate_started = false
    state.rotate_progress = 0
    state.rotate_completed = false
    state.rotate_returning = false
    state.rotate_return_start_t = 0
    state.rotate_return_start_progress = 0
    -- Phase 4b：异常路径（过场/actor 丢失/换关）也清 finalize，防残留阻塞下次解锁
    state.finalize_started = false
    state.finalize_lock = nil
    state.finalize_temp = nil
    state.finalize_row = nil
    state.finalize_key = nil
    state.finalize_t0 = nil
    -- Phase 4b 跟随清理（finalize 完成回 Idle / 异常路径）
    state.follow_sm = nil
    state.follow_local_pos = nil
    state.follow_local_rot = nil
    state.follow_started = false
    if reason ~= nil then
        log("ITEM_DOOR", "[GRAB] reset: " .. tostring(reason))
    end
end

-- 门钥匙抓取音（Phase 4b：抓取完成瞬间播放）。
-- 关键：Play_Item_PickUp 依赖 Item_Type switch 区分音色（否则落默认纸张声），必须走
-- audio.play_event_at_actor（从钥匙 actor AudioComponent.SavedSwitchValue 取引擎已解析 switch，
-- 发到同一钥匙 actor 宿主）。diag Test Play_Item_PickUp 已验证（钥匙 actor 路由）。
-- 必须定义在 finish_grab_attach 之前（后者直接调用，local 前置引用会解析为 nil 全局 →
-- 2026-08-21 实测此坑：调用 nil 中断 finish_grab_attach，[SOUND]/[GRAB] holding 均未打出）。
local KEY_PICKUP_EVENT = "Play_Item_PickUp"
local KEY_PICKUP_EVENT_PATH = "/Game/WWiseAudio/Events/Item/Play_Item_PickUp.Play_Item_PickUp"
local function play_key_pickup_sound()
    if audio == nil or type(audio.play_event_at_actor) ~= "function" then return end
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then return end
    local ok = audio.play_event_at_actor(KEY_PICKUP_EVENT, KEY_PICKUP_EVENT_PATH, actor)
    log("ITEM_DOOR", string.format("[SOUND] pickup Play_Item_PickUp -> key actor ok=%s", tostring(ok)))
end

-- =============================================================================
-- 钥匙偏移 configui 面板（纯滑块 UI，不做持久化）
--   面板名 "Item Door Key Offset"；受 main.lua 开发者模式门控：setDeveloperMode 被注释时
--   不调用 init_config_ui。configui saveFile 传 ""（不读写 json），偏移整表由
--   load_key_offsets / persist_key_offsets 落在 data/keys.json。
--   设计：下拉选钥匙 → 滑块编辑该钥匙 loc/rot/ins/pullback；拉变动实时写回 state.key_offsets 并整表落盘；
--   抓取钥匙时自动切换当前编辑钥匙（finish_grab_attach → M.set_diag_key）。
-- =============================================================================
local key_offset_cfg_active = false  -- 面板已注册标记（防止未注册时误刷新）
local key_offset_combo_names = {}    -- 当前下拉钥匙名缓存（index -> name）

local function key_offset_refresh_combo()
    if configui == nil or not key_offset_cfg_active then return end
    local names = M.get_key_offset_names()
    if #names == 0 then names = { "default" } end
    key_offset_combo_names = names
    configui.setSelections("idk_key", names)
    local cur = state.diag_key or "default"
    local idx = 0
    for i, n in ipairs(names) do
        if n == cur then idx = i - 1 break end
    end
    configui.setValue("idk_key", idx, true)
end

-- 把某钥匙偏移载入滑块（noCallbacks=true 避免触发写回回调）
local function key_offset_load_to_widgets(key)
    if configui == nil then return end
    local ofs = get_key_offset(key)
    configui.setValue("idk_loc_x", ofs.loc[1], true)
    configui.setValue("idk_loc_y", ofs.loc[2], true)
    configui.setValue("idk_loc_z", ofs.loc[3], true)
    configui.setValue("idk_rot_p", ofs.rot[1], true)
    configui.setValue("idk_rot_y", ofs.rot[2], true)
    configui.setValue("idk_rot_r", ofs.rot[3], true)
    configui.setValue("idk_pullback", ofs.pullback or KEY_PULLBACK_DEFAULT_CM, true)
    local ins = ofs.ins or { 0, 0, 0 }
    configui.setValue("idk_ins_p", ins[1], true)
    configui.setValue("idk_ins_y", ins[2], true)
    configui.setValue("idk_ins_r", ins[3], true)
end

-- 滑块当前值 flush 回钥匙（切换下拉前调用）
local function key_offset_flush_widgets(key)
    if configui == nil then return end
    local ofs = get_key_offset(key)
    ofs.loc[1] = tonumber(configui.getValue("idk_loc_x")) or ofs.loc[1]
    ofs.loc[2] = tonumber(configui.getValue("idk_loc_y")) or ofs.loc[2]
    ofs.loc[3] = tonumber(configui.getValue("idk_loc_z")) or ofs.loc[3]
    ofs.rot[1] = tonumber(configui.getValue("idk_rot_p")) or ofs.rot[1]
    ofs.rot[2] = tonumber(configui.getValue("idk_rot_y")) or ofs.rot[2]
    ofs.rot[3] = tonumber(configui.getValue("idk_rot_r")) or ofs.rot[3]
    ofs.pullback = tonumber(configui.getValue("idk_pullback")) or (ofs.pullback or KEY_PULLBACK_DEFAULT_CM)
    local ins = ofs.ins or { 0, 0, 0 }
    ofs.ins = ins
    ins[1] = tonumber(configui.getValue("idk_ins_p")) or ins[1]
    ins[2] = tonumber(configui.getValue("idk_ins_y")) or ins[2]
    ins[3] = tonumber(configui.getValue("idk_ins_r")) or ins[3]
end

-- 单个滑块变动回调：写回当前钥匙，若正持有该钥匙则实时刷新
local function key_offset_on_slider(field, index)
    if state.diag_key == nil then return end
    local key = state.diag_key
    local ofs = get_key_offset(key)
    local wid
    if field == "loc" then
        wid = index == 1 and "idk_loc_x" or (index == 2 and "idk_loc_y" or "idk_loc_z")
    elseif field == "rot" then
        wid = index == 1 and "idk_rot_p" or (index == 2 and "idk_rot_y" or "idk_rot_r")
    elseif field == "ins" then
        wid = index == 1 and "idk_ins_p" or (index == 2 and "idk_ins_y" or "idk_ins_r")
    end
    local v = tonumber(configui.getValue(wid)) or 0
    if ofs[field] == nil then ofs[field] = { 0, 0, 0 } end
    ofs[field][index] = v
    persist_key_offsets()  -- 滑块改动：整表实时落盘
    local helf_apply = (state.grab_phase == GrabPhase.Holding and state.grab_key_name == key)
    log("ITEM_DOOR", string.format("[SLIDER] field=%s[%d] v=%.3f | diag_key=%s | grab_key=%s | apply=%s",
        field, index, v, tostring(state.diag_key), tostring(state.grab_key_name), tostring(helf_apply)))
    if state.grab_phase == GrabPhase.Holding and state.grab_key_name == key then
        apply_key_hand_offset(state.grab_actor, key)
    end
end

-- M.set_diag_key 现已直接用 state.diag_key（字符串）无条件驱动面板（key_offset_refresh_combo），不再需要此函数。

function M.init_config_ui()
    if configui == nil or configui.createConfigPanel == nil then
        log("ITEM_DOOR", "[KEYOFF] configui not available, skipping key offset config UI")
        return
    end
    if key_offset_cfg_active then
        key_offset_refresh_combo()
        key_offset_load_to_widgets(state.diag_key)  -- 已注册也无返回值：重载后须回显 json 数据，否则滑块停在初始值
        return
    end
    key_offset_cfg_active = true
    ensure_key_offsets()

    local widgets = {
        { widgetType = "combo", id = "idk_key", label = "Key", selections = {}, initialValue = 0, width = 260 },
        { widgetType = "input_text", id = "idk_current", label = "Current Key", initialValue = "default", width = 260 },
        { widgetType = "slider_float", id = "idk_loc_x", label = "Loc X (cm)", range = { -20, 20 }, initialValue = 0, format = "%.2f" },
        { widgetType = "slider_float", id = "idk_loc_y", label = "Loc Y (cm)", range = { -20, 20 }, initialValue = 0, format = "%.2f" },
        { widgetType = "slider_float", id = "idk_loc_z", label = "Loc Z (cm)", range = { -20, 20 }, initialValue = 0, format = "%.2f" },
        { widgetType = "slider_float", id = "idk_rot_p", label = "Rot Pitch (deg)", range = { -180, 180 }, initialValue = 0, format = "%.0f" },
        { widgetType = "slider_float", id = "idk_rot_y", label = "Rot Yaw (deg)", range = { -180, 180 }, initialValue = 0, format = "%.0f" },
        { widgetType = "slider_float", id = "idk_rot_r", label = "Rot Roll (deg)", range = { -180, 180 }, initialValue = 0, format = "%.0f" },
        { widgetType = "slider_float", id = "idk_pullback", label = "Pullback (cm)", range = { -10, 10 }, initialValue = 6, format = "%.1f" },
        { widgetType = "slider_float", id = "idk_ins_p", label = "Ins Pitch (deg)", range = { -180, 180 }, initialValue = 0, format = "%.0f" },
        { widgetType = "slider_float", id = "idk_ins_y", label = "Ins Yaw (deg)", range = { -180, 180 }, initialValue = 0, format = "%.0f" },
        { widgetType = "slider_float", id = "idk_ins_r", label = "Ins Roll (deg)", range = { -180, 180 }, initialValue = 0, format = "%.0f" },
    }
    configui.createConfigPanel("Item Door Key Offset", "", widgets)
    -- 下拉的 UEVR 预览文本不随编程 setValue 刷新，会误导（残留上一把钥匙），故隐藏，改用只读 Current Key 直显
    configui.hideWidget("idk_key", true)

    -- 初始化当前编辑钥匙与滑块
    if state.diag_key == nil then state.diag_key = "default" end
    key_offset_refresh_combo()
    key_offset_load_to_widgets(state.diag_key)

    -- 下拉切换：flush 旧钥匙 -> 切新钥匙 -> 载入新钥匙滑块
    configui.onUpdate("idk_key", function(idx)
        local key = state.diag_key or "default"
        if key ~= "default" then key_offset_flush_widgets(key) end
        local name = key_offset_combo_names[(idx or 0) + 1] or "default"
        state.diag_key = name
        key_offset_load_to_widgets(name)
    end)
    -- 滑块变动回调
    configui.onUpdate("idk_loc_x", function() key_offset_on_slider("loc", 1) end)
    configui.onUpdate("idk_loc_y", function() key_offset_on_slider("loc", 2) end)
    configui.onUpdate("idk_loc_z", function() key_offset_on_slider("loc", 3) end)
    configui.onUpdate("idk_rot_p", function() key_offset_on_slider("rot", 1) end)
    configui.onUpdate("idk_rot_y", function() key_offset_on_slider("rot", 2) end)
    configui.onUpdate("idk_rot_r", function() key_offset_on_slider("rot", 3) end)
    configui.onUpdate("idk_ins_p", function() key_offset_on_slider("ins", 1) end)
    configui.onUpdate("idk_ins_y", function() key_offset_on_slider("ins", 2) end)
    configui.onUpdate("idk_ins_r", function() key_offset_on_slider("ins", 3) end)
    configui.onUpdate("idk_pullback", function()
        if state.diag_key == nil then return end
        local ofs = get_key_offset(state.diag_key)
        ofs.pullback = tonumber(configui.getValue("idk_pullback")) or ofs.pullback
        persist_key_offsets()  -- 滑块改动：整表实时落盘
    end)

    log("ITEM_DOOR", "[KEYOFF] config UI registered (pure UI; persists to " .. KEY_OFFSETS_JSON .. ")")
end

-- 供 diagnose / 外部在切换当前钥匙时同步下拉高亮与滑块
function M.refresh_config_ui()
    if key_offset_cfg_active then
        key_offset_refresh_combo()
        key_offset_load_to_widgets(state.diag_key)
    end
end

-- 当前诊断编辑的钥匙键名（nil 表示 default）
function M.get_diag_key()
    return state.diag_key
end

function M.set_diag_key(key_name)
    state.diag_key = key_name
    log("ITEM_DOOR", string.format("[DIAG-KEY] set_diag_key -> %s (grab_key_name=%s)",
        tostring(key_name), tostring(state.grab_key_name)))
    if configui ~= nil and key_offset_cfg_active then
        -- 以当前手上钥匙（字符串 state.diag_key）为唯一真值驱动面板：
        -- 无条件按字符串重建 combo 并载入滑块，与 [DIAG-KEY] 日志同一来源，
        -- 避免 combo 沿用旧缓存的 index / 残留上一把钥匙。
        key_offset_refresh_combo()
        key_offset_load_to_widgets(state.diag_key)
        -- 只读框直显手上钥匙名（字符串，与日志同源），绕开 UEVR combo 预览不刷新的问题
        pcall(function()
            configui.setValue("idk_current", tostring(state.diag_key or "default"), true)
        end)
        local idx = configui.getValue("idk_key") or -1
        log("ITEM_DOOR", string.format("[KEYOFF-SYNC] target=%s idx=%s combo_n=%s",
            tostring(state.diag_key), tostring(idx),
            key_offset_combo_names and tostring(#key_offset_combo_names) or "-1"))
    end
end

-- 已知钥匙配置键名列表（供下拉选择）
-- 合并 state.key_offsets 已有条目 + L1 门缓存中所有门的 UnlockItem.RowName，
-- 确保未抓取过的钥匙也能出现在下拉菜单中供用户选择并自动创建条目。
function M.get_key_offset_names()
    local cfg = ensure_key_offsets()
    local seen = {}
    -- 1. 已有 key_offsets 中的条目（含 default）
    for k in pairs(cfg) do
        seen[k] = true
    end
    -- 2. 合并 L1 门缓存中所有门的 row_name（未抓取过的钥匙也能显示在下拉中）
    if state.door_cache ~= nil and state.door_cache_valid then
        for _, entry in ipairs(state.door_cache) do
            local rn = entry.row_name
            if rn ~= nil and rn ~= "" then
                seen[tostring(rn)] = true
            end
        end
    end
    -- 3. 确保 default 始终存在
    seen["default"] = true
    local names = {}
    for k in pairs(seen) do
        names[#names + 1] = k
    end
    table.sort(names)
    return names
end

-- 读取当前诊断钥匙的偏移（含 ins 插入旋转与 pullback，供外部诊断完整回显）
function M.get_diag_key_offset()
    local key = state.diag_key
    local ofs = get_key_offset(key)
    local ins = ofs.ins or { 0, 0, 0 }
    return {
        key = key,
        loc = { ofs.loc[1], ofs.loc[2], ofs.loc[3] },
        rot = { ofs.rot[1], ofs.rot[2], ofs.rot[3] },
        ins = { tonumber(ins[1]) or 0, tonumber(ins[2]) or 0, tonumber(ins[3]) or 0 },
        pullback = tonumber(ofs.pullback) or KEY_PULLBACK_DEFAULT_CM,
    }
end

-- 写入当前诊断钥匙的偏移（滑块回调；整表实时落盘）
function M.set_diag_key_offset(field, index, value)
    local key = state.diag_key
    local ofs = get_key_offset(key)
    if ofs[field] == nil then ofs[field] = { 0, 0, 0 } end
    ofs[field][index] = tonumber(value) or 0
    persist_key_offsets()
    log("ITEM_DOOR", string.format("[KEYOFF] set key=%s field=%s idx=%d value=%.2f -> loc=(%s) rot=(%s) ins=(%s) pullback=%.2f",
        tostring(key), tostring(field), index, ofs[field][index],
        table.concat({ string.format("%.2f", ofs.loc[1]), string.format("%.2f", ofs.loc[2]), string.format("%.2f", ofs.loc[3]) }, ","),
        table.concat({ string.format("%.1f", ofs.rot[1]), string.format("%.1f", ofs.rot[2]), string.format("%.1f", ofs.rot[3]) }, ","),
        table.concat({ string.format("%.1f", (ofs.ins or {})[1] or 0), string.format("%.1f", (ofs.ins or {})[2] or 0), string.format("%.1f", (ofs.ins or {})[3] or 0) }, ","),
        tonumber(ofs.pullback) or KEY_PULLBACK_DEFAULT_CM))
    -- 若正在持有该钥匙，实时刷新手部偏移（Seated 期由 tick_seated 每帧按最新配置重钉，无需在此处理）
    if state.grab_phase == GrabPhase.Holding and state.grab_key_name == key then
        apply_key_hand_offset(state.grab_actor, key)
    end
end

-- 飞行完成：把钥匙 Mesh 附着到左手 hand_l_bn + 应用每钥手部偏移
local function finish_grab_attach()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then
        grab_reset("grab attach fail")
        return
    end
    -- 新方案：不做 attach（IK 手臂网格 attach 会致 root 位置爆炸），holding 期每帧用左手插槽世界坐标覆盖 root
    apply_key_hand_offset(actor, state.grab_key_name)
    -- 设置手部动画（pull_lock，与 unlock_door 拧钥匙手势一致）
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, "pull_lock")
    end)
    state.flight_start_t = nil
    state.flight_start_loc = nil
    state.flight_start_rot = nil
    state.flight_end_loc = nil
    state.flight_end_rot = nil
    state.grab_phase = GrabPhase.Holding
    -- 诊断滑块默认编辑当前持有的钥匙（同步下拉高亮+滑块载入，消除面板显示与生效数据脱节）
    M.set_diag_key(state.grab_key_name)
    -- 触觉反馈
    if eventFeedback ~= nil and type(eventFeedback.play_remote_grab_haptic) == "function" then
        pcall(eventFeedback.play_remote_grab_haptic)
    end
    -- 诊断：打印门名 + 配置键名 + spawn 记录 RowName 三方，定位"手上钥匙与面板不符"是门→行错配还是行本身错配
    local spawn_door_name = tostring(state.grab_door_name)
    local spawn_rec_row = nil
    pcall(function()
        if state.spawned_keys ~= nil then
            local sk = state.spawned_keys[state.grab_door_name]
            if sk ~= nil then spawn_rec_row = tostring(sk.row_name) end
        end
    end)
    log("ITEM_DOOR", string.format("[MATCH] door=%s | cfg_key=%s | spawn_row=%s",
        spawn_door_name, tostring(state.grab_key_name), tostring(spawn_rec_row)))
    log("ITEM_DOOR", string.format("[GRAB] holding %s on hand_l_bn", tostring(state.grab_key_name)))
end

-- 钥匙飞回 spawn 原位完成后的收尾：清理手部偏移（Mesh relative 归零）、恢复自转、抓取态回 Idle。
-- 复用 rt_tick_flight 已把 root 写到 home；此处只清偏移与复位状态。
local function drop_key_at_home()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor ~= nil then
        local comp = nil
        pcall(function() comp = actor["Mesh"] end)
        comp = uevrUtils.getValid(comp)
        if comp ~= nil then
            -- 清抓取时写的手部偏移（loc+rot），钥匙回原位后仅自转、无残留相对姿态
            pcall(function()
                uevrUtils.set_component_relative_location(comp, uevrUtils.vector(0, 0, 0))
                uevrUtils.set_component_relative_rotation(comp, uevrUtils.rotator(0, 0, 0))
            end)
            last_hand_offset = nil -- #3 缓存失效：相对变换已被归零
        end
        -- 恢复 spawn 展示自转
        spin.start(actor, KEY_SPIN_PERIOD_S)
    end
    state.flight_return_home = false
    state.flight_home_pos = nil
    state.flight_home_rot = nil
    grab_reset("drop home")
end

-- 飞行阶段 tick：钥匙从当前位置 lerp 到左手
local function tick_grab_flying()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then
        grab_reset("grab actor lost")
        return
    end
    local root = reload_tools.get_actor_root(actor)
    if root == nil then
        grab_reset("grab root missing")
        return
    end
    -- 复用 remote_grab 的成熟飞行工具：驱动 actor root（整 actor）
    -- 目的由 flight_return_home 决定：
    --   false = 飞向实时左手（正常抓取）；true = 飞回 spawn 原位（Holding 松手放回）。
    local return_home = state.flight_return_home == true
    local end_fn = return_home
        and function()
            return state.flight_home_pos, state.flight_home_rot
        end
        or function()
            return get_left_hand_socket_world()
        end
    local result = remote_grab.rt_tick_flight(
        root,
        state.flight_start_loc,
        state.flight_start_rot,
        state.flight_start_t,
        FLIGHT_DURATION,
        end_fn
    )
    if result == "attach" then
        if return_home then
            drop_key_at_home()
        else
            finish_grab_attach()
        end
    elseif result == "lost" then
        grab_reset("grab root lost")
    end
end

-- 预加载该钥匙的门挂变体资产（{主短名}_doorattachment）：
-- 主 mesh（手持/掉落姿态建模）与门上引擎最终挂的变体（挂门姿态建模）几何有差异，
-- 纯旋转只能大概对齐 → 落座时换装变体，建模即挂门姿态，与 LoadAndTrySetKeyMesh 最终呈现一致。
-- 候选源优先级：
--   0. 门自身 KeyStaticMesh 已挂的 mesh（引擎 LoadAndTrySetKeyMesh 的原版选择，已解锁门有效，零猜测）
--   1. 路径推导（主短名去 _Inspect 后缀 → 同目录 / Keys 根目录，getLoadedAsset 阻塞加载）
--   2. 已加载实例按末段短名匹配回退
-- 全部失败：dump DataTable 行字段到日志（排查是否存在 doorattachment 专用列），回退主 mesh + ins。
-- 返回值：mesh（失败 nil）, source（命中路径标签 + 开销统计，供 spawn 诊断日志用）：
--   door_key_static_mesh:<full> / already_variant / path:<ref>|att=k/n|derive=x.xms /
--   loaded_instance:<full>|att=k/n|derive=x.xms|enum_n=N|enum=x.xms /
--   none|att=n/n|derive=..|enum_n=..|enum=.. / no_mesh / no_static_mesh / bad_mesh_name
--   att=推导链第 k 次命中/共 n 次（每次 getLoadedAsset 未加载时内部 LoadAsset_Blocking，潜在阻塞点）；
--   derive=推导链累计耗时；enum_n/enum=全图枚举对象数/耗时（仅走到兜底时非 0）。
-- 必须定义在 begin_insert 之前（后者直接调用它，local 前置引用会解析为 nil 全局）。
load_doorattachment_mesh = function(actor, door_entry)
    -- 候选源 0：门上 KeyStaticMesh 已挂 mesh（引擎原版资产，最精确）
    if door_entry ~= nil and door_entry.actor ~= nil then
        local door_sm = read_key_mesh(door_entry.actor)
        if door_sm ~= nil then
            local dfull = nil
            pcall(function() dfull = door_sm:get_full_name() end)
            log("ITEM_DOOR", "[SEAT-MESH] from door KeyStaticMesh: " .. tostring(dfull))
            return door_sm, "door_key_static_mesh:" .. tostring(dfull)
        end
    end
    local mesh = get_itembase_mesh(actor)
    if mesh == nil then return nil, "no_mesh" end
    local full = nil
    pcall(function()
        if mesh.StaticMesh ~= nil then full = mesh.StaticMesh:get_full_name() end
    end)
    if full == nil then return nil, "no_static_mesh" end
    -- 幂等：已是变体（spawn/插入期换装过）直接返回当前 mesh。
    -- 否则会拼出 _doorattachment_doorattachment 双后缀必然查找失败 → insert_mesh_swapped=false，
    -- 变体被错误走 compose(锁坯,ins) 路径（2026-08-17 修复）。
    if string.match(tostring(full), "_doorattachment%.") ~= nil then
        log("ITEM_DOOR", "[SEAT-MESH] already variant: " .. tostring(full))
        return mesh.StaticMesh, "already_variant"
    end
    -- "StaticMesh /Game/.../Keys/SaulApsB2Key.SaulApsB2Key" → 对象路径 + 短名
    local obj_path = string.match(tostring(full), "^StaticMesh%s+(.+)$")
    if obj_path == nil then return nil, "bad_mesh_name" end
    local name = string.match(obj_path, "%.([%w_]+)$")
    local base_path = string.match(obj_path, "^(.*)%.[%w_]+$")
    if name == nil or base_path == nil then return nil, "bad_mesh_name" end
    local dir = string.match(base_path, "^(.*)/[%w_]+$") or "/Game/Game/Art/Items/Keys"
    -- 候选短名：本体原名优先（2026-09-03 21:48 多关实测实锤：12+ 组配对成功案例中，
    -- 变体短名 = 本体短名 + "_doorattachment" 无一例外，WsaFW_/HP_ 等带前缀名前缀原样保留）。
    -- 兜底：逐级剥尾部纯字母段（唯一实测例外 KeyLockerRoom_A_Posed：变体不带 _Posed，
    -- A 族第一轮剥离即可命中）。
    -- B 族"剥关卡前缀"候选已废弃（2026-09-03 21:48）：全部实测数据中没有任何变体剥过前缀，
    -- 保留只会多出必然 miss 的阻塞加载尝试（getLoadedAsset 未加载时内部 LoadAsset_Blocking）。
    -- 候选上限 6（× 2 目录 = 最多 12 次尝试），控制 miss 期的阻塞加载成本；本体原名排最前。
    local shorts = {}
    local seen = {}
    local function push_short(n)
        if n ~= nil and not seen[n] and #n >= 3 and #shorts < 6 then
            seen[n] = true
            shorts[#shorts + 1] = n
        end
    end
    -- A 族：原名逐级剥尾部（剥到段内含数字即停，避免把 KeyFlat_03_A 这类合法后缀误剥）
    local cur = name
    for _ = 1, 5 do
        push_short(cur)
        local stripped = string.match(cur, "^(.*)_[A-Za-z]+$")
        if stripped == nil or #stripped < 3 then break end
        cur = stripped
    end
    -- 候选目录：主 mesh 同目录优先 → Keys 根目录
    -- 2026-09-03 实锤："变体与本体同目录"（12+ 组配对无一例外），dir[1] 命中绝大多数；
    -- Keys 根目录为第二保险。目录维度无更深层规律（公共前缀只到 /Game/Game/Art/Items/），
    -- 不再扩展候选目录列表，miss 后交由下方已加载实例枚举兜底。
    -- 2026-09-03 诊断：统计推导链尝试次数 + 总耗时（getLoadedAsset 未加载时内部 LoadAsset_Blocking，
    -- 每次=一次潜在阻塞加载；derive_ms 大即阻塞加载实锤）
    local dirs = { dir, "/Game/Game/Art/Items/Keys" }
    -- 2026-09-03 诊断：打印本体 mesh 资产路径 + 推导出的候选（目录 × 短名），
    -- 多把钥匙的数据积累后用于归纳 doorattachment 的真实命名/目录规律
    log("ITEM_DOOR", string.format("[KEY-MESH] body=%s", tostring(full)))
    log("ITEM_DOOR", string.format("[KEY-MESH] derived dir=%s name=%s shorts=[%s] dirs=[%s]",
        tostring(dir), tostring(name), table.concat(shorts, ","), table.concat(dirs, ",")))
    local derive_t0 = os.clock()
    local att = 0
    local att_total = #shorts * #dirs
    for _, sn in ipairs(shorts) do
        local short = sn .. "_doorattachment"
        for _, d in ipairs(dirs) do
            local ref = "StaticMesh " .. d .. "/" .. short .. "." .. short
            local asset = nil
            att = att + 1
            pcall(function()
                if type(uevrUtils.getLoadedAsset) == "function" then
                    asset = uevrUtils.getLoadedAsset(ref)
                end
            end)
            if asset ~= nil then
                local derive_ms = (os.clock() - derive_t0) * 1000
                log("ITEM_DOOR", string.format("[SEAT-MESH] loaded %s (att=%d/%d, derive=%.1fms)",
                    ref, att, att_total, derive_ms))
                return asset, string.format("path:%s|att=%d/%d|derive=%.1fms", ref, att, att_total, derive_ms)
            else
                -- 2026-09-03 诊断：逐条记录 miss 的猜测路径（配合 [KEY-MESH] 归纳规律用）
                log("ITEM_DOOR", "[SEAT-MESH] miss " .. ref)
            end
        end
    end
    -- 回退：已加载实例末段短名匹配（资产不在常规路径时；全部候选短名都试）
    -- 2026-09-03 诊断：记录枚举对象数 + 耗时（enum_n/enum_ms，数千对象时数百 ms 级实锤）
    local enum_t0 = os.clock()
    local enum_n = 0
    local found = nil
    pcall(function()
        local all = uevrUtils.find_all_of("Class /Script/Engine.StaticMesh", false)
        if all ~= nil then
            enum_n = #all
            for _, m in ipairs(all) do
                local mf = nil
                pcall(function() mf = m:get_full_name() end)
                local last = mf ~= nil and string.match(tostring(mf), "%.([%w_]+)$") or nil
                if last ~= nil then
                    for _, sn in ipairs(shorts) do
                        if last == (sn .. "_doorattachment") then
                            found = m
                            break
                        end
                    end
                end
                if found ~= nil then break end
            end
        end
    end)
    local enum_ms = (os.clock() - enum_t0) * 1000
    if found ~= nil then
        local ffull = nil
        pcall(function() ffull = found:get_full_name() end)
        log("ITEM_DOOR", string.format("[SEAT-MESH] fallback instance %s (att=%d/%d, derive=%.1fms, enum_n=%d, enum=%.1fms)",
            tostring(ffull), att, att_total, (os.clock() - derive_t0) * 1000, enum_n, enum_ms))
        return found, string.format("loaded_instance:%s|att=%d/%d|derive=%.1fms|enum_n=%d|enum=%.1fms",
            tostring(ffull), att, att_total, (os.clock() - derive_t0) * 1000, enum_n, enum_ms)
    else
        log("ITEM_DOOR", string.format("[SEAT-MESH] no doorattachment asset for %s (att=%d/%d, derive=%.1fms, enum_n=%d, enum=%.1fms; keep main mesh + ins)",
            name, att, att_total, (os.clock() - derive_t0) * 1000, enum_n, enum_ms))
        -- 排查辅助：dump DataTable 行字段到日志（寻找是否存在 doorattachment 专用列，2026-08-17）
        if door_entry ~= nil and door_entry.data_table ~= nil and door_entry.row_name ~= nil then
            pcall(function()
                local uevr_api = rawget(_G, "uevr")
                if uevr_api == nil or uevr_api.api == nil then return end
                local lib_class = uevr_api.api:find_uobject("Class /Script/Engine.DataTableFunctionLibrary")
                if lib_class == nil then return end
                local lib_cdo = lib_class:get_class_default_object()
                if lib_cdo == nil then return end
                local out_row = {}
                local rn = uevrUtils.fname_from_string(tostring(door_entry.row_name))
                if not lib_cdo:GetDataTableRowFromName(door_entry.data_table, rn, out_row) then return end
                local row = out_row.result
                if row == nil then return end
                for k, v in pairs(row) do
                    log("ITEM_DOOR", string.format("[SEAT-DT] %s.%s = %s",
                        tostring(door_entry.row_name), tostring(k), tostring(v)))
                end
            end)
        end
    end
    return found, string.format("none|att=%d/%d|derive=%.1fms|enum_n=%d|enum=%.1fms",
        att, att_total, (os.clock() - derive_t0) * 1000, enum_n, enum_ms)
end

-- =============================================================================
-- Phase 4a：拧钥匙 + 解锁门（对齐 unlock_door ROTATING L1528-1723 结构，数学走 math_lib 不封装）
-- 位置钉死落座点，只旋转；Grip 按住拧转、松开即脱附（用户拍板）。
-- =============================================================================

-- 播放开锁音效 Play_Key_Unlock（走 libs/audio，pistol/rifle/shotgun 同模式）
-- 播放时长优先查 Wwise MaximumDuration，查询失败兜底固定值；register_event 幂等
local function play_key_unlock_sound()
    if audio == nil or type(audio.play_segment) ~= "function" then return end
    if type(audio.register_event) == "function" then
        audio.register_event(KEY_UNLOCK_AUDIO_KEY, KEY_UNLOCK_EVENT, KEY_UNLOCK_EVENT_PATH)
    end
    local dur = nil
    pcall(function()
        if type(audio.get_max_duration) == "function" then
            dur = audio.get_max_duration(KEY_UNLOCK_EVENT)
        end
    end)
    if dur == nil or dur <= 0 then dur = KEY_UNLOCK_AUDIO_FALLBACK_S end
    pcall(audio.play_segment, KEY_UNLOCK_AUDIO_KEY, 0, dur)
end

-- 解锁门（4a 仅此一步）：复用 unlock_door.unlock_door_directly
-- （内部 navigate_to_door_lock → SetLocked(false, true)；RemoveItem/LoadAndTrySetKeyMesh 属 4b）
local function apply_unlock()
    if unlock_door == nil or type(unlock_door.unlock_door_directly) ~= "function" then
        log("ITEM_DOOR", "[ROTATE] apply_unlock: unlock_door module unavailable")
        return
    end
    if state.insert_entry == nil or state.insert_entry.actor == nil then
        log("ITEM_DOOR", "[ROTATE] apply_unlock: insert_entry actor nil")
        return
    end
    local key_sm = nil
    pcall(function() key_sm = state.insert_entry.actor["KeyStaticMesh"] end)
    if key_sm == nil then
        log("ITEM_DOOR", "[ROTATE] apply_unlock: KeyStaticMesh nil")
        return
    end
    local ok = false
    pcall(function() ok = (unlock_door.unlock_door_directly(key_sm) == true) end)
    log("ITEM_DOOR", string.format("[ROTATE] apply_unlock %s for %s",
        ok and "OK" or "FAIL", tostring(state.grab_key_name)))
end

-- =============================================================================
-- Phase 4b 跟随（用户 2026-08-21 拍板：拧到位即启动，不是松手后）：
--   apply_unlock 后门已解锁、可能被推开，而表演体仍钉死在拧转落座点 → 门动钥匙不动穿帮。
--   真钥匙 mesh 在松手 finalize 后才异步渲染，但 KeyStaticMesh 组件位姿随时可读。
--   方案：拧到位瞬间快照「表演体相对组件的本地偏移」（位置差旋转回组件本地系 + 旋转差），
--   此后每帧 childWorldTransform(组件当前位姿, 本地偏移) 写表演体——保持相对姿态跟随，
--   门绕铰链转动时钥匙位置/朝向都随门走，零跳变；松手 finalize 就绪后销毁，无缝交接。
-- =============================================================================
-- 旋转求逆（欧拉倒序取反近似；门锁场景组件旋转通常 (0,0,0)，此时精确）
local function inverse_rot(r)
    return { Pitch = -(r.Roll or 0), Yaw = -(r.Yaw or 0), Roll = -(r.Pitch or 0) }
end

-- 启动跟随：快照表演体相对锁孔 KeyStaticMesh 组件的本地偏移
local function start_follow_lock_sm(actor, reason)
    if state.follow_started then return end
    if actor == nil then return end
    local lock_actor = state.insert_entry ~= nil and state.insert_entry.actor or nil
    if lock_actor == nil then
        log("ITEM_DOOR", "[FOLLOW] start skip: insert_entry actor nil")
        return
    end
    local mc = nil
    pcall(function() mc = lock_actor["KeyStaticMesh"] end)
    if mc == nil then
        log("ITEM_DOOR", "[FOLLOW] start skip: KeyStaticMesh nil")
        return
    end
    local sm_loc = reload_tools.get_component_world_location(mc)
    local sm_rot = reload_tools.get_component_world_rotation(mc)
    local root = reload_tools.get_actor_root(actor)
    local t_loc = root ~= nil and reload_tools.get_component_world_location(root) or nil
    local t_rot = root ~= nil and reload_tools.get_component_world_rotation(root) or nil
    if sm_loc == nil or t_loc == nil then
        log("ITEM_DOOR", "[FOLLOW] start skip: world pose unreadable")
        return
    end
    -- 本地位置偏移 = 世界差旋转回组件本地系（childWorldTransform 的逆变换）
    local world_diff = { X = t_loc.X - sm_loc.X, Y = t_loc.Y - sm_loc.Y, Z = t_loc.Z - sm_loc.Z }
    local local_pos = world_diff
    if sm_rot ~= nil then
        pcall(function() local_pos = math_lib.vectorRotate(world_diff, inverse_rot(sm_rot)) end)
    end
    -- 本地旋转偏移 = childWorldTransform 的逆：local = compose(world, inverse(parent))
    -- （门锁组件旋转通常 (0,0,0)，composeRotators 零跳过使两序等价；保持推导序以防非零场景）
    local local_rot = nil
    if sm_rot ~= nil and t_rot ~= nil then
        pcall(function() local_rot = math_lib.composeRotators(t_rot, inverse_rot(sm_rot)) end)
    end
    state.follow_sm = mc
    state.follow_local_pos = local_pos
    state.follow_local_rot = local_rot
    state.follow_started = true
    log("ITEM_DOOR", string.format(
        "[FOLLOW] start (%s) sm=(%.1f,%.1f,%.1f) local_pos=(%.1f,%.1f,%.1f) local_rot_set=%s",
        tostring(reason),
        sm_loc.X, sm_loc.Y, sm_loc.Z,
        local_pos.X or 0, local_pos.Y or 0, local_pos.Z or 0,
        tostring(local_rot ~= nil)))
end

-- 每帧跟随：表演体 = childWorldTransform(组件当前位姿, 启动时快照的本地偏移)
local function tick_follow_lock_sm()
    if not state.follow_started or state.follow_sm == nil then return end
    -- 表演体来源：Rotating 期 = grab_actor（Grip 仍按住）；Unlocked/finalize 期 = finalize_temp
    local actor = uevrUtils.getValid(state.finalize_temp ~= nil and state.finalize_temp or state.grab_actor)
    if actor == nil then return end
    local sm_loc = reload_tools.get_component_world_location(state.follow_sm)
    if sm_loc == nil then return end
    local sm_rot = reload_tools.get_component_world_rotation(state.follow_sm)
    local w_loc, w_rot = nil, nil
    pcall(function()
        w_loc, w_rot = math_lib.childWorldTransform(sm_loc, sm_rot, state.follow_local_pos, state.follow_local_rot)
    end)
    if w_loc ~= nil then
        set_actor_world_pose(actor, w_loc, w_rot)
    end
end

-- =============================================================================
-- Phase 4b finalize（松开左 Grip 时触发；顺序不可换 G3，见计划 §5/§912）：
--   ①脱附左手（edge_released 通常已做，此处幂等再调兜底）
--   → ②RemoveItem 消耗背包道具（失败仅记日志，不阻断挂钥匙）
--   → ③LoadAndTrySetKeyMesh 引擎挂真实钥匙（不传临时 mesh，引擎自动选）
--   ③④ 为异步加载窗口（G4），就绪轮询交给 tick_finalize_poll 逐帧驱动。
--   跟随已在拧到位时启动（start_follow_lock_sm），finalize 期间 tick_follow_lock_sm 继续驱动。
-- =============================================================================
local function begin_finalize()
    if state.finalize_started then return end
    local sk = state.spawned_keys ~= nil and state.spawned_keys[state.grab_door_name] or nil
    -- 门锁 actor：优先 insert_entry（Rotating 期由落座/插入写入）；兜底用 spawned_keys 条目的 .entry
    local lock_actor = state.insert_entry ~= nil and state.insert_entry.actor or nil
    if lock_actor == nil and sk ~= nil and sk.entry ~= nil then
        lock_actor = sk.entry.actor
    end
    if lock_actor == nil then
        log("ITEM_DOOR", "[FINAL] skip: lock actor nil")
        grab_reset("finalize no lock")
        return
    end
    local temp_actor = sk ~= nil and sk.actor or nil
    local row_name = sk ~= nil and sk.row_name or state.grab_key_name
    state.finalize_started = true
    state.finalize_lock = lock_actor
    state.finalize_temp = temp_actor
    state.finalize_row = row_name
    state.finalize_key = state.grab_door_name
    state.finalize_t0 = os.clock()
    -- ① 幂等脱附（异常路径兜底）
    detach_hand_from_key("finalize begin")
    -- ② 消耗背包道具
    if row_name ~= nil then
        M.remove_item(row_name)
    end
    -- ③ 引擎挂真实钥匙（不传临时 mesh，让引擎自行选择挂门资产）
    local ok_call = false
    pcall(function() lock_actor:LoadAndTrySetKeyMesh(); ok_call = true end)
    local lock_name = tostring(lock_actor)
    pcall(function() lock_name = lock_actor:get_full_name() or tostring(lock_actor) end)
    log("ITEM_DOOR", string.format("[FINAL] begin LoadAndTrySetKeyMesh=%s lock=%s row=%s",
        tostring(ok_call), tostring(lock_name), tostring(row_name)))
end

-- Phase 4b ③④：异步就绪轮询（复用 poll_variant_swap 的 KeyStaticMesh 就绪判定模式 +
-- FINALIZE_READY_TIMEOUT_S 超时兜底 G4）。就绪或超时后执行 ⑤销毁临时 actor + 清 spawned_keys → 回 Idle。
local function tick_finalize_poll()
    if not state.finalize_started then return end
    local lock_actor = state.finalize_lock
    -- 跟随继续（拧到位时已启动）：finalize 期间门仍可能被推开，表演体保持相对姿态贴住锁孔组件；
    -- 兜底：若跟随未启动（异常路径），以 finalize_temp 当前位姿为基准启动。
    if not state.follow_started and state.finalize_temp ~= nil then
        start_follow_lock_sm(uevrUtils.getValid(state.finalize_temp), "finalize fallback")
    end
    tick_follow_lock_sm()
    local done = false
    if lock_actor ~= nil then
        local sm = nil
        pcall(function()
            local mc = lock_actor["KeyStaticMesh"]
            if mc ~= nil then sm = mc.StaticMesh end
        end)
        if sm ~= nil then done = true end
    end
    local elapsed = os.clock() - (state.finalize_t0 or os.clock())
    if not done and elapsed < FINALIZE_READY_TIMEOUT_S then
        return -- 未就绪且未超时，继续等下帧
    end
    -- 就绪或超时兜底：⑤销毁临时 actor + 清 spawned_keys 条目
    if state.finalize_key ~= nil and state.spawned_keys ~= nil then
        state.spawned_keys[state.finalize_key] = nil
        state.variant_pending = nil -- #4 计数失效：条目移除，下帧重数
    end
    if state.finalize_temp ~= nil then
        spin.stop(state.finalize_temp)
        pcall(function() uevrUtils.destroy_actor(state.finalize_temp) end)
        log("ITEM_DOOR", string.format("[FINAL] temp destroyed ready=%s after=%dms key=%s",
            tostring(done), math.floor(elapsed * 1000), tostring(state.finalize_key)))
    end
    -- 回 Idle（grab_reset 内部清 finalize 字段 + 脱附）
    grab_reset("finalize done")
end

-- 回弹按 progress 写旋转（对齐 unlock_door update_key_rotation_by_progress）
local function update_rotate_by_progress(progress)
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then return end
    if state.rotate_axis == nil or state.rotate_body_rot == nil
        or state.insert_seat_loc == nil then
        return
    end
    local angle_deg = -progress * KEY_ROTATE_THRESHOLD_DEG
    local delta_rot = math_lib.rotatorFromAxisAndAngle(state.rotate_axis, angle_deg)
    local new_rot = math_lib.composeRotators(state.rotate_body_rot, delta_rot)
    -- 位置钉死
    set_actor_world_pose(actor, state.insert_seat_loc, new_rot)
end

-- 拧转驱动（对齐 unlock_door update_key_rotation）：
-- Pitch delta × sensitivity → 只允许逆时针（正 delta 归零）→ clamp ≤90° → 写钥匙 root 旋转
local function update_rotate()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then
        grab_reset("rotate actor lost")
        return
    end
    if state.rotate_axis == nil or state.rotate_body_rot == nil
        or state.insert_seat_loc == nil then
        return
    end
    -- 拧到位后：门已解锁（apply_unlock 已执行）可能被推开，位姿不再钉死，
    -- 改由 follow 逐帧跟随锁孔 KeyStaticMesh 组件（保持相对姿态，松手 finalize 前一直贴住）。
    if state.rotate_completed then
        return
    end
    local hand_rot = controllers.getControllerRotation(0)
    if hand_rot == nil then return end

    local delta_pitch = (hand_rot.Pitch or 0) - (state.rotate_start_pitch or 0)
    local effective_delta = delta_pitch * KEY_ROTATE_SENSITIVITY

    -- 限定方向：只允许逆时针（负 delta_pitch 方向），正方向归零（对齐 unlock_door Phase 3）
    if effective_delta > 0 then
        effective_delta = 0
    end
    -- 限定最大 90°，不能超过解锁阈值（对齐 unlock_door Phase 3）
    if effective_delta < -KEY_ROTATE_THRESHOLD_DEG then
        effective_delta = -KEY_ROTATE_THRESHOLD_DEG
    end
    -- 拧转开始阈值：手逆时针有效转角（×sensitivity，与 90° 完成同口径）超 10° 才算真正开始拧，
    -- 此时才播一次"拧钥匙音效"（此前仅延迟音效，钥匙视觉仍随手动）；过滤落座瞬间手微抖误触发
    if not state.rotate_started and effective_delta <= -KEY_ROTATE_START_THRESHOLD_DEG then
        state.rotate_started = true
        pcall(play_key_unlock_sound)
        log("ITEM_DOOR", string.format("[ROTATE-AUDIO] turn started (>%ddeg, eff=%.1f) Play_Key_Unlock for %s",
            KEY_ROTATE_START_THRESHOLD_DEG, effective_delta, tostring(state.grab_key_name)))
    end
    state.rotate_progress = math.abs(effective_delta) / KEY_ROTATE_THRESHOLD_DEG

    -- 旋转 = 落座基准 + 绕锁孔 Y 轴旋转 effective_delta（负值 = 逆时针）
    local delta_rot = math_lib.rotatorFromAxisAndAngle(state.rotate_axis, effective_delta)
    local new_rot = math_lib.composeRotators(state.rotate_body_rot, delta_rot)
    -- 位置钉死（Rotating 期 tick_seated 已停，无重钉打架 G5）
    set_actor_world_pose(actor, state.insert_seat_loc, new_rot)

    -- 拧到位：haptic + apply_unlock 立即触发（rotate_completed 防重；Grip 仍可按住）
    if state.rotate_progress >= 1.0 and not state.rotate_completed then
        state.rotate_completed = true
        if eventFeedback ~= nil and type(eventFeedback.play_latch_haptic) == "function" then
            pcall(eventFeedback.play_latch_haptic)
        end
        apply_unlock()
        -- 门已解锁即启动跟随：此后（含松手 finalize 前）表演体每帧随锁孔组件动，门开钥匙跟着走
        start_follow_lock_sm(actor, "rotate completed")
    end
end

-- 进入拧转（对齐 unlock_door begin_rotate）：
--   ① enter_seated 时 Grip 仍按住（插入、拧钥匙一气呵成）
--   ② Seated 态 Grip 按下沿（G2 重抓/回弹后重拧，progress 归 0 不跨轮记录）
local function begin_rotate()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then return end
    if state.insert_entry == nil or state.insert_entry.actor == nil then return end
    if state.insert_seat_rot == nil or state.insert_seat_loc == nil then return end

    -- 锁孔组件（轴向来源 + 解锁导航起点）
    local key_sm = nil
    pcall(function() key_sm = state.insert_entry.actor["KeyStaticMesh"] end)
    if key_sm == nil then
        log("ITEM_DOOR", "[ROTATE] skip: KeyStaticMesh nil")
        return
    end

    -- 锁状态预检（对齐 unlock_door Phase 5）：门已解锁/导航失败则不进入 Rotating，保持 Seated
    if unlock_door ~= nil and type(unlock_door.navigate_to_door_lock) == "function" then
        local door_lock = nil
        pcall(function() door_lock = unlock_door.navigate_to_door_lock(key_sm) end)
        local locked = false
        if door_lock ~= nil then
            pcall(function() locked = (door_lock:IsLocked() == true) end)
        end
        if door_lock == nil or not locked then
            log("ITEM_DOOR", "[ROTATE] skip: door already unlocked or lock not found")
            return
        end
    end

    -- 旋转轴 = 锁孔 KeyStaticMesh local Y（GetRightVector，与插入轴同线；正负号实测校准 G7）
    local axis = nil
    pcall(function() axis = key_sm:GetRightVector() end)
    if axis ~= nil then
        state.rotate_axis = { X = axis.X or 0, Y = axis.Y or 0, Z = axis.Z or 0 }
    else
        state.rotate_axis = { X = 0, Y = 1, Z = 0 }  -- 组件方法调用失败时回退
    end

    -- 旋转基准 = 当前落座旋转（变体=锁坯基准；回退=compose(锁坯,ins)）；位置钉死 insert_seat_loc
    state.rotate_body_rot = state.insert_seat_rot
    state.rotate_progress = 0
    state.rotate_completed = false
    state.rotate_returning = false

    -- 左手 Pitch 基准（Grip 按住中，手正握钥匙）
    local hand_rot = controllers.getControllerRotation(0)
    state.rotate_start_pitch = (hand_rot ~= nil) and (hand_rot.Pitch or 0) or 0

    state.grab_phase = GrabPhase.Rotating
    -- 拧钥匙音效不再立即播放：延迟到 update_rotate 中手逆时针有效转角超 10°（KEY_ROTATE_START_THRESHOLD_DEG）
    -- 才真正开始拧并播一次音效，过滤落座瞬间手的微小抖动（用户 2026-08-21 拍板）
    state.rotate_started = false
    log("ITEM_DOOR", string.format("[ROTATE] begin for %s axis=(%.2f,%.2f,%.2f) start_pitch=%.1f",
        tostring(state.grab_key_name),
        state.rotate_axis.X, state.rotate_axis.Y, state.rotate_axis.Z,
        state.rotate_start_pitch))
end

-- 进入 Seated 统一入口（tick_insert 两个结束分支共用）：
-- ① 变体资产可用 → 换装 SetStaticMesh，旋转基准直接用锁坯旋转（ins 不参与，建模已是挂门姿态）
-- ② 换装失败 → 保持主 mesh，旋转仍走 compose(锁坯, ins) 路径（现状可调）
local function enter_seated(tag)
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor ~= nil and state.insert_door_mesh ~= nil then
        local mesh = get_itembase_mesh(actor)
        if mesh ~= nil then
            local ok = false
            pcall(function() ok = mesh:SetStaticMesh(state.insert_door_mesh) end)
            state.insert_mesh_swapped = (ok == true)
            log("ITEM_DOOR", string.format("[SEAT-MESH] %s doorattachment swap for %s",
                state.insert_mesh_swapped and "OK" or "FAIL", tostring(state.grab_key_name)))
        end
    end
    if state.insert_mesh_swapped then
        -- 换装成功：旋转 = 锁坯基准（不含 ins），重钉落座位姿
        state.insert_seat_rot = state.insert_base_rot or state.insert_seat_rot
        if actor ~= nil and state.insert_seat_loc ~= nil then
            set_actor_world_pose(actor, state.insert_seat_loc, state.insert_seat_rot)
        end
    end
    state.grab_phase = GrabPhase.Seated
    log("ITEM_DOOR", string.format("[INSERT] %s -> seated for %s", tostring(tag), tostring(state.grab_key_name)))
    -- Phase 4a：落座时 Grip 仍按住 → 直接 begin_rotate（插入、拧钥匙一气呵成，不要求松手重按）。
    -- attach 幂等：插入期已挂附则 no-op；插入期松过手又按回（未挂附）则此刻零偏移补挂附。
    if is_left_grip_pressed() then
        attach_hand_to_key(actor, "seated rotate")
        begin_rotate()
    end
end

-- 进入插入：钥匙 snap 到锁孔外沿插入轴 INSERT_TRACK_LEN_CM 处，然后 start_slide 滑入锁孔
-- 注意：本函数必须定义在 maybe_begin_insert 之前（后者直接调用它，local 前置引用会解析为 nil 全局）
local function begin_insert(actor, entry)
    local seat_loc, seat_rot = lock_seat_point(entry)
    if seat_loc == nil then
        grab_reset("insert: no lock seat")
        return
    end
    -- 复位 Holding 期写在 Mesh 相对变换上的手部偏移（keys.json），否则落座视觉位带偏移误差
    local mesh = get_itembase_mesh(actor)
    if mesh ~= nil then
        pcall(function()
            uevrUtils.set_component_relative_location(mesh, uevrUtils.vector(0, 0, 0))
            uevrUtils.set_component_relative_rotation(mesh, uevrUtils.rotator(0, 0, 0))
        end)
        last_hand_offset = nil -- #3 缓存失效：相对变换已被归零
    end
    -- 插入轴：与生成钥匙同一本地 Y 轴（right_from_rot），保证生成/插入轴向一致。
    -- 方向取反：实测 +Y 会从门背后位移过来，反转后从正面滑入。
    -- 位置用世界坐标，但轴向必须用锁孔 mesh 本地轴。
    -- 最终停止点（end_loc）用共享 insert_end_point = 锁孔沿反轴按该钥匙 pullback 拉回玩家侧
    local end_loc = insert_end_point(entry, key_pullback(entry and entry.row_name))
    if end_loc == nil then
        grab_reset("insert: no lock seat")
        return
    end
    local axis0 = right_from_rot(seat_rot)
    local axis = { X = -axis0.X, Y = -axis0.Y, Z = -axis0.Z }
    if axis == nil then axis = { X = 0, Y = 0, Z = 1 } end
    -- 通道起点 = 终点再沿插入反向（更靠玩家）延伸 INSERT_TRACK_LEN_CM，形成一段 5cm 可见滑入路径
    local start = {
        X = end_loc.X - axis.X * INSERT_TRACK_LEN_CM,
        Y = end_loc.Y - axis.Y * INSERT_TRACK_LEN_CM,
        Z = end_loc.Z - axis.Z * INSERT_TRACK_LEN_CM,
    }
    -- 门挂变体（2026-08-17 用户拍板：全程用变体，本体仅作资产推导源）。
    -- 直接复用 spawn 期已解析的变体缓存（actor-keyed，零查找）：
    -- spawn 阶段已换装变体并写入 spawn_variant_cache[actor]，insert 不会 MISS；
    -- 若变体真不存在，spawn 期已枚举找过且失败，此处兜底再枚举一遍同样找不到，属恒无收益死代码。
    -- 2026-09-01 性能审计：移除原 cache MISS 时的 load_doorattachment_mesh 兜底全图枚举。
    state.insert_door_mesh = state.spawn_variant_cache[actor]
    log("ITEM_DOOR", string.format("[SEAT-MESH] %s: reuse spawn variant cache%s",
        tostring(state.grab_key_name),
        state.insert_door_mesh == nil and " (nil, variant not found at spawn)" or " (HIT)"))
    state.insert_mesh_swapped = false
    if state.insert_door_mesh ~= nil and mesh ~= nil then
        local ok = false
        pcall(function() ok = mesh:SetStaticMesh(state.insert_door_mesh) end)
        state.insert_mesh_swapped = (ok == true)
    end
    -- 插入旋转：变体路径 = 锁坯基准（建模即挂门姿态，ins 不参与）；
    -- 本体回退路径 = compose_local_rot_offset(锁坯, ins) 局部四元数合成
    -- （欧拉逐分量相加不等于旋转叠加，ins 随门朝向退化垃圾值——2026-08-17 修复教训）
    local ir = key_insert_rot(entry and entry.row_name)
    local final_rot
    if state.insert_mesh_swapped then
        final_rot = seat_rot
    else
        final_rot = reload_tools.compose_local_rot_offset(
            seat_rot, { pitch = ir[1] or 0, yaw = ir[2] or 0, roll = ir[3] or 0 })
        if final_rot == nil then final_rot = seat_rot end
    end

    -- Seated 期实时重算基准：entry(锁孔位姿来源) + 不含 ins 的锁坯世界旋转
    -- 插入后拖 ins/pullback 滑块时 tick_seated 每帧按当前配置重钉，所见即所调
    state.insert_entry = entry
    state.insert_base_rot = seat_rot
    state.insert_seat_loc = end_loc
    state.insert_seat_rot = final_rot
    state.insert_state = {}
    reload_tools.start_slide(state.insert_state, {
        sx = start.X, sy = start.Y, sz = start.Z,
        ex = end_loc.X, ey = end_loc.Y, ez = end_loc.Z,
        duration = INSERT_DURATION,
        skip_fall = true,
        interpolate_rot = true,
        start_rot = final_rot,
        end_rot = final_rot,
    })
    state.grab_phase = GrabPhase.Inserting
    -- Phase 3 收尾（§7.1）：进入插入即零偏移挂附左手到钥匙 root，手随钥匙一起滑入；
    -- 此刻 root 仍在手位附近（第一次 tick_insert 才开始滑动），挂附无跳变
    attach_hand_to_key(actor, "insert begin")
    -- 开始插入音效：钥匙滑入锁孔时播 Play_Key_Unlock（复用 play_key_unlock_sound 三连回退）。
    -- pcall 包裹：音频异常不得打断插入主流程。
    pcall(play_key_unlock_sound)
    log("ITEM_DOOR", string.format("[INSERT-AUDIO] Play_Key_Unlock on insert begin for %s",
        tostring(state.grab_key_name)))
    -- 开始插入震动：复用拧转完成的 play_latch_haptic（11号文件，手柄+振动袖），用户 2026-08-21 拍板。
    -- pcall 包裹：震动异常不得打断插入主流程（对齐现有 haptic 惯例）。
    if eventFeedback ~= nil and type(eventFeedback.play_latch_haptic) == "function" then
        pcall(eventFeedback.play_latch_haptic)
    end
    log("ITEM_DOOR", string.format("[INSERT-HAPTIC] play_latch_haptic on insert begin for %s",
        tostring(state.grab_key_name)))
end

-- Phase 3: 检测手持钥匙与锁孔距离，< INSERT_TRIGGER_DISTANCE_CM 触发插入
-- 在 Holding tick 内调用；返回 true 表示已进入插入（调用方应停止后续 holding 覆盖）
local function maybe_begin_insert(actor, entry)
    if actor == nil or entry == nil then return false end
    local end_loc = insert_end_point(entry, key_pullback(entry and entry.row_name))
    if end_loc == nil then
        return false
    end
    local key_loc = get_key_visual_world(actor)
    if key_loc == nil then return false end
    -- 距离检测点 = 最终停止点（insert_end_point，拉回玩家侧），非锁孔原始位
    if distance_sq(key_loc, end_loc) >= INSERT_TRIGGER_DISTANCE_CM * INSERT_TRIGGER_DISTANCE_CM then
        return false
    end
    begin_insert(actor, entry)
    return true
end

-- 插入阶段 tick：沿固定通道滑入锁孔（reload_tools.start_slide/tick_slide）
local function tick_insert()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then
        grab_reset("insert actor lost")
        return
    end
    if state.insert_state == nil then
        grab_reset("insert state missing")
        return
    end
    local res = reload_tools.tick_slide(state.insert_state)
    if res == nil then
        -- slide 已结束（active=false）→ 统一入口落座（含 doorattachment 换装）
        enter_seated("done")
        return
    end
    set_actor_world_pose(actor,
        uevrUtils.vector(res.x or 0, res.y or 0, res.z or 0),
        res.pitch ~= nil and uevrUtils.rotator(res.pitch, res.yaw, res.roll) or nil)
    if res.all_done then
        enter_seated("all_done")
    end
end

-- 落座阶段 tick：每帧重算并钉死锁孔位（防碰撞/游戏交互挤动漂移）
-- 位姿 = 锁孔基准 + 当前 keys.json 配置：end_loc 随 pullback、旋转随 ins 实时变化
-- → 插入后拖 ins/pullback 滑块立即看到钥匙转动/位移，调好即落盘（所见即所调）
local function tick_seated()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then
        grab_reset("seated actor lost")
        return
    end
    local key = state.grab_key_name
    -- 位置：锁孔位沿插入反轴按当前 pullback 拉回（基准缺失时回退插入瞬间固化值）
    local end_loc = nil
    if state.insert_entry ~= nil and key ~= nil then
        pcall(function()
            end_loc = insert_end_point(state.insert_entry, key_pullback(key))
        end)
    end
    if end_loc == nil then end_loc = state.insert_seat_loc end
    -- 旋转：已换装 doorattachment → 直接锁坯基准（建模即挂门姿态，ins 不参与）；
    -- 未换装（资产缺失回退）→ 主 mesh 走 compose(锁坯, ins) 实时预览
    local base = state.insert_base_rot or state.insert_seat_rot
    local rot = base
    if not state.insert_mesh_swapped and base ~= nil and key ~= nil then
        local ir = key_insert_rot(key)
        rot = reload_tools.compose_local_rot_offset(
            base, { pitch = ir[1], yaw = ir[2], roll = ir[3] }) or base
    end
    if end_loc ~= nil then
        state.insert_seat_loc = end_loc
        state.insert_seat_rot = rot
        set_actor_world_pose(actor, end_loc, rot)
    end
end

-- 持有阶段 tick：每帧重刷手部偏移（滑块实时生效）；钥匙一直粘在手上，松手不飞回
local function tick_grab_holding()
    local actor = uevrUtils.getValid(state.grab_actor)
    if actor == nil then
        grab_reset("holding actor lost")
        return
    end
    -- Phase 3: 手持钥匙距锁孔 < INSERT_TRIGGER_DISTANCE_CM 自动进入插入（阻止后续 holding 覆盖）
    -- 注意：spawned_keys 的键是门名（grab_door_name），其值 { actor=钥匙actor, entry=门锁entry, row_name }
    -- 锁孔基准必须用 门锁 entry（.entry），不能用整个 spawned_keys 值——否则 entry.actor 是钥匙 actor，读不到 KeyStaticMesh
    local held_entry = nil
    if state.spawned_keys ~= nil then
        local sk = state.spawned_keys[state.grab_door_name]
        if sk ~= nil then held_entry = sk.entry end
    end
    if maybe_begin_insert(actor, held_entry) then return end
    -- 纯坐标跟随：每帧用左手 hand_l_bn 插槽世界坐标覆盖 root（不做 attach，避免 IK 网格 attach 位置爆炸）
    -- set_actor_world_pose 内部对 root 组件用 K2_SetWorldLocation 写入（组件级，对 ItemBase_BP_C 生效）
    local h_loc, h_rot = get_left_hand_socket_world()
    if h_loc ~= nil then
        set_actor_world_pose(actor, h_loc, h_rot)
    end
    apply_key_hand_offset(actor, state.grab_key_name)
    -- 注：钥匙粘在手上，松手不再飞回（用户已确认删除返回逻辑）
end

-- 距离检测 + 左 Grip 边沿 → 触发抓取（不做射线）
local function begin_grab_from_cache()
    if state.grab_phase ~= GrabPhase.Idle then return end
    last_hand_offset = nil -- #3 缓存失效：新抓取会话（actor 可能已销毁重建，Mesh 相对变换已归零）
    if left_hand_occupied() then
        log("ITEM_DOOR", "[GRAB] left hand occupied, skip grab", nil)
        return
    end
    local left_loc = get_left_hand_socket_world()
    if left_loc == nil then
        return
    end
    -- 找最近的在 L2 内且已 spawn 的钥匙
    local best_key = nil
    local best_actor = nil
    local best_entry = nil
    local best_dist2 = math.huge
    for key, entry in pairs(state.spawned_keys) do
        local actor = uevrUtils.getValid(entry and entry.actor)
        if actor ~= nil then
            local loc = get_key_visual_world(actor)
            if loc ~= nil then
                local d2 = distance_sq(left_loc, loc)
                if d2 < best_dist2 then
                    best_dist2 = d2
                    best_key = key
                    best_actor = actor
                    best_entry = entry
                end
            end
        end
    end
    if best_actor == nil then
        return
    end
    local thresh = GRAB_DISTANCE_CM * GRAB_DISTANCE_CM
    if best_dist2 > thresh then
        return
    end
    -- 触发抓取
    spin.stop(best_actor)
    local home_pos, home_rot = nil, nil
    if best_entry and best_entry.entry then
        home_pos, home_rot = lock_spawn_point(best_entry.entry)
    end
    if home_pos == nil then
        pcall(function()
            if best_actor.K2_GetActorLocation ~= nil then home_pos = best_actor:K2_GetActorLocation() end
        end)
    end
    if home_pos == nil then
        return
    end
    local start_loc = math_lib.copyVector(home_pos)
    local start_rot = math_lib.copyRotator(home_rot) or { Pitch = 0, Yaw = 0, Roll = 0 }
    -- 记录 spawn 原位（Holding 松手飞回时复用，drop_key_at_home 后清空）
    state.flight_home_pos = math_lib.copyVector(home_pos)
    state.flight_home_rot = math_lib.copyRotator(home_rot)
    -- 每次新抓取重置飞回标记（热重载/上次 drop 残留安全兜底）
    state.flight_return_home = false
    -- 配置键名：UnlockItem.RowName（稳定、抓取时已知）
    local key_name = (best_entry and best_entry.row_name) or best_key
    state.grab_door_name = best_key
    state.grab_key_name = key_name
    state.grab_actor = best_actor
    state.flight_start_t = os.clock()
    state.flight_start_loc = start_loc
    state.flight_start_rot = start_rot
    -- 终点 = 左手 hand_l_bn 插槽世界位
    local end_loc, end_rot = get_left_hand_socket_world()
    state.flight_end_loc = end_loc
    state.flight_end_rot = end_rot
    -- 确保持钥配置存在（惰性创建）
    get_key_offset(key_name)
    -- 抓取瞬间即应用手部偏移（2026-08-17 修复首帧跳变）：
    -- 此前偏移仅在飞行结束吸附时应用，飞行 0.3s 里视觉无偏移（错位），吸附瞬间跳变到调好位置。
    -- 现在飞行全程带偏移：视觉 = root + rel offset，落位即调好位置，无跳变。
    apply_key_hand_offset(best_actor, key_name)
    state.grab_phase = GrabPhase.Flying
    -- 钥匙开始飞向手：提前播放钥匙拾取声（Play_Item_PickUp，带 Item_Type switch），用户 2026-08-21 拍板。
    -- pcall 包裹：音频异常不得打断抓取主流程（对齐 haptic 惯例）。
    pcall(play_key_pickup_sound)
    log("ITEM_DOOR", string.format("[SOUND] pickup Play_Item_PickUp start flight for %s", tostring(key_name)))
end

-- 每帧 grab tick（postEngineTick）：左 Grip 边沿 + 状态机驱动
local function on_grab_tick()
    -- 过场/过门动画结束的"立即重建一次"（对齐 remote_grab，用户定案 2026-09-05）：
    -- 由每帧本函数立即消费（独立于 1s interval 的常规重建路径；建完 0 条也不进入 2s 重试）。
    if state.l1_cutscene_once then
        state.l1_cutscene_once = false
        state.l1_rebuild_pending = false
        state.l1_retry_pending = false
        state.l1_retry_count = 0
        state.l1_build_reason = "cutscene_end" -- 卡顿排查 2026-09-03
        pcall(function()
            build_item_door_cache()
            update_item_door_l2()
            pcall(M.refresh_config_ui) -- 重建后刷新钥匙偏移下拉菜单（合并新发现的 row_name）
        end)
    end
    -- 2026-09-03 帧卡顿看门狗：本模块每帧都被调用（无论 pending），相邻两次 tick 的 os.clock
    -- 差 = 真实墙钟帧间隔。>120ms 即记一条 [FRAME-HITCH]——Lua 侧 os.clock 分段计时（SPAWN-TIMING）
    -- 只测得到本模块 CPU 耗时，测不到引擎侧卡顿（流送/BeginPlay/GC/音频），此看门狗补上盲区。
    local now = os.clock()
    local dt = now - (state.last_tick_clock or now)
    state.last_tick_clock = now
    if dt > 0.12 then
        log("ITEM_DOOR", string.format("[FRAME-HITCH] dt=%.0fms (game thread stalled between ticks)", dt * 1000))
    end
    -- 每帧变体换装轮询（引擎挂上本体 mesh 的当帧换装，消除 spawn 期翻转跳变）
    poll_variant_swap()
    -- Phase 4a：audio 段落播放器计时器驱动（到期自动停；pistol/rifle/shotgun 同模式）
    if audio ~= nil and type(audio.tick) == "function" then
        pcall(audio.tick)
    end
    -- 左 Grip 边沿检测（is_left_grip_pressed 为"按住"状态，边沿自行维护上一帧）
    local grip = is_left_grip_pressed()
    local edge_pressed = grip and not state.last_grip_pressed
    local edge_released = (not grip) and state.last_grip_pressed
    state.last_grip_pressed = grip

    if state.grab_phase ~= GrabPhase.Idle and uevrUtils.isInCutscene() then
        grab_reset("cutscene")
        return
    end

    -- Phase 4a：回弹动画（未拧到位松手后钥匙自转回 0°；手已脱附不跟随）。
    -- 期间吞掉所有输入（对齐 unlock_door returning 顶层拦截），完成后回 Seated 等重按。
    if state.rotate_returning then
        local elapsed = os.clock() - (state.rotate_return_start_t or os.clock())
        local dur = math.max(KEY_ROTATE_RETURN_S, 0.01)
        local t = elapsed / dur
        if t > 1 then t = 1 end
        update_rotate_by_progress((state.rotate_return_start_progress or 0) * (1 - t))
        if t >= 1 then
            state.rotate_returning = false
            state.rotate_progress = 0
            state.grab_phase = GrabPhase.Seated
            log("ITEM_DOOR", "[ROTATE] return done -> seated")
        end
        return
    end

    -- Phase 3 收尾（§7.1）+ Phase 4a：Grip 松开即脱附左手（用户 2026-08-18 拍板：
    -- grip 才是明确的松开意图，detach 不做距离检测）。仅脱手，不动钥匙的滑入/落座。
    if edge_released then
        if state.grab_phase == GrabPhase.Inserting or state.grab_phase == GrabPhase.Seated then
            detach_hand_from_key("grip released")
        elseif state.grab_phase == GrabPhase.Holding then
            -- 修复"第二把钥匙抓不了"：Holding 期松手若无处理，grab_phase 卡在 Holding，
            -- 下一扇门钥匙 begin_grab 因非 Idle 不进入（只能重载恢复）。
            -- 此处松手 → 钥匙复用 rt_tick_flight 插值飞回 spawn 原位，抓取态回 Idle。
            local actor = uevrUtils.getValid(state.grab_actor)
            local start_loc, start_rot = nil, nil
            if actor ~= nil then
                local root = reload_tools.get_actor_root(actor)
                if root ~= nil then
                    pcall(function()
                        start_loc = reload_tools.get_component_world_location(root)
                        start_rot = reload_tools.get_component_world_rotation(root)
                    end)
                end
            end
            state.flight_start_loc = start_loc
            state.flight_start_rot = start_rot
            state.flight_start_t = os.clock()
            state.flight_return_home = true
            -- 复位手的抓握手势（脱离 holding 动画，避免松手后一直握拳）
            pcall(function()
                hands.setHoldingAttachment(Handed.Left, nil)
            end)
            state.grab_phase = GrabPhase.Flying
            log("ITEM_DOOR", "[GRAB] drop key (holding release) -> fly home")
        elseif state.grab_phase == GrabPhase.Rotating then
            detach_hand_from_key("grip released (rotate)")
            if state.rotate_completed then
                -- 拧到位松手：仅脱附（上方已做）→ Unlocked 过渡 → 清抓取状态回 Idle（4a 无 finalize）
                state.grab_phase = GrabPhase.Unlocked
            elseif (state.rotate_progress or 0) > 0 then
                -- 未拧到位：回弹动画（钥匙自转回 0°，手已脱附）→ 回 Seated
                state.rotate_returning = true
                state.rotate_return_start_t = os.clock()
                state.rotate_return_start_progress = state.rotate_progress or 0
            else
                -- 尚未旋转：直接回 Seated
                state.grab_phase = GrabPhase.Seated
            end
        end
    end

    if state.grab_phase == GrabPhase.Idle then
        if edge_pressed then
            begin_grab_from_cache()
        end
    elseif state.grab_phase == GrabPhase.Flying then
        tick_grab_flying()
    elseif state.grab_phase == GrabPhase.Holding then
        tick_grab_holding()
    elseif state.grab_phase == GrabPhase.Inserting then
        tick_insert()
    elseif state.grab_phase == GrabPhase.Seated then
        -- Phase 4a（G2 重抓路径）：手已脱附（插入后松过手/回弹后）+ Grip 按下沿
        -- + 手近钥匙（GRAB_DISTANCE_CM）→ 重挂附 + 直接 begin_rotate（progress 归 0 重拧）
        if edge_pressed and not state.hand_attached_to_key then
            local actor = uevrUtils.getValid(state.grab_actor)
            if actor ~= nil then
                local key_loc = get_key_visual_world(actor)
                local h_loc = get_left_hand_socket_world()
                if key_loc ~= nil and h_loc ~= nil
                    and distance_sq(h_loc, key_loc) <= GRAB_DISTANCE_CM * GRAB_DISTANCE_CM then
                    attach_hand_to_key(actor, "re-grab")
                    begin_rotate()
                end
            end
        end
        tick_seated()
    elseif state.grab_phase == GrabPhase.Rotating then
        -- Grip 按住 → 拧转驱动（松手分流见上方 edge_released 块）
        update_rotate()
        -- 拧到位后（门已解锁）：逐帧跟随锁孔组件（门被推开时钥匙随门走），直到松手 finalize
        tick_follow_lock_sm()
    elseif state.grab_phase == GrabPhase.Unlocked then
        -- Phase 4b：松手后触发 finalize（①脱附→②RemoveItem→③LoadAndTrySetKeyMesh→④就绪轮询→⑤销毁→回 Idle）。
        -- finalize_started 未置则首帧 begin，其后每帧 tick_finalize_poll 轮询异步就绪（G4），
        -- 就绪/超时后 grab_reset 回 Idle。
        if not state.finalize_started then
            begin_finalize()
        end
        -- begin_finalize 在"no lock"异常路径已 grab_reset 回 Idle，此处需避免重复 tick
        if state.grab_phase == GrabPhase.Unlocked then
            tick_finalize_poll()
        end
    end
end

-- 每帧 grab tick 入口（供 postEngineTick 驱动）
function M.on_grab_tick()
    -- 2026-09-03 卡顿排查（用户拍板）：整体自计时，>50ms 落盘本文件诊断日志，定死卡顿时本文件是否清白
    local t0 = os.clock()
    on_grab_tick()
    local dt = os.clock() - t0
    if dt > 0.05 then
        log("ITEM_DOOR", string.format("[TICK-SLOW] item_door on_grab_tick took %.1fms", dt * 1000))
    end
end

return M