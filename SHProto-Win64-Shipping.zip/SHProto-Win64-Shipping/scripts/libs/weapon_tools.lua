--[[
================================================================================
SH2 双手控枪纯姿态求解库 (weapon_tools)
================================================================================
重构自 weapon_two_hand.lua 的纯数学/求解段，按 sh2_weapon_two_hand_split_plan.md
剥离为无 SDK、无 IO、无游戏语义的确定性姿态求解库。

设计原则（硬性，对齐 recoil_tools.lua）：
    1. 无游戏耦合：无 weapon_id / SH2 / UEVR / SDK / attachments 等符号
    2. 无 IO：不读 json、不写文件、不调 os.clock / math.random
       —— 时间由上层通过 dt 传入
    3. 状态隔离：所有求解状态由 M.new_solver_state() 创建并作为参数显式传入
    4. 配置协议：M.CONFIG 为求解调参（非游戏语义）；上层负责 configui 持久化
    5. 输入输出：pose 一律 plain table {X,Y,Z} / {Pitch,Yaw,Roll} / {W,X,Y,Z}，
       不接受 userdata
================================================================================
]]--

local M = {}

-- 求解调参（非游戏语义；上层 configui 写入）
M.CONFIG = {
    rotation_blend_speed = 8.0,
    position_blend_speed = 1.0,
    left_stability = 0.0,
    roll_strength = 1.0,
    apply_180y_fix = false,
    baseline_ref_cm = 35.0,
    baseline_scale_min = 0.25,
}

-- 安全阈值（cm）
M.MAX_WEAPON_DIST_HARD_CM = 2000.0
M.MAX_WEAPON_DIST_WARN_CM = 400.0

-- ===== 向量 =====

local function v3(x, y, z)
    return { X = x or 0.0, Y = y or 0.0, Z = z or 0.0 }
end

local function v3_copy(v)
    if v == nil then return nil end
    return v3(v.X or v.x or 0.0, v.Y or v.y or 0.0, v.Z or v.z or 0.0)
end

local function v3_add(a, b)
    return v3((a.X or 0) + (b.X or 0), (a.Y or 0) + (b.Y or 0), (a.Z or 0) + (b.Z or 0))
end

local function v3_sub(a, b)
    return v3((a.X or 0) - (b.X or 0), (a.Y or 0) - (b.Y or 0), (a.Z or 0) - (b.Z or 0))
end

local function v3_scale(a, s)
    return v3((a.X or 0) * s, (a.Y or 0) * s, (a.Z or 0) * s)
end

local function v3_len(a)
    local x, y, z = a.X or 0, a.Y or 0, a.Z or 0
    return math.sqrt(x * x + y * y + z * z)
end

local function v3_dot(a, b)
    return (a.X or 0) * (b.X or 0) + (a.Y or 0) * (b.Y or 0) + (a.Z or 0) * (b.Z or 0)
end

local function v3_cross(a, b)
    return v3(
        (a.Y or 0) * (b.Z or 0) - (a.Z or 0) * (b.Y or 0),
        (a.Z or 0) * (b.X or 0) - (a.X or 0) * (b.Z or 0),
        (a.X or 0) * (b.Y or 0) - (a.Y or 0) * (b.X or 0)
    )
end

local function v3_normalize(a)
    local l = v3_len(a)
    if l < 1e-8 then return nil end
    return v3_scale(a, 1.0 / l)
end

M.v3 = v3
M.v3_copy = v3_copy
M.v3_add = v3_add
M.v3_sub = v3_sub
M.v3_scale = v3_scale
M.v3_len = v3_len
M.v3_dot = v3_dot
M.v3_cross = v3_cross
M.v3_normalize = v3_normalize

-- ===== 四元数 =====

local function quat_mul(a, b)
    local aw, ax, ay, az = a.W or a.w, a.X or a.x, a.Y or a.y, a.Z or a.z
    local bw, bx, by, bz = b.W or b.w, b.X or b.x, b.Y or b.y, b.Z or b.z
    return {
        W = aw * bw - ax * bx - ay * by - az * bz,
        X = aw * bx + ax * bw + ay * bz - az * by,
        Y = aw * by - ax * bz + ay * bw + az * bx,
        Z = aw * bz + ax * by - ay * bx + az * bw,
    }
end

local function quat_normalize(q)
    local w, x, y, z = q.W or q.w, q.X or q.x, q.Y or q.y, q.Z or q.z
    local l = math.sqrt(w * w + x * x + y * y + z * z)
    if l < 1e-8 then return { W = 1, X = 0, Y = 0, Z = 0 } end
    return { W = w / l, X = x / l, Y = y / l, Z = z / l }
end

local function quat_inverse(q)
    return { W = q.W or q.w, X = -(q.X or q.x), Y = -(q.Y or q.y), Z = -(q.Z or q.z) }
end

local function quat_from_to(from_v, to_v)
    local f = v3_normalize(from_v)
    local t = v3_normalize(to_v)
    if f == nil or t == nil then return { W = 1, X = 0, Y = 0, Z = 0 } end
    local dot = v3_dot(f, t)
    if dot > 0.9999 then return { W = 1, X = 0, Y = 0, Z = 0 } end
    if dot < -0.9999 then
        local axis = v3_normalize(v3_cross(f, v3(1, 0, 0)))
        if axis == nil then
            axis = v3_normalize(v3_cross(f, v3(0, 0, 1)))
        end
        if axis == nil then return { W = 1, X = 0, Y = 0, Z = 0 } end
        return { W = 0, X = axis.X, Y = axis.Y, Z = axis.Z }
    end
    local c = v3_cross(f, t)
    return quat_normalize({ W = 1.0 + dot, X = c.X, Y = c.Y, Z = c.Z })
end

local function quat_slerp(a, b, t)
    local aw, ax, ay, az = a.W or a.w, a.X or a.x, a.Y or a.y, a.Z or a.z
    local bw, bx, by, bz = b.W or b.w, b.X or b.x, b.Y or b.y, b.Z or b.z
    local dot = ax * bx + ay * by + az * bz + aw * bw
    if dot < 0.0 then
        bx, by, bz, bw = -bx, -by, -bz, -bw
        dot = -dot
    end
    if dot > 0.9995 then
        return quat_normalize({
            W = aw + (bw - aw) * t,
            X = ax + (bx - ax) * t,
            Y = ay + (by - ay) * t,
            Z = az + (bz - az) * t,
        })
    end
    local theta_0 = math.acos(dot)
    local theta = theta_0 * t
    local sin_theta = math.sin(theta)
    local sin_theta_0 = math.sin(theta_0)
    local s0 = math.cos(theta) - dot * sin_theta / sin_theta_0
    local s1 = sin_theta / sin_theta_0
    return {
        W = s0 * aw + s1 * bw,
        X = s0 * ax + s1 * bx,
        Y = s0 * ay + s1 * by,
        Z = s0 * az + s1 * bz,
    }
end

local function quat_axis_angle(axis, angle_rad)
    local n = v3_normalize(axis)
    if n == nil then return { W = 1, X = 0, Y = 0, Z = 0 } end
    local h = angle_rad * 0.5
    local s = math.sin(h)
    return { W = math.cos(h), X = n.X * s, Y = n.Y * s, Z = n.Z * s }
end

local function quat_rotate_v3(vec, quat)
    local q = quat_normalize(quat)
    local vx, vy, vz = vec.X or 0, vec.Y or 0, vec.Z or 0
    local qx, qy, qz, qw = q.X, q.Y, q.Z, q.W
    local tx = 2.0 * (qy * vz - qz * vy)
    local ty = 2.0 * (qz * vx - qx * vz)
    local tz = 2.0 * (qx * vy - qy * vx)
    return v3(
        vx + qw * tx + (qy * tz - qz * ty),
        vy + qw * ty + (qz * tx - qx * tz),
        vz + qw * tz + (qx * ty - qy * tx)
    )
end

M.quat_mul = quat_mul
M.quat_normalize = quat_normalize
M.quat_inverse = quat_inverse
M.quat_from_to = quat_from_to
M.quat_slerp = quat_slerp
M.quat_axis_angle = quat_axis_angle
M.quat_rotate_v3 = quat_rotate_v3

-- ===== Rot =====

local function rot_copy(r)
    if r == nil then return nil end
    return {
        Pitch = r.Pitch or r.pitch or 0.0,
        Yaw = r.Yaw or r.yaw or 0.0,
        Roll = r.Roll or r.roll or 0.0,
    }
end

-- 内联纯 Euler->Quat（拷贝 math_lib.quatFromEuler 的纯 Lua 分支）
local function rotator_to_quat(rot)
    if rot == nil then return { W = 1, X = 0, Y = 0, Z = 0 } end
    local pitch  = rot.Pitch or rot.pitch or rot.X or rot.x or 0.0
    local yaw    = rot.Yaw or rot.yaw or rot.Y or rot.y or 0.0
    local roll   = rot.Roll or rot.roll or rot.Z or rot.z or 0.0

    local deg2rad = math.pi / 180.0
    local hr = (roll  * deg2rad) * 0.5
    local hp = (pitch * deg2rad) * 0.5
    local hy = (yaw   * deg2rad) * 0.5

    local sr, cr = math.sin(hr), math.cos(hr)
    local sp, cp = math.sin(hp), math.cos(hp)
    local sy, cy = math.sin(hy), math.cos(hy)

    local x = (cr * sp * sy) - (sr * cp * cy)
    local y = -(cr * sp * cy) - (sr * cp * sy)
    local z = (cr * cp * sy) - (sr * sp * cy)
    local w = (cr * cp * cy) + (sr * sp * sy)

    return { W = w, X = x, Y = y, Z = z }
end

M.rot_copy = rot_copy
M.rotator_to_quat = rotator_to_quat

-- ===== 几何 =====

local function flatten_z(v)
    return v3(v.X or 0, v.Y or 0, 0)
end

local function apply_baseline_pitch_scale(delta_q, engage_dir, curr_dir, scale)
    if scale >= 0.999 then
        return delta_q
    end
    local e = v3_normalize(engage_dir)
    local c = v3_normalize(curr_dir)
    if e == nil or c == nil then
        return delta_q
    end
    local e_h = v3_normalize(flatten_z(e))
    local c_h = v3_normalize(flatten_z(c))
    if e_h == nil or c_h == nil then
        return delta_q
    end
    local delta_yaw = quat_from_to(e_h, c_h)
    local delta_pitch = quat_normalize(quat_mul(quat_inverse(delta_yaw), delta_q))
    local identity = { W = 1, X = 0, Y = 0, Z = 0 }
    local delta_pitch_scaled = quat_slerp(identity, delta_pitch, scale)
    return quat_normalize(quat_mul(delta_yaw, delta_pitch_scaled))
end

local function signed_angle_rad(from_v, to_v, axis)
    local cross = v3_cross(from_v, to_v)
    local y = v3_dot(axis, cross)
    local x = v3_dot(from_v, to_v)
    return math.atan(y, x)
end

local function vec3_project_on_plane(v, n)
    local d = v3_dot(v, n)
    return v3_sub(v, v3_scale(n, d))
end

M.flatten_z = flatten_z
M.apply_baseline_pitch_scale = apply_baseline_pitch_scale
M.signed_angle_rad = signed_angle_rad
M.vec3_project_on_plane = vec3_project_on_plane

-- ===== 求解状态 =====

function M.new_solver_state()
    return {
        active = false,
        blend = 0.0,
        right_grip_local = nil,
        left_grip_local = nil,
        right_ctrl_rot_local = nil,
        engage_rot = nil,
        engage_dir = nil,
        engage_roll_up = nil,
        last_blended_pos = nil,
        last_blended_rot = nil,
        baseline_L = 0.0,
        baseline_pitch_scale = 1.0,
    }
end

function M.reset_solver_state(state)
    state.active = false
    state.blend = 0.0
    state.right_grip_local = nil
    state.left_grip_local = nil
    state.right_ctrl_rot_local = nil
    state.engage_rot = nil
    state.engage_dir = nil
    state.engage_roll_up = nil
    state.last_blended_pos = nil
    state.last_blended_rot = nil
    state.baseline_L = 0.0
    state.baseline_pitch_scale = 1.0
end

-- ===== 求解器 =====

--- 求解一次双手武器姿态
---@param state table  M.new_solver_state() 返回的实例
---@param opts table   { dt, base_location, base_rotation,
---                      right_ctrl_pos, right_ctrl_rot,
---                      left_ctrl_pos, left_ctrl_rot }
---@return table|nil solved  求解结果（plain table）；失败返回 nil, err
function M.solve(state, opts)
    local right_ctrl_pos = opts.right_ctrl_pos
    local right_rot_tbl = opts.right_ctrl_rot
    local left_ctrl_pos = opts.left_ctrl_pos
    local left_rot_tbl = opts.left_ctrl_rot
    local base_location = opts.base_location
    local base_rotation = opts.base_rotation

    if right_ctrl_pos == nil or right_rot_tbl == nil or left_ctrl_pos == nil or left_rot_tbl == nil then
        return nil, "motion_controller_pose_nil"
    end
    if base_location == nil or base_rotation == nil then
        return nil, "base_pose_nil"
    end

    local dt = tonumber(opts.dt) or 0.016
    if dt ~= dt or dt < 0 then dt = 0.016 end
    if dt > 0.1 then dt = 0.1 end

    local right_ctrl_rot = rotator_to_quat(right_rot_tbl)
    local left_ctrl_rot = rotator_to_quat(left_rot_tbl)

    if M.CONFIG.apply_180y_fix then
        local base_fix = rotator_to_quat({ X = 0, Y = 180.0, Z = 0 })
        right_ctrl_rot = quat_normalize(quat_mul(right_ctrl_rot, base_fix))
    end

    if not state.active then
        state.last_blended_pos = v3_copy(base_location)
        state.last_blended_rot = rotator_to_quat(base_rotation)
        state.active = true
        state.blend = 0.0
        state.right_grip_local = quat_rotate_v3(
            v3_sub(right_ctrl_pos, state.last_blended_pos),
            quat_inverse(state.last_blended_rot)
        )
        state.left_grip_local = quat_rotate_v3(
            v3_sub(left_ctrl_pos, state.last_blended_pos),
            quat_inverse(state.last_blended_rot)
        )
        state.right_ctrl_rot_local = quat_normalize(quat_mul(
            quat_inverse(state.last_blended_rot),
            right_ctrl_rot
        ))
        state.engage_rot = {
            W = state.last_blended_rot.W,
            X = state.last_blended_rot.X,
            Y = state.last_blended_rot.Y,
            Z = state.last_blended_rot.Z,
        }
        state.engage_dir = v3_sub(left_ctrl_pos, right_ctrl_pos)
        local fwd0 = v3_normalize(state.engage_dir)
        if fwd0 then
            local up_r0 = quat_rotate_v3(v3(0, 0, 1), right_ctrl_rot)
            local up_l0 = quat_rotate_v3(v3(0, 0, 1), left_ctrl_rot)
            local up_avg0 = v3_normalize(v3_add(up_r0, up_l0)) or up_r0
            state.engage_roll_up = v3_normalize(vec3_project_on_plane(up_avg0, fwd0))
        else
            state.engage_roll_up = nil
        end
    end

    state.blend = math.min(1.0, state.blend + M.CONFIG.rotation_blend_speed * dt)

    local curr_dir = v3_sub(left_ctrl_pos, right_ctrl_pos)
    local delta_q = quat_from_to(state.engage_dir, curr_dir)

    local L = v3_len(curr_dir)
    local L_min = 5.0
    local pitch_scale = 1.0
    if L >= L_min then
        pitch_scale = math.max(M.CONFIG.baseline_scale_min, math.min(1.0, M.CONFIG.baseline_ref_cm / L))
    end
    state.baseline_L = L
    state.baseline_pitch_scale = pitch_scale
    delta_q = apply_baseline_pitch_scale(delta_q, state.engage_dir, curr_dir, pitch_scale)

    local solved_rot = {
        W = state.last_blended_rot.W,
        X = state.last_blended_rot.X,
        Y = state.last_blended_rot.Y,
        Z = state.last_blended_rot.Z,
    }
    if delta_q then
        solved_rot = quat_normalize(quat_mul(delta_q, state.engage_rot))
    end

    local fwd = v3_normalize(curr_dir)
    if fwd and state.engage_roll_up then
        local up_r = quat_rotate_v3(v3(0, 0, 1), right_ctrl_rot)
        local up_l = quat_rotate_v3(v3(0, 0, 1), left_ctrl_rot)
        local up_avg = v3_normalize(v3_add(up_r, up_l)) or up_r
        local up_proj = v3_normalize(vec3_project_on_plane(up_avg, fwd))
        if up_proj then
            local roll_delta = signed_angle_rad(state.engage_roll_up, up_proj, fwd) * M.CONFIG.roll_strength
            local roll_q = quat_axis_angle(fwd, roll_delta)
            solved_rot = quat_normalize(quat_mul(roll_q, solved_rot))
        end
    end

    local r_world = quat_rotate_v3(state.right_grip_local, solved_rot)
    local solved_pos = v3_sub(right_ctrl_pos, r_world)
    local l_world = quat_rotate_v3(state.left_grip_local, solved_rot)
    local left_pred = v3_add(solved_pos, l_world)
    local left_err = v3_sub(left_ctrl_pos, left_pred)
    solved_pos = v3_add(solved_pos, v3_scale(left_err, M.CONFIG.left_stability))

    local blended_rot = quat_slerp(state.last_blended_rot, solved_rot, state.blend)
    local pos_t = math.min(1.0, state.blend * M.CONFIG.position_blend_speed * 5.0)
    local blended_pos = v3_add(state.last_blended_pos, v3_scale(v3_sub(solved_pos, state.last_blended_pos), pos_t))

    local dist_right = v3_len(v3_sub(blended_pos, right_ctrl_pos))
    if dist_right > M.MAX_WEAPON_DIST_HARD_CM then
        return nil, string.format("weapon_too_far dist=%.1fcm", dist_right)
    end
    local dist_warn = dist_right > M.MAX_WEAPON_DIST_WARN_CM

    state.last_blended_pos = v3_copy(blended_pos)
    state.last_blended_rot = {
        W = blended_rot.W, X = blended_rot.X, Y = blended_rot.Y, Z = blended_rot.Z,
    }

    local ctrl_pos = v3_add(blended_pos, quat_rotate_v3(state.right_grip_local, blended_rot))
    local ctrl_rot = quat_normalize(quat_mul(blended_rot, state.right_ctrl_rot_local))

    -- 注意：weapon_rotation / ctrl_rotation 返回四元数 {W,X,Y,Z}，
    -- 上层需用 uevrUtils.rotatorFromQuat 转为 {Pitch,Yaw,Roll} 再用于 UE API。
    -- right_mc_rotation / left_mc_rotation 保持 rotator 格式（从 opts 原样拷贝）。
    return {
        weapon_location = v3_copy(blended_pos),
        weapon_rotation = {
            W = blended_rot.W, X = blended_rot.X, Y = blended_rot.Y, Z = blended_rot.Z,
        },
        ctrl_location = v3_copy(ctrl_pos),
        ctrl_rotation = {
            W = ctrl_rot.W, X = ctrl_rot.X, Y = ctrl_rot.Y, Z = ctrl_rot.Z,
        },
        right_mc_location = v3_copy(right_ctrl_pos),
        right_mc_rotation = rot_copy(right_rot_tbl),
        left_mc_location = v3_copy(left_ctrl_pos),
        left_mc_rotation = rot_copy(left_rot_tbl),
        dist_weapon_to_right_mc = dist_right,
        dist_warn = dist_warn,
        active = true,
        baseline_L = L,
        baseline_pitch_scale = pitch_scale,
    }, nil
end

return M
