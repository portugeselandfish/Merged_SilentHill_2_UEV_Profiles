--[[
================================================================================
SH2 武器后座力纯逻辑库 (recoil_tools)
================================================================================
重构自原 re9_vr_recoil.lua 移植版（1500+ 行），按 sh2_recoil_port_plan.md §2.1
剥离为无 SDK、无 JSON/文件 IO、无游戏语义、无震动的确定性后座力物理库。

设计原则（硬性）：
    1. 无游戏耦合：无 weapon_id 字符串 / SH2 / UEVR / SDK / USHRanged 等符号
    2. 无 IO：不读 json、不写文件、不调用 os.clock() / math.random()
       —— 时间由上层 on_pre_engine_tick 通过 dt 传入；随机数由上层 random_01 传入
    3. 无震动：本文件不包含任何 haptic / vrmod / pulse / vibe 代码
    4. 状态隔离：所有状态由 M.new_state() 创建并作为参数显式传入，无模块级可变状态
    5. 配置协议：M.apply_settings(plain_table) / M.export_settings()，
       JSON IO 由上层 recoil.lua 负责

保留：table 数学 / 最小 CONFIG·PHYS / apply_settings / export_settings /
     new_state / reset_spring / seed_recoil / update_recoil_spring / get_recoil_state_table
================================================================================
]]--

local M = {}

-- =============================================================================
-- [1] 通用工具
-- =============================================================================

function M.deg2rad(d)
    return d * 0.0174532925
end

local function finite(v, fallback)
    if type(v) ~= "number" or v ~= v or v >= 1e12 or v <= -1e12 then
        return fallback or 0.0
    end
    return v
end

local function is_finite(v)
    return type(v) == "number" and v == v and v < 1e12 and v > -1e12
end

local sanitize_num = finite

local function sanitize_state_fields(state)
    if type(state) ~= "table" then
        return
    end
    local keys = {
        "recoil_attack_t", "recoil_attack_pos_y", "recoil_attack_pos_z",
        "recoil_attack_pitch", "recoil_attack_yaw", "recoil_attack_roll",
        "spring_pos_y", "spring_pos_z", "spring_pitch", "spring_yaw", "spring_roll",
        "spring_vel_y", "spring_vel_z", "spring_vel_pitch", "spring_vel_yaw", "spring_vel_roll",
        "smoothed_pitch_jitter", "smoothed_yaw", "sustained_remaining",
    }
    for i = 1, #keys do
        local k = keys[i]
        state[k] = finite(state[k], 0.0)
    end
end

local sanitize_state_numbers = sanitize_state_fields

--- 用四元数旋转向量；q / v 仅接受 plain table（无 userdata）
---@param q table {w,x,y,z} 或 {1=w,2=x,3=y,4=z}
---@param v table {x,y,z} 或 {1=x,2=y,3=z}
---@return table {x,y,z}
function M.vec3_rotate_vec3(q, v)
    if type(q) ~= "table" or type(v) ~= "table" then
        return { x = 0.0, y = 0.0, z = 0.0 }
    end
    local qw, qx, qy, qz = q.w or q[1], q.x or q[2], q.y or q[3], q.z or q[4]
    local vx, vy, vz = v.x or v[1], v.y or v[2], v.z or v[3]
    qw = finite(qw, 1.0)
    qx = finite(qx, 0.0)
    qy = finite(qy, 0.0)
    qz = finite(qz, 0.0)
    vx = finite(vx, 0.0)
    vy = finite(vy, 0.0)
    vz = finite(vz, 0.0)
    local uvx = qy * vz - qz * vy
    local uvy = qz * vx - qx * vz
    local uvz = qx * vy - qy * vx
    local uuvx = qy * uvz - qz * uvy
    local uuvy = qz * uvx - qx * uvz
    local uuvz = qx * uvy - qy * uvx
    return {
        x = finite(vx + ((uvx * qw) + uuvx) * 2.0, 0.0),
        y = finite(vy + ((uvy * qw) + uuvy) * 2.0, 0.0),
        z = finite(vz + ((uvz * qw) + uuvz) * 2.0, 0.0),
    }
end

-- =============================================================================
-- [2] CONFIG / PHYS 表
-- 仅保留 SH2 实际消费的字段；删除 camera_shake / killswitch / support 双手输出
-- / pivot / 自动武器累积 / vrmod 集成等 RE9 专属字段
-- =============================================================================

M.CONFIG = {
    enabled = true,

    -- 整体强度倍率（被 seed_recoil 应用于 intensity_mult 的基础值）
    intensity_multiplier = 3.0,

    -- 位置/旋转基础强度（米 / 弧度）
    recoil_position_intensity = 0.0105,
    recoil_rotation_intensity = 0.072,
    recoil_horizontal_spread = 0.014,
    recoil_vertical_spread = 0.018,
    recoil_randomness = 0.22,

    recoil_mult_exponent = 0.35,
    recoil_stack_cap = 2.0,

    recoil_kick_up_ratio = 0.85,
    recoil_kick_back_ratio = 1.0,

    recoil_roll_intensity = 0.022,
    recoil_roll_from_yaw = 0.25,

    recoil_yaw_ratio = 0.50,
    recoil_yaw_max_of_pitch = 0.35,
    recoil_yaw_smoothing = 0.35,
    recoil_pitch_smoothing = 0.18,

    recoil_seed_debounce_sec = 0.02,

    recoil_spring_stiffness = 120.0,
    recoil_spring_damping = 20.0,

    recoil_attack_duration = 0.024,
    recoil_sustained_damping = 30.0,
    recoil_sustained_window = 0.12,

    -- 稳定判定（与上层 is_stabilized() 协议）
    recoil_stabilized_requires_both = false,

    -- 未稳定时按重量级 / 硬垂直类的力度放大
    recoil_unsupported_heavy_mult = 1.9,
    recoil_unsupported_light_mult = 1.18,
    recoil_stabilized_impulse_mult = 1.0,
    recoil_unsupported_hard_vertical_mult = 1.48,
    recoil_hard_return_stiffness_mul = 0.58,
    recoil_hard_return_damping_mul = 0.82,

    -- per-weapon intensity 倍率覆盖（由 apply_settings 写入，上层 recoil.lua 读取）
    weapon_intensity_overrides = {},
}

M.PHYS = {
    nonlinear_intensity_boost = 0.30,
    linear_impulse_gain = 20.0,
    angular_impulse_gain = 26.0,
}

-- =============================================================================
-- [3] 配置协议：apply_settings(plain_table) / export_settings()
-- 工具层不读 json；上层负责 json.load_file / json.dump_file
-- =============================================================================

local function coerce_number(v, default)
    if type(v) == "number" and v == v then return v end
    return default
end

local function coerce_bool(v, default)
    if type(v) == "boolean" then return v end
    return default
end

--- 应用 plain table 配置到 M.CONFIG（仅认 small set，忽略无关字段）
---@param data table 由上层 json.load_file 后传入
function M.apply_settings(data)
    if type(data) ~= "table" then return end
    if data.enabled ~= nil then
        M.CONFIG.enabled = coerce_bool(data.enabled, M.CONFIG.enabled)
    end
    if data.intensity_multiplier ~= nil then
        M.CONFIG.intensity_multiplier = math.max(0.0,
            coerce_number(data.intensity_multiplier, M.CONFIG.intensity_multiplier))
    end
    if data.recoil_stabilized_impulse_mult ~= nil then
        M.CONFIG.recoil_stabilized_impulse_mult = math.max(0.0, math.min(1.0,
            coerce_number(data.recoil_stabilized_impulse_mult, M.CONFIG.recoil_stabilized_impulse_mult)))
    end
    if data.recoil_stabilized_requires_both ~= nil then
        M.CONFIG.recoil_stabilized_requires_both = coerce_bool(data.recoil_stabilized_requires_both,
            M.CONFIG.recoil_stabilized_requires_both)
    end
    if data.weapon_intensity_overrides and type(data.weapon_intensity_overrides) == "table" then
        for k, v in pairs(data.weapon_intensity_overrides) do
            if type(k) == "string" and type(v) == "number" and v == v then
                M.CONFIG.weapon_intensity_overrides[k] = v
            end
        end
    end
end

--- 导出当前可持久化字段（上层 json.dump_file 用）
---@return table
function M.export_settings()
    return {
        enabled = M.CONFIG.enabled,
        intensity_multiplier = M.CONFIG.intensity_multiplier,
        recoil_stabilized_impulse_mult = M.CONFIG.recoil_stabilized_impulse_mult,
        recoil_stabilized_requires_both = M.CONFIG.recoil_stabilized_requires_both,
        weapon_intensity_overrides = M.CONFIG.weapon_intensity_overrides,
    }
end

-- =============================================================================
-- [4] Spring 状态实例
-- 删除原版的 recoil_last_t / recoil_last_shot_t / auto_onehand_accum / auto_decay_last_now
-- 改用 sustained_remaining 倒计时（dt 累减）替代绝对时间 sustained damping
-- =============================================================================

--- 创建全新 spring state 实例
---@return table state
function M.new_state()
    local s = {
        -- 弹簧位置 / 速度
        spring_pos_y = 0.0,
        spring_pos_z = 0.0,
        spring_vel_y = 0.0,
        spring_vel_z = 0.0,

        -- 弹簧旋转 / 速度（弧度）
        spring_pitch = 0.0,
        spring_vel_pitch = 0.0,
        spring_yaw = 0.0,
        spring_vel_yaw = 0.0,
        spring_roll = 0.0,
        spring_vel_roll = 0.0,

        -- attack 阶段（sin 曲线爬升到峰值）
        recoil_attack_active = false,
        recoil_attack_t = 0.0,
        recoil_attack_pos_y = 0.0,
        recoil_attack_pos_z = 0.0,
        recoil_attack_pitch = 0.0,
        recoil_attack_yaw = 0.0,
        recoil_attack_roll = 0.0,

        -- 标志位
        recoil_active = false,
        unsupported_hard_return_active = false,

        -- sustained damping 倒计时（dt 累减，单位：秒）
        sustained_remaining = 0.0,

        -- debounce 跟踪：任意成功 seed 都会写入（SH2 防 RequestManualFire 双回调）
        last_seed_t = nil,

        -- 平滑滤波缓存
        smoothed_yaw = 0.0,
        smoothed_pitch_jitter = 0.0,
    }
    return s
end

--- 重置弹簧状态
---@param state table M.new_state() 返回的实例
function M.reset_spring(state)
    if type(state) ~= "table" then
        return
    end
    state.spring_pos_y = 0.0
    state.spring_pos_z = 0.0
    state.spring_vel_y = 0.0
    state.spring_vel_z = 0.0

    state.spring_pitch = 0.0
    state.spring_vel_pitch = 0.0
    state.spring_yaw = 0.0
    state.spring_vel_yaw = 0.0
    state.spring_roll = 0.0
    state.spring_vel_roll = 0.0

    state.recoil_attack_active = false
    state.recoil_attack_t = 0.0
    state.recoil_attack_pos_y = 0.0
    state.recoil_attack_pos_z = 0.0
    state.recoil_attack_pitch = 0.0
    state.recoil_attack_yaw = 0.0
    state.recoil_attack_roll = 0.0

    state.recoil_active = false
    state.unsupported_hard_return_active = false
    state.sustained_remaining = 0.0
    state.last_seed_t = nil
end

-- =============================================================================
-- [5] seed_recoil：注入一次后座力脉冲
-- opts = {
--   kick_up_scale  = number,        -- 上层武器上抬缩放因子（如 1.0/1.52/1.54）
--   intensity_mult = number,        -- 整体强度倍率
--   stabilized     = bool,          -- 上层稳定判定（双手 / 副手 docked）
--   is_auto        = bool,          -- 是否连发武器（SH2 恒 false）
--   is_heavy       = bool|nil,      -- 重量级（未稳定时用 heavy_mult）
--   is_hard_vertical = bool|nil,   -- 硬垂直类（未稳定时用 hard_vertical_mult）
--   source         = string|nil,   -- seed 来源标识（仅诊断/日志用）
--   now            = number,        -- 上层 os.clock() 传入，用于 debounce 时间戳
--   random_01      = number,        -- 上层 math.random() 传入，范围 [0, 1]
-- }
--
-- v1 限制：传入单一 random_01；4 处 jitter（random_factor / pitch_jitter / yaw_raw
-- / roll_rand）共享同一随机源（相关）。上层可在需要时通过更频繁的 seed 调用引入
-- 额外随机性；后续可扩展 opts.randoms 数组。
-- =============================================================================

function M.seed_recoil(state, opts)
    if type(state) ~= "table" then return end
    if not M.CONFIG.enabled then return end
    if opts == nil then return end
    sanitize_state_fields(state)

    local kick_up_scale = sanitize_num(opts.kick_up_scale, 1.0)
    local intensity_mult = sanitize_num(opts.intensity_mult, 1.0)
    local stabilized = opts.stabilized == true
    local is_heavy = opts.is_heavy == true
    local is_hard_vertical = opts.is_hard_vertical == true
    local now = sanitize_num(opts.now, 0.0)
    local random_01 = opts.random_01
    if type(random_01) ~= "number" or random_01 ~= random_01 then
        random_01 = 0.5
    end
    if random_01 < 0.0 then random_01 = 0.0 end
    if random_01 > 1.0 then random_01 = 1.0 end

    local mult = math.max(0.0, intensity_mult)

    -- 未稳定时根据重量级放大
    if not stabilized then
        if is_heavy then
            mult = mult * (M.CONFIG.recoil_unsupported_heavy_mult or 1.0)
        else
            mult = mult * (M.CONFIG.recoil_unsupported_light_mult or 1.0)
        end
    end

    if mult <= 0.0 then return end

    -- debounce：任意 seed 源在窗口内重复调用则跳过（防 RequestManualFire 双回调叠 seed）
    if state.last_seed_t ~= nil then
        if (now - state.last_seed_t) < M.CONFIG.recoil_seed_debounce_sec then
            return
        end
    end

    if stabilized then
        state.unsupported_hard_return_active = false
    end

    -- 单一随机源映射到 [-0.5, 0.5]
    local function jit_01()
        return (random_01 - 0.5)
    end

    local random_factor = 1.0 + jit_01() * M.CONFIG.recoil_randomness
    local exp = math.max(0.1, math.min(1.0, M.CONFIG.recoil_mult_exponent))
    local total_mult = (mult ^ exp) * random_factor
    local mult_norm = math.min(1.0, mult / 3.0)
    total_mult = total_mult * (1.0 + M.PHYS.nonlinear_intensity_boost * mult_norm)

    if stabilized then
        local sm = M.CONFIG.recoil_stabilized_impulse_mult
        if sm ~= nil and sm > 0.0 then
            total_mult = total_mult * sm
        end
    end

    local hard_vert_mult = 1.0

    local pos_peak = M.CONFIG.recoil_position_intensity * total_mult
    local new_pos_y = pos_peak * M.CONFIG.recoil_kick_up_ratio
    local new_pos_z = -pos_peak * M.CONFIG.recoil_kick_back_ratio

    local pitch_base = M.CONFIG.recoil_rotation_intensity * total_mult
    local pitch_jitter = jit_01() * M.CONFIG.recoil_vertical_spread * total_mult

    do
        local a = math.max(0.0, math.min(1.0, M.CONFIG.recoil_pitch_smoothing or 0.0))
        state.smoothed_pitch_jitter = state.smoothed_pitch_jitter
            + (pitch_jitter - state.smoothed_pitch_jitter) * (1.0 - a)
        pitch_jitter = state.smoothed_pitch_jitter
    end

    local pitch_peak = pitch_base + pitch_jitter

    if kick_up_scale ~= 1.0 then
        new_pos_y = new_pos_y * kick_up_scale
        pitch_peak = pitch_peak * kick_up_scale
    end

    if not stabilized and is_hard_vertical then
        hard_vert_mult = math.max(1.0, M.CONFIG.recoil_unsupported_hard_vertical_mult or 1.0)
        new_pos_y = new_pos_y * hard_vert_mult
        pitch_peak = pitch_peak * hard_vert_mult
        state.unsupported_hard_return_active = true
    end

    -- yaw 水平散布
    local yaw_raw = jit_01() * 2.0 * M.CONFIG.recoil_horizontal_spread * total_mult
    yaw_raw = yaw_raw * (M.CONFIG.recoil_yaw_ratio or 0.5)

    local yaw_cap = math.abs(pitch_peak) * (M.CONFIG.recoil_yaw_max_of_pitch or 0.35)
    if yaw_cap > 0.0 then
        if yaw_raw > yaw_cap then yaw_raw = yaw_cap end
        if yaw_raw < -yaw_cap then yaw_raw = -yaw_cap end
    else
        yaw_raw = 0.0
    end

    local yaw_peak = yaw_raw
    do
        local a = math.max(0.0, math.min(1.0, M.CONFIG.recoil_yaw_smoothing or 0.0))
        state.smoothed_yaw = state.smoothed_yaw + (yaw_peak - state.smoothed_yaw) * (1.0 - a)
        yaw_peak = state.smoothed_yaw
    end

    -- roll：随机 + 由 yaw 反向耦合
    local roll_rand = jit_01() * 2.0 * M.CONFIG.recoil_roll_intensity * total_mult
    local roll_peak = roll_rand + (-yaw_peak) * M.CONFIG.recoil_roll_from_yaw

    -- 累加到 attack 缓冲（支持叠加）
    state.recoil_attack_pos_y = state.recoil_attack_pos_y + new_pos_y
    state.recoil_attack_pos_z = state.recoil_attack_pos_z + new_pos_z
    state.recoil_attack_pitch = state.recoil_attack_pitch + pitch_peak
    state.recoil_attack_yaw = state.recoil_attack_yaw + yaw_peak
    state.recoil_attack_roll = state.recoil_attack_roll + roll_peak

    -- 叠加封顶
    if M.CONFIG.recoil_stack_cap > 0.0 then
        local cap_scale = math.max(1.0, mult ^ exp)
        local cap_pos = M.CONFIG.recoil_position_intensity * M.CONFIG.recoil_stack_cap * cap_scale
        local cap_rot = M.CONFIG.recoil_rotation_intensity * M.CONFIG.recoil_stack_cap * cap_scale
        local cap_yaw = M.CONFIG.recoil_horizontal_spread * M.CONFIG.recoil_stack_cap * cap_scale

        state.recoil_attack_pos_y = math.min(
            state.recoil_attack_pos_y,
            cap_pos * M.CONFIG.recoil_kick_up_ratio * kick_up_scale * hard_vert_mult
        )
        state.recoil_attack_pos_z = math.max(state.recoil_attack_pos_z, -cap_pos * M.CONFIG.recoil_kick_back_ratio)
        state.recoil_attack_pitch = math.min(state.recoil_attack_pitch, cap_rot * kick_up_scale * hard_vert_mult)

        if state.recoil_attack_yaw > cap_yaw then state.recoil_attack_yaw = cap_yaw end
        if state.recoil_attack_yaw < -cap_yaw then state.recoil_attack_yaw = -cap_yaw end

        local cap_roll = M.CONFIG.recoil_roll_intensity * M.CONFIG.recoil_stack_cap * cap_scale
        state.recoil_attack_roll = math.max(-cap_roll, math.min(state.recoil_attack_roll, cap_roll))
    end

    -- 注入弹簧速度脉冲
    state.spring_vel_y = state.spring_vel_y + (new_pos_y * M.PHYS.linear_impulse_gain)
    state.spring_vel_z = state.spring_vel_z + (new_pos_z * M.PHYS.linear_impulse_gain)
    state.spring_vel_pitch = state.spring_vel_pitch + (pitch_peak * M.PHYS.angular_impulse_gain)
    state.spring_vel_yaw = state.spring_vel_yaw + (yaw_peak * M.PHYS.angular_impulse_gain)
    state.spring_vel_roll = state.spring_vel_roll + (roll_peak * M.PHYS.angular_impulse_gain)

    state.recoil_attack_t = 0.0
    state.recoil_attack_active = true
    state.recoil_active = true

    -- sustained damping 倒计时启动（替代原绝对时间 now - recoil_last_shot_t）
    state.sustained_remaining = math.max(0.0, M.CONFIG.recoil_sustained_window or 0.0)

    -- 任意成功 seed 都写入时间戳，供下次 debounce
    state.last_seed_t = now
    sanitize_state_fields(state)
end

-- =============================================================================
-- [6] update_recoil_spring(state, dt)
-- 弹簧-阻尼积分（含 attack 阶段 + sustained damping + 子步细分）
-- 工具层不读时钟：dt 由上层 clamp 后传入
-- =============================================================================

function M.update_recoil_spring(state, dt)
    if type(state) ~= "table" then
        return
    end
    if not (state.recoil_active or state.recoil_attack_active) then
        return
    end
    sanitize_state_fields(state)
    if type(dt) ~= "number" or dt ~= dt then dt = 0.0 end
    if dt < 0.0 then dt = 0.0 end
    if dt > 0.05 then dt = 0.05 end

    -- attack 阶段：sin 曲线爬升到峰值
    if state.recoil_attack_active and dt > 0.0 then
        local T = math.max(sanitize_num(M.CONFIG.recoil_attack_duration, 0.024), 0.001)
        state.recoil_attack_t = state.recoil_attack_t + dt

        if state.recoil_attack_t >= T then
            -- attack 结束：把峰值写入 spring，清零 attack 缓冲
            state.spring_pos_y = state.recoil_attack_pos_y
            state.spring_pos_z = state.recoil_attack_pos_z
            state.spring_pitch = state.recoil_attack_pitch
            state.spring_yaw = state.recoil_attack_yaw
            state.spring_roll = state.recoil_attack_roll

            state.spring_vel_y = 0.0
            state.spring_vel_z = 0.0
            state.spring_vel_pitch = 0.0
            state.spring_vel_yaw = 0.0
            state.spring_vel_roll = 0.0

            state.recoil_attack_pos_y = 0.0
            state.recoil_attack_pos_z = 0.0
            state.recoil_attack_pitch = 0.0
            state.recoil_attack_yaw = 0.0
            state.recoil_attack_roll = 0.0
            state.recoil_attack_t = 0.0
            state.recoil_attack_active = false
        else
            -- attack 进行中：sin(0..π/2) 插值
            local s = math.sin((state.recoil_attack_t / T) * (math.pi * 0.5))
            if not is_finite(s) then s = 0.0 end
            state.spring_pos_y = state.recoil_attack_pos_y * s
            state.spring_pos_z = state.recoil_attack_pos_z * s
            state.spring_pitch = state.recoil_attack_pitch * s
            state.spring_yaw = state.recoil_attack_yaw * s
            state.spring_roll = state.recoil_attack_roll * s

            state.spring_vel_y = 0.0
            state.spring_vel_z = 0.0
            state.spring_vel_pitch = 0.0
            state.spring_vel_yaw = 0.0
            state.spring_vel_roll = 0.0
        end
    end

    -- 弹簧-阻尼阶段：子步细分积分
    if not state.recoil_attack_active and dt > 0.0 then
        local k = sanitize_num(M.CONFIG.recoil_spring_stiffness, 120.0)
        local c = sanitize_num(M.CONFIG.recoil_spring_damping, 20.0)

        if state.unsupported_hard_return_active then
            k = k * sanitize_num(M.CONFIG.recoil_hard_return_stiffness_mul, 0.58)
            c = c * sanitize_num(M.CONFIG.recoil_hard_return_damping_mul, 0.82)
        end

        -- sustained damping：开火后短期窗口内加大阻尼
        -- 用 sustained_remaining 倒计时（dt 累减），不读时钟
        if state.sustained_remaining > 0.0 then
            local win = math.max(0.01, sanitize_num(M.CONFIG.recoil_sustained_window, 0.12))
            local t_blend = math.max(0.0, math.min(1.0, state.sustained_remaining / win))
            c = c + (sanitize_num(M.CONFIG.recoil_sustained_damping, 30.0) - c) * t_blend
            state.sustained_remaining = state.sustained_remaining - dt
            if state.sustained_remaining < 0.0 then state.sustained_remaining = 0.0 end
        end

        -- 防止极端 k/c 把速度打成 Inf
        if k < 0.0 then k = 0.0 end
        if c < 0.0 then c = 0.0 end
        if k > 5000.0 then k = 5000.0 end
        if c > 5000.0 then c = 5000.0 end

        local steps = math.max(1, math.min(10, math.floor(dt / 0.008)))
        local sub = dt / steps

        for _ = 1, steps do
            local ay = -k * state.spring_pos_y - c * state.spring_vel_y
            state.spring_vel_y = sanitize_num(state.spring_vel_y + ay * sub, 0.0)
            state.spring_pos_y = sanitize_num(state.spring_pos_y + state.spring_vel_y * sub, 0.0)

            local az = -k * state.spring_pos_z - c * state.spring_vel_z
            state.spring_vel_z = sanitize_num(state.spring_vel_z + az * sub, 0.0)
            state.spring_pos_z = sanitize_num(state.spring_pos_z + state.spring_vel_z * sub, 0.0)

            local ap = -k * state.spring_pitch - c * state.spring_vel_pitch
            state.spring_vel_pitch = sanitize_num(state.spring_vel_pitch + ap * sub, 0.0)
            state.spring_pitch = sanitize_num(state.spring_pitch + state.spring_vel_pitch * sub, 0.0)

            local aw = -k * state.spring_yaw - c * state.spring_vel_yaw
            state.spring_vel_yaw = sanitize_num(state.spring_vel_yaw + aw * sub, 0.0)
            state.spring_yaw = sanitize_num(state.spring_yaw + state.spring_vel_yaw * sub, 0.0)

            local ar = -k * state.spring_roll - c * state.spring_vel_roll
            state.spring_vel_roll = sanitize_num(state.spring_vel_roll + ar * sub, 0.0)
            state.spring_roll = sanitize_num(state.spring_roll + state.spring_vel_roll * sub, 0.0)
        end
    end

    sanitize_state_fields(state)

    -- 静止检测：位置/旋转/速度都低于阈值时停止
    local pos_mag = math.abs(state.spring_pos_y) + math.abs(state.spring_pos_z)
    local rot_mag = math.abs(state.spring_pitch) + math.abs(state.spring_yaw) + math.abs(state.spring_roll)
    local vel_mag = math.abs(state.spring_vel_y) + math.abs(state.spring_vel_z)
        + math.abs(state.spring_vel_pitch) + math.abs(state.spring_vel_yaw) + math.abs(state.spring_vel_roll)

    if pos_mag < 0.00005 and rot_mag < 0.0002 and vel_mag < 0.001 then
        state.spring_pos_y = 0.0
        state.spring_pos_z = 0.0
        state.spring_vel_y = 0.0
        state.spring_vel_z = 0.0
        state.spring_pitch = 0.0
        state.spring_yaw = 0.0
        state.spring_roll = 0.0
        state.spring_vel_pitch = 0.0
        state.spring_vel_yaw = 0.0
        state.spring_vel_roll = 0.0
        state.recoil_active = false
        state.unsupported_hard_return_active = false
        state.sustained_remaining = 0.0
    end
end

-- =============================================================================
-- [7] get_recoil_state_table(state)
-- 返回当前 recoil 状态快照（plain table）
-- =============================================================================

---@param state table
---@return table {active,pos_y,pos_z,pitch,yaw,roll}
function M.get_recoil_state_table(state)
    if type(state) ~= "table" then
        return { active = false, pos_y = 0, pos_z = 0, pitch = 0, yaw = 0, roll = 0 }
    end
    sanitize_state_fields(state)
    local function clamp_mag(v, lim)
        v = sanitize_num(v, 0.0)
        if v > lim then return lim end
        if v < -lim then return -lim end
        return v
    end
    -- 米 / 弧度硬顶：防异常弹簧值进入 UE 写入
    return {
        active = (state.recoil_active or state.recoil_attack_active) and true or false,
        pos_y = clamp_mag(state.spring_pos_y, 0.5),
        pos_z = clamp_mag(state.spring_pos_z, 0.5),
        pitch = clamp_mag(state.spring_pitch, 0.7),
        yaw = clamp_mag(state.spring_yaw, 0.7),
        roll = clamp_mag(state.spring_roll, 0.7),
    }
end

return M
