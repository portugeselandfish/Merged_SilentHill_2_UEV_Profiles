--[[
audio.lua — Wwise 音频段落播放器(底层工具)

职责:
  做好一个"播放器"的工作 — 上层"插入CD按下播放键"
  - register_event: 注册音频事件(缓存 UAkAudioEvent 对象)
  - play_segment: 从指定位置开始播放, 到指定时长自动停止
  - tick: 每帧检查计时器, 到期自动停止
  - stop: 立即停止
  - is_playing: 查询状态
  - invalidate_cache: 关卡/读档后清空 UObject 缓存(避免悬空指针静默失败或崩溃)

技术方案(已验证可行):
  - SpawnAkComponentAtLocation(AutoPost=true) 创建并自动播放, 返回 UAkComponent* 引用
  - SeekOnEvent(event_name, ak_comp, percent, false, 0) 跳到指定位置
  - ak_comp:Stop() 停止播放
  - ak_comp:SetOutputBusVolume(0) 静音 / SetOutputBusVolume(1) 恢复（Seek 前静音避免中间音效泄漏）

上层调用示例:
  local audio = require("libs.audio")
  audio.register_event("pistol_reload", "Play_Wpn_Pistol_Reload",
      "/Game/WWiseAudio/Events/.../Play_Wpn_Pistol_Reload.Play_Wpn_Pistol_Reload")
  audio.play_segment("pistol_reload", 0.5, 0.7)  -- 从0.5s处播0.7s
  -- 上层 on_tick 中: audio.tick()
]]--

local uevr_utils = require("libs.uevr_utils")

local M = {}

-- ============================================================================
-- 内部状态
-- ============================================================================

-- AkGameplayStatics 类对象和 CDO(延迟初始化)
local ak_class = nil
local cdo = nil

-- 已注册的音频事件表
-- key -> { event_name=string, event_path=string, ak_event=UAkAudioEvent*, max_dur=float }
local registered_events = {}

-- 播放器状态(单实例, 同时只能播一个音效)
local player = {
    active = false,
    start_time = 0,
    duration = 0,
    ak_comp = nil,
    event_key = "",
}

-- ============================================================================
-- 内部函数
-- ============================================================================

--- UObject 是否仍存活(读档/切关后缓存指针可能悬空)
local function uobject_alive(obj)
    if obj == nil then
        return false
    end
    if rawget(_G, "UEVR_UObjectHook") ~= nil and UEVR_UObjectHook.exists ~= nil then
        local ok, exists = pcall(function()
            return UEVR_UObjectHook.exists(obj)
        end)
        if ok then
            return exists == true
        end
    end
    local ok, valid = pcall(function()
        return uevr_utils.getValid(obj) ~= nil
    end)
    return ok and valid == true
end

-- 延迟初始化: 获取 AkGameplayStatics CDO
-- @return boolean 是否初始化成功
local function ensure_init()
    if ak_class ~= nil and cdo ~= nil and uobject_alive(cdo) then
        return true
    end
    ak_class = nil
    cdo = nil
    if uevr == nil or uevr.api == nil then
        return false
    end
    ak_class = uevr.api:find_uobject("Class /Script/AkAudio.AkGameplayStatics")
    if ak_class == nil then
        return false
    end
    cdo = ak_class:get_class_default_object()
    return cdo ~= nil
end

--- 重新 resolve 并缓存 ak_event / max_dur
local function resolve_ak_event(reg)
    if reg == nil then
        return false
    end
    -- 保留 override_max_dur（如果 register_event 时硬编码了）
    local saved_max_dur = reg.max_dur
    reg.ak_event = nil
    reg.max_dur = nil
    if not ensure_init() then
        reg.max_dur = saved_max_dur
        return false
    end
    pcall(function()
        reg.ak_event = uevr.api:find_uobject("AkAudioEvent " .. reg.event_path)
    end)
    if reg.ak_event == nil or not uobject_alive(reg.ak_event) then
        reg.ak_event = nil
        reg.max_dur = saved_max_dur
        return false
    end
    pcall(function() reg.max_dur = reg.ak_event.MaximumDuration end)
    if reg.max_dur == nil then
        pcall(function() reg.max_dur = reg.ak_event:get_property("MaximumDuration") end)
    end
    -- 属性读取失败/为0/负值时，回退到硬编码 override
    if reg.max_dur == nil or reg.max_dur <= 0 then
        reg.max_dur = saved_max_dur
    end
    return true
end

-- 获取已注册事件(含缓存 ak_event 和 max_dur；失效时自动重查)
-- @param key string 注册时的 key
-- @return table|nil 注册信息表
local function get_registered(key)
    local reg = registered_events[key]
    if reg == nil then
        return nil
    end
    if reg.ak_event ~= nil and uobject_alive(reg.ak_event) then
        if reg.max_dur == nil then
            pcall(function() reg.max_dur = reg.ak_event.MaximumDuration end)
            if reg.max_dur == nil then
                pcall(function() reg.max_dur = reg.ak_event:get_property("MaximumDuration") end)
            end
        end
        return reg
    end
    if not resolve_ak_event(reg) then
        return nil
    end
    return reg
end

local function ensure_lifecycle_hooks()
    if rawget(_G, "__SH2_AUDIO_LIFECYCLE_REGISTERED") == true then
        return
    end
    _G.__SH2_AUDIO_LIFECYCLE_REGISTERED = true
    -- 切关/读档后旧 UAkAudioEvent / UAkComponent 可能已销毁；经 _G 间接调用便于热重载
    uevr_utils.registerPreLevelChangeCallback(function()
        local fn = rawget(_G, "__sh2_audio_invalidate")
        if type(fn) == "function" then
            fn()
        end
    end)
    uevr_utils.registerUEVRCallback("on_client_restart", function()
        local fn = rawget(_G, "__sh2_audio_invalidate")
        if type(fn) == "function" then
            fn()
        end
    end)
end

-- ============================================================================
-- 公开 API
-- ============================================================================

--- 清空所有缓存的 UObject 引用并停止播放(读档/切关后调用)
function M.invalidate_cache()
    M.stop()
    for _, reg in pairs(registered_events) do
        reg.ak_event = nil
        reg.max_dur = nil
    end
    -- CDO 一般跨关卡存活，但保险起见也允许下次 ensure_init 重取
    if cdo ~= nil and not uobject_alive(cdo) then
        ak_class = nil
        cdo = nil
    end
end

_G.__sh2_audio_invalidate = M.invalidate_cache

--- 注册一个音频事件(只需注册一次, 内部缓存 UAkAudioEvent 对象)
-- @param key string 事件标识符, 如 "pistol_reload"
-- @param event_name string Wwise 事件短名, 如 "Play_Wpn_Pistol_Reload" (SeekOnEvent 用)
-- @param event_path string 完整对象路径, 如 "/Game/.../Play_Wpn_Pistol_Reload.Play_Wpn_Pistol_Reload"
-- @param override_max_dur number|nil 可选：硬编码总时长(秒)。Wwise MaximumDuration 对 Random Container
--   可能为 0/负值导致 SeekOnEvent 不执行，传此参数跳过属性读取，直接用作 percent 分母
-- @return boolean 是否注册成功
function M.register_event(key, event_name, event_path, override_max_dur)
    if key == nil or event_name == nil or event_path == nil then
        return false
    end
    registered_events[key] = {
        event_name = event_name,
        event_path = event_path,
        ak_event = nil,
        max_dur = override_max_dur or nil,
    }
    ensure_lifecycle_hooks()
    -- 立即预加载 ak_event 对象(不阻塞, 失败也允许注册, play_segment 时再 resolve)
    resolve_ak_event(registered_events[key])
    return true
end

--- 播放已注册事件的指定段落
-- @param key string register_event 时使用的 key
-- @param start_sec number 起始位置(秒), 0 表示从头播放
-- @param duration_sec number 播放时长(秒), 到时自动停止
-- @return boolean 是否成功开始播放
function M.play_segment(key, start_sec, duration_sec)
    -- 先停止当前播放
    M.stop()

    if not ensure_init() then
        return false
    end

    local reg = get_registered(key)
    if reg == nil then
        return false
    end

    -- 获取 pawn 位置(音频从这里播放)
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    if pawn == nil or not uobject_alive(pawn) then
        return false
    end
    local loc, rot = nil, nil
    pcall(function() loc = pawn:K2_GetActorLocation() end)
    pcall(function() rot = pawn:K2_GetActorRotation() end)
    if loc == nil then
        return false
    end
    if rot == nil then
        rot = uevr_utils.rotator(0, 0, 0)
    end

    local function try_spawn()
        local ak_comp = nil
        pcall(function()
            ak_comp = cdo:SpawnAkComponentAtLocation(pawn, reg.ak_event, loc, rot, true, reg.event_name, false, false)
        end)
        if ak_comp ~= nil and uobject_alive(ak_comp) then
            return ak_comp
        end
        return nil
    end

    -- SpawnAkComponentAtLocation(AutoPost=true) 创建并自动播放
    local ak_comp = try_spawn()
    -- 失败时强制重 resolve 事件再试一次(读档后常见)
    if ak_comp == nil then
        if resolve_ak_event(reg) then
            ak_comp = try_spawn()
        end
    end
    if ak_comp == nil then
        return false
    end

    -- SeekOnEvent 跳到指定位置(如果 start_sec > 0)
    -- 2026-07-30 修复：Seek 前静音，避免复合事件中 seek 前的音效泄漏
    -- 例如 Play_Wpn_Rifle_Reload 包含"拉栓+插弹"，Seek 到 0.2s 会先触发拉栓声
    -- 解决：先 SetOutputBusVolume(0) 静音 → Seek → SetOutputBusVolume(1) 恢复
    start_sec = start_sec or 0
    if start_sec > 0 and reg.max_dur ~= nil and reg.max_dur > 0 then
        -- 先静音（seek 前的中间音效不可闻）
        pcall(function() ak_comp:SetOutputBusVolume(0.0) end)
        local percent = start_sec / reg.max_dur
        if percent > 1.0 then
            percent = 1.0
        end
        pcall(function()
            cdo:SeekOnEvent(reg.event_name, ak_comp, percent, false, 0)
        end)
        -- 恢复音量（seek 之后的声音正常播放）
        pcall(function() ak_comp:SetOutputBusVolume(1.0) end)
    end

    -- 设置计时器
    player.active = true
    player.start_time = os.clock()
    player.duration = duration_sec or 0.5
    player.ak_comp = ak_comp
    player.event_key = key
    return true
end

--- 每帧调用, 检查计时器是否到期, 到期自动停止
function M.tick()
    if not player.active then
        return
    end
    -- 读档后 ak_comp 可能已死：直接清状态，避免对悬空指针 Stop
    if player.ak_comp ~= nil and not uobject_alive(player.ak_comp) then
        player.active = false
        player.ak_comp = nil
        player.event_key = ""
        return
    end
    local elapsed = os.clock() - player.start_time
    if elapsed < player.duration then
        return
    end
    M.stop()
end

--- 立即停止当前播放
function M.stop()
    if not player.active and player.ak_comp == nil then
        return
    end
    player.active = false
    if player.ak_comp ~= nil then
        if uobject_alive(player.ak_comp) then
            pcall(function()
                player.ak_comp:Stop()
            end)
        end
        player.ak_comp = nil
    end
    player.event_key = ""
end

--- 在指定宿主 actor 上播放事件（带 switch，可选）。
-- 与 play_segment（SpawnAkComponentAtLocation，无 switch）互补：
--   事件若依赖 switch 区分音色（如道具拾取音 Play_Item_PickUp 需 Item_Type-Keys_Standard，
--   否则落默认纸张声），必须走本函数让 switch 生效。
-- switch 来源：优先 host_actor.AudioComponent.SavedSwitchValue（引擎在 spawn 时已将道具类软指针
--   ItemAudioType 解析为已加载的 UAkSwitchValue*，零猜测）；SetSwitch 与 PostEvent 同一宿主 actor，
--   对齐 unlock_door.set_door_audio_switches 已实证的对象版 SetSwitch 模式。
-- @param event_name string Wwise 事件短名（PostEventByName 用）
-- @param event_path string 完整对象路径（fallback 复用 getLoadedAsset 时用）
-- @param host_actor UObject|nil 宿主 actor（取 switch + 播放对象）；nil 回退音频从 pawn 位置播
-- @return boolean 是否成功开始播放
function M.play_event_at_actor(event_name, event_path, host_actor)
    if event_name == nil then
        return false
    end
    if not ensure_init() then
        return false
    end
    local uevr_internal = uevr

    -- switch 来源：钥匙 actor 的 AudioComponent.SavedSwitchValue（引擎已解析对应道具音色）
    local sw = nil
    if host_actor ~= nil then
        pcall(function()
            local audio_comp = host_actor["AudioComponent"]
            if audio_comp ~= nil then
                sw = audio_comp["SavedSwitchValue"]
            end
        end)
    end

    -- 播放对象：优先宿主 actor，其次 pawn 位置（SpawnAkComponentAtLocation）
    local function play_on(cdo_internal, ak_event_internal, target_actor, target_loc, target_rot)
        -- 1) 先设 switch（对象版，对齐 set_door_audio_switches 已验证模式）
        if sw ~= nil then
            pcall(function() cdo_internal:SetSwitch(sw, target_actor, "", "") end)
        end
        -- 2) 组件方法 PostEvent，规避 reload_hooks 对 PostEventByName 的 hook 递归锁
        local ak_comp = nil
        pcall(function() ak_comp = target_actor["AudioComponent"] end)
        if ak_comp ~= nil and ak_comp.PostEvent ~= nil then
            local ok = false
            pcall(function() ak_comp:PostEvent(event_name) end)
            if ok then
                return true
            end
        end
        -- 3) 回退：cdo:PostEventByName（unlock_door.play_key_unlock_sound Method 1）
        local ok2 = false
        pcall(function() ok2 = cdo_internal:PostEventByName(event_name, target_actor, true) end)
        if ok2 then
            return true
        end
        -- 4) 回退：AkAudioEvent 对象 PostOnActor
        if ak_event_internal ~= nil then
            local ok3 = false
            pcall(function() ok3 = ak_event_internal:PostOnActor(target_actor, true) end)
            if ok3 then
                return true
            end
        end
        return false
    end

    -- 解析事件对象（路径 fallback 用）
    local ak_event = nil
    if event_path ~= nil then
        pcall(function() ak_event = uevr_internal.api:find_uobject("AkAudioEvent " .. event_path) end)
    end

    if host_actor ~= nil and uobject_alive(host_actor) then
        return play_on(cdo, ak_event, host_actor, nil, nil)
    end

    -- 宿主不可用：回退从 pawn 位置播放（无 switch 音色，作保底）
    local pawn = uevr_internal and uevr_internal.api and uevr_internal.api:get_local_pawn(0) or nil
    if pawn == nil or not uobject_alive(pawn) then
        return false
    end
    local loc = nil
    pcall(function() loc = pawn:K2_GetActorLocation() end)
    if loc == nil then
        return false
    end
    local rot = nil
    pcall(function() rot = pawn:K2_GetActorRotation() end)
    if rot == nil then
        rot = uevr_utils.rotator(0, 0, 0)
    end
    return play_on(cdo, ak_event, pawn, loc, rot)
end

--- 在指定组件上直播 AkAudioEvent（通用，非 lever 专用）。
-- 与 play_event_at_actor（AudioComponent/CDO + PostEventByName 短名）调用方式不同：
-- 本函数贴到入参指定组件(如 SHAk_Lever)，用组件原生方法 SimplePostAkEvent(AkEvent对象) /
-- PostAkEvent(AkEvent对象) 试播，继承组件自身 Switch 音色，最适合"某组件专属音效"。
-- 逐路径 pcall，首个成功即止：
--   ① component:SimplePostAkEvent(evt)   (Bloober 单参签名)
--   ② component:PostAkEvent(evt)         (native 5 参签名)
--   ③ evt:PostOnActor(组件所属Actor)     (open_latch 先例)
-- 事件对象由 event_path 用 find_uobject 解析（若已传 evt 对象则优先用之）。
-- @param component UObject 目标组件(如 SHAk_Lever)
-- @param event_path string 完整路径(find_uobject 解析用, 可 nil 若直接传 ak_event)
-- @param ak_event UObject|nil 已解析的 AkAudioEvent 对象（优先；nil 则用 event_path 解析）
-- @return boolean 是否成功开始播放
function M.play_event_on_component(component, event_path, ak_event)
    if component == nil or not uobject_alive(component) then
        return false
    end
    -- 事件对象解析：优先外部传入的 ak_event，否则用 event_path find_uobject
    local evt = ak_event
    if (evt == nil or not uobject_alive(evt)) and event_path ~= nil then
        evt = nil
        pcall(function() evt = uevr.api:find_uobject("AkAudioEvent " .. event_path) end)
    end
    if evt == nil or not uobject_alive(evt) then
        return false
    end
    -- 1) 组件 SimplePostAkEvent(对象) —— Bloober 单参签名，最贴合
    if component.SimplePostAkEvent ~= nil then
        local ok = pcall(function() component:SimplePostAkEvent(evt) end)
        if ok then
            return true
        end
    end
    -- 2) 组件 PostAkEvent(对象) —— native 5 参签名，引擎 lever 下压走此
    if component.PostAkEvent ~= nil then
        local ok = pcall(function() component:PostAkEvent(evt) end)
        if ok then
            return true
        end
    end
    -- 3) 事件 PostOnActor 贴所属 Actor（继承组件侧 Switch 状态）
    local owner = nil
    pcall(function() owner = component:GetOwner() end)
    if owner ~= nil and uobject_alive(owner) and evt.PostOnActor ~= nil then
        local ok = pcall(function() evt:PostOnActor(owner, true) end)
        if ok then
            return true
        end
    end
    return false
end

--- 查询是否正在播放
-- @return boolean
function M.is_playing()
    return player.active
end

--- 获取当前播放状态详情
-- @return table { active, elapsed, duration, event_key }
function M.get_status()
    if not player.active then
        return { active = false }
    end
    return {
        active = true,
        elapsed = os.clock() - player.start_time,
        duration = player.duration,
        event_key = player.event_key,
    }
end

--- 根据 event_name 查询 MaximumDuration
-- @param event_name string Wwise 事件短名
-- @return number|nil MaximumDuration（秒）
function M.get_max_duration(event_name)
    for key, reg in pairs(registered_events) do
        if reg.event_name == event_name then
            local r = get_registered(key)
            if r then
                return r.max_dur
            end
        end
    end
    return nil
end

ensure_lifecycle_hooks()
_G.__sh2_audio_module = M

return M
