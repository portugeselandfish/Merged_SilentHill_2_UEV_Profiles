--[[
    spin.lua — 通用"沿世界 Z 轴匀速自转"动画驱动器
    - 用途：让任意 actor 围绕世界垂直轴（Z 轴）缓慢旋转，常用于展示体/预览物。
    - 设计：单个 postEngineTick 回调驱动注册表内全部自转 actor，避免每 actor 各自注册回调。
    - 接口：start(actor, periodSec) / stop(actor) / stop_all() / is_active(actor) / active_count()

    说明：
    - periodSec = 自转一整圈（360°）所需秒数。正值顺时针，负值逆时针。
    - 沿世界 Z 轴自转 = 只累加 Yaw 角；用 math_lib.composeRotators 叠加当前朝向。
    - 不依赖具体业务模块，纯 lib 工具，供 unlock_item_door 等业务脚本调用。
]]

local uevrUtils = require("libs/uevr_utils")
local math_lib = require("libs/core/math_lib")

-- 注册表：actor地址 -> { actor, yaw_deg, period_sec, last_delta }
local spins = {}
local tick_registered = false

local function deg_to_rad(d)
    return d * math.pi / 180.0
end

-- 每帧驱动所有自转 actor
local function spin_tick(engine, delta)
    if next(spins) == nil then return end
    if delta == nil or delta <= 0 then return end
    for addr, s in pairs(spins) do
        if s.actor == nil then
            spins[addr] = nil
        else
            -- Yaw 累加：360° / period 每秒角度
            local step_deg = (360.0 / s.period_sec) * delta
            s.yaw_deg = s.yaw_deg + step_deg
            local spin_rot = { Pitch = 0, Yaw = s.yaw_deg, Roll = 0 }
            local final_rot = math_lib.composeRotators(s.base_rot, spin_rot)
            pcall(function()
                if s.actor.K2_SetActorRotation ~= nil then
                    s.actor:K2_SetActorRotation(final_rot, false, nil, true)
                end
            end)
        end
    end
end

local function ensure_tick()
    if not tick_registered then
        uevrUtils.registerPostEngineTickCallback(spin_tick)
        tick_registered = true
    end
end

-- 开始让 actor 沿世界 Z 轴自转。
-- 会记录 actor 当前朝向作为基准，之后 Yaw 从 0 累加。
-- 若该 actor 已在自转，仅更新周期（不重置已转角度）。
local function start(actor, period_sec)
    if actor == nil then return false end
    local addr = tostring(actor)
    local s = spins[addr]
    if s == nil then
        local base_rot = { Pitch = 0, Yaw = 0, Roll = 0 }
        pcall(function()
            if actor.K2_GetActorRotation ~= nil then base_rot = actor:K2_GetActorRotation() end
        end)
        s = { actor = actor, base_rot = base_rot, yaw_deg = 0, period_sec = period_sec or 5.0 }
        spins[addr] = s
    else
        s.period_sec = period_sec or s.period_sec
    end
    ensure_tick()
    return true
end

local function stop(actor)
    if actor == nil then return end
    spins[tostring(actor)] = nil
end

local function stop_all()
    spins = {}
end

local function is_active(actor)
    return actor ~= nil and spins[tostring(actor)] ~= nil
end

local function active_count()
    local n = 0
    for _ in pairs(spins) do n = n + 1 end
    return n
end

local M = {
    start = start,
    stop = stop,
    stop_all = stop_all,
    is_active = is_active,
    active_count = active_count,
}

return M