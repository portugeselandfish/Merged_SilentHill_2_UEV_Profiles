--[[修改说明：
1. 新建公共 hook 入口模块，集中注册武器换弹相关的 UFunction hooks（A 类）和附件 hooks（B 类）
2. 按 _G.__sh2_current_weapon_type（含 resolve_combat_chain fallback）dispatch 到各武器业务模块
3. 避免 pistol_reload / shotgun_reload 等业务文件重复 hook 同一 UFunction 导致后注册覆盖前者
4. 各武器业务文件通过 M.register_weapon_module(type, module) 注册自己，并实现以下回调入口：
   - A 类（UFunction hooks）:
       M.on_fire_ready_check(obj)            → true=阻止开火 / "allow"=强制可开火 / false=放行原函数
       M.on_out_of_ammo(obj)                 → 处理空仓事件
       M.on_can_be_reloaded_check(obj)       → bool: 是否阻止原生换弹
       M.on_play_request_check(obj, locals)  → bool: 是否 skip PlayRequest/PlayOrOverwriteRequest
       M.on_ranged_reload_check(obj)         → bool: 是否 skip OnRangedReload
       M.on_montage_change_check(montage, montageName, animInstance) → bool: 是否阻止 montage
       M.on_fire_success(ranged_subcomp)     → 开火成功后通知（post hook RequestManualFire，霰弹枪用）
       M.on_single_action_prepare_end(montage, endType) → 泵动完成回调（post hook OnRangedSingleActionPrepareEnd，霰弹枪用）
   - B 类（附件 hooks）:
       M.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL) → 8 值: 合并后的 grip update 返回
       M.on_init_attachment(attachment, gripHand, options)     → 处理附件初始化
5. C 类（武器专属 accessory hooks）和 D 类（生命周期回调）仍由各业务文件自己注册
6. 注：on_fire_success / on_single_action_prepare_end 主要为霰弹枪泵动机制服务，
   手枪模块可不实现（dispatch 时检查 type(mod.on_xxx) == "function"）
7. 2026-07-28：B 类 grip/initAttachment 在武器模块之后额外 dispatch 到 _G.__sh2_heal_module，
   防止 heal 表演道具被 grip interval 在 attachment=nil 时 detach 掉
8. 2026-07-29：新增 AnimNotify_UnequipWeapon:Received_Notify 全拦截钩子（A 类）
   - 目的：拦截系统自动收起武器（AutoUnequipTime 触发的动画通知路径）
   - 当前为全拦截（pre-hook return false），验证生效后再加标志位放行 09 文件主动收起
9. 2026-08-03：新增 register_fire_listener(fn) 旁路开火监听 API
   - RequestManualFire post hook 改为：先 dispatch 给当前 weapon_module 的 on_fire_success
     （若有），再无条件广播给 fire_listeners（pcall 保护）
   - 不再 early-return：手枪（无 on_fire_success）也能 seed 后座力
   - register_weapon_module 单槽覆盖语义不变；后座力改用 register_fire_listener 旁路
]]--

local uevrUtils = require("libs/uevr_utils")
local vr_globals = require("UEVR_00_init_globals")
local attachments = require("libs/attachments")
local reload_tools = require("libs/reload_tools")

local KEYS = vr_globals.KEYS
local M = {}

-- =============================================================================
-- 武器业务模块注册表
-- =============================================================================

local weapon_modules = {}

--- 注册武器业务模块到 dispatch 表
--- 单槽覆盖：weapon_modules[type] = module（同一类型后注册会覆盖前者）
--- 后座力等不希望覆盖换弹模块的功能请改用 register_fire_listener
---@param weapon_type string "pistol" / "shotgun" / "rifle"
---@param module table 业务模块表（含 on_xxx 回调入口）
function M.register_weapon_module(weapon_type, module)
    weapon_modules[weapon_type] = module
end

-- =============================================================================
-- 开火成功旁路监听列表（独立于 weapon_modules 槽位）
-- RequestManualFire post 时，先 dispatch 给当前武器 module 的 on_fire_success
-- （若有），再无条件广播给 fire_listeners。这样：
--   - 换弹模块仍能在 on_fire_success 里设置 needs_pump / needs_bolt（泵/栓流程）
--   - 后座力等模块无需注册 weapon_module 即可收到开火事件
--   - 手枪（无 on_fire_success）也能 seed 后座力
-- =============================================================================

local fire_listeners = {}

--- 注册一个开火成功旁路监听器
--- 不与 register_weapon_module 抢槽；fn 会被 pcall 保护
---@param fn function fn(ranged_subcomp_or_obj, weapon_type)
function M.register_fire_listener(fn)
    if type(fn) == "function" then
        fire_listeners[#fire_listeners + 1] = fn
    end
end

-- =============================================================================
-- 武器类型读取：_G 优先 + resolve_combat_chain fallback
-- main.lua 每 200ms 在 gripUpdate interval 中发布 _G.__sh2_current_weapon_type
-- 若全局为 nil/"none"（发布时机晚或失败），fallback 直接读 pawn 链
-- =============================================================================

local function resolve_weapon_type_from_pawn()
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    if pawn == nil then
        return "none"
    end
    local chain = reload_tools.resolve_combat_chain(pawn)
    local weapon = chain and chain.equipped_weapon or nil
    if weapon == nil then
        return "none"
    end
    local ok, name = pcall(function()
        return weapon:get_full_name()
    end)
    if not ok or name == nil then
        return "none"
    end
    if uevrUtils.startsWith(name, "WeaponPistol") then
        return "pistol"
    elseif uevrUtils.startsWith(name, "WeaponShotgun") then
        return "shotgun"
    elseif uevrUtils.startsWith(name, "WeaponRifle") then
        return "rifle"
    end
    return "none"
end

local function get_current_weapon_type()
    local wt = rawget(_G, KEYS.current_weapon_type)
    if wt == nil or wt == "none" then
        wt = resolve_weapon_type_from_pawn()
    end
    return wt
end

local function get_active_module()
    return weapon_modules[get_current_weapon_type()]
end

-- =============================================================================
-- UFunction hook 安装工具（从 pistol_reload 抽出通用化）
-- =============================================================================

local SHItemWeaponRanged_c = uevrUtils.find_required_object("Class /Script/SHProto.SHItemWeaponRanged")
local SHRangedCmbSubcomp_c = reload_tools.SHRangedCmbSubcomp_c
local SHAnimMontagePlayer_c = uevrUtils.find_required_object("Class /Script/SHProto.SHAnimMontagePlayer")
local AnimInstance_c = uevrUtils.find_required_object("Class /Script/Engine.AnimInstance")
-- 2026-07-29：武器自动收起动画通知类，用于拦截系统 AutoUnequipTime 路径
local AnimNotify_UnequipWeapon_c = uevrUtils.find_required_object("Class /Script/SHProto.AnimNotify_UnequipWeapon")

local function uobject_valid(obj)
    if obj == nil then
        return false
    end
    if rawget(_G, "UEVR_UObjectHook") ~= nil and UEVR_UObjectHook.exists ~= nil then
        local ok, exists = pcall(function()
            return UEVR_UObjectHook.exists(obj)
        end)
        return ok and exists == true
    end
    return true
end

local function force_bool_return(result, value)
    if result == nil then
        return
    end
    local v = value == true
    pcall(function()
        result.ReturnValue = v
    end)
    pcall(function()
        result.return_value = v
    end)
end

local function force_bool_return_false(result)
    force_bool_return(result, false)
end

local function force_bool_return_true(result)
    force_bool_return(result, true)
end

local function print_log(text, logLevel, tag)
    local label = tag ~= nil and tag or "RELOAD_HOOKS"
    print("[" .. label .. "] " .. tostring(text))
end

-- 独立诊断日志：HOOK_INSTALL / HOOK_ERROR 直写 reload_hooks.log；
-- PUMP_TRACE 不直写文件（仅 UEVR_12_diagnose 面板可见）
local DIAG_LOG_FILE = "reload_hooks.log"

local function write_diag_trace(tag, message)
    -- PUMP_TRACE 仅走面板，不直写文件（避免绕过面板开关）
    if tag == "PUMP_TRACE" then
        return
    end
    pcall(function()
        local f = io.open(DIAG_LOG_FILE, "ab")
        if f ~= nil then
            f:write(os.date("%Y-%m-%d %H:%M:%S") .. " [" .. tostring(tag) .. "] " .. tostring(message) .. "\n")
            f:close()
        end
    end)
end

local function wrap_hook_callback(fn)
    if fn == nil then
        return nil
    end
    return function(...)
        local ok, ret = pcall(fn, ...)
        if not ok then
            print_log("hook callback error: " .. tostring(ret), LogLevel.Warn, "RELOAD_HOOKS")
            write_diag_trace("HOOK_ERROR", tostring(ret))
            return nil
        end
        return ret
    end
end

local function install_uevr_function_hook(class_obj, func_name, pre_fn, post_fn)
    if class_obj == nil or func_name == nil then
        return false
    end
    local method = nil
    pcall(function()
        method = class_obj:find_function(func_name)
    end)
    if method == nil then
        return false
    end
    local ok, err = pcall(function()
        method:hook_ptr(wrap_hook_callback(pre_fn), wrap_hook_callback(post_fn))
    end)
    if not ok then
        print_log("hook install failed " .. func_name .. ": " .. tostring(err), LogLevel.Warn)
        return false
    end
    return true
end

-- bool 查询专用：native pre + 写 ReturnValue 并跳过原函数
-- decision_fn(obj) → true/"block"=强制 false；"allow"=强制 true；false/nil=放行原函数
local function install_uevr_native_bool_pre_override(class_obj, func_name, decision_fn, log_msg)
    if class_obj == nil or func_name == nil or type(decision_fn) ~= "function" then
        return false
    end
    local method = nil
    pcall(function()
        method = class_obj:find_function(func_name)
    end)
    if method == nil then
        return false
    end
    pcall(function()
        method:set_function_flags(method:get_function_flags() | 0x400)
    end)
    local ok, err = pcall(function()
        method:hook_ptr(wrap_hook_callback(function(_, obj, _, result)
            local decision = decision_fn(obj)
            if decision == true or decision == "block" then
                force_bool_return_false(result)
                if log_msg ~= nil then
                    print_log(log_msg .. " (block)", LogLevel.Debug, "RELOAD_HOOKS")
                end
                return false
            end
            if decision == "allow" then
                force_bool_return_true(result)
                if log_msg ~= nil then
                    print_log(log_msg .. " (allow)", LogLevel.Debug, "RELOAD_HOOKS")
                end
                return false
            end
            -- false / nil：放行原函数
        end), nil)
    end)
    if not ok then
        print_log("native bool hook failed " .. func_name .. ": " .. tostring(err), LogLevel.Warn)
        return false
    end
    return true
end

-- 兼容旧名（仅 block）
local function install_uevr_native_bool_pre_block(class_obj, func_name, should_block_fn, log_msg)
    return install_uevr_native_bool_pre_override(class_obj, func_name, function(obj)
        if should_block_fn(obj) then
            return true
        end
        return false
    end, log_msg)
end

-- void 流程专用：native pre + return false 阻止原函数
local function install_uevr_native_pre_skip(class_obj, func_name, should_skip_fn, log_msg)
    if class_obj == nil or func_name == nil or type(should_skip_fn) ~= "function" then
        return false
    end
    local method = nil
    pcall(function()
        method = class_obj:find_function(func_name)
    end)
    if method == nil then
        return false
    end
    pcall(function()
        method:set_function_flags(method:get_function_flags() | 0x400)
    end)
    local ok, err = pcall(function()
        method:hook_ptr(wrap_hook_callback(function(_, obj, locals, _)
            if should_skip_fn(obj, locals) then
                if log_msg ~= nil then
                    print_log(log_msg, LogLevel.Info, "RELOAD_HOOKS")
                end
                return false
            end
        end), nil)
    end)
    if not ok then
        print_log("native pre skip failed " .. func_name .. ": " .. tostring(err), LogLevel.Warn)
        return false
    end
    return true
end

-- =============================================================================
-- montage 名字判断（通用：包含 "reload" 字样即认为是换弹 montage）
-- 武器特定 markers 由各业务模块在 on_montage_change_check 内自行判断
-- =============================================================================

local function montage_name_is_reload(name)
    if name == nil or name == "" then
        return false
    end
    return string.find(string.lower(name), "reload", 1, true) ~= nil
end

-- =============================================================================
-- A 类：UFunction hooks 集中注册（每个 UFunction 只 hook 一次）
-- =============================================================================

local montage_guard = false
local montage_callback_registered = false

local function install_fire_ready_hook()
    if SHItemWeaponRanged_c == nil then
        return false
    end
    return install_uevr_native_bool_pre_override(SHItemWeaponRanged_c, "IsFireReady", function(obj)
        local mod = get_active_module()
        if mod == nil or type(mod.on_fire_ready_check) ~= "function" then
            return false
        end
        -- 透传模块决策：true/"block" 拦；"allow" 强制可射；false/nil 放行
        return mod.on_fire_ready_check(obj)
    end, "IsFireReady override")
end

local function install_out_of_ammo_hook()
    if SHItemWeaponRanged_c == nil then
        return false
    end
    return install_uevr_function_hook(SHItemWeaponRanged_c, "OnOutOfAmmoPerformed", function(_, obj)
        local mod = get_active_module()
        if mod == nil or type(mod.on_out_of_ammo) ~= "function" then
            return
        end
        mod.on_out_of_ammo(obj)
    end, nil)
end

local function install_can_be_reloaded_hook()
    if SHItemWeaponRanged_c == nil then
        return false
    end
    return install_uevr_native_bool_pre_block(SHItemWeaponRanged_c, "CanBeReloaded", function(obj)
        local mod = get_active_module()
        if mod == nil or type(mod.on_can_be_reloaded_check) ~= "function" then
            return false
        end
        return mod.on_can_be_reloaded_check(obj) == true
    end, "CanBeReloaded blocked")
end

local function install_play_request_hook()
    if SHAnimMontagePlayer_c == nil then
        write_diag_trace("HOOK_INSTALL", "PlayRequest skip: SHAnimMontagePlayer_c=nil")
        return false
    end
    local play_request_call_count = 0
    local function should_skip(obj, locals)
        play_request_call_count = play_request_call_count + 1
        local mod = get_active_module()
        -- trace: 每次调用都写文件日志（不受任何开关门控）
        local mod_type = mod ~= nil and type(mod.on_play_request_check) == "function" and "has_handler" or "no_handler"
        local wt = get_current_weapon_type()
        write_diag_trace("PUMP_TRACE", "PlayRequest #" .. tostring(play_request_call_count)
            .. " weapon_type=" .. tostring(wt) .. " mod=" .. tostring(mod_type))
        if mod == nil or type(mod.on_play_request_check) ~= "function" then
            return false
        end
        return mod.on_play_request_check(obj, locals) == true
    end
    local ok_request = install_uevr_native_pre_skip(
        SHAnimMontagePlayer_c, "PlayRequest", should_skip, "PlayRequest skipped"
    )
    local ok_overwrite = install_uevr_native_pre_skip(
        SHAnimMontagePlayer_c, "PlayOrOverwriteRequest", should_skip, "PlayOrOverwriteRequest skipped"
    )
    if not ok_request and not ok_overwrite then
        write_diag_trace("HOOK_INSTALL", "PlayRequest+PlayOrOverwriteRequest both failed find_function/hook_ptr")
    end
    return ok_request or ok_overwrite
end

local function install_on_ranged_reload_hook()
    if SHRangedCmbSubcomp_c == nil then
        return false
    end
    return install_uevr_native_pre_skip(SHRangedCmbSubcomp_c, "OnRangedReload", function(obj)
        local mod = get_active_module()
        if mod == nil or type(mod.on_ranged_reload_check) ~= "function" then
            return false
        end
        return mod.on_ranged_reload_check(obj) == true
    end, "OnRangedReload skipped")
end

-- 霰弹枪泵动机制专用：开火成功 post hook（通知业务模块设置 needs_pump）
-- 手枪模块可不实现 on_fire_success，dispatch 时自动跳过
local function install_request_manual_fire_hook()
    if SHRangedCmbSubcomp_c == nil then
        write_diag_trace("HOOK_INSTALL", "RequestManualFire skip: SHRangedCmbSubcomp_c=nil")
        return false
    end
    local method = nil
    pcall(function()
        method = SHRangedCmbSubcomp_c:find_function("RequestManualFire")
    end)
    if method == nil then
        write_diag_trace("HOOK_INSTALL", "RequestManualFire skip: find_function=nil")
        return false
    end
    local fire_call_count = 0
    local ok, err = pcall(function()
        method:hook_ptr(nil, wrap_hook_callback(function(_, obj, locals)
            fire_call_count = fire_call_count + 1
            local mod = get_active_module()
            local wt = get_current_weapon_type()
            local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
            local chain = reload_tools.resolve_combat_chain(pawn)
            local subcomp = chain and chain.ranged or nil
            write_diag_trace("PUMP_TRACE", "RequestManualFire #" .. tostring(fire_call_count)
                .. " weapon_type=" .. tostring(wt)
                .. " mod=" .. tostring(mod ~= nil and "yes" or "nil")
                .. " has_handler=" .. tostring(mod ~= nil and type(mod.on_fire_success) == "function")
                .. " subcomp=" .. tostring(subcomp ~= nil)
                .. " obj=" .. tostring(obj ~= nil)
                .. " listeners=" .. tostring(#fire_listeners))
            -- 1) 先 dispatch 给换弹 module 的 on_fire_success（若有；泵/栓在此标记）
            --    手枪 module 无 on_fire_success：跳过本步，不 early-return
            if mod ~= nil and type(mod.on_fire_success) == "function" then
                -- subcomp 解析失败时仍回调（用 hook 的 obj 兜底），避免静默丢 FIRE 事件
                mod.on_fire_success(subcomp or obj)
            end
            -- 2) 无条件广播给旁路 listeners（recoil 等；不抢 weapon_module 槽位）
            --    pcall 保护：单个 listener 异常不影响其它 listener / 后续 hook
            if #fire_listeners > 0 then
                local target = subcomp or obj
                for i = 1, #fire_listeners do
                    pcall(fire_listeners[i], target, wt)
                end
            end
        end))
    end)
    if not ok then
        print_log("RequestManualFire post hook failed: " .. tostring(err), LogLevel.Warn)
        write_diag_trace("HOOK_INSTALL", "RequestManualFire hook_ptr failed: " .. tostring(err))
        return false
    end
    return true
end

-- 霰弹枪泵动机制专用：泵动完成回调 post hook（观测引擎内部泵动状态翻转）
local function install_single_action_prepare_end_hook()
    if SHRangedCmbSubcomp_c == nil then
        write_diag_trace("HOOK_INSTALL", "OnRangedSingleActionPrepareEnd skip: SHRangedCmbSubcomp_c=nil")
        return false
    end
    local method = nil
    pcall(function()
        method = SHRangedCmbSubcomp_c:find_function("OnRangedSingleActionPrepareEnd")
    end)
    if method == nil then
        write_diag_trace("HOOK_INSTALL", "OnRangedSingleActionPrepareEnd skip: find_function=nil")
        return false
    end
    local ok, err = pcall(function()
        method:hook_ptr(nil, wrap_hook_callback(function(_, _obj, locals)
            local mod = get_active_module()
            local wt = get_current_weapon_type()
            local montage = nil
            local end_type = 0
            if locals ~= nil then
                pcall(function() montage = locals.Montage end)
                -- SDK dump: 参数名是 AnimEndType（不是 EndType）
                pcall(function()
                    end_type = locals.AnimEndType or locals.EndType or locals.ESHAnimEndType or 0
                end)
            end
            write_diag_trace("PUMP_TRACE", "PrepareEnd weapon_type=" .. tostring(wt)
                .. " mod=" .. tostring(mod ~= nil and "yes" or "nil")
                .. " end_type=" .. tostring(end_type))
            if mod == nil or type(mod.on_single_action_prepare_end) ~= "function" then
                return
            end
            mod.on_single_action_prepare_end(montage, end_type)
        end))
    end)
    if not ok then
        print_log("OnRangedSingleActionPrepareEnd post hook failed: " .. tostring(err), LogLevel.Warn)
        write_diag_trace("HOOK_INSTALL", "OnRangedSingleActionPrepareEnd hook_ptr failed: " .. tostring(err))
        return false
    end
    return true
end

local function register_reload_montage_blocker()
    if montage_callback_registered then
        return
    end
    montage_callback_registered = true
    uevrUtils.registerMontageChangeCallback(function(montage, montageName, animInstance)
        if montage_guard then
            return
        end
        if not montage_name_is_reload(montageName) then
            return
        end
        local mod = get_active_module()
        if mod == nil or type(mod.on_montage_change_check) ~= "function" then
            return
        end
        if not mod.on_montage_change_check(montage, montageName, animInstance) then
            return
        end
        montage_guard = true
        pcall(function()
            if uobject_valid(animInstance) and uobject_valid(montage) and animInstance.Montage_Stop ~= nil then
                animInstance:Montage_Stop(0.0, montage)
            end
        end)
        montage_guard = false
    end, 100)
end

-- =============================================================================
-- B 类：附件 hooks 集中注册（grip update / initAttachment 只能被包装一次）
-- =============================================================================

local function get_heal_module()
    local heal = rawget(_G, "__sh2_heal_module")
    if type(heal) == "table" then
        return heal
    end
    return nil
end

local function get_remote_grab_module()
    local remote_grab = rawget(_G, "__sh2_remote_grab_module")
    if type(remote_grab) == "table" then
        return remote_grab
    end
    return nil
end

local function install_grip_update_hook()
    if rawget(_G, "__sh2_reload_grip_hook") then
        return
    end
    local originalRegister = attachments.registerOnGripUpdateCallback
    attachments.registerOnGripUpdateCallback = function(callback)
        originalRegister(function()
            local rA, rM, rS, lA, lM, lS, oR, oL = callback()
            local mod = get_active_module()
            if mod ~= nil and type(mod.on_grip_update_merge) == "function" then
                rA, rM, rS, lA, lM, lS, oR, oL = mod.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
            end
            -- heal 在武器 merge 之后覆盖：治疗表演道具占用手时优先认领，避免 interval
            -- 在 left/rightAttachment=nil 时 detachGripAttachments 拆掉刚 spawn 的 prop
            local heal = get_heal_module()
            if heal ~= nil and type(heal.on_grip_update_merge) == "function" then
                rA, rM, rS, lA, lM, lS, oR, oL = heal.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
            end
            -- remote_grab 左手表演体最后认领左手槽
            local remote_grab = get_remote_grab_module()
            if remote_grab ~= nil and type(remote_grab.on_grip_update_merge) == "function" then
                return remote_grab.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
            end
            return rA, rM, rS, lA, lM, lS, oR, oL
        end)
    end
    _G.__sh2_reload_grip_hook = true
    print_log("grip update hook installed (dispatch to active weapon + heal + remote_grab)")
end

local function install_init_attachment_hook()
    if rawget(_G, "__sh2_reload_init_attachment_hook") then
        return
    end
    local originalInit = attachments.initAttachment
    attachments.initAttachment = function(attachment, gripHand, options)
        originalInit(attachment, gripHand, options)
        local mod = get_active_module()
        if mod ~= nil and type(mod.on_init_attachment) == "function" then
            mod.on_init_attachment(attachment, gripHand, options)
        end
        local heal = get_heal_module()
        if heal ~= nil and type(heal.on_init_attachment) == "function" then
            heal.on_init_attachment(attachment, gripHand, options)
        end
        local remote_grab = get_remote_grab_module()
        if remote_grab ~= nil and type(remote_grab.on_init_attachment) == "function" then
            remote_grab.on_init_attachment(attachment, gripHand, options)
        end
    end
    _G.__sh2_reload_init_attachment_hook = true
    print_log("initAttachment hook installed (dispatch to active weapon + heal + remote_grab)")
end

-- 2026-07-29：拦截系统自动收起武器（AnimNotify_UnequipWeapon 动画通知路径）
-- 当前为全拦截：pre-hook return false 阻止原函数执行，验证生效后再加标志位放行主动收起
-- Received_Notify 签名：bool Received_Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
local function install_anim_notify_unequip_hook()
    if AnimNotify_UnequipWeapon_c == nil then
        write_diag_trace("HOOK_INSTALL", "AnimNotify_UnequipWeapon skip: class=nil")
        return false
    end
    local ok = install_uevr_function_hook(AnimNotify_UnequipWeapon_c, "Received_Notify", function(_, obj)
        write_diag_trace("HOOK_INSTALL", "AnimNotify_UnequipWeapon intercepted (full block)")
        return false -- 全拦截：阻止原 Received_Notify 执行
    end, nil)
    if ok then
        write_diag_trace("HOOK_INSTALL", "AnimNotify_UnequipWeapon hook installed (full block)")
    else
        write_diag_trace("HOOK_INSTALL", "AnimNotify_UnequipWeapon hook install FAILED")
    end
    return ok
end

-- =============================================================================
-- 初始化：B 类立即安装；A 类延迟安装（类对象可能 init 后才就绪）
-- =============================================================================

-- 逐项记录安装结果。旧逻辑用 OR：任一成功就停止重试，会导致
-- prepare_end 装上但 RequestManualFire/PlayRequest 失败时永远不再试。
--
-- 2026-07-19 事实（sdk_notes §5.5）：霰弹枪自动拉泵阻断靠清零 PrepareAnimData（非 hook）；
-- 开火门控靠 IsFireReady。PlayRequest/RequestManualFire 对泵动路径不可靠，不再算 critical。
local a_hook_status = {
    fire_ready = false,
    out_of_ammo = false,
    can_be_reloaded = false,
    play_request = false,       -- 手枪/换弹用；泵动 SKIP 已证伪
    ranged_reload = false,      -- MulticastDelegate，find_function 恒 nil；不再重试
    ranged_reload_attempted = false,
    fire_success = false,       -- 可选；霰弹枪 needs_pump 以 clip 下降兜底
    prepare_end = false,        -- 观测/泄漏用，不阻断泵动
    montage_blocker = false,
    anim_notify_unequip = false, -- 2026-07-29：拦截系统自动收起武器（全拦截验证阶段）
}
local a_hooks_critical_ready = false
local a_hooks_retry_registered = false
local a_hooks_last_summary = nil

local function a_hooks_summary_text()
    return "A-class hooks (fire_ready=" .. tostring(a_hook_status.fire_ready)
        .. ", out_of_ammo=" .. tostring(a_hook_status.out_of_ammo)
        .. ", can_be_reloaded=" .. tostring(a_hook_status.can_be_reloaded)
        .. ", play_request=" .. tostring(a_hook_status.play_request)
        .. ", ranged_reload=" .. tostring(a_hook_status.ranged_reload)
        .. ", fire_success=" .. tostring(a_hook_status.fire_success)
        .. ", prepare_end=" .. tostring(a_hook_status.prepare_end)
        .. ", anim_notify_unequip=" .. tostring(a_hook_status.anim_notify_unequip)
        .. ", classes: ranged=" .. tostring(SHItemWeaponRanged_c ~= nil)
        .. " subcomp=" .. tostring(SHRangedCmbSubcomp_c ~= nil)
        .. " montage=" .. tostring(SHAnimMontagePlayer_c ~= nil)
        .. " unequip_notify=" .. tostring(AnimNotify_UnequipWeapon_c ~= nil) .. ")"
end

local function try_install_a_hooks()
    if a_hooks_critical_ready then
        return
    end

    if not a_hook_status.fire_ready then
        a_hook_status.fire_ready = install_fire_ready_hook()
    end
    if not a_hook_status.out_of_ammo then
        a_hook_status.out_of_ammo = install_out_of_ammo_hook()
    end
    if not a_hook_status.can_be_reloaded then
        a_hook_status.can_be_reloaded = install_can_be_reloaded_hook()
    end
    if not a_hook_status.play_request then
        a_hook_status.play_request = install_play_request_hook()
    end
    -- OnRangedReload：只尝试一次，失败后不再刷重试（已知是 MulticastDelegate）
    if not a_hook_status.ranged_reload_attempted then
        a_hook_status.ranged_reload_attempted = true
        a_hook_status.ranged_reload = install_on_ranged_reload_hook()
        if not a_hook_status.ranged_reload then
            write_diag_trace("HOOK_INSTALL", "OnRangedReload skipped permanently (not a UFunction)")
        end
    end
    if not a_hook_status.fire_success then
        a_hook_status.fire_success = install_request_manual_fire_hook()
    end
    if not a_hook_status.prepare_end then
        a_hook_status.prepare_end = install_single_action_prepare_end_hook()
    end
    if not a_hook_status.montage_blocker then
        register_reload_montage_blocker()
        a_hook_status.montage_blocker = true
    end
    -- 2026-07-29：AnimNotify_UnequipWeapon 全拦截（系统自动收起武器）
    if not a_hook_status.anim_notify_unequip then
        a_hook_status.anim_notify_unequip = install_anim_notify_unequip_hook()
    end

    -- 泵动关键：IsFireReady 必须装上（策略 C 门控）。其余 A 类为可选/手枪共用。
    a_hooks_critical_ready = a_hook_status.fire_ready == true

    local hook_summary = a_hooks_summary_text()
        .. " critical_ready=" .. tostring(a_hooks_critical_ready)
        .. " (critical=IsFireReady only; pump block=PrepareAnimData null)"
    if hook_summary ~= a_hooks_last_summary then
        a_hooks_last_summary = hook_summary
        print_log(hook_summary, LogLevel.Info)
        write_diag_trace("HOOK_INSTALL", hook_summary)
    end
end

function M.init()
    -- B 类立即安装：grip update / initAttachment 包装层
    install_grip_update_hook()
    install_init_attachment_hook()

    -- A 类尝试安装：类对象此时可能未就绪
    try_install_a_hooks()

    -- A 类兜底：关键 hook 未齐则每帧重试（已成功的项跳过，避免重复 hook_ptr）
    if not a_hooks_critical_ready and not a_hooks_retry_registered then
        a_hooks_retry_registered = true
        uevrUtils.registerPostEngineTickCallback(function()
            if a_hooks_critical_ready then
                return
            end
            try_install_a_hooks()
        end)
    end
end

-- 暴露内部工具给业务模块（诊断用）
M.get_current_weapon_type = get_current_weapon_type
M.get_active_module = get_active_module
M.uobject_valid = uobject_valid

--- 返回 A 类 hook 安装状态快照（供 shotgun_diagnose ImGui 显示）
function M.get_a_hooks_status()
    return {
        fire_ready = a_hook_status.fire_ready,
        out_of_ammo = a_hook_status.out_of_ammo,
        can_be_reloaded = a_hook_status.can_be_reloaded,
        play_request = a_hook_status.play_request,
        ranged_reload = a_hook_status.ranged_reload,
        fire_success = a_hook_status.fire_success,
        prepare_end = a_hook_status.prepare_end,
        anim_notify_unequip = a_hook_status.anim_notify_unequip,
        critical_ready = a_hooks_critical_ready,
        summary = a_hooks_last_summary or a_hooks_summary_text(),
        class_ranged = SHItemWeaponRanged_c ~= nil,
        class_subcomp = SHRangedCmbSubcomp_c ~= nil,
        class_montage = SHAnimMontagePlayer_c ~= nil,
        class_unequip_notify = AnimNotify_UnequipWeapon_c ~= nil,
    }
end

return M
