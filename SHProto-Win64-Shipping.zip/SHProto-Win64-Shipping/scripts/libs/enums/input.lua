--[[
================================================================================
VR输入模式枚举定义模块 (VR Input Mode Enums Module)
================================================================================
功能概述：
    定义VR系统中各种输入控制模式的枚举常量。
    用于配置瞄准方式、Pawn旋转模式、Pawn位置模式等。

枚举类型：
    1. AimMethod（瞄准方式）：
       - UEVR: 使用UEVR默认瞄准
       - HEAD: 头部瞄准
       - RIGHT_CONTROLLER: 右控制器瞄准
       - LEFT_CONTROLLER: 左控制器瞄准
       - RIGHT_WEAPON: 右武器瞄准
       - LEFT_WEAPON: 左武器瞄准

    2. PawnRotationMode（Pawn旋转模式）：
       - NONE: 无旋转控制
       - RIGHT_CONTROLLER: 右控制器控制旋转
       - LEFT_CONTROLLER: 左控制器控制旋转
       - LOCKED: 锁定旋转
       - SIMPLE: 简单旋转模式
       - ADVANCED: 高级旋转模式

    3. PawnPositionMode（Pawn位置模式）：
       - NONE: 无位置控制
       - FOLLOWS: Pawn跟随头部/控制器位置
       - ANIMATED: 使用动画控制位置

使用示例：
    local inputEnums = require("libs/enums/input")
    local aimMethod = inputEnums.AimMethod.RIGHT_CONTROLLER
    local rotationMode = inputEnums.PawnRotationMode.ADVANCED
================================================================================
]]--

local M = {}
M.AimMethod =
{
    UEVR = 1,
    HEAD = 2,
    RIGHT_CONTROLLER = 3,
    LEFT_CONTROLLER = 4,
    RIGHT_WEAPON = 5,
    LEFT_WEAPON = 6
}

-- M.MovementMethod =
-- {
--     UEVR = 1,
--     HEAD = 2,
--     RIGHT_CONTROLLER = 3,
--     LEFT_CONTROLLER = 4
-- }

M.PawnRotationMode =
{
    NONE = 1,
    RIGHT_CONTROLLER = 2,
    LEFT_CONTROLLER = 3,
	LOCKED = 4,
    SIMPLE = 5,
    ADVANCED = 6,
}

M.PawnPositionMode =
{
    NONE = 1,
    FOLLOWS = 2,
    ANIMATED = 3
}

return M