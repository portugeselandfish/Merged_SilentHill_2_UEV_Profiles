
local uevrUtils = require("libs/uevr_utils")
local configui = require("libs/configui")
local bodyYaw = require("libs/body_yaw")
local pawnModule = require("libs/pawn")
local inputEnums = require("libs/enums/input")

local M = {}

local configFileName = "dev/input_config_dev"
local configTabLabel = "Input Dev Config"
local widgetPrefix = "uevr_input_"

M.AimMethod = inputEnums.AimMethod
M.PawnPositionMode = inputEnums.PawnPositionMode
M.PawnRotationMode = inputEnums.PawnRotationMode
--M.MovementMethod = inputEnums.MovementMethod

local boneList = {}
local pawnCameraList = {}

local paramManager = nil


--local configIDs = {"isDisabledOverride", "aimMethod", "fixSpatialAudio", "rootOffset", "useSnapTurn", "snapAngle", "smoothTurnSpeed", "pawnRotationMode", "pawnPositionMode", "pawnPositionSweepMovement", "pawnPositionAnimationScale", "headOffset", "adjustForAnimation", "adjustForEyeOffset", "eyeOffset"}
-- local configDefaults = {
--     isDisabledOverride = false,
--     useRootOffset = true,
--     aimMethod = M.AimMethod.UEVR,
--     fixSpatialAudio = true,
--     rootOffset = {X=0,Y=0,Z=0},
--     useSnapTurn = false,
--     snapAngle = 30,
--     smoothTurnSpeed = 50,
--     pawnPositionMode = M.PawnPositionMode.FOLLOWS,
--     pawnRotationMode = M.PawnRotationMode.LOCKED,
--     pawnPositionSweepMovement = true,
--     pawnPositionAnimationScale = 0.2,
--     headOffset = {X=0,Y=0,Z=0},
--     adjustForAnimation = false,
--     adjustForEyeOffset = false,
--     eyeOffset = 0
--     aimCamera = ""
--	   useControllerRotationPitch = 1
--	   useControllerRotationYaw = 1
--	   useControllerRotationRoll = 1
--     usePawnControlRotation = 1
-- }
local configDefaults = {}

local helpText = "This module provides advanced input configuration options for developers. Adjust settings such as aim method, turning behavior, body orientation, and roomscale movement to fine-tune the VR experience."
local function getConfigWidgets(m_paramManager)
    return spliceableInlineArray {
	{
		widgetType = "checkbox",
		id = widgetPrefix .. "isDisabledOverride",
		label = "Disabled",
		initialValue = configDefaults["isDisabledOverride"]
	},
	-- {
	-- 	widgetType = "tree_node",
	-- 	id = widgetPrefix .. "handedness_tree",
	-- 	initialOpen = true,
	-- 	label = "Handedness"
	-- },
	-- 	{
	-- 		widgetType = "combo",
	-- 		id = widgetPrefix .. "handedness",
	-- 		label = "Hand",
	-- 		selections = {"Left", "Right"},
	-- 		initialValue = uevrUtils.getHandedness()
	-- 	},
	-- {
	-- 	widgetType = "tree_pop"
	-- },
	expandArray(m_paramManager.getProfilePreConfigurationWidgets, widgetPrefix),
	{
		widgetType = "checkbox",
		id = widgetPrefix .. "fixSpatialAudio",
		label = "Fix Spatial Audio",
		initialValue = configDefaults["fixSpatialAudio"]
	},
	{
		widgetType = "checkbox",
		id = widgetPrefix .. "useRootOffset",
		label = "Use HMD Offset",
		initialValue = configDefaults["useRootOffset"] or true
	},
	{
		widgetType = "drag_float3",
		id = widgetPrefix .. "rootOffset",
		label = "HMD Offset",
		speed = .1,
		range = {-200, 200},
		initialValue = {configDefaults["rootOffset"].X, configDefaults["rootOffset"].Y, configDefaults["rootOffset"].Z}
	},
	{
		widgetType = "tree_node",
		id = widgetPrefix .. "aim_method_tree",
		initialOpen = true,
		label = "Aim Method"
	},
		{
			widgetType = "combo",
			id = widgetPrefix .. "aimMethod",
			label = "Type",
			selections = {"UEVR", "Head/HMD", "Right Controller", "Left Controller", "Right Weapon", "Left Weapon"},
			initialValue = configDefaults["aimMethod"]
		},
        {
            widgetType = "begin_group",
            id = widgetPrefix .. "advanced_aim_group",
            isHidden = false
        },
			{
				widgetType = "combo",
				id = widgetPrefix .. "aimCameraList",
				label = "Aim Camera",
				selections = {"None"},
				initialValue = 1
			},
			{ widgetType = "indent", width = 10} ,
			{
				widgetType = "combo",
				id = widgetPrefix .. "usePawnControlRotation",
				label = "camera.usePawnControlRotation",
				selections = {"Default", "True", "False"},
				initialValue = 1,
				width = 100
			},
			{
				widgetType = "combo",
				id = widgetPrefix .. "cameraResetAction",
				label = "On Camera Deactivation",
				selections = {"Do not reset location and rotation", "Set to parent's location and rotation"}, --  "Zero location and rotation"},
				initialValue = 1,
			},
			{ widgetType = "unindent", width = 10} ,
        {
            widgetType = "end_group",
        },
	{
		widgetType = "tree_pop"
	},
	{
		widgetType = "begin_group",
		id = widgetPrefix .. "advanced_input_group",
		isHidden = false
	},
		{
			widgetType = "tree_node",
			id = widgetPrefix .. "turning_tree",
			initialOpen = true,
			label = "Turning"
		},
			{
				widgetType = "checkbox",
				id = widgetPrefix .. "useSnapTurn",
				label = "Use Snap Turn",
				initialValue = configDefaults["useSnapTurn"]
			},
			{
				widgetType = "slider_int",
				id = widgetPrefix .. "snapAngle",
				label = "Snap Turn Angle",
				speed = 1.0,
				range = {2, 180},
				initialValue = configDefaults["snapAngle"]
			},
			{
				widgetType = "slider_int",
				id = widgetPrefix .. "smoothTurnSpeed",
				label = "Smooth Turn Speed",
				speed = 1.0,
				range = {1, 200},
				initialValue = configDefaults["smoothTurnSpeed"]
			},
		{
			widgetType = "tree_pop"
		},
		{
			widgetType = "tree_node",
			id = widgetPrefix .. "movement_orientation_tree",
			initialOpen = false,
			label = "Movement Orientation"
		},
			-- {
			-- 	widgetType = "combo",
			-- 	id = widgetPrefix .. "movementMethod",
			-- 	label = "Type",
			-- 	selections = {"UEVR", "Head/HMD", "Right Controller", "Left Controller"},
			-- 	initialValue = configDefaults["movementMethod"]
			-- },
			{
				widgetType = "combo",
				id = widgetPrefix .. "orientRotationToMovement",
				label = "pawn.CharacterMovement.bOrientRotationToMovement",
				selections = {"Default", "True", "False"},
				initialValue = 1,
				width = 100
			},
			{
				widgetType = "combo",
				id = widgetPrefix .. "useControllerDesiredRotation",
				label = "pawn.CharacterMovement.bUseControllerDesiredRotation",
				selections = {"Default", "True", "False"},
				initialValue = 1,
				width = 100
			},
		{
			widgetType = "tree_pop"
		},
		{
			widgetType = "tree_node",
			id = widgetPrefix .. "movement_tree",
			initialOpen = true,
			label = "Body Orientation"
		},
				{
					widgetType = "combo",
					id = widgetPrefix .. "pawnRotationMode",
					label = "Type",
					selections = {"Game", "Right Controller", "Left Controller", "Locked Head/HMD", "Follows Head (Simple)", "Follows Head (Advanced)"},
					initialValue = configDefaults["pawnRotationMode"]
				},
				{ widgetType = "same_line"},
				{
					widgetType = "checkbox",
					id = widgetPrefix .. "optimizeBodyRotationCalculations",
					label = "Optimize",
					initialValue = configDefaults["optimizeBodyRotationCalculations"]
				},
				{
					widgetType = "checkbox",
					id = widgetPrefix .. "pawnRotationModeDisableRotation",
					label = "Disable Rotation",
					initialValue = configDefaults["pawnRotationModeDisableRotation"]
				},
				{ widgetType = "same_line"},
				{
					widgetType = "checkbox",
					id = widgetPrefix .. "pawnRotationModeDisableInEarlyUpdate",
					label = "Disable In Early Update",
					initialValue = configDefaults["pawnRotationModeDisableInEarlyUpdate"]
				},
				{
					widgetType = "slider_float",
					id = widgetPrefix .. "pawnRotationLockedSmoothTime",
					label = "Smoothing",
					speed = .01,
					range = {0, 1},
					initialValue = configDefaults["pawnRotationLockedSmoothTime"],
					isHidden = true
				},
				expandArray(bodyYaw.getConfigurationWidgets),
		{
			widgetType = "tree_pop"
		},
		{
			widgetType = "tree_node",
			id = widgetPrefix .. "roomscale_tree",
			initialOpen = true,
			label = "Roomscale Movement"
		},
			{
				widgetType = "combo",
				id = widgetPrefix .. "pawnPositionMode",
				label = "Type",
				selections = {"None", "Follows HMD", "Follows HMD With Animation"},
				initialValue = configDefaults["pawnPositionMode"]
			},
			{ widgetType = "same_line"},
			{
				widgetType = "checkbox",
				id = widgetPrefix .. "optimizeBodyLocationCalculations",
				label = "Optimize",
				initialValue = configDefaults["optimizeBodyLocationCalculations"]
			},
			{
				widgetType = "checkbox",
				id = widgetPrefix .. "pawnPositionSweepMovement",
				label = "Sweep Movement",
				initialValue = configDefaults["pawnPositionSweepMovement"]
			},
			{
				widgetType = "slider_float",
				id = widgetPrefix .. "pawnPositionAnimationScale",
				label = "Animation Scale",
				speed = .01,
				range = {0, 1},
				initialValue = configDefaults["pawnPositionAnimationScale"],
			},
		{
			widgetType = "tree_pop"
		},
		{
			widgetType = "tree_node",
			id = widgetPrefix .. "uevr_input_pawn_tree",
			initialOpen = true,
			label = "Player Body"
		},
			{
				widgetType = "combo",
				id = widgetPrefix .. "useControllerRotationPitch",
				label = "pawn.bUseControllerRotationPitch",
				selections = {"Default", "True", "False"},
				initialValue = 1,
				width = 100
			},
			{
				widgetType = "combo",
				id = widgetPrefix .. "useControllerRotationYaw",
				label = "pawn.bUseControllerRotationYaw",
				selections = {"Default", "True", "False"},
				initialValue = 1,
				width = 100
			},
			{
				widgetType = "combo",
				id = widgetPrefix .. "useControllerRotationRoll",
				label = "pawn.bUseControllerRotationRoll",
				selections = {"Default", "True", "False"},
				initialValue = 1,
				width = 100
			},
			{
				widgetType = "drag_float3",
				id = widgetPrefix .. "headOffset",
				label = "Mesh Offset",
				speed = .1,
				range = {-200, 200},
				initialValue = {configDefaults["headOffset"] and configDefaults["headOffset"].X or 0, configDefaults["headOffset"] and configDefaults["headOffset"].Y or 0, configDefaults["headOffset"] and configDefaults["headOffset"].Z or 0}
			},
            {
                widgetType = "checkbox",
                id = widgetPrefix .. "useMeshHeightForHeadOffset",
                label = "Use Mesh Height",
                initialValue = configDefaults["useMeshHeightForHeadOffset"]
            },
			{
				widgetType = "checkbox",
				id = widgetPrefix .. "adjustForAnimation",
				label = "Animation Movement Compensation",
				initialValue = configDefaults["adjustForAnimation"]
			},
			{
				widgetType = "combo",
				id = widgetPrefix .. "headBones",
				label = "Head Bone",
				selections = {"None"},
				initialValue = 1
			},
			{
				widgetType = "checkbox",
				id = widgetPrefix .. "adjustForEyeOffset",
				label = "Eye Offset Compensation",
				initialValue = configDefaults["adjustForEyeOffset"]
			},
			{
				widgetType = "slider_float",
				id = widgetPrefix .. "eyeOffset",
				label = "Eye Offset",
				speed = .1,
				range = {-40, 40},
				initialValue = configDefaults["eyeOffset"]
			},
		{
			widgetType = "tree_pop"
		},
	{
		widgetType = "end_group",
	},
	{ widgetType = "new_line" },
	expandArray(m_paramManager.getProfilePostConfigurationWidgets, widgetPrefix),
	{ widgetType = "new_line" },
	{
		widgetType = "tree_node",
		id = widgetPrefix .. "help_tree",
		initialOpen = true,
		label = "Help"
	},
		{
			widgetType = "text",
			id = widgetPrefix .. "help",
			label = helpText,
			wrapped = true
		},
	{
		widgetType = "tree_pop"
	},
	-- {
		-- widgetType = "slider_float",
		-- id = "neckOffset",
		-- label = "Neck Offset",
		-- speed = .1,
		-- range = {-40, 40},
		-- initialValue = 10
	-- },
    }
end
local function updateSetting(key, value)
    uevrUtils.executeUEVRCallbacks("on_input_config_param_change", key, value, true)
end

local function setCurrentHeadBone(value)
	print("Setting current head bone to index " .. value)
	if #boneList < value then
		print("Invalid head bone index")
		return
	end
	local headBoneName = boneList[value]
    updateSetting("headBoneName", headBoneName)
	local mesh = pawnModule.getBodyMesh()
	if mesh ~= nil then
		local rootBoneFName = uevrUtils.getRootBoneOfBone(mesh, headBoneName)
		if rootBoneFName ~= nil then
			local rootBoneName = rootBoneFName:to_string()
            updateSetting("rootBoneName", rootBoneName)
		end
	end
end

local function setBoneNames()
	local mesh = pawnModule.getBodyMesh()
	if mesh ~= nil then
		boneList = uevrUtils.getBoneNames(mesh)
		if boneList ~= nil and #boneList > 0 then
			configui.setSelections(widgetPrefix .. "headBones", boneList)
		end
	end
	local currentHeadBoneIndex = configui.getValue(widgetPrefix .. "headBones")
	if currentHeadBoneIndex~= nil and currentHeadBoneIndex > 1 then
		setCurrentHeadBone(currentHeadBoneIndex)
	end
end

local function updateUIState(key)
    local exKey = widgetPrefix .. key
    if key == "aimMethod" then
       -- configui.hideWidget(widgetPrefix .. "advanced_input_group", configui.getValue(exKey) == M.AimMethod.UEVR)
        configui.hideWidget(widgetPrefix .. "advanced_aim_group", configui.getValue(exKey) == M.AimMethod.UEVR)
    elseif key == "useSnapTurn" then
        configui.hideWidget(widgetPrefix .. "snapAngle", not configui.getValue(exKey))
        configui.hideWidget(widgetPrefix .. "smoothTurnSpeed", configui.getValue(exKey))
    elseif key == "pawnRotationMode" then
        configui.hideWidget("minAngularDeviation", not (configui.getValue(exKey) == M.PawnRotationMode.SIMPLE or configui.getValue(exKey) == M.PawnRotationMode.ADVANCED))
        configui.hideWidget("alignConfidenceThreshold",  configui.getValue(exKey) ~= M.PawnRotationMode.ADVANCED)
        configui.hideWidget(widgetPrefix .. "pawnRotationLockedSmoothTime",  configui.getValue(exKey) == M.PawnRotationMode.NONE)
    elseif key == "pawnPositionMode" then
        configui.hideWidget(widgetPrefix .. "pawnPositionAnimationScale", configui.getValue(exKey) ~= M.PawnPositionMode.ANIMATED)
        configui.hideWidget(widgetPrefix .. "pawnPositionSweepMovement", configui.getValue(exKey) ~= M.PawnPositionMode.FOLLOWS)
    elseif key == "adjustForAnimation" then
        configui.hideWidget(widgetPrefix .. "headBones", not configui.getValue(exKey))
    elseif key == "adjustForEyeOffset" then
        configui.hideWidget(widgetPrefix .. "eyeOffset", not configui.getValue(exKey))
	elseif key == "aimCameraList" then
		print("@@@@@@@@@@@@@@@@@")
		configui.hideWidget(widgetPrefix .. "usePawnControlRotation", configui.getValue(exKey) == 1)
		configui.hideWidget(widgetPrefix .. "cameraResetAction", configui.getValue(exKey) == 1)
    end
end

local function setSelectedPawnCamera(currentCameraName, noCallbacks)
	local selectedIndex = 1
	for i = 1, #pawnCameraList do
		if pawnCameraList[i] == currentCameraName then
			selectedIndex = i
			break
		end
	end
	configui.setValue(widgetPrefix .. "aimCameraList", selectedIndex, noCallbacks)
end


local function setPawnCameraList(currentCameraName, noCallbacks)
	--print("Setting pawn camera list")
    pawnCameraList = uevrUtils.getObjectPropertyDescriptors(pawn, "Pawn", "Class /Script/Engine.CameraComponent", true)
	--print("Found " .. #pawnCameraList .. " cameras")
	table.insert(pawnCameraList, 1, "None")
	-- for i, name in ipairs(pawnCameraList) do
	-- 	print("Camera " .. i .. ": " .. name)
	-- end

	local listName = "aimCameraList"
	--print("Updating camera list UI", widgetPrefix .. listName)
	configui.setSelections(widgetPrefix .. listName, pawnCameraList)
	-- local selectedIndex = 1
	-- for i = 1, #pawnCameraList do
	-- 	if pawnCameraList[i] == currentCameraName then
	-- 		selectedIndex = i
	-- 		break
	-- 	end
	-- end
	-- configui.setValue(widgetPrefix .. listName, selectedIndex, noCallbacks)
	setSelectedPawnCamera(currentCameraName, noCallbacks)
end

configui.onCreateOrUpdate(widgetPrefix .. "isDisabledOverride", function(value)
    updateSetting("isDisabledOverride", value)
end)

configui.onUpdate(widgetPrefix .. "headOffset", function(value)
	local arr = uevrUtils.getNativeValue(value)
    updateSetting("headOffset", {X=arr[1],Y=arr[2],Z=arr[3]})
end)

configui.onUpdate(widgetPrefix .. "useRootOffset", function(value)
	updateSetting("useRootOffset", value)
	configui.hideWidget(widgetPrefix .. "rootOffset", not value)
end)

configui.onCreate(widgetPrefix .. "useRootOffset", function(value)
	configui.hideWidget(widgetPrefix .. "rootOffset", not value)
end)

configui.onUpdate(widgetPrefix .. "rootOffset", function(value)
    --updateSetting("rootOffset", {X=value[1],Y=value[2],Z=value[3]})
	local arr = uevrUtils.getNativeValue(value)
    updateSetting("rootOffset", {X=arr[1],Y=arr[2],Z=arr[3]})
end)

configui.onUpdate(widgetPrefix .. "headBones", function(value)
	setCurrentHeadBone(value)
end)

configui.onUpdate(widgetPrefix .. "aimMethod", function(value)
	updateSetting("aimMethod", value)
    updateUIState("aimMethod")
end)

-- configui.onUpdate(widgetPrefix .. "movementMethod", function(value)
-- 	updateSetting("movementMethod", value)
--     updateUIState("movementMethod")
-- end)

configui.onCreate(widgetPrefix .. "aimMethod", function(value)
	updateUIState("aimMethod")
end)

configui.onUpdate(widgetPrefix .. "useSnapTurn", function(value)
	updateSetting("useSnapTurn", value)
    updateUIState("useSnapTurn")
end)

configui.onCreate(widgetPrefix .. "useSnapTurn", function(value)
    updateUIState("useSnapTurn")
end)

configui.onUpdate(widgetPrefix .. "snapAngle", function(value)
	updateSetting("snapAngle", value)
end)

configui.onUpdate(widgetPrefix .. "optimizeBodyRotationCalculations", function(value)
	updateSetting("optimizeBodyRotationCalculations", value)
end)

configui.onUpdate(widgetPrefix .. "pawnRotationModeDisableRotation", function(value)
	updateSetting("pawnRotationModeDisableRotation", value)
end)

configui.onUpdate(widgetPrefix .. "pawnRotationModeDisableInEarlyUpdate", function(value)
	updateSetting("pawnRotationModeDisableInEarlyUpdate", value)
end)

configui.onUpdate(widgetPrefix .. "optimizeBodyLocationCalculations", function(value)
	updateSetting("optimizeBodyLocationCalculations", value)
end)

configui.onUpdate(widgetPrefix .. "smoothTurnSpeed", function(value)
	updateSetting("smoothTurnSpeed", value)
end)

configui.onUpdate(widgetPrefix .. "pawnRotationMode", function(value)
	updateSetting("pawnRotationMode", value)
    updateUIState("pawnRotationMode")
end)

configui.onUpdate(widgetPrefix .. "pawnRotationLockedSmoothTime", function(value)
	updateSetting("pawnRotationLockedSmoothTime", value)
end)

configui.onCreate(widgetPrefix .. "pawnRotationMode", function(value)
    updateUIState("pawnRotationMode")
end)

configui.onUpdate(widgetPrefix .. "pawnPositionMode", function(value)
	updateSetting("pawnPositionMode", value)
    updateUIState("pawnPositionMode")
end)

configui.onCreate(widgetPrefix .. "pawnPositionMode", function(value)
    updateUIState("pawnPositionMode")
end)

configui.onUpdate(widgetPrefix .. "pawnPositionAnimationScale", function(value)
	updateSetting("pawnPositionAnimationScale", value)
end)

configui.onUpdate(widgetPrefix .. "adjustForAnimation", function(value)
	updateSetting("adjustForAnimation", value)
    updateUIState("adjustForAnimation")
end)

configui.onCreate(widgetPrefix .. "adjustForAnimation", function(value)
    updateUIState("adjustForAnimation")
end)

configui.onUpdate(widgetPrefix .. "useMeshHeightForHeadOffset", function(value)
    updateSetting("useMeshHeightForHeadOffset", value)
end)


configui.onUpdate(widgetPrefix .. "adjustForEyeOffset", function(value)
	updateSetting("adjustForEyeOffset", value)
    updateUIState("adjustForEyeOffset")
end)

configui.onCreate(widgetPrefix .. "adjustForEyeOffset", function(value)
    updateUIState("adjustForEyeOffset")
end)

configui.onUpdate(widgetPrefix .. "eyeOffset", function(value)
	updateSetting("eyeOffset", value)
end)

configui.onUpdate(widgetPrefix .. "pawnPositionSweepMovement", function(value)
	updateSetting("pawnPositionSweepMovement", value)
end)

configui.onUpdate(widgetPrefix .. "fixSpatialAudio", function(value)
	updateSetting("fixSpatialAudio", value)
end)

configui.onUpdate(widgetPrefix .. "useControllerRotationPitch", function(value)
	updateSetting("useControllerRotationPitch", value)
end)

configui.onUpdate(widgetPrefix .. "useControllerRotationYaw", function(value)
	updateSetting("useControllerRotationYaw", value)
end)

configui.onUpdate(widgetPrefix .. "useControllerRotationRoll", function(value)
	updateSetting("useControllerRotationRoll", value)
end)

configui.onUpdate(widgetPrefix .. "orientRotationToMovement", function(value)
	updateSetting("orientRotationToMovement", value)
end)

configui.onUpdate(widgetPrefix .. "useControllerDesiredRotation", function(value)
	updateSetting("useControllerDesiredRotation", value)
end)

configui.onUpdate(widgetPrefix .. "usePawnControlRotation", function(value)
	updateSetting("usePawnControlRotation", value)
end)

configui.onUpdate(widgetPrefix .. "cameraResetAction", function(value)
	updateSetting("cameraResetAction", value)
end)



configui.onUpdate(widgetPrefix .. "aimCameraList", function(value)
	--get the camera name from the selection
	local cameraName = pawnCameraList[value]
	updateSetting("aimCamera", cameraName)
	updateUIState("aimCameraList")
end)


-- configui.onUpdate(widgetPrefix .. "handedness", function(value)
-- 	uevrUtils.setHandedness(value-1)
-- end)

uevrUtils.registerLevelChangeCallback(function(level)
	setBoneNames()
end)

function M.getConfigurationWidgets(options)
	return configui.applyOptionsToConfigWidgets(getConfigWidgets(paramManager), options)
end

function M.showConfiguration(saveFileName, options)
	local configDefinition = {
		{
			panelLabel = configTabLabel,
			saveFile = saveFileName,
			layout = spliceableInlineArray{
				expandArray(M.getConfigurationWidgets, options)
			}
		}
	}
	configui.create(configDefinition)
end

local function setUIValue(key, value)
	if key == "aimCamera" then
		--select from the list
		--setPawnCameraList(value, true)
		setSelectedPawnCamera(value, true)
		--configui.setValue(widgetPrefix .. "aimCameraList", 1, true)
	else
		configui.setValue(widgetPrefix .. key, value, true)
	end
	updateUIState(key)
end

local function updateUI(params)
	for key, value in pairs(params) do
		setUIValue(key, value)
	end
end

function M.init(m_paramManager)
    --M.loadParameters(parametersFileName)
    configDefaults = m_paramManager and m_paramManager:getAllActiveProfileParams() or {}
	paramManager = m_paramManager
    M.showConfiguration(configFileName)

	paramManager:initProfileHandler(widgetPrefix, function(profileParams)
		updateUI(profileParams)
		setPawnCameraList(profileParams["aimCamera"], true)
	end)

	--updateUI(parameters)
end

uevrUtils.registerUEVRCallback("on_input_config_param_change", function(key, value)
	setUIValue(key, value)
end)

-- function M.registerParameterChangedCallback(callback)
--     uevrUtils.registerUEVRCallback("on_input_config_param_change", callback)
-- end

-- uevrUtils.registerHandednessChangeCallback(function(handed)
-- 	configui.setValue(widgetPrefix .. "handedness", handed + 1, true)
-- end)

return M