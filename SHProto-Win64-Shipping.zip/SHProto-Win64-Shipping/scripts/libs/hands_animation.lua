--[[
================================================================================
VR手部动画处理模块 (VR Hand Animation Handler Module)
================================================================================
功能概述：
    处理VR手部骨骼动画，根据控制器输入和物品抓握状态实时更新手指动画。
    实现从张开手掌到握紧物品的完整动画过渡，支持多种抓握姿势。

核心特性：
    1. 输入驱动的手指动画：
       - Trigger（扳机）：食指按压动画
       - Grip（抓握键）：中指/无名指/小指握紧动画
       - Thumbrest（拇指触摸）：拇指放置动画
       - 支持左右手独立控制

    2. 物品抓握动画切换：
       - 未持物状态：张开手掌动画（open_left/open_right）
       - 持物状态：握紧物品动画（grip_left_weapon/grip_right_weapon）
       - 支持多种抓握姿势扩展（如 _pistol, _rifle 等）
       - 自动根据attachments系统的抓握动画变化切换状态

    3. 自动/手动输入处理：
       - 自动模式：自动拦截XInput状态，处理输入
       - 手动模式：手动调用handleInput/handleInputForHands
       - 可通过setAutoHandleInput切换模式

    4. 动画处理器管理：
       - createAnimationHandler：为手部组件创建动画处理器
       - destroyAnimationHandler：销毁动画处理器
       - 支持多个手部组件同时存在

    5. 回调系统集成：
       - 监听attachments系统的抓握动画变化回调
       - 监听Montage变化事件
       - 支持脚本重置和关卡切换清理

    6. 动画禁用功能：
       - disableAnimations：禁用所有动画更新
       - 用于手部配置工具避免干扰

典型应用场景：
    - VR游戏中手部手指动画控制
    - VR射击游戏的武器握持和射击动画
    - VR近战游戏的武器挥砍准备动画
    - VR应用的物品抓取和操作动画
    - 配合hands.lua实现完整的手部系统

依赖模块：
    - libs/uevr_utils (UEVR工具函数)
    - libs/attachments (物品附加系统)
    - libs/animation (动画系统)

使用示例：
    local handsAnimation = require("libs/hands_animation")

    -- 创建动画处理器
    handsAnimation.createAnimationHandler("hand_right", rightHandComponent, handAnimations)

    -- 设置持物状态
    handsAnimation.setHoldingAttachment(Handed.Right, "pistol")

    -- 手动处理输入
    handsAnimation.handleInputForHands(state, "pistol", nil, false)

    -- 禁用自动输入处理
    handsAnimation.setAutoHandleInput(false)

================================================================================
]]--

local uevrUtils = require("libs/uevr_utils")
local attachments = require("libs/attachments")
local animation = require("libs/animation")

local M = {}

local holdingAttachment = {}
local inputHandlerAnimID = {}
local activeComponents = {}
local autoHandleInput = true
local disableAnimations = false --used during hand configuration to prevent loaded animation from interfering
-- 每只手上次已同步过的 weapon grip 扩展名；仅在扩展名变化时重置扳机通道，
-- 避免 montage 结束反复 updateAnimationState 时误触食指松开插值。
local lastWeaponGripExtension = {}


local currentLogLevel = LogLevel.Error
function M.setLogLevel(val)
	currentLogLevel = val
end
function M.print(text, logLevel)
	if logLevel == nil then logLevel = LogLevel.Debug end
	if logLevel <= currentLogLevel then
		uevrUtils.print("[hands_animation] " .. text, logLevel)
	end
end

local function getAnimIDSuffix(animID)
	local arr = uevrUtils.splitStr(animID, "_")
	return #arr > 0 and arr[#arr] or nil
end


-- This needs to be called externally
function M.createAnimationHandler(animID, component, handAnimations)
    if component == nil then
        M.print("No component provided for animation handler creation for animID: " .. tostring(animID), LogLevel.Error)
        return
    end
    local suffix = getAnimIDSuffix(animID)
    if suffix ~= nil then inputHandlerAnimID[animID] = suffix end
    activeComponents[component] = animID
    animation.add(animID, component, handAnimations)
	animation.initialize(animID, component)
end

function M.destroyAnimationHandler(component)
    local animID = activeComponents[component]
    if animID ~= nil then
        inputHandlerAnimID[animID] = nil
    end
end

function M.reset()
	autoHandleInput = true
    disableAnimations = false
	inputHandlerAnimID = {}
    holdingAttachment = {}
    activeComponents = {}
	lastWeaponGripExtension = {}
end

function M.exists()
    return next(inputHandlerAnimID) ~= nil
end

local function forEachUniqueTarget(callback)
	local handledTargets = {}
	for _, target in pairs(inputHandlerAnimID) do
		if target ~= nil and not handledTargets[target] then
			handledTargets[target] = true
			callback(target)
		end
	end
end

local createInputHandler = doOnce(function()
	attachments.registerOnGripAnimationCallback(function(gripAnimation, gripHand)
		M.print("Grip animation changed to " .. (gripAnimation and tostring(gripAnimation) or "None") .. " for " .. (gripHand == Handed.Left and "Left" or "Right") .. " hand", LogLevel.Debug)
		--print("Grip animation changed to ", gripAnimation, gripHand)
		M.updateAnimationState(gripHand)
	end)

	uevrUtils.registerOnPreInputGetStateCallback(function(retval, user_index, state)
		if autoHandleInput and M.exists() then
			local rightAttachment = holdingAttachment[Handed.Right] or attachments.getCurrentGripAnimation(Handed.Right)
			local leftAttachment = holdingAttachment[Handed.Left] or attachments.getCurrentGripAnimation(Handed.Left)
			--M.handleInput(state, attachment, Handed.Right, nil, true)
			M.handleInputForHands(state, rightAttachment, leftAttachment, nil, true)
		end
	end, 10) --high priority to intercept messages before possible remapper
end, Once.EVER)
createInputHandler()

local function getAttachmentStateAndExtension(attachment)
	local isHoldingAttachment = false
	local attachmentExtension = ""
	if type(attachment) == "boolean" then
		isHoldingAttachment = attachment
	elseif type(attachment) == "string" and attachment ~= "attachment_none" then
		isHoldingAttachment = true
		if attachment ~= "" then
			attachmentExtension = "_" .. attachment
		end
	end
	return isHoldingAttachment, attachmentExtension
end

-- Poses registered by attachment name itself (not grip_<hand>_weapon_<name>).
-- inject_syringe uses the normal weapon path so index finger follows trigger.
-- drink_potion also uses weapon channels, but grip is forced ON (half-fist)
-- in handleInputForHands so it never loosens / jumps toward open.
-- ammo_box uses dedicated left_grip_ammo_box / left_trigger_ammo_box (open + light curl).
local function getDirectPoseId(attachment)
	if type(attachment) ~= "string" then
		return nil
	end
	if attachment == "closed_hands" or attachment == "pull_slide" or attachment == "ammo_box" then
		return attachment
	end
	if attachment == "pull_slider" then
		return "pull_slide"
	end
	return nil
end

function M.setAutoHandleInput(val)
	autoHandleInput = val
end

function M.disableAnimations(value)
	disableAnimations = value
end

function M.setHoldingAttachment(hand, val)
	holdingAttachment[hand] = val
	M.updateAnimationState(hand)
end

function M.updateAnimationState(hand)
	if M.exists() then
		local attachment = holdingAttachment[hand]
		if attachment == nil then
			attachment = attachments.getCurrentGripAnimation(hand)
		end
		M.print("Updating animation state for " .. (hand == Handed.Left and "Left" or "Right") .. " hand with attachment: " .. (type(attachment) == "string" and attachment or tostring(attachment)), LogLevel.Debug)
		local isHoldingAttachment, attachmentExtension = getAttachmentStateAndExtension(attachment)
		M.print("Is holding attachment: " .. tostring(isHoldingAttachment), LogLevel.Debug)

		if isHoldingAttachment then
			local directPose = getDirectPoseId(attachment)
			local triggerExtChanged = (directPose == nil)
				and (lastWeaponGripExtension[hand] ~= attachmentExtension)
			forEachUniqueTarget(function(target)
				local handStr = hand == Handed.Left and "left" or "right"
				local animID = handStr .. "_" .. target
				if directPose ~= nil then
					animation.pose(animID, directPose)
				else
					-- 清空手通道；若握姿扩展名变了，再清上一套 weapon 通道。
					-- 避免旧插值继续写同一批指骨；不整表 cancel，以免误打断当前扳机食指。
					animation.cancelEmptyHandAnimations(animID, handStr)
					local prevExt = lastWeaponGripExtension[hand]
					if prevExt ~= nil and prevExt ~= attachmentExtension then
						local prevGrip = handStr .. "_grip_weapon" .. prevExt
						local prevTrigger = handStr .. "_trigger_weapon" .. prevExt
						uevrUtils.cancelLerp(animID .. "-" .. prevGrip)
						uevrUtils.cancelLerp(animID .. "-" .. prevTrigger)
						animation.resetAnimation(animID, prevGrip, false)
						animation.resetAnimation(animID, prevTrigger, false)
					end
					local gripName = handStr .. "_grip_weapon" .. attachmentExtension
					local triggerName = handStr .. "_trigger_weapon" .. attachmentExtension
					animation.animate(animID, gripName, "on")
					animation.resetAnimation(animID, gripName, true)
					if triggerExtChanged then
						animation.animate(animID, triggerName, "off")
						animation.resetAnimation(animID, triggerName, false)
					end
				end
			end)
			if directPose ~= nil then
				lastWeaponGripExtension[hand] = nil
			else
				lastWeaponGripExtension[hand] = attachmentExtension
			end
		else
			lastWeaponGripExtension[hand] = nil
			forEachUniqueTarget(function(target)
				local handStr = hand == Handed.Left and "left" or "right"
				animation.pose(handStr .. "_" .. target, "open_" .. handStr)
			end)
		end
	end
end
M.updateAnimationState = uevrUtils.profiler:wrap("Hand Animations: updateAnimationState", M.updateAnimationState)

function M.handleInputForHands(state, rightAttachment, leftAttachment, overrideTrigger, allowAutoHandle)
	if allowAutoHandle ~= true then
		autoHandleInput = false --if something else is calling this then dont auto handle input
	end
	if disableAnimations then
		--print("Animations are disabled, skipping handleInputForHands")
		return true
	end

	if overrideTrigger == nil then overrideTrigger = false end
	local animDuration = 0.1
	forEachUniqueTarget(function(target)
		for hand = Handed.Left, Handed.Right do
			local handStr = hand == Handed.Right and "right" or "left"
			--do not use ternary operators like this. If right attachment is nil then it will always pick leftAttachment for Handed.Right == true
			--local attachment = hand == Handed.Right and rightAttachment or leftAttachment
			local attachment = nil
			if hand == Handed.Right then attachment = rightAttachment else attachment = leftAttachment end
			local isHoldingAttachment, attachmentExtension = getAttachmentStateAndExtension(attachment)
			--print("Handling input for " .. handStr .. " hand, attachment: " .. (type(attachment) == "string" and attachment or tostring(attachment)) .. ", isHoldingAttachment: " .. tostring(isHoldingAttachment) .. ", attachmentExtension: " .. attachmentExtension)

			local directPose = getDirectPoseId(attachment)
			if directPose ~= nil then
				-- closed_hands / pull_slide are both pose ids and animation channel names.
				if attachment == "closed_hands" or attachment == "pull_slide" or attachment == "pull_slider" then
					animation.updateAnimation(handStr.."_"..target, directPose, true, {duration=animDuration})
				elseif attachment == "ammo_box" then
					-- Lock open+light-curl: grip ON, trigger OFF (left-only channels).
					if hand == Handed.Left then
						animation.updateAnimation(handStr.."_"..target, "left_grip_ammo_box", true, {duration=animDuration})
						animation.updateAnimation(handStr.."_"..target, "left_trigger_ammo_box", false, {duration=animDuration})
					else
						animation.pose(handStr .. "_" .. target, directPose)
					end
				else
					animation.pose(handStr .. "_" .. target, directPose)
				end
			elseif not isHoldingAttachment then
				local weaponHandTriggerValue = (hand == Handed.Right or overrideTrigger) and state.Gamepad.bRightTrigger or state.Gamepad.bLeftTrigger
				animation.updateAnimation(handStr.."_"..target, handStr.."_trigger", weaponHandTriggerValue > 100, {duration=animDuration})
				animation.updateAnimation(handStr.."_"..target, handStr.."_grip", uevrUtils.isButtonPressed(state, hand == Handed.Right and XINPUT_GAMEPAD_RIGHT_SHOULDER or XINPUT_GAMEPAD_LEFT_SHOULDER), {duration=animDuration})

				local weaponhandController = uevr.params.vr.get_right_joystick_source()
				if not (hand == Handed.Right) then weaponhandController = uevr.params.vr.get_left_joystick_source() end
				local weaponhandRest = uevr.params.vr.get_action_handle(hand == Handed.Right and "/actions/default/in/ThumbrestTouchRight" or "/actions/default/in/ThumbrestTouchLeft")
				animation.updateAnimation(handStr.."_"..target, handStr.."_thumb", uevr.params.vr.is_action_active(weaponhandRest, weaponhandController), {duration=animDuration})
			elseif attachment == "drink_potion" then
				-- Half-fist locked: always grip ON. Hand Creator edits
				-- left_grip_weapon_drink_potion / left_trigger_weapon_drink_potion.
				-- Do not follow grip button (would loosen toward open).
				local weaponHandTriggerValue = (hand == Handed.Right or overrideTrigger) and state.Gamepad.bRightTrigger or state.Gamepad.bLeftTrigger
				animation.updateAnimation(handStr.."_"..target, handStr.."_trigger_weapon_drink_potion", weaponHandTriggerValue > 100, {duration=animDuration})
				animation.updateAnimation(handStr.."_"..target, handStr.."_grip_weapon_drink_potion", true, {duration=animDuration})
			else
				local weaponHandTriggerValue = (hand == Handed.Right or overrideTrigger) and state.Gamepad.bRightTrigger or state.Gamepad.bLeftTrigger
				animation.updateAnimation(handStr.."_"..target, handStr.."_trigger_weapon" .. attachmentExtension, weaponHandTriggerValue > 100, {duration=animDuration})
				local isButtonPressed = uevrUtils.isButtonPressed(state, hand == Handed.Right and XINPUT_GAMEPAD_RIGHT_SHOULDER or XINPUT_GAMEPAD_LEFT_SHOULDER)
				animation.updateAnimation(handStr.."_"..target, handStr.."_grip_weapon" .. attachmentExtension, isButtonPressed, {duration=animDuration})
			end
		end
	end)
end

--deprecated
function M.handleInput(state, attachment, hand, overrideTrigger, allowAutoHandle)
	if allowAutoHandle ~= true then
		autoHandleInput = false --if something else is calling this then dont auto handle input
	end
	if disableAnimations then
		--print("Animations are disabled, skipping handleInput")
		return true
	end

	local isHoldingAttachment, attachmentExtension = getAttachmentStateAndExtension(attachment)

	if hand == nil then hand = Handed.Right end
	if overrideTrigger == nil then overrideTrigger = false end
	local isRightHanded = hand == Handed.Right
	local weaponHandStr = isRightHanded and "right" or "left"
	local offHandStr = isRightHanded and "left" or "right"
	local animDuration = 0.1
	forEachUniqueTarget(function(target)
		local offhandTriggerValue = (isRightHanded or overrideTrigger) and state.Gamepad.bLeftTrigger or state.Gamepad.bRightTrigger
		animation.updateAnimation(offHandStr.."_"..target, offHandStr.."_trigger", offhandTriggerValue > 100, {duration=animDuration})

		animation.updateAnimation(offHandStr.."_"..target, offHandStr.."_grip", uevrUtils.isButtonPressed(state, isRightHanded and XINPUT_GAMEPAD_LEFT_SHOULDER or XINPUT_GAMEPAD_RIGHT_SHOULDER), {duration=animDuration})

		local offhandController = uevr.params.vr.get_left_joystick_source()
		if not isRightHanded then offhandController = uevr.params.vr.get_right_joystick_source() end
		local offhandRest = uevr.params.vr.get_action_handle(isRightHanded and "/actions/default/in/ThumbrestTouchLeft" or "/actions/default/in/ThumbrestTouchRight")
		animation.updateAnimation(offHandStr.."_"..target, offHandStr.."_thumb", uevr.params.vr.is_action_active(offhandRest, offhandController), {duration=animDuration})

		if not isHoldingAttachment then
			local weaponHandTriggerValue = (isRightHanded or overrideTrigger) and state.Gamepad.bRightTrigger or state.Gamepad.bLeftTrigger
			animation.updateAnimation(weaponHandStr.."_"..target, weaponHandStr.."_trigger", weaponHandTriggerValue > 100, {duration=animDuration})

			animation.updateAnimation(weaponHandStr.."_"..target, weaponHandStr.."_grip", uevrUtils.isButtonPressed(state, isRightHanded and XINPUT_GAMEPAD_RIGHT_SHOULDER or XINPUT_GAMEPAD_LEFT_SHOULDER), {duration=animDuration})

			local weaponhandController = uevr.params.vr.get_right_joystick_source()
			if not isRightHanded then weaponhandController = uevr.params.vr.get_left_joystick_source() end
			local weaponhandRest = uevr.params.vr.get_action_handle(isRightHanded and "/actions/default/in/ThumbrestTouchRight" or "/actions/default/in/ThumbrestTouchLeft")
			animation.updateAnimation(weaponHandStr.."_"..target, weaponHandStr.."_thumb", uevr.params.vr.is_action_active(weaponhandRest, weaponhandController), {duration=animDuration})
		else
			local weaponHandTriggerValue = (isRightHanded or overrideTrigger) and state.Gamepad.bRightTrigger or state.Gamepad.bLeftTrigger
			animation.updateAnimation(weaponHandStr.."_"..target, weaponHandStr.."_trigger_weapon" .. attachmentExtension, weaponHandTriggerValue > 100, {duration=animDuration})
			if uevrUtils.isButtonPressed(state, isRightHanded and XINPUT_GAMEPAD_RIGHT_SHOULDER or XINPUT_GAMEPAD_LEFT_SHOULDER) then
				animation.resetAnimation(weaponHandStr.."_"..target, weaponHandStr.."_grip_weapon" .. attachmentExtension, false) --forces an update regardless of current state
--print("Here",weaponHandStr.."_"..target,weaponHandStr.."_grip_weapon" .. attachmentExtension)
				animation.updateAnimation(weaponHandStr.."_"..target, weaponHandStr.."_grip_weapon" .. attachmentExtension, true, {duration=animDuration})
			end
		end
	end)
end

uevrUtils.registerUEVRCallback("on_module_montage_change", function(montageObject, montageName, label, animInstance)
	if montageName == nil or montageName == "" then
		M.updateAnimationState(Handed.Left)
		M.updateAnimationState(Handed.Right)
	end
end)

uevr.params.sdk.callbacks.on_script_reset(function()
	M.reset()
end)

uevrUtils.registerPreLevelChangeCallback(function(level)
	M.reset()
end)

return M