--[[修改说明：
1. 从 manual_reload.lua 分离出来的底层换弹工具模块
2. 提供 slide（滑出/滑入）和 fall（垂直掉落）两阶段动画驱动
3. 上层文件可自由选择 slide 后是否立即进入 fall，还是停留在 slide 终态
4. 时间/距离参数由上层调用时传入，本模块不硬编码
5. 提供换弹相关的数学工具函数（坐标偏移、旋转变换、spawn transform 构造等）
6. 后续扩展：pull slide（拉栓）动作接口位预留
7. 2026-07-23：从 pistol_reload.lua / shotgun_reload.lua 下沉通用工具函数（uobject_valid, bone_name_to_string, bone_space_component, rotator_to_slide_table, foreach_component_tree, copy_component_world_transform, apply_poseable_render_flags, get_actor_root, get_drop_scene_component, prepare_spawned_actor_visible, read_bone_scale, component_display_name）
8. 2026-07-27：新增 compose_world_rot_offset（世界坐标系旋转偏移合成）
   - 与 rifle_reload.lua / shotgun_reload.lua 的 compose_local_rot_offset 对应
   - 区别：offset 在世界坐标系应用（pitch=世界 Y, yaw=世界 Z 垂直, roll=世界 X）
   - 用途：当 socket 局部轴不对应世界轴时（如步枪 bone_bullet），避免欧拉角万向锁
   - 合成顺序：composeRotators(base_rot, local_rot)（vs local 版的 composeRotators(local_rot, base_rot)）
9. 2026-07-30：新增角色运动补偿锚定 API（capture_slide_anchor / calc_slide_pull_anchored / calc_slide_rotate_anchored）
   - 原霰弹枪 tick_pump 内联的「(lh - socket) · axis 之差」模式下沉为通用函数
   - 原理：begin 阶段捕获 start_dist = (lh - socket) · axis；tick 阶段 current_dist = (lh - socket) · axis
     signed = current_dist - start_dist。玩家走动/转身时 (lh-socket) 与 axis 同步变换，内积不变
     → signed 只反映手相对枪的真实位移，与角色世界坐标运动无关
   - 用途：步枪 4 阶段拉栓（rotate_up/pull/push/rotate_down）移动中跟手；
     霰弹枪未来也可迁移到该 API 替换内联实现
   - 三个阶段切换或 pause/resume 时需重捕 start_dist（call capture_slide_anchor）
10. 2026-07-30：新增 compose_local_rot_offset（从 shotgun_reload.lua 私有版本下沉为公共工具）
    - 与已有 compose_world_rot_offset 对应：offset 在 socket 局部坐标系应用
    - 合成顺序：composeRotators(local_rot, base_rot)（vs world 版的 composeRotators(base_rot, local_rot)）
    - 用途：步枪入膛角度切回 local frame，使子弹旋转随枪体同步（枪怎么转夹角不变）
    - shotgun 保留自己的私有副本，本次不迁移（仅 rifle 切换）
11. 2026-07-30：tick_slide 旋转插值从线性欧拉改为 RLerp(bShortestPath=true)
    - 原线性插值 pitch/yaw/roll 各自独立 start+(end-start)*t，不走最短角距
    - 问题：compose_local_rot_offset 返回的 FRotator 在万向锁/等价解下会得到另一组欧拉值
      （同一物理朝向多种表示），线性插值会走长路径（45° 的旋转转成 135°），枪举角一变就复现
    - 修复：tick_slide 改用 mathLib.rlerp_shortest（RLerp 第4参 true），内部转四元数做最短角距 nlerp
    - 影响：tick_slide 为 pistol/rifle/shotgun 共用，三把枪滑入旋转都改为最短路径
    - fallback：RLerp 返回 nil 时回退原线性欧拉插值
]]--

local uevrUtils = require("libs/uevr_utils")
local mathLib = require("libs/core/math_lib")

local M = {}

---------------------------------------------------------------------------
-- 缓动函数
---------------------------------------------------------------------------

--- smoothstep 缓动
---@param t number 0~1
---@return number
function M.ease(t)
    if t <= 0.0 then return 0.0 end
    if t >= 1.0 then return 1.0 end
    return t * t * (3.0 - 2.0 * t)
end

--- 将线性进度 t 映射到「延迟后再插值」的 0~1
--- delay=0.6 → 前 60% 进度保持 0，后 40% 才从 0→1（用于旋转晚于位移变平）
---@param t number 0~1
---@param delay number 0~1
---@return number
function M.ease_delayed(t, delay)
    if t <= 0.0 then return 0.0 end
    if t >= 1.0 then return 1.0 end
    local d = delay or 0
    if d < 0 then d = 0 end
    if d > 0.95 then d = 0.95 end
    if d <= 0 then
        return M.ease(t)
    end
    if t <= d then
        return 0.0
    end
    return M.ease((t - d) / (1.0 - d))
end

---------------------------------------------------------------------------
-- Drop 状态创建
---------------------------------------------------------------------------

--- 创建一个新的 mag drop 状态表
--- 上层持有此状态，调用 start_slide/start_fall/tick 系列函数驱动动画
---@return table
function M.new_drop_state()
    return {
        active = false,
        -- "slide" | "fall"
        phase = "fall",
        at_rest = false,
        -- slide 阶段参数
        slide_duration = 0.25,
        slide_sx = 0, slide_sy = 0, slide_sz = 0,
        slide_ex = 0, slide_ey = 0, slide_ez = 0,
        -- slide 旋转插值
        slide_sp = 0, slide_syaw = 0, slide_sr = 0,
        slide_ep = 0, slide_eyaw = 0, slide_er = 0,
        slide_interpolate_rot = false,
        slide_rot_delay = 0,  -- 0~1：旋转相对位移延迟开始（越大越晚变平）
        -- slide 结束后是否跳过 fall（slide-in 用 true）
        skip_fall = false,
        -- fall 阶段参数
        duration = 0.5,
        distance = 120.0,
        -- fall 阶段起点
        sx = 0, sy = 0, sz = 0,
        -- fall 阶段水平跟随：记录初始 socket 水平位置和初始 fall 起点，每帧计算 delta
        -- 使 fall 阶段 x/y 跟随枪体移动（相对运动），z 自由下坠
        fall_init_socket_x = nil,  -- fall 开始时 follow_provider 返回的 sx（枪体水平位置）
        fall_init_socket_y = nil,
        fall_init_sx = nil,        -- fall 开始时的 state.sx（弹匣水平位置）
        fall_init_sy = nil,
        -- 通用
        start_t = 0,
        -- 动画完成回调
        on_finish = nil,
        -- 跟随提供器：每帧刷新 slide 起点/终点/旋转（用于枪移动时弹夹跟随枪体）
        -- 签名: function() -> {sx,sy,sz,ex,ey,ez,start_rot={Pitch,Yaw,Roll},end_rot={Pitch,Yaw,Roll}} | nil
        -- 返回 nil 时 tick_slide 回退到缓存的 sx/sy/sz/ex/ey/ez（优雅降级）
        -- fall 阶段复用此 provider：tick_fall 读取返回的 sx/sy 作为枪体水平位置，计算相对运动
        follow_provider = nil,
    }
end

---------------------------------------------------------------------------
-- Slide 阶段 API
---------------------------------------------------------------------------

--- 启动 slide 动画阶段
---@param state table 由 new_drop_state 创建的状态表
---@param opts table {
---   sx, sy, sz       -- 起点世界坐标
---   ex, ey, ez       -- 终点世界坐标
---   duration          -- slide 时长（秒）
---   skip_fall         -- slide 结束后是否跳过 fall（默认 false；slide-in 设 true）
---   interpolate_rot   -- 是否插值旋转（默认 false）
---   start_rot         -- 起点旋转 {Pitch, Yaw, Roll}（interpolate_rot=true 时必填）
---   end_rot           -- 终点旋转 {Pitch, Yaw, Roll}
---   rot_delay         -- 0~1，旋转相对位移延迟（默认 0；越大越晚从 start 转到 end）
---   on_finish         -- 动画完成回调（可选）
--- }
---@return boolean
function M.start_slide(state, opts)
    if opts == nil then return false end
    state.phase = "slide"
    state.active = true
    state.at_rest = false
    state.start_t = os.clock()

    state.slide_sx = opts.sx or 0
    state.slide_sy = opts.sy or 0
    state.slide_sz = opts.sz or 0
    state.slide_ex = opts.ex or 0
    state.slide_ey = opts.ey or 0
    state.slide_ez = opts.ez or 0
    state.slide_duration = opts.duration or 0.25
    state.skip_fall = opts.skip_fall == true
    state.on_finish = opts.on_finish
    -- 跟随提供器（可选）：每帧刷新 slide 起点/终点/旋转，用于枪移动时弹夹跟随枪体
    state.follow_provider = opts.follow_provider

    local rot_delay = opts.rot_delay or 0
    if rot_delay < 0 then rot_delay = 0 end
    if rot_delay > 0.95 then rot_delay = 0.95 end
    state.slide_rot_delay = rot_delay

    if opts.interpolate_rot and opts.start_rot and opts.end_rot then
        state.slide_interpolate_rot = true
        state.slide_sp = opts.start_rot.Pitch or 0
        state.slide_syaw = opts.start_rot.Yaw or 0
        state.slide_sr = opts.start_rot.Roll or 0
        state.slide_ep = opts.end_rot.Pitch or 0
        state.slide_eyaw = opts.end_rot.Yaw or 0
        state.slide_er = opts.end_rot.Roll or 0
    else
        state.slide_interpolate_rot = false
    end

    return true
end

--- 每帧驱动 slide 插值
---@param state table
---@return table|nil result {
---   x, y, z          -- 当前位置
---   pitch, yaw, roll -- 当前旋转（仅 interpolate_rot 时有值）
---   phase_done        -- slide 阶段是否结束
---   all_done          -- skip_fall=true 且 slide 结束时为 true
--- }
---   返回 nil 表示动画未激活
function M.tick_slide(state)
    if not state.active or state.phase ~= "slide" then
        return nil
    end

    -- 跟随提供器：每帧从枪体 socket 重新计算起点/终点/旋转（枪移动时弹夹跟随）
    -- 返回 nil 时回退到缓存的 sx/sy/sz/ex/ey/ez（优雅降级）
    if state.follow_provider ~= nil then
        local ok, fresh = pcall(state.follow_provider)
        if ok and fresh ~= nil then
            state.slide_sx = fresh.sx or state.slide_sx
            state.slide_sy = fresh.sy or state.slide_sy
            state.slide_sz = fresh.sz or state.slide_sz
            state.slide_ex = fresh.ex or state.slide_ex
            state.slide_ey = fresh.ey or state.slide_ey
            state.slide_ez = fresh.ez or state.slide_ez
            if state.slide_interpolate_rot then
                if fresh.start_rot ~= nil then
                    state.slide_sp   = fresh.start_rot.Pitch or state.slide_sp
                    state.slide_syaw = fresh.start_rot.Yaw   or state.slide_syaw
                    state.slide_sr   = fresh.start_rot.Roll  or state.slide_sr
                end
                if fresh.end_rot ~= nil then
                    state.slide_ep   = fresh.end_rot.Pitch or state.slide_ep
                    state.slide_eyaw = fresh.end_rot.Yaw   or state.slide_eyaw
                    state.slide_er   = fresh.end_rot.Roll  or state.slide_er
                end
            end
        end
    end

    local elapsed = os.clock() - state.start_t
    local sd = math.max(state.slide_duration, 0.01)
    local t = elapsed / sd
    if t > 1.0 then t = 1.0 end
    -- 位移用全程 ease；旋转可用 rot_delay 延后（斜着走大半程，靠近终点再转平）
    local u = M.ease(t)

    local x = state.slide_sx + (state.slide_ex - state.slide_sx) * u
    local y = state.slide_sy + (state.slide_ey - state.slide_sy) * u
    local z = state.slide_sz + (state.slide_ez - state.slide_sz) * u

    local result = {
        x = x, y = y, z = z,
        phase_done = false,
        all_done = false,
    }

    if state.slide_interpolate_rot then
        local ur = M.ease_delayed(t, state.slide_rot_delay or 0)
        -- 2026-07-30：旋转插值改用 RLerp(bShortestPath=true)
        -- 原线性欧拉插值在万向锁/等价解下会走长路径（45° 的旋转转成 135°）
        -- RLerp 内部转四元数做最短角距插值，枪举角变化时始终走最短路径
        local start_rotator = uevrUtils.rotator(state.slide_sp, state.slide_syaw, state.slide_sr)
        local end_rotator   = uevrUtils.rotator(state.slide_ep, state.slide_eyaw, state.slide_er)
        local lerped = mathLib.rlerp_shortest(start_rotator, end_rotator, ur)
        if lerped ~= nil then
            result.pitch = lerped.Pitch or 0
            result.yaw   = lerped.Yaw or 0
            result.roll  = lerped.Roll or 0
        else
            -- fallback：RLerp 不可用时回退原线性欧拉插值
            result.pitch = state.slide_sp + (state.slide_ep - state.slide_sp) * ur
            result.yaw   = state.slide_syaw + (state.slide_eyaw - state.slide_syaw) * ur
            result.roll  = state.slide_sr + (state.slide_er - state.slide_sr) * ur
        end
    end

    if t >= 1.0 then
        result.phase_done = true
        if state.skip_fall then
            -- slide-only 模式（slide-in）：动画全部完成
            state.active = false
            state.at_rest = true
            result.all_done = true
            local cb = state.on_finish
            state.on_finish = nil
            if cb then cb() end
        end
        -- 否则由上层决定是否调用 start_fall 进入下落阶段
    end

    return result
end

---------------------------------------------------------------------------
-- Fall 阶段 API
---------------------------------------------------------------------------

--- 启动垂直下落阶段
---@param state table
---@param opts table {
---   sx, sy, sz       -- 下落起点世界坐标
---   duration          -- 下落时长（秒）
---   distance          -- 下落距离（cm）
---   on_finish         -- 完成回调（可选）
---   follow_provider   -- 水平跟随提供器（可选）：每帧返回枪体水平位置，使 x/y 跟随枪体移动
---                      签名与 slide 阶段相同：function() -> {sx,sy,...} | nil
---                      传入 nil 时清理 state.follow_provider（fall 阶段不跟随）
--- }
---@return boolean
function M.start_fall(state, opts)
    if opts == nil then return false end
    state.phase = "fall"
    state.active = true
    state.at_rest = false
    state.start_t = os.clock()

    state.sx = opts.sx or 0
    state.sy = opts.sy or 0
    state.sz = opts.sz or 0
    state.duration = opts.duration or 0.5
    state.distance = opts.distance or 120.0
    state.on_finish = opts.on_finish
    -- fall 阶段 follow_provider：使 x/y 跟随枪体移动（相对运动），z 自由下坠
    -- 传 nil 时清理（避免上一次 slide 阶段的 provider 残留）
    state.follow_provider = opts.follow_provider
    -- 清理 fall 相对运动的初始位置缓存（tick_fall 第一次调用时会重新记录）
    state.fall_init_socket_x = nil
    state.fall_init_socket_y = nil
    state.fall_init_sx = nil
    state.fall_init_sy = nil

    return true
end

--- 每帧驱动 fall 插值（二次加速下落）
--- 若 state.follow_provider 存在：x/y 跟随枪体水平移动（相对运动），z 自由下坠
---@param state table
---@return table|nil result {
---   x, y, z     -- 当前位置
---   done         -- 下落是否完成
--- }
---   返回 nil 表示动画未激活
function M.tick_fall(state)
    if not state.active or state.phase ~= "fall" then
        return nil
    end

    -- fall 阶段水平跟随：每帧从 follow_provider 获取枪体水平位置，计算相对运动
    -- 使 fall 的 x/y 跟随枪体移动（走动/转身时弹匣不会脱离枪体原地下坠）
    -- z 仍由自由下坠计算（state.sz - fall），不受 follow_provider 影响
    if state.follow_provider ~= nil then
        local ok, fresh = pcall(state.follow_provider)
        if ok and fresh ~= nil and fresh.sx ~= nil and fresh.sy ~= nil then
            -- 第一次调用时记录初始 socket 水平位置和初始 fall 起点
            if state.fall_init_socket_x == nil then
                state.fall_init_socket_x = fresh.sx
                state.fall_init_socket_y = fresh.sy
                state.fall_init_sx = state.sx
                state.fall_init_sy = state.sy
            else
                -- 计算 delta：枪体相对 fall 开始时的位移
                local delta_x = fresh.sx - state.fall_init_socket_x
                local delta_y = fresh.sy - state.fall_init_socket_y
                -- 更新 fall 起点 x/y（相对运动）
                state.sx = state.fall_init_sx + delta_x
                state.sy = state.fall_init_sy + delta_y
            end
        end
        -- follow_provider 返回 nil 时回退到缓存的 state.sx/sy（优雅降级，保持上一帧位置）
    end

    local elapsed = os.clock() - state.start_t
    local duration = math.max(state.duration, 0.01)
    local t = elapsed / duration
    if t > 1.0 then t = 1.0 end
    local fall = state.distance * (t * t)
    local z = state.sz - fall

    local result = {
        x = state.sx,
        y = state.sy,
        z = z,
        done = false,
    }

    if t >= 1.0 and not state.at_rest then
        state.at_rest = true
        state.active = false
        result.done = true
        local cb = state.on_finish
        state.on_finish = nil
        if cb then cb() end
    end

    return result
end

---------------------------------------------------------------------------
-- 取消 / 重置
---------------------------------------------------------------------------

--- 取消动画，重置状态（不清理 actor，由上层负责）
---@param state table
function M.cancel(state)
    state.active = false
    state.at_rest = false
    state.phase = "fall"
    state.skip_fall = false
    state.slide_interpolate_rot = false
    state.on_finish = nil
    state.follow_provider = nil
    -- 清理 fall 阶段相对运动的初始位置缓存
    state.fall_init_socket_x = nil
    state.fall_init_socket_y = nil
    state.fall_init_sx = nil
    state.fall_init_sy = nil
end

---------------------------------------------------------------------------
-- 便捷：从 slide 终点自动接 fall
---------------------------------------------------------------------------

--- 当 slide 结束且 skip_fall=false 时，上层可调用此函数自动以 slide 终点为 fall 起点
--- 典型用法：在 tick_slide 返回 phase_done=true 且 skip_fall=false 时调用
--- 自动复用 slide 阶段的 follow_provider：fall 阶段 x/y 跟随枪体移动，z 自由下坠
---@param state table
---@param opts_override table|nil 可选覆盖 { duration, distance, on_finish, follow_provider }
---@return boolean
function M.transition_slide_to_fall(state, opts_override)
    local opts = {
        sx = state.slide_ex,
        sy = state.slide_ey,
        sz = state.slide_ez,
        duration = state.duration,
        distance = state.distance,
        -- 复用 slide 阶段的 follow_provider：fall 阶段继续跟随枪体水平移动
        follow_provider = state.follow_provider,
    }
    if opts_override then
        for k, v in pairs(opts_override) do
            opts[k] = v
        end
    end
    return M.start_fall(state, opts)
end

---------------------------------------------------------------------------
-- 数学工具函数（从 pistol_reload 迁移）
---------------------------------------------------------------------------

--- 给世界坐标加上偏移量
---@param loc table {X, Y, Z}
---@param ox number|nil
---@param oy number|nil
---@param oz number|nil
---@return table|nil
function M.apply_world_offset(loc, ox, oy, oz)
    if loc == nil then
        return nil
    end
    return {
        X = loc.X + (ox or 0),
        Y = loc.Y + (oy or 0),
        Z = loc.Z + (oz or 0),
    }
end

--- 根据 socket 世界旋转，将局部偏移（forward/right/down）转换为世界坐标增量
--- 用 uevrUtils.rotateVector（内部含 mathLib 纯 Lua 四元数回退），
--- 避免 kismet_math_library 为 nil 时直接返回 0 导致 slide 动画失效
---@param rot table 世界旋转 Rotator
---@param local_forward number
---@param local_right number
---@param local_down number
---@return number dx, number dy, number dz
function M.local_offset_to_world_delta(rot, local_forward, local_right, local_down)
    if rot == nil then
        return 0, 0, 0
    end
    local forward = uevrUtils.rotateVector(uevrUtils.vector(1, 0, 0), rot)
    local right = uevrUtils.rotateVector(uevrUtils.vector(0, 1, 0), rot)
    local up = uevrUtils.rotateVector(uevrUtils.vector(0, 0, 1), rot)
    local lf = local_forward or 0
    local lr = local_right or 0
    local ld = local_down or 0
    return forward.X * lf + right.X * lr - up.X * ld,
        forward.Y * lf + right.Y * lr - up.Y * ld,
        forward.Z * lf + right.Z * lr - up.Z * ld
end

--- 从 socket 旋转获取局部偏移的世界坐标增量（封装 mesh:GetSocketRotation 调用由上层完成）
--- 上层先获取 socket 旋转后传入此函数
---@param socket_rot table 由 mesh:GetSocketRotation 获取的世界旋转
---@param local_forward number
---@param local_right number
---@param local_down number
---@return number dx, number dy, number dz
function M.socket_local_offset_to_world_delta(socket_rot, local_forward, local_right, local_down)
    return M.local_offset_to_world_delta(socket_rot, local_forward, local_right, local_down)
end

--- 从 Rotator userdata/table 提取 Pitch/Yaw/Roll，构造四元数（用于 spawn transform）
---@param world_rot table Rotator userdata 或 table
---@return userdata|nil quaternion
function M.rotation_for_spawn_transform(world_rot)
    if world_rot == nil then
        return nil
    end
    local pitch, yaw, roll
    if type(world_rot) == "userdata" then
        local ok, p = pcall(function() return world_rot.Pitch end)
        local ok2, y = pcall(function() return world_rot.Yaw end)
        local ok3, r = pcall(function() return world_rot.Roll end)
        if not (ok and ok2 and ok3) then
            return nil
        end
        pitch, yaw, roll = p, y, r
    else
        local r = uevrUtils.rotator(world_rot)
        if type(r) == "userdata" then
            pitch, yaw, roll = r.Pitch, r.Yaw, r.Roll
        elseif type(r) == "table" then
            pitch = r.Pitch or r.X or r.x or 0
            yaw = r.Yaw or r.Y or r.y or 0
            roll = r.Roll or r.Z or r.z or 0
        else
            return nil
        end
    end
    return uevrUtils.quatFromRotator(pitch, yaw, roll)
end

--- 构造 spawn transform（位置 + 旋转四元数）
---@param world_loc table {X, Y, Z}
---@param world_rot table|nil Rotator
---@return userdata transform
function M.make_spawn_transform(world_loc, world_rot)
    local pos = { X = world_loc.X, Y = world_loc.Y, Z = world_loc.Z }
    return uevrUtils.get_transform(pos, M.rotation_for_spawn_transform(world_rot))
end

---------------------------------------------------------------------------
-- Pull Slide（拉栓）数学工具
-- 纯数学/状态管理，不依赖任何游戏 API
-- 上层 pistol_reload.lua 负责获取控制器位置、枪体方向、PoseableMesh 等
---------------------------------------------------------------------------

--- 创建拉栓状态表
--- 上层持有此状态，调用 calc_slide_pull_anchored / calc_slide_rotate_anchored /
--- is_pull_done / is_push_done 驱动逻辑
---@return table
function M.new_slide_rack_state()
    return {
        active = false,           -- 拉栓手势是否激活
        start_pos = nil,          -- {X, Y, Z} 起始世界坐标（SteamVR 控制器坐标）
        backward_axis = nil,      -- {X, Y, Z} 枪体后方向单位向量
        signed_pull = 0,          -- 当前后拉距离（cm，正值=后拉）
        pull_max = 0,             -- 本轮拉栓最大后拉距离
        pull_done = false,        -- 后拉是否已到位
        pull_progress = 0,        -- 0~1 渐进进度
        -- 旋转上拉/下压（与后拉/前推同构：沿 rotate_axis 手势投影）
        rotate_axis = nil,        -- {X, Y, Z} 上拉方向单位向量（下压阶段可取反）
        signed_rotate = 0,        -- 当前沿旋转轴投影距离（cm）
        rotate_max = 0,           -- 本阶段最大投影距离
        rotate_up_done = false,   -- 上拉是否已到位
        rotate_progress = 0,      -- 0~1 旋转渐进进度
        rotate_base = 0,          -- 断点续拉基准偏移（cm）：pause→resume 时已累积的 signed_rotate 值
        pull_base = 0,            -- 断点续拉基准偏移（cm）：pause→resume 时已累积的 signed_pull 值
        -- 运动补偿锚定标量（2026-07-30 新增）：begin/阶段切换/resume 时捕获
        -- nil 时 calc_slide_pull_anchored / calc_slide_rotate_anchored 走旧 world-space fallback
        start_anchor_dist = nil,  -- (lh - socket) · axis 的基准值；阶段切换时需重捕
        -- 弹簧复位动画（降级方案或 PoseableMesh 回弹时用）
        returning = false,
        return_start_t = 0,
        return_duration = 0.15,
        return_start_progress = 0,  -- 复位起始 progress（通常为 pull_done 时的 1.0）
        return_rest_progress = 0,   -- 复位目标 progress（通常为 0）
    }
end

--- 计算拉栓进度（旧函数，2026-07-30 已删除）
--- 手枪/霰弹枪/步枪已全部迁移到 calc_slide_pull_anchored（含运动补偿）
--- 旧算法内联于 calc_slide_pull_anchored 的 fallback 路径

--- 后拉到位判定
---@param signed_pull number 当前后拉距离
---@param pull_dist number 后拉到位阈值（cm）
---@return boolean
function M.is_pull_done(signed_pull, pull_dist)
    return (signed_pull or 0) >= (pull_dist or 1.0)
end

--- 推回到位判定：后拉到位后，手沿枪轴前移 push_dist 才算完成（相对满程，不用 pull_max 防抖动误触）
---@param pull_threshold number 后拉满程（cm）
---@param signed_pull number 当前后拉距离
---@param push_dist number 须前移的距离（cm）
---@return boolean
function M.is_push_done(pull_threshold, signed_pull, push_dist)
    local full = math.max(pull_threshold or 1.0, 0.001)
    local push = push_dist or 1.0
    -- 严格大于：允许 push_dist == full 时不触发钳制，
    -- 使 push 完成条件为 signed_pull <= 0（栓完全推回原位才完成）
    if push > full then
        push = full * 0.5
    end
    return (signed_pull or 0) <= (full - push)
end

--- 计算旋转上拉/下压进度（旧函数，2026-07-30 已删除）
--- 与 calc_slide_pull 同构，手枪/霰弹枪/步枪已全部迁移到 calc_slide_rotate_anchored



---------------------------------------------------------------------------
-- 锚定到枪体 socket 的运动补偿 API（2026-07-30 新增）
-- 原理：(lh - socket) · axis 在角色刚体运动下保持不变（正交变换保内积）。
--   begin 阶段捕获 start_dist = (lh - socket) · axis；
--   tick  阶段 current_dist = (lh - socket) · axis；
--   signed = current_dist - start_dist 只反映手相对枪的真实位移量。
-- 用途：移动/转身中拉栓不漂移；霰弹枪 tick_pump 内联算法的下沉封装。
---------------------------------------------------------------------------

--- 捕获锚定基准标量（begin 阶段或阶段切换时调用）
--- 计算 (lh_pos - socket_loc) 在 axis 上的投影距离，作为后续 tick 的基准
---@param lh_pos table {X, Y, Z} 左手世界坐标
---@param socket_loc table {X, Y, Z} 枪体 socket 世界坐标
---@param axis table {X, Y, Z} 投影轴单位向量（backward_axis 或 rotate_axis）
---@return number|nil start_dist 锚定标量；nil 表示参数缺失
function M.capture_slide_anchor(lh_pos, socket_loc, axis)
    if lh_pos == nil or socket_loc == nil or axis == nil then
        return nil
    end
    local dx = (lh_pos.X or 0) - (socket_loc.X or 0)
    local dy = (lh_pos.Y or 0) - (socket_loc.Y or 0)
    local dz = (lh_pos.Z or 0) - (socket_loc.Z or 0)
    return dx * (axis.X or 0)
         + dy * (axis.Y or 0)
         + dz * (axis.Z or 0)
end

--- 锚定到 socket 的后拉进度计算（pull/push 阶段）
--- start_dist 为 nil 时优雅降级到旧 world-space 行为（内联算法，原 calc_slide_pull 已删除）
---@param lh_pos table {X, Y, Z} 当前左手世界坐标
---@param socket_loc table {X, Y, Z} 当前枪体 socket 世界坐标
---@param axis table {X, Y, Z} backward_axis 单位向量
---@param start_dist number|nil 由 capture_slide_anchor 捕获的基准标量
---@param threshold number 后拉满程阈值（cm）
---@param fallback_start_pos table|nil 旧 world-space fallback 用的起始坐标（rack.start_pos）
---@return number signed_pull 正值=后拉距离
---@return number pull_progress 0~1
function M.calc_slide_pull_anchored(lh_pos, socket_loc, axis, start_dist, threshold, fallback_start_pos)
    if start_dist == nil or socket_loc == nil or axis == nil then
        -- fallback：旧 world-space 行为（内联原 calc_slide_pull 算法，旧函数已删除）
        if fallback_start_pos == nil or lh_pos == nil then
            return 0, 0
        end
        local fdx = (lh_pos.X or 0) - (fallback_start_pos.X or 0)
        local fdy = (lh_pos.Y or 0) - (fallback_start_pos.Y or 0)
        local fdz = (lh_pos.Z or 0) - (fallback_start_pos.Z or 0)
        local fsigned
        if axis ~= nil then
            fsigned = fdx * (axis.X or 0) + fdy * (axis.Y or 0) + fdz * (axis.Z or 0)
        else
            fsigned = math.sqrt(fdx * fdx + fdy * fdy + fdz * fdz)
        end
        local fthr = math.max(threshold or 1.0, 0.001)
        local fprogress = fsigned / fthr
        if fprogress < 0 then fprogress = 0 end
        if fprogress > 1 then fprogress = 1 end
        return fsigned, fprogress
    end
    local dx = (lh_pos.X or 0) - (socket_loc.X or 0)
    local dy = (lh_pos.Y or 0) - (socket_loc.Y or 0)
    local dz = (lh_pos.Z or 0) - (socket_loc.Z or 0)
    local current_dist = dx * (axis.X or 0)
                       + dy * (axis.Y or 0)
                       + dz * (axis.Z or 0)
    local signed = current_dist - start_dist
    local thr = math.max(threshold or 1.0, 0.001)
    local progress = signed / thr
    if progress < 0 then progress = 0 end
    if progress > 1 then progress = 1 end
    return signed, progress
end

--- 锚定到 socket 的旋转进度计算（rotate_up/rotate_down 阶段）
--- 与 calc_slide_pull_anchored 同构，独立命名便于旋转阶段语义清晰
---@param lh_pos table {X, Y, Z} 当前左手世界坐标
---@param socket_loc table {X, Y, Z} 当前枪体 socket 世界坐标
---@param axis table {X, Y, Z} rotate_axis 单位向量
---@param start_dist number|nil 由 capture_slide_anchor 捕获的基准标量
---@param threshold number 旋转满程手移距离（cm）
---@param fallback_start_pos table|nil 旧 world-space fallback 用的起始坐标（rack.start_pos）
---@return number signed_rotate 正值=沿轴向位移
---@return number rotate_progress 0~1
function M.calc_slide_rotate_anchored(lh_pos, socket_loc, axis, start_dist, threshold, fallback_start_pos)
    return M.calc_slide_pull_anchored(lh_pos, socket_loc, axis, start_dist, threshold, fallback_start_pos)
end

--- 上拉到位判定（与 is_pull_done 同构）
---@param signed_rotate number 当前沿旋转轴投影距离
---@param rotate_dist number 上拉满程阈值（cm）
---@return boolean
function M.is_rotate_up_done(signed_rotate, rotate_dist)
    return (signed_rotate or 0) >= (rotate_dist or 1.0)
end

--- 下压到位判定：上拉满程后，手沿轴反向移动 down_dist 才算完成（与 is_push_done 同构）
--- 若下压阶段重新捕获 start_pos 并用取反轴，也可直接用 is_rotate_up_done
---@param rotate_threshold number 旋转满程（cm）
---@param signed_rotate number 当前沿旋转轴投影距离（相对上拉起点）
---@param down_dist number 须下压的距离（cm）
---@return boolean
function M.is_rotate_down_done(rotate_threshold, signed_rotate, down_dist)
    return M.is_push_done(rotate_threshold, signed_rotate, down_dist)
end

--- 计算 PoseableMesh 骨骼目标位置（纯向量运算）
--- slide_joint 新位置 = 静止位置 + progress × 最大后拉距离 × 后方向
---@param rest_pos table {X, Y, Z} slide_joint 静止时的世界坐标
---@param backward_axis table {X, Y, Z} 枪体后方向单位向量
---@param progress number 0~1 渐进进度
---@param max_distance number 最大后拉距离（cm）
---@return table {X, Y, Z}
function M.calc_slide_bone_offset(rest_pos, backward_axis, progress, max_distance)
    local p = progress or 0
    if p < 0 then p = 0 end
    if p > 1 then p = 1 end
    local dist = p * (max_distance or 0)
    return {
        X = (rest_pos.X or 0) + dist * (backward_axis.X or 0),
        Y = (rest_pos.Y or 0) + dist * (backward_axis.Y or 0),
        Z = (rest_pos.Z or 0) + dist * (backward_axis.Z or 0),
    }
end

--- 启动弹簧复位动画（PoseableMesh lerp 回原位）
---@param state table 由 new_slide_rack_state 创建
---@param start_progress number 复位起始 progress（通常为当前 pull_progress）
---@param duration number|nil 复位时长（秒），默认 0.15
---@return boolean
function M.start_slide_return(state, start_progress, duration)
    if state == nil then return false end
    state.returning = true
    state.return_start_t = os.clock()
    state.return_duration = duration or 0.15
    state.return_start_progress = start_progress or state.pull_progress or 0
    state.return_rest_progress = 0
    return true
end

--- 每帧驱动弹簧复位插值
---@param state table
---@return table|nil {progress, done}  返回 nil 表示未在复位中
function M.tick_slide_return(state)
    if state == nil or not state.returning then
        return nil
    end

    local elapsed = os.clock() - state.return_start_t
    local dur = math.max(state.return_duration, 0.01)
    local t = elapsed / dur
    if t > 1 then t = 1 end
    local u = M.ease(t)

    local sp = state.return_start_progress or 0
    local progress = sp + (0 - sp) * u

    local result = {
        progress = progress,
        done = false,
    }

    if t >= 1 then
        state.returning = false
        result.done = true
        result.progress = 0
    end

    return result
end

--- 取消/重置拉栓状态（纯状态重置，不清理 actor——由上层负责）
---@param state table
function M.cancel_slide_rack(state)
    if state == nil then return end
    state.active = false
    state.start_pos = nil
    state.backward_axis = nil
    state.signed_pull = 0
    state.pull_max = 0
    state.pull_done = false
    state.pull_progress = 0
    state.rotate_axis = nil
    state.signed_rotate = 0
    state.rotate_max = 0
    state.rotate_up_done = false
    state.rotate_progress = 0
    state.returning = false
    state.return_start_t = 0
    state.return_start_progress = 0
    state.return_rest_progress = 0
end

---------------------------------------------------------------------------
-- 通用工具函数（从 pistol_reload / shotgun_reload 提级）
-- socket 查询、组件坐标、距离计算、武器标识——不含任何武器特有逻辑
-- 将来 rifle_reload 也会复用
---------------------------------------------------------------------------

--- 获取 socket 世界坐标
---@param mesh userdata
---@param socket_name string
---@return table|nil {X, Y, Z}
function M.get_socket_world_location(mesh, socket_name)
    if mesh == nil or mesh.GetSocketLocation == nil then
        return nil
    end
    local ok, loc = pcall(function()
        return mesh:GetSocketLocation(uevrUtils.fname_from_string(socket_name))
    end)
    if ok and loc ~= nil then
        return loc
    end
    return nil
end

--- 获取组件世界坐标
---@param comp userdata
---@return table|nil {X, Y, Z}
function M.get_component_world_location(comp)
    if comp == nil then
        return nil
    end
    local ok, loc = pcall(function()
        if comp.K2_GetComponentLocation ~= nil then
            return comp:K2_GetComponentLocation()
        end
        if comp.GetWorldLocation ~= nil then
            return comp:GetWorldLocation()
        end
        return nil
    end)
    if ok and loc ~= nil then
        return loc
    end
    return nil
end

--- 获取组件世界旋转
---@param comp userdata
---@return table|nil Rotator
function M.get_component_world_rotation(comp)
    if comp == nil then
        return nil
    end
    local ok, rot = pcall(function()
        if comp.K2_GetComponentRotation ~= nil then
            return comp:K2_GetComponentRotation()
        end
        if comp.GetWorldRotation ~= nil then
            return comp:GetWorldRotation()
        end
        return nil
    end)
    if ok and rot ~= nil then
        return rot
    end
    return nil
end

--- 3D 距离计算
---@param a table|nil {X, Y, Z}
---@param b table|nil {X, Y, Z}
---@return number math.huge if either nil
function M.vector_distance(a, b)
    if a == nil or b == nil then
        return math.huge
    end
    local dx = (a.X or 0) - (b.X or 0)
    local dy = (a.Y or 0) - (b.Y or 0)
    local dz = (a.Z or 0) - (b.Z or 0)
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

--- 获取当前武器稳定标识（内存地址字符串，换枪检测用）
--- 从 _G.__sh2_equipped_weapon 全局缓存读取，返回 tostring(addr) 保证类型稳定
---@return string|nil
function M.get_current_weapon_key()
    local weapon = rawget(_G, "__sh2_equipped_weapon")
    if weapon == nil then
        return nil
    end
    local addr = nil
    pcall(function()
        addr = weapon:get_address()
    end)
    if addr == nil then
        return nil
    end
    return tostring(addr)
end

--- 组件显示名（调试用，返回 full_name 或 "<invalid>"）
---@param comp userdata|nil
---@return string
local function component_display_name(comp)
    if comp == nil then
        return "<nil>"
    end
    local ok, name = pcall(function()
        return comp:get_full_name()
    end)
    return ok and name or "<unreadable>"
end

--- 解析左手世界坐标（多源降级）
--- 依次尝试：MotionControllerScene → cached → createController后 → hand组件 → IK mesh → 左手grip附件
--- 比单源 controllers.getControllerLocation 更健壮，某些 hands_type 下直接取 controller 会失败
---@return table sources 诊断详情
---@return table|nil best_loc {X, Y, Z}
---@return string|nil best_source 命中的源名
---@return string|nil err 全部失败时的错误信息
function M.resolve_left_hand_world_sources()
    local sources = {}
    local best_loc = nil
    local best_source = nil

    local function set_best(loc, source_id)
        if loc ~= nil and best_loc == nil then
            best_loc = loc
            best_source = source_id
        end
    end

    local ok_c, controllers_mod = pcall(require, "libs/controllers")
    if not ok_c or controllers_mod == nil then
        return sources, nil, nil, "controllers_module_unavailable"
    end

    local Handed = rawget(_G, "Handed") or { Left = 0, Right = 1 }

    local mc_scene = controllers_mod.getController(Handed.Left, false)
    local scene_loc = nil
    if mc_scene ~= nil then
        local ok_loc, loc = pcall(function()
            return mc_scene:K2_GetComponentLocation()
        end)
        scene_loc = ok_loc and loc or nil
        sources.motion_controller_scene = {
            loc = scene_loc,
            component = component_display_name(mc_scene),
            err = scene_loc == nil and "K2_GetComponentLocation failed" or nil,
        }
    else
        sources.motion_controller_scene = {
            loc = nil,
            err = "getController(Left,false) nil",
        }
    end
    set_best(scene_loc, "motion_controller_scene")

    local cached_loc = controllers_mod.getControllerLocation(Handed.Left)
    sources.motion_controller_cached = {
        loc = cached_loc,
        err = cached_loc == nil and "getControllerLocation nil (actors cache)" or nil,
    }
    set_best(cached_loc, "motion_controller_cached")

    if scene_loc == nil and cached_loc == nil then
        pcall(function()
            controllers_mod.createController(Handed.Left)
        end)
        local after_cached = controllers_mod.getControllerLocation(Handed.Left)
        sources.motion_controller_after_create = {
            loc = after_cached,
            err = after_cached == nil and "createController后仍为nil" or nil,
        }
        set_best(after_cached, "motion_controller_after_create")

        local mc_after = controllers_mod.getController(Handed.Left, false)
        if mc_after ~= nil then
            local ok_loc, loc = pcall(function()
                return mc_after:K2_GetComponentLocation()
            end)
            sources.motion_controller_after_create_scene = {
                loc = ok_loc and loc or nil,
                component = component_display_name(mc_after),
            }
            set_best(ok_loc and loc or nil, "motion_controller_after_create_scene")
        end
    end

    local ok_h, hands_mod = pcall(require, "libs/hands")
    if ok_h and hands_mod and hands_mod.getHandComponent then
        local hand_comp = hands_mod.getHandComponent(Handed.Left)
        local hand_loc = hand_comp and M.get_component_world_location(hand_comp) or nil
        sources.forearms_hand = {
            loc = hand_loc,
            component = component_display_name(hand_comp),
            err = hand_comp == nil and "getHandComponent nil" or (hand_loc == nil and "no location" or nil),
        }
        set_best(hand_loc, "forearms_hand")
    end

    local ok_ik, ik_mod = pcall(require, "libs/ik")
    if ok_ik and ik_mod and ik_mod.getCurrentMesh then
        local ik_mesh = ik_mod.getCurrentMesh()
        local ik_loc = ik_mesh and M.get_component_world_location(ik_mesh) or nil
        sources.ik_mesh = {
            loc = ik_loc,
            component = component_display_name(ik_mesh),
            err = ik_mesh == nil and "getCurrentMesh nil" or nil,
        }
    end

    local ok_a, attachments_mod = pcall(require, "libs/attachments")
    if ok_a and attachments_mod and attachments_mod.getCurrentGrippedAttachment then
        local gripped = attachments_mod.getCurrentGrippedAttachment(Handed.Left)
        local gripped_loc = gripped and M.get_component_world_location(gripped) or nil
        sources.left_gripped_attachment = {
            loc = gripped_loc,
            component = component_display_name(gripped),
            err = gripped == nil and "none" or nil,
        }
    end

    local err = best_loc == nil and "no_left_hand_position_source" or nil
    return sources, best_loc, best_source, err
end

--- 便捷：直接返回左手世界坐标（多源降级后）
---@return table|nil {X, Y, Z}
---@return string|nil source
---@return string|nil err
function M.get_left_hand_world_location()
    local _, loc, source, err = M.resolve_left_hand_world_sources()
    return loc, source, err
end

---------------------------------------------------------------------------
-- Combat chain resolution（从 reload_diagnose.lua 迁移）
---------------------------------------------------------------------------

local SHRangedCmbSubcomp_c = uevrUtils.find_required_object("Class /Script/SHProto.SHRangedCmbSubcomp")
local SHWeaponManageCmbSubcomp_c = uevrUtils.find_required_object("Class /Script/SHProto.SHWeaponManageCmbSubcomp")
local SHAnimCombatSubcomp_c = uevrUtils.find_required_object("Class /Script/SHProto.SHAnimCombatSubcomp")

--- 解析战斗组件链：pawn → Combat → ranged / weapon_manage / animation → equipped_weapon
---@param pawn userdata|nil
---@return table { pawn, combat, ranged, weapon_manage, equipped_weapon, weapon_mesh, animation, anim_combat, ranged_reload }
function M.resolve_combat_chain(pawn)
    local result = {
        pawn = pawn,
        combat = nil,
        ranged = nil,
        weapon_manage = nil,
        equipped_weapon = nil,
        weapon_mesh = nil,
        animation = nil,
        anim_combat = nil,
        ranged_reload = nil,
    }
    if pawn == nil then
        return result
    end
    result.combat = uevrUtils.getValid(pawn, {"Combat"})
    result.animation = uevrUtils.getValid(pawn, {"Animation"})
    result.equipped_weapon = uevrUtils.getValid(pawn, {"Mesh", "AnimScriptInstance", "WeaponManageCmbSubcomp", "EquippedWeapon"})
    result.weapon_mesh = uevrUtils.getValid(result.equipped_weapon, {"Mesh"})
    if result.combat ~= nil and SHRangedCmbSubcomp_c ~= nil then
        pcall(function()
            result.ranged = result.combat:FindSubcomponentByClass(SHRangedCmbSubcomp_c)
        end)
    end
    if result.combat ~= nil and SHWeaponManageCmbSubcomp_c ~= nil then
        pcall(function()
            result.weapon_manage = result.combat:FindSubcomponentByClass(SHWeaponManageCmbSubcomp_c)
        end)
    end
    if result.animation ~= nil and SHAnimCombatSubcomp_c ~= nil then
        pcall(function()
            result.anim_combat = result.animation:FindSubcomponentByClass(SHAnimCombatSubcomp_c)
            if result.anim_combat ~= nil then
                result.ranged_reload = result.anim_combat.RangedReload
            end
        end)
    end
    if result.ranged ~= nil and result.equipped_weapon == nil then
        pcall(function()
            result.equipped_weapon = result.ranged:GetEquippedRangedWeapon()
        end)
        result.weapon_mesh = uevrUtils.getValid(result.equipped_weapon, {"Mesh"})
    end
    return result
end

--- 暴露类对象给上层模块使用
M.SHRangedCmbSubcomp_c = SHRangedCmbSubcomp_c
M.SHWeaponManageCmbSubcomp_c = SHWeaponManageCmbSubcomp_c
M.SHAnimCombatSubcomp_c = SHAnimCombatSubcomp_c

---------------------------------------------------------------------------
-- 弹药直接内存控制（CE 反编译发现的偏移量）
-- 每种枪械一张偏移表（WEAPON_PROFILES）；pistol 已填入 CE 验证过的值。
-- shotgun / rifle 待 CE 分析后补充同结构偏移表。
---------------------------------------------------------------------------

local AMMO_CTRL_TAG = "AMMO_CTRL"

-- 武器弹药偏移表（profile）
-- 每个 profile 对应一种武器类型，包含读取/写入弹药所需的全部偏移
-- 上层通过 reload_tools.WEAPON_PROFILES.<type> 获取并传入各 ammo 函数
local WEAPON_PROFILES = {
    -- 2026-09-22：备弹改走 USHCharacterPlayItemsComponent:GetItemCount(WeaponAmmoItem.RowName)，
    -- 以下 reserve_* 常量全部停用（保留备查，勿删）：
    --   reserve_object / reserve_array_ptr / reserve_entry_stride / reserve_value / reserve_entry_index
    --   停用原因：CollectedItems 是 TArray，元素顺序 = 插入顺序，换存档/装模组必漂；
    --   且 Lua 侧「pawn 当窗口」读组件内部时 delta 常达数 GB，超 int32 被截断（array 恒为 0x0）。
    pistol = {
        clip_ammo            = 0xBB4,   -- ASHItemWeaponRanged + 0xBB4 (mov [rcx+0xBB4], edx)
        clip_size            = 0x06A8,  -- ASHItemWeaponRanged + 0x06A8 (WeaponClipSize)
        -- reserve_object       = 0x6C0,   -- 【停用】pawn+0x6C0 指向备弹对象
        -- reserve_array_ptr    = 0x110,   -- 【停用】备弹对象+0x110 指向数组
        -- reserve_entry_stride = 0x0C,    -- 【停用】数组元素大小 12 字节
        -- reserve_value        = 0x08,    -- 【停用】每个元素的 value 在 +08 处
        -- reserve_entry_index  = 8,       -- 【停用】备弹在数组的第 8 个元素（旧值 4 作废）
    },
    -- shotgun：路径同手枪；reserve_entry_index 由 CE 于 exe+2ACC09A 确认（(r10-array)/0x0C）
    shotgun = {
        clip_ammo            = 0xBB4,   -- 可读不可写入
        clip_size            = 0x06A8,  -- 运行时确认 = 6
        -- reserve_object       = 0x6C0,   -- 【停用 2026-09-22】
        -- reserve_array_ptr    = 0x110,   -- 【停用 2026-09-22】
        -- reserve_entry_stride = 0x0C,    -- 【停用 2026-09-22】
        -- reserve_value        = 0x08,    -- 【停用 2026-09-22】
        -- reserve_entry_index  = 29,      -- 【停用 2026-09-22】旧值 9 作废
    },
    -- rifle：同基类 ASHItemWeaponRangedSingleAction，偏移同霰弹枪（SDK notes §3.4）
    -- reserve_entry_index=14 为占位符，需 CE 反编译确认
    rifle = {
        clip_ammo            = 0xBB4,   -- 同霰弹枪（ASHItemWeaponRanged + 0xBB4）
        clip_size            = 0x06A8,  -- WeaponClipSize（~4，runtime 确认）
        -- reserve_object       = 0x6C0,   -- 【停用 2026-09-22】
        -- reserve_array_ptr    = 0x110,   -- 【停用 2026-09-22】
        -- reserve_entry_stride = 0x0C,    -- 【停用 2026-09-22】
        -- reserve_value        = 0x08,    -- 【停用 2026-09-22】
        -- reserve_entry_index  = 61,      -- 【停用 2026-09-22】旧占位 7 作废
    },
}

-- 根据当前武器类型（_G.__sh2_current_weapon_type）返回对应 profile
-- 未知/未支持武器回退到 pistol profile
local function get_active_offsets()
    local wt = rawget(_G, "__sh2_current_weapon_type") or "none"
    return WEAPON_PROFILES[wt] or WEAPON_PROFILES.pistol
end

local function safe_tostring(value)
    if value == nil then
        return "nil"
    end
    local ok, text = pcall(function()
        return tostring(value)
    end)
    return ok and text or "<unreadable>"
end

--- 获取当前装备的武器对象（用于弹药控制）
-- 从 _G.__sh2_equipped_weapon 全局缓存读取（由 main.lua ~200ms 发布）
-- 不再实时调用 resolve_combat_chain；换枪时上层 reload 状态全部清零，数据不会写入旧武器
---@return userdata|nil weapon
---@return userdata|nil ranged  -- 目前恒为 nil，保持三返回值签名兼容
---@return userdata|nil pawn
function M.get_equipped_weapon()
    local weapon = rawget(_G, "__sh2_equipped_weapon")
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    local ranged = nil
    return weapon, ranged, pawn
end

--- 读取弹夹弹药数量（当前装备武器）
---@param weapon userdata
---@param offsets table WEAPON_PROFILES.<type>
---@return number|nil
function M.read_clip_ammo(weapon, offsets)
    if weapon == nil then return nil end
    local off = offsets or WEAPON_PROFILES.pistol
    local ok, val = pcall(function() return weapon:read_dword(off.clip_ammo) end)
    return ok and val or nil
end

--- 读取弹夹容量（当前装备武器）
---@param weapon userdata
---@param offsets table WEAPON_PROFILES.<type>
---@return number|nil
function M.read_clip_size(weapon, offsets)
    if weapon == nil then return nil end
    local off = offsets or WEAPON_PROFILES.pistol
    local ok, val = pcall(function() return weapon:read_dword(off.clip_size) end)
    return ok and val or nil
end

---------------------------------------------------------------------------
-- 备弹读写（2026-09-22 定案）
--   读：USHCharacterPlayItemsComponent:GetItemCount( weapon.WeaponAmmoItem.RowName )
--   写：游戏无 SetItemCount，只能按增量 CollectItem(+) / RemoveItem(-)
--   RowName 每次从 weapon 对象现场读，不存任何常量
--     ⇒ 零偏移、零 index、跨存档 / 跨机器 / 装模组全通用
--   实测三把枪 RowName：HandgunAmmo / ShotgunAmmo / RifleAmmo
--   已知现象：改完 HUD 不会立即刷新，要等下次 UI 重绘（如再次瞄准）才显示新值；账务本身正确
---------------------------------------------------------------------------

local bridge_log  -- forward: 定义在下方的 SH2 桥接段（备弹写入复核日志要用）

local function reserve_fname_to_string(value)
    if value == nil then return nil end
    local ok, text = pcall(function()
        if type(value.to_string) == "function" then return value:to_string() end
        return tostring(value)
    end)
    if ok then return text end
    return nil
end

-- pawn → USHCharacterPlayItemsComponent
local function get_items_component(pawn)
    if pawn == nil then return nil end
    local comp = nil
    pcall(function() comp = uevrUtils.getValid(pawn, {"Items"}) end)
    return comp
end

-- weapon → WeaponAmmoItem.RowName（FDataTableRowHandle，与门锁 UnlockItem 同构）
local function get_ammo_row_name(weapon)
    if weapon == nil then return nil end
    local name = nil
    pcall(function()
        local handle = weapon["WeaponAmmoItem"]
        if handle ~= nil then
            name = reserve_fname_to_string(handle.RowName)
        end
    end)
    return name
end

--- 取备弹操作三件套：组件 / FName / 行名字符串
---@return userdata|nil comp
---@return userdata|nil fname_obj
---@return string|nil row_str
---@return string|nil error
function M.reserve_binding(weapon, pawn)
    if weapon == nil then
        return nil, nil, nil, "weapon=nil（未装备枪械，或近战武器没有弹药行）"
    end
    if pawn == nil then
        return nil, nil, nil, "pawn=nil"
    end
    local row_str = get_ammo_row_name(weapon)
    if row_str == nil or row_str == "" or row_str == "None" then
        return nil, nil, nil, "WeaponAmmoItem.RowName 不可读"
    end
    local comp = get_items_component(pawn)
    if comp == nil then
        return nil, nil, nil, "pawn.Items=nil"
    end
    local fname_obj = nil
    pcall(function() fname_obj = uevrUtils.fname_from_string(row_str) end)
    if fname_obj == nil then
        return nil, nil, nil, "fname_from_string failed"
    end
    return comp, fname_obj, row_str, nil
end

local reserve_binding = M.reserve_binding

--- 读取备弹数量（游戏组件函数，RowName 现场匹配）
---@param pawn userdata 可为 nil（自动取本地 pawn）
---@param offsets table 【已停用】仅为兼容旧调用签名保留
---@return number|nil ammo_count
---@return string|nil error
function M.read_reserve_ammo(pawn, offsets)
    local weapon, _, local_pawn = M.get_equipped_weapon()
    local p = pawn or local_pawn
    local comp, fname_obj, row_str, err = reserve_binding(weapon, p)
    if comp == nil then
        return nil, err
    end
    local count = nil
    local ok = pcall(function() count = comp:GetItemCount(fname_obj) end)
    if not ok or count == nil then
        return nil, string.format("GetItemCount(%s) failed", tostring(row_str))
    end
    return tonumber(count)
end

--[==[ 旧实现（裸内存 + 硬编码 index，2026-09-22 停用，保留备查，勿删）
function M.read_reserve_ammo(pawn, offsets)
    if pawn == nil then return nil, "pawn=nil" end
    local off = offsets or WEAPON_PROFILES.pistol
    local ok_base, base = pcall(function() return pawn:get_address() end)
    if not ok_base or base == nil or base == 0 then
        return nil, "pawn:get_address() failed"
    end
    local ok1, reserve_obj = pcall(function() return pawn:read_qword(off.reserve_object) end)
    if not ok1 or reserve_obj == nil or reserve_obj == 0 then
        return nil, "pawn+reserve_object read failed"
    end
    local delta2 = reserve_obj - base + off.reserve_array_ptr
    local ok2, array_ptr = pcall(function() return pawn:read_qword(delta2) end)
    if not ok2 or array_ptr == nil or array_ptr == 0 then
        return nil, string.format("reserve_obj+reserve_array_ptr read failed (delta2=0x%X)", delta2)
    end
    local delta3 = array_ptr - base + off.reserve_entry_index * off.reserve_entry_stride + off.reserve_value
    local ok3, ammo_count = pcall(function() return pawn:read_dword(delta3) end)
    if not ok3 or ammo_count == nil then
        return nil, string.format("array+entry read failed (delta3=0x%X)", delta3)
    end
    return ammo_count
end
]==]

--- 写入备弹数量（设为目标值；游戏无 SetItemCount，内部按增量 Collect/Remove）
---@param pawn userdata 可为 nil（自动取本地 pawn）
---@param value number 目标备弹数
---@param offsets table 【已停用】仅为兼容旧调用签名保留
---@return boolean ok
---@return string|nil error
function M.write_reserve_ammo(pawn, value, offsets)
    local weapon, _, local_pawn = M.get_equipped_weapon()
    local p = pawn or local_pawn
    local comp, fname_obj, row_str, err = reserve_binding(weapon, p)
    if comp == nil then
        return false, err
    end

    local target = math.floor(tonumber(value) or 0)
    if target < 0 then target = 0 end

    local cur = nil
    pcall(function() cur = comp:GetItemCount(fname_obj) end)
    if cur == nil then
        return false, string.format("GetItemCount(%s) failed", tostring(row_str))
    end

    local delta = target - tonumber(cur)
    if delta == 0 then
        return true, nil
    end

    if delta > 0 then
        local ok = pcall(function() comp:CollectItem(fname_obj, delta, false) end)
        if not ok then
            return false, string.format("CollectItem(%s, +%d) failed", tostring(row_str), delta)
        end
    else
        local amount = -delta
        local ok = pcall(function() comp:RemoveItem(fname_obj, amount, false) end)
        if not ok then
            return false, string.format("RemoveItem(%s, -%d) failed", tostring(row_str), amount)
        end
    end

    -- 复核
    local after = nil
    pcall(function() after = comp:GetItemCount(fname_obj) end)
    bridge_log(AMMO_CTRL_TAG, string.format(
        "reserve write %s: %s -> %s (target %d)",
        tostring(row_str), tostring(cur), tostring(after), target
    ))
    return true, nil
end

--[==[ 旧实现（裸内存 + 硬编码 index，2026-09-22 停用，保留备查，勿删）
function M.write_reserve_ammo(pawn, value, offsets)
    if pawn == nil then return false, "pawn=nil" end
    local off = offsets or WEAPON_PROFILES.pistol
    local ok_base, base = pcall(function() return pawn:get_address() end)
    if not ok_base or base == nil or base == 0 then
        return false, "pawn:get_address() failed"
    end
    local ok1, reserve_obj = pcall(function() return pawn:read_qword(off.reserve_object) end)
    if not ok1 or reserve_obj == nil or reserve_obj == 0 then
        return false, "pawn+reserve_object read failed"
    end
    local delta2 = reserve_obj - base + off.reserve_array_ptr
    local ok2, array_ptr = pcall(function() return pawn:read_qword(delta2) end)
    if not ok2 or array_ptr == nil or array_ptr == 0 then
        return false, string.format("reserve_obj+reserve_array_ptr read failed (delta2=0x%X)", delta2)
    end
    local delta3 = array_ptr - base + off.reserve_entry_index * off.reserve_entry_stride + off.reserve_value
    local ok3, err3 = pcall(function() pawn:write_dword(delta3, value) end)
    if not ok3 then
        return false, string.format("array+entry write failed (delta3=0x%X): %s", delta3, tostring(err3))
    end
    return true
end
]==]

---------------------------------------------------------------------------
-- SH2.dll 备弹桥接（plugins/SH2.dll）
-- 仅 custom_event 双向通信（同 TrueGear 模式，无 Lua C API）：
--   Lua -> C++: dispatch_custom_event("sh2:<cmd>", json_body)
--   C++ -> Lua: on_lua_event("sh2:ready" | "sh2:result", json_body)
-- DLL 命令：
--   probe / set_clip_native（weapon_addr + value，调用 exe+2B22CF0）
--   【2026-09-22 弃用】get_reserve_ammo / set_reserve_ammo（pawn_addr + entry_index）
--     备弹改走 Lua 侧 USHCharacterPlayItemsComponent:GetItemCount / CollectItem / RemoveItem，
--     按 weapon.WeaponAmmoItem.RowName 现场匹配，不再依赖 index（换存档/装模组必漂）。
-- 弹夹读取/容量读取/weapon 解析：Lua；弹夹持久写入：DLL 原生函数；备弹读写：Lua 组件函数（不再走 DLL）
---------------------------------------------------------------------------

local SH2_AMMO_LOG = "SH2_AMMO"

-- 独立弹药日志：直接写 ammo_ctrl.log（不再依赖外部 log_fn 回调）
-- 开关：false = 关闭 ammo_ctrl.log 写入
local SH2_BRIDGE_LOG_ENABLED = false

-- 上方已有 forward 声明，此处必须是赋值形式（否则备弹段引用不到）
bridge_log = function(tag, message, force)
    if not SH2_BRIDGE_LOG_ENABLED then
        return
    end
    pcall(function()
        local f = io.open("ammo_ctrl.log", "ab")
        if f ~= nil then
            f:write(os.date("%Y-%m-%d %H:%M:%S") .. " [" .. tag .. "] " .. tostring(message) .. "\n")
            f:close()
        end
    end)
end

local function sh2_write_log(message)
    bridge_log(SH2_AMMO_LOG, message)
end

local sh2_dispatch_queue = {}
local sh2_dispatch_in_flight = false
local sh2_last_reserve_poll = 0
local SH2_RESERVE_AUTO_POLL_SEC = 2.0

local function sh2_dispatch_pump()
    if sh2_dispatch_in_flight then
        return
    end
    if #sh2_dispatch_queue == 0 then
        return
    end
    if uevr == nil or uevr.api == nil or uevr.api.dispatch_custom_event == nil then
        M.sh2_state().lastError = "uevr.api.dispatch_custom_event unavailable"
        return
    end

    local op = table.remove(sh2_dispatch_queue, 1)
    local st = M.sh2_state()
    local event_name = "sh2:" .. tostring(op.cmd)
    st.pendingCmd = op.cmd
    st.lastCmd = op.cmd
    st.lastSent = event_name
    st.sentCount = (st.sentCount or 0) + 1
    sh2_dispatch_in_flight = true
    uevr.api:dispatch_custom_event(event_name, op.body)
    sh2_write_log("SENT " .. event_name .. " body=" .. op.body)
end

local function sh2_dispatch_finish()
    sh2_dispatch_in_flight = false
    sh2_dispatch_pump()
end

--- 获取 SH2 桥接状态表（单例，存储在 _G）
function M.sh2_state()
    local st = rawget(_G, "__SH2_AMMO_BRIDGE_STATE")
    if type(st) ~= "table" then
        st = {
            ready = false,
            sentCount = 0,
            recvCount = 0,
            lastSent = nil,
            lastRecv = nil,
            lastCmd = nil,
            pendingCmd = nil,
            lastResultText = nil,
            lastError = nil,
            reserveAmmo = nil,
            clipAmmo = nil,
            pendingClipAction = nil,
            pendingAction = nil,
            pendingPawnAddr = nil,
            pendingOffsets = nil,
            magEjectClipBefore = nil,
            magEjectMoved = nil,
            magEjectReserveBefore = nil,
            magEjectReserveAfter = nil,
            magEjectOffsets = nil,
            magInsertClipBefore = nil,
            magInsertClipSize = nil,
            magInsertReserveBefore = nil,
            magInsertReserveAfter = nil,
            magInsertRoundsAdded = nil,
            magInsertDeferClipFill = nil,
            magInsertOffsets = nil,
            shellInsertQueue = nil,
            shellInsertClipBefore = nil,
            shellInsertClipSize = nil,
            shellInsertReserveBefore = nil,
            shellInsertReserveAfter = nil,
            shellInsertOffsets = nil,
        }
        _G.__SH2_AMMO_BRIDGE_STATE = st
    end
    return st
end

local function sh2_parse_result(text)
    if json and type(json.load_string) == "function" then
        local ok, parsed = pcall(json.load_string, text or "")
        if ok and type(parsed) == "table" then
            return parsed
        end
    end
    local body = tostring(text or "")
    if body == "" then
        return nil
    end
    local result = {}
    if body:find('"ok"%s*:%s*true') then
        result.ok = true
    elseif body:find('"ok"%s*:%s*false') then
        result.ok = false
    end
    local count = body:match('"count"%s*:%s*(-?%d+)')
    if count ~= nil then
        result.count = tonumber(count)
    end
    local verified = body:match('"verified"%s*:%s*(-?%d+)')
    if verified ~= nil then
        result.verified = tonumber(verified)
    end
    local err = body:match('"error"%s*:%s*"([^"]*)"')
    if err ~= nil then
        result.error = err
    end
    local probe = body:match('"probe"%s*:%s*"([^"]*)"')
    if probe ~= nil then
        result.probe = probe
    end
    local weapon_addr = body:match('"weapon_addr"%s*:%s*(%d+)')
    if weapon_addr ~= nil then
        result.weapon_addr = tonumber(weapon_addr)
    end
    -- §17: block_unequip 结果字段
    local enabled = body:match('"enabled"%s*:%s*(%d+)')
    if enabled ~= nil then
        result.enabled = (tonumber(enabled) ~= 0)
    end
    local hook_id = body:match('"hook_id"%s*:%s*(%d+)')
    if hook_id ~= nil then
        result.hook_id = tonumber(hook_id)
    end
    local hits = body:match('"hits"%s*:%s*(%d+)')
    if hits ~= nil then
        result.hits = tonumber(hits)
    end
    return result
end

local function sh2_body_for_weapon_set(weapon_addr, value, offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    -- 携带 clip_ammo 偏移供 C++ 验证读取;C++ 收不到时回退 DEFAULT_WEAPON_CLIP_AMMO_OFFSET
    return string.format(
        '{"weapon_addr":%s,"value":%d,"clip_ammo":%d}',
        tostring(weapon_addr), math.floor(tonumber(value) or 0), math.floor(tonumber(off.clip_ammo) or 0)
    )
end

-- 备弹读/写 JSON body:携带当前武器的 reserve offsets,pistol/shotgun/rifle 各自的偏移由调用者传入
-- C++ 端收到缺失字段会回退到 DEFAULT_* 常量(pistol),保证旧版 DLL 兼容
-- 【2026-09-22 弃用】备弹已改走 Lua 侧 Items:GetItemCount / CollectItem / RemoveItem，
-- 这两个 DLL body 构造不再被调用（保留备查）。DLL 仅保留弹夹写入 set_clip_native。
local function sh2_body_for_reserve(pawn_addr, offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    return string.format(
        '{"pawn_addr":%s,"reserve_object":%d,"reserve_array_ptr":%d,"reserve_entry_stride":%d,"reserve_value":%d,"reserve_entry_index":%d}',
        tostring(pawn_addr),
        math.floor(tonumber(off.reserve_object) or 0),
        math.floor(tonumber(off.reserve_array_ptr) or 0),
        math.floor(tonumber(off.reserve_entry_stride) or 0),
        math.floor(tonumber(off.reserve_value) or 0),
        math.floor(tonumber(off.reserve_entry_index) or 0)
    )
end

local function sh2_body_for_reserve_set(pawn_addr, value, offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    return string.format(
        '{"pawn_addr":%s,"value":%d,"reserve_object":%d,"reserve_array_ptr":%d,"reserve_entry_stride":%d,"reserve_value":%d,"reserve_entry_index":%d}',
        tostring(pawn_addr), math.floor(tonumber(value) or 0),
        math.floor(tonumber(off.reserve_object) or 0),
        math.floor(tonumber(off.reserve_array_ptr) or 0),
        math.floor(tonumber(off.reserve_entry_stride) or 0),
        math.floor(tonumber(off.reserve_value) or 0),
        math.floor(tonumber(off.reserve_entry_index) or 0)
    )
end

local function sh2_dispatch(cmd, json_body)
    if uevr == nil or uevr.api == nil or uevr.api.dispatch_custom_event == nil then
        M.sh2_state().lastError = "uevr.api.dispatch_custom_event unavailable"
        return false, M.sh2_state().lastError
    end
    sh2_dispatch_queue[#sh2_dispatch_queue + 1] = {
        cmd = cmd,
        body = json_body or "{}",
    }
    sh2_dispatch_pump()
    return true, nil
end

--- 写入弹夹弹药数量（经 SH2.dll 调用 exe+2B22CF0 SetClipAmmo）
---@param weapon userdata
---@param value number
---@param offsets table WEAPON_PROFILES.<type>
---@return boolean ok
---@return string|nil err
function M.write_clip_ammo(weapon, value, offsets)
    if weapon == nil then return false, "weapon=nil" end
    local off = offsets or WEAPON_PROFILES.pistol

    local ok_addr, weapon_addr = pcall(function() return weapon:get_address() end)
    if not ok_addr or weapon_addr == nil or weapon_addr == 0 then
        return false, "weapon:get_address() failed"
    end

    local clip_size = M.read_clip_size(weapon, off) or 10
    local before = M.read_clip_ammo(weapon, off)
    local target = math.floor(tonumber(value) or 0)
    if target < 0 then target = 0 end
    if target > clip_size then target = clip_size end

    bridge_log(AMMO_CTRL_TAG, string.format(
        "SetClipAmmo request: weapon=0x%X before=%s target=%d cap=%d",
        weapon_addr, safe_tostring(before), target, clip_size
    ))

    local ok_dispatch, dispatch_err = sh2_dispatch(
        "set_clip_native",
        sh2_body_for_weapon_set(weapon_addr, target, off)
    )
    if not ok_dispatch then
        return false, dispatch_err
    end

    return true, nil
end

local function write_clip_ammo(weapon, value, offsets)
    return M.write_clip_ammo(weapon, value, offsets)
end

local function sh2_get_pawn_addr()
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    if pawn == nil or pawn.get_address == nil then
        return nil, "pawn=nil"
    end
    local ok, addr = pcall(function() return pawn:get_address() end)
    if not ok or addr == nil then
        return nil, "pawn:get_address() failed"
    end
    return addr, nil
end

--- 通过 SH2.dll 读取备弹（需传入对应武器 profile 的 offsets 以确定 entry_index）
---@param offsets table WEAPON_PROFILES.<type>
---@return boolean ok
---@return string|nil err
function M.sh2_read_reserve(offsets)
    local st = M.sh2_state()
    local off = offsets or WEAPON_PROFILES.pistol
    local count, err = M.read_reserve_ammo(nil, off)
    if count == nil then
        st.lastError = err
        return false, err
    end
    st.reserveAmmo = count
    st.lastError = nil
    return true, nil
end

local sh2_handle_mag_reserve_result  -- forward: 定义在下方

-- 备弹读取已同步化（2026-09-22）：不再 dispatch 给 DLL，读完后就地驱动状态机
local function sh2_begin_reserve_read(pawn_addr, pending_action, offsets)
    local st = M.sh2_state()
    local off = offsets or WEAPON_PROFILES.pistol
    st.pendingAction = pending_action
    st.pendingPawnAddr = pawn_addr
    st.pendingOffsets = off
    local count, err = M.read_reserve_ammo(nil, off)
    if count == nil then
        sh2_handle_mag_reserve_result(st, { ok = false, error = err or "reserve read failed" }, "get_reserve_ammo")
        return false, err
    end
    sh2_handle_mag_reserve_result(st, { ok = true, count = count }, "get_reserve_ammo")
    return true, nil
end

-- 备弹写入已同步化：Collect/Remove 后就地驱动状态机的 *_set 分支（DLL 只保留弹夹写入）
local function sh2_set_reserve_sync(pawn_addr, value, offsets)
    local st = M.sh2_state()
    local ok, err = M.write_reserve_ammo(nil, value, offsets)
    if ok then
        sh2_handle_mag_reserve_result(st, { ok = true, count = value, verified = value }, "set_reserve_ammo")
    else
        sh2_handle_mag_reserve_result(st, { ok = false, error = err or "reserve write failed" }, "set_reserve_ammo")
    end
    return ok, err
end

local function sh2_clear_mag_reserve_pending(st)
    st.pendingAction = nil
    st.pendingPawnAddr = nil
    st.magEjectClipBefore = nil
    st.magEjectMoved = nil
    st.magEjectReserveBefore = nil
    st.magEjectReserveAfter = nil
    st.magEjectOffsets = nil
    st.magInsertClipBefore = nil
    st.magInsertClipSize = nil
    st.magInsertReserveBefore = nil
    st.magInsertReserveAfter = nil
    st.magInsertRoundsAdded = nil
    st.magInsertDeferClipFill = nil
    st.magInsertOffsets = nil
    st.shellInsertClipBefore = nil
    st.shellInsertClipSize = nil
    st.shellInsertReserveBefore = nil
    st.shellInsertReserveAfter = nil
    st.shellInsertOffsets = nil
end

--- 霰弹枪单发入仓：先扣备弹，完成后再 SetClipAmmo（HUD 才能立刻看到备弹减少）
local function shell_insert_busy(st)
    local pending = st.pendingAction
    return pending == "shell_insert_reserve" or pending == "shell_insert_reserve_set"
end

local function shell_insert_start_next(st)
    if shell_insert_busy(st) then
        return
    end
    local queue = st.shellInsertQueue
    if type(queue) ~= "table" or #queue == 0 then
        return
    end
    local job = table.remove(queue, 1)
    local off = (job and job.offsets) or WEAPON_PROFILES.shotgun
    local weapon, _, pawn = M.get_equipped_weapon()
    if weapon == nil or pawn == nil then
        bridge_log(AMMO_CTRL_TAG, "Shell insert: weapon/pawn=nil, drop remaining queue")
        st.shellInsertQueue = {}
        return
    end
    local clip_before = M.read_clip_ammo(weapon, off)
    local clip_size = M.read_clip_size(weapon, off)
    if clip_before == nil or clip_size == nil then
        bridge_log(AMMO_CTRL_TAG, "Shell insert: read clip failed, drop job")
        shell_insert_start_next(st)
        return
    end
    if clip_before >= clip_size then
        bridge_log(AMMO_CTRL_TAG, string.format(
            "Shell insert skipped: clip full (%d/%d)", clip_before, clip_size
        ))
        shell_insert_start_next(st)
        return
    end
    local ok_addr, pawn_addr = pcall(function() return pawn:get_address() end)
    if not ok_addr or pawn_addr == nil then
        bridge_log(AMMO_CTRL_TAG, "Shell insert: pawn:get_address() failed")
        st.shellInsertQueue = {}
        return
    end
    st.shellInsertClipBefore = clip_before
    st.shellInsertClipSize = clip_size
    st.shellInsertOffsets = off
    st.pendingOffsets = off
    sh2_write_log(string.format(
        "===== Shell insert: clip=%d/%d, reserve-1 then SetClipAmmo =====",
        clip_before, clip_size
    ))
    sh2_begin_reserve_read(pawn_addr, "shell_insert_reserve", off)
end

-- 注意：上方已有 forward 声明，此处必须是赋值形式（若写 local function 会遮蔽 upvalue 导致同步调用拿到 nil）
sh2_handle_mag_reserve_result = function(st, result, cmd)
    local pending = st.pendingAction

    if pending == "mag_eject_reserve" and cmd == "get_reserve_ammo" then
        if result.ok == true and result.count ~= nil then
            local pawn_addr = st.pendingPawnAddr
            local moved = st.magEjectMoved or 0
            local reserve_before = tonumber(result.count)
            local new_reserve = reserve_before + moved
            local off = st.magEjectOffsets or WEAPON_PROFILES.pistol
            st.pendingAction = "mag_eject_reserve_set"
            st.magEjectReserveBefore = reserve_before
            st.magEjectReserveAfter = new_reserve
            sh2_write_log(string.format(
                "mag_eject reserve read: %d, will write %d (+%d)",
                reserve_before, new_reserve, moved
            ))
            sh2_set_reserve_sync(pawn_addr, new_reserve, off)
        else
            sh2_clear_mag_reserve_pending(st)
            bridge_log(AMMO_CTRL_TAG, "Mag eject reserve read failed: " .. tostring(result.error or "unknown"))
        end
        return true
    end

    if pending == "mag_eject_reserve_set" and cmd == "set_reserve_ammo" then
        local moved = st.magEjectMoved or 0
        local reserve_before = st.magEjectReserveBefore
        local off = st.magEjectOffsets or WEAPON_PROFILES.pistol
        if result.ok == true then
            local reserve_after = result.verified or result.count or st.magEjectReserveAfter
            bridge_log(AMMO_CTRL_TAG, string.format(
                "Mag eject reserve: %s -> %s (moved %d)",
                safe_tostring(reserve_before), safe_tostring(reserve_after), moved
            ))
            M.queue_set_clip(1, "mag_eject", off)
        else
            bridge_log(AMMO_CTRL_TAG, "Mag eject reserve write failed: " .. tostring(result.error or "unknown"))
        end
        sh2_clear_mag_reserve_pending(st)
        return true
    end

    if pending == "mag_insert_reserve" and cmd == "get_reserve_ammo" then
        if result.ok == true and result.count ~= nil then
            local pawn_addr = st.pendingPawnAddr
            local clip_before = st.magInsertClipBefore or 0
            local clip_size = st.magInsertClipSize or 10
            local reserve_before = tonumber(result.count)
            local rounds_needed = clip_size - clip_before
            local rounds_to_add = math.min(rounds_needed, reserve_before)
            if rounds_to_add <= 0 then
                sh2_clear_mag_reserve_pending(st)
                bridge_log(AMMO_CTRL_TAG, string.format(
                    "Mag insert failed: need %d rounds, reserve=%d",
                    rounds_needed, reserve_before
                ))
                return true
            end
            local new_reserve = reserve_before - rounds_to_add
            local off = st.magInsertOffsets or WEAPON_PROFILES.pistol
            st.pendingAction = "mag_insert_reserve_set"
            st.magInsertReserveBefore = reserve_before
            st.magInsertReserveAfter = new_reserve
            st.magInsertRoundsAdded = rounds_to_add
            sh2_write_log(string.format(
                "mag_insert reserve read: %d, will write %d (-%d)",
                reserve_before, new_reserve, rounds_to_add
            ))
            sh2_set_reserve_sync(pawn_addr, new_reserve, off)
        else
            sh2_clear_mag_reserve_pending(st)
            bridge_log(AMMO_CTRL_TAG, "Mag insert reserve read failed: " .. tostring(result.error or "unknown"))
        end
        return true
    end

    if pending == "mag_insert_reserve_set" and cmd == "set_reserve_ammo" then
        if result.ok == true then
            local reserve_before = st.magInsertReserveBefore
            local reserve_after = result.verified or result.count or st.magInsertReserveAfter
            local rounds_to_add = st.magInsertRoundsAdded or 0
            local clip_before = st.magInsertClipBefore or 0
            local clip_size = st.magInsertClipSize or 10
            local defer_fill = st.magInsertDeferClipFill == true
            local off = st.magInsertOffsets or WEAPON_PROFILES.pistol
            local target_clip = clip_before + rounds_to_add
            st.magInsertTargetClip = target_clip
            bridge_log(AMMO_CTRL_TAG, string.format(
                "Mag insert reserve: %s -> %s (-%d); clip %d -> %d%s",
                safe_tostring(reserve_before), safe_tostring(reserve_after), rounds_to_add,
                clip_before, target_clip,
                defer_fill and " (fill deferred until rack)" or ""
            ))
            local rounds_needed = clip_size - clip_before
            if rounds_to_add < rounds_needed then
                bridge_log(AMMO_CTRL_TAG, string.format(
                    "Mag insert partial: wanted %d more rounds, only %d available in reserve",
                    rounds_needed, rounds_to_add
                ))
            end
            if defer_fill then
                bridge_log(AMMO_CTRL_TAG, "Mag insert: clip fill deferred until slide rack")
            else
                M.sh2_state().pendingClipAction = {
                    kind = "set",
                    value = target_clip,
                    source = "mag_insert",
                    offsets = off,
                }
                bridge_log(AMMO_CTRL_TAG, string.format(
                    "Clip set %d queued (post_engine_tick) source=mag_insert",
                    target_clip
                ))
            end
        else
            bridge_log(AMMO_CTRL_TAG, "Mag insert reserve write failed: " .. tostring(result.error or "unknown"))
        end
        sh2_clear_mag_reserve_pending(st)
        return true
    end

    -- 霰弹枪：入仓一发 = reserve-1 → 再 SetClipAmmo(clip+1)，保证 HUD 刷新时备弹已是新值
    if pending == "shell_insert_reserve" and cmd == "get_reserve_ammo" then
        if result.ok == true and result.count ~= nil then
            local pawn_addr = st.pendingPawnAddr
            local clip_before = st.shellInsertClipBefore or 0
            local clip_size = st.shellInsertClipSize or 6
            local reserve_before = tonumber(result.count)
            local off = st.shellInsertOffsets or WEAPON_PROFILES.shotgun
            if reserve_before <= 0 then
                bridge_log(AMMO_CTRL_TAG, string.format(
                    "Shell insert failed: reserve=%d clip=%d/%d",
                    reserve_before, clip_before, clip_size
                ))
                sh2_clear_mag_reserve_pending(st)
                shell_insert_start_next(st)
                return true
            end
            if clip_before >= clip_size then
                bridge_log(AMMO_CTRL_TAG, string.format(
                    "Shell insert failed: clip already full (%d/%d)",
                    clip_before, clip_size
                ))
                sh2_clear_mag_reserve_pending(st)
                shell_insert_start_next(st)
                return true
            end
            local new_reserve = reserve_before - 1
            st.pendingAction = "shell_insert_reserve_set"
            st.shellInsertReserveBefore = reserve_before
            st.shellInsertReserveAfter = new_reserve
            sh2_write_log(string.format(
                "shell_insert reserve read: %d, will write %d (-1); then clip %d -> %d",
                reserve_before, new_reserve, clip_before, clip_before + 1
            ))
            sh2_set_reserve_sync(pawn_addr, new_reserve, off)
        else
            bridge_log(AMMO_CTRL_TAG, "Shell insert reserve read failed: " .. tostring(result.error or "unknown"))
            sh2_clear_mag_reserve_pending(st)
            shell_insert_start_next(st)
        end
        return true
    end

    if pending == "shell_insert_reserve_set" and cmd == "set_reserve_ammo" then
        if result.ok == true then
            local reserve_before = st.shellInsertReserveBefore
            local reserve_after = result.verified or result.count or st.shellInsertReserveAfter
            local clip_before = st.shellInsertClipBefore or 0
            local off = st.shellInsertOffsets or WEAPON_PROFILES.shotgun
            local target_clip = clip_before + 1
            bridge_log(AMMO_CTRL_TAG, string.format(
                "Shell insert reserve: %s -> %s (-1); clip %d -> %d",
                safe_tostring(reserve_before), safe_tostring(reserve_after),
                clip_before, target_clip
            ))
            -- 备弹已写入后再 SetClipAmmo，HUD 刷新会带上新备弹数
            M.queue_set_clip(target_clip, "shotgun_insert", off)
            sh2_clear_mag_reserve_pending(st)
            -- 等 post_engine_tick 写完 clip 后再泵下一发，避免连入读到旧弹仓
        else
            bridge_log(AMMO_CTRL_TAG, "Shell insert reserve write failed: " .. tostring(result.error or "unknown"))
            sh2_clear_mag_reserve_pending(st)
            shell_insert_start_next(st)
        end
        return true
    end

    return false
end

local function sh2_apply_clip_result(st, result, cmd)
    if cmd ~= "set_clip_native" then
        return
    end
    if result.weapon_addr == nil then
        return
    end
    if result.verified ~= nil then
        st.clipAmmo = result.verified
    elseif result.count ~= nil then
        st.clipAmmo = result.count
    end
    if result.ok == true then
        bridge_log(AMMO_CTRL_TAG, string.format(
            "SH2 SetClipAmmo: verified=%s weapon=0x%X",
            safe_tostring(result.verified or result.count),
            result.weapon_addr or 0
        ))
    elseif result.ok == false then
        st.lastError = tostring(result.error or "SetClipAmmo failed")
    end
end

local function sh2_apply_reserve_result(st, result, cmd)
    if cmd == "get_reserve_ammo" and result.count ~= nil then
        st.reserveAmmo = result.count
    elseif cmd == "set_reserve_ammo" then
        if result.verified ~= nil then
            st.reserveAmmo = result.verified
        elseif result.count ~= nil then
            st.reserveAmmo = result.count
        end
    end
    if result.ok == false then
        st.lastError = tostring(result.error or "unknown error")
    elseif cmd == "probe" and result.probe ~= nil then
        st.ready = true
        st.lastError = nil
    elseif result.ok == true then
        st.lastError = nil
    end
end

local function sh2_handle_result(result)
    local st = M.sh2_state()
    st.recvCount = (st.recvCount or 0) + 1
    st.lastRecv = "sh2:result"
    local cmd = st.pendingCmd
    st.pendingCmd = nil
    sh2_write_log("RECV sh2:result cmd=" .. tostring(cmd) .. " raw=" .. tostring(st.lastResultText))

    -- read_byte / read_dword / write_byte 结果处理已移除（策略 G 已放弃）

    sh2_apply_reserve_result(st, result, cmd)
    sh2_apply_clip_result(st, result, cmd)

    -- §17: 处理 block_unequip 结果 (归一化为 boolean)
    if cmd == "set_block_unequip" or cmd == "get_block_unequip" then
        local raw_enabled = result.enabled
        local bool_enabled = (raw_enabled == true) or (tonumber(raw_enabled) == 1)
        st.blockUnequip = {
            enabled = bool_enabled,
            hook_id = result.hook_id,
            hits = result.hits,
            ok = result.ok,
        }
    end

    if not sh2_handle_mag_reserve_result(st, result, cmd) then
        local pending = st.pendingAction
        --[==[ reserve_add_one / reserve_sub_one 异步分支（2026-09-22 停用）
             备弹已同步化（M.reserve_add_one / M.reserve_sub_one 直接 Collect/Remove），
             不再产生 pendingAction=reserve_add_one / reserve_sub_one，此分支永不触发。
        if pending == "reserve_add_one" and cmd == "get_reserve_ammo" and ... then
            ...
        end
        ]==]
        if pending ~= nil and cmd == "get_reserve_ammo" then
            st.pendingAction = nil
            st.pendingPawnAddr = nil
            st.pendingOffsets = nil
        end
    end

    sh2_dispatch_finish()
end

--- 探测 SH2.dll 是否就绪
function M.sh2_probe_dll()
    sh2_dispatch("probe", "{}")
end

--- §17: 设置拦截收枪开关
---@param enabled boolean
function M.set_block_unequip(enabled)
    local body = string.format('{"enabled":%d}', enabled and 1 or 0)
    sh2_dispatch("set_block_unequip", body)
end

--- §17: 查询拦截收枪状态
function M.get_block_unequip()
    sh2_dispatch("get_block_unequip", "{}")
end

--- §17: 手动收枪/换枪时间窗口（ms），UEVR_09 主动操作前调用
--- 在 duration_ms 内所有 unequip 调用都放行，窗口到期自动关闭
---@param duration_ms number 默认 500
function M.allow_unequip_window(duration_ms)
    local dur = tonumber(duration_ms) or 500
    local body = string.format('{"duration_ms":%d}', dur)
    sh2_dispatch("allow_unequip_window", body)
end

-- 注册 on_lua_event 回调（只注册一次）
if uevr and uevr.api and uevr.sdk and uevr.sdk.callbacks then
    if rawget(_G, "__SH2_AMMO_EVENT_REGISTERED") ~= true then
        uevr.sdk.callbacks.on_lua_event(function(event_name, event_data)
            if event_name == "sh2:ready" then
                local st = M.sh2_state()
                st.ready = true
                st.recvCount = (st.recvCount or 0) + 1
                st.lastRecv = event_name
                st.lastError = nil
                sh2_write_log("RECV sh2:ready")
                M.sh2_probe_dll()
                return
            end
            if event_name ~= "sh2:result" then
                return
            end
            local st = M.sh2_state()
            st.lastResultText = tostring(event_data or "")
            local result = sh2_parse_result(event_data)
            if result == nil then
                st.lastError = "invalid sh2:result"
                sh2_write_log("RECV sh2:result parse failed raw=" .. tostring(event_data))
                return
            end
            sh2_handle_result(result)
        end)
        _G.__SH2_AMMO_EVENT_REGISTERED = true
    end
end

local function execute_set_clip(offsets, target_value, source_label)
    local off = offsets or WEAPON_PROFILES.pistol
    local weapon = M.get_equipped_weapon()
    if weapon == nil then
        bridge_log(AMMO_CTRL_TAG, (source_label or "set_clip") .. ": weapon=nil (equip a weapon first)")
        return false, "weapon=nil"
    end
    local before = M.read_clip_ammo(weapon, off)
    local ok, err = write_clip_ammo(weapon, target_value, off)
    local after = M.read_clip_ammo(weapon, off)
    bridge_log(AMMO_CTRL_TAG, string.format(
        "%s: %s -> %s (target=%d)%s",
        source_label or "set_clip",
        safe_tostring(before), safe_tostring(after), math.floor(tonumber(target_value) or 0),
        ok and "" or (" ERR=" .. tostring(err))
    ))
    return ok, err
end

local function execute_clear_clip(offsets)
    execute_set_clip(offsets, 0, "Clear clip")
end

local function execute_fill_clip(offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    local weapon = M.get_equipped_weapon()
    if weapon == nil then
        bridge_log(AMMO_CTRL_TAG, "Fill clip: weapon=nil (equip a weapon first)")
        return
    end
    local clipSize = M.read_clip_size(weapon, off) or 10
    execute_set_clip(off, clipSize, "Fill clip")
end

local function execute_add_one_clip(offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    local weapon = M.get_equipped_weapon()
    if weapon == nil then
        bridge_log(AMMO_CTRL_TAG, "Clip +1: weapon=nil (equip a weapon first)")
        return
    end
    local clipSize = M.read_clip_size(weapon, off) or 10
    local before = M.read_clip_ammo(weapon, off) or 0
    local newVal = math.min(before + 1, clipSize)
    execute_set_clip(off, newVal, "Clip +1")
end

--- 排队写入弹夹（与 diagnose 按钮相同：post_engine_tick 内重新取 weapon 再调 SetClipAmmo）
---@param value number
---@param source string|nil
---@param offsets table WEAPON_PROFILES.<type>
function M.queue_set_clip(value, source, offsets)
    local target = math.floor(tonumber(value) or 0)
    M.sh2_state().pendingClipAction = {
        kind = "set",
        value = target,
        source = source or "set_clip",
        offsets = offsets or WEAPON_PROFILES.pistol,
    }
    bridge_log(AMMO_CTRL_TAG, string.format(
        "Clip set %d queued (post_engine_tick) source=%s",
        target, source or "set_clip"
    ))
end

--- 在 post_engine_tick 中处理排队的弹夹操作，并自动刷新备弹面板
function M.sh2_tick_pending_clip()
    local st = M.sh2_state()
    local action = st.pendingClipAction
    local did_clip = false
    if action ~= nil then
        st.pendingClipAction = nil
        did_clip = true
        if type(action) == "table" then
            if action.kind == "clear" then
                execute_clear_clip(action.offsets)
            elseif action.kind == "fill" then
                execute_fill_clip(action.offsets)
            elseif action.kind == "add_one" then
                execute_add_one_clip(action.offsets)
            elseif action.kind == "set" then
                execute_set_clip(action.offsets, action.value, action.source)
            else
                bridge_log(AMMO_CTRL_TAG, "Unknown pendingClipAction kind: " .. tostring(action.kind))
            end
        else
            bridge_log(AMMO_CTRL_TAG, "Unknown pendingClipAction: " .. tostring(action))
        end
    end

    -- 霰弹枪入仓队列：clip 写完后再启动下一发（避免连入读到旧弹仓）
    if did_clip or (type(st.shellInsertQueue) == "table" and #st.shellInsertQueue > 0) then
        shell_insert_start_next(st)
    end

    if st.pendingAction ~= nil or sh2_dispatch_in_flight or #sh2_dispatch_queue > 0 or st.pendingClipAction ~= nil then
        return
    end

    local weapon = M.get_equipped_weapon()
    if weapon == nil then
        return
    end

    -- 2026-09-22：备弹轮询改同步（不再 dispatch 给 DLL，也就不再占用 DLL 命令通道）
    local now = os.clock()
    if now - sh2_last_reserve_poll < SH2_RESERVE_AUTO_POLL_SEC then
        return
    end
    sh2_last_reserve_poll = now

    local off = get_active_offsets()
    local count = M.read_reserve_ammo(nil, off)
    if count ~= nil then
        M.sh2_state().reserveAmmo = count
    end
end

if uevr and uevr.sdk and uevr.sdk.callbacks then
    if rawget(_G, "__SH2_CLIP_TICK_REGISTERED") ~= true then
        uevr.sdk.callbacks.on_post_engine_tick(function()
            M.sh2_tick_pending_clip()
        end)
        _G.__SH2_CLIP_TICK_REGISTERED = true
    end
end

--- 清空弹夹（ImGui 按钮排队，下一帧 engine tick 执行）
---@param offsets table WEAPON_PROFILES.<type>
function M.clear_clip(offsets)
    M.sh2_state().pendingClipAction = { kind = "clear", offsets = offsets or WEAPON_PROFILES.pistol }
    bridge_log(AMMO_CTRL_TAG, "Clear clip queued (post_engine_tick)")
end

--- 加满弹夹（ImGui 按钮排队，下一帧 engine tick 执行）
---@param offsets table WEAPON_PROFILES.<type>
function M.fill_clip(offsets)
    M.sh2_state().pendingClipAction = { kind = "fill", offsets = offsets or WEAPON_PROFILES.pistol }
    bridge_log(AMMO_CTRL_TAG, "Fill clip queued (post_engine_tick)")
end

--- 弹夹加一发（ImGui 按钮排队，下一帧 engine tick 执行）
---@param offsets table WEAPON_PROFILES.<type>
function M.add_one_clip(offsets)
    M.sh2_state().pendingClipAction = { kind = "add_one", offsets = offsets or WEAPON_PROFILES.pistol }
    bridge_log(AMMO_CTRL_TAG, "Clip +1 queued (post_engine_tick)")
end

--- 备弹加一发（2026-09-22：同步走 Items:CollectItem，不再经 SH2.dll）
---@param offsets table WEAPON_PROFILES.<type>（备弹已不依赖 offsets，仅为兼容签名保留）
function M.reserve_add_one(offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    local weapon, ranged, pawn = M.get_equipped_weapon()
    if pawn == nil then
        bridge_log(AMMO_CTRL_TAG, "Reserve +1: pawn=nil (equip a weapon first)")
        return
    end
    local cur, err = M.read_reserve_ammo(pawn, off)
    if cur == nil then
        bridge_log(AMMO_CTRL_TAG, "Reserve +1: read failed: " .. tostring(err))
        return
    end
    local ok, werr = M.write_reserve_ammo(pawn, cur + 1, off)
    if not ok then
        bridge_log(AMMO_CTRL_TAG, "Reserve +1: write failed: " .. tostring(werr))
        return
    end
    bridge_log(AMMO_CTRL_TAG, string.format("Reserve +1: %d -> %d", cur, cur + 1))
end

--- 霰弹枪入仓一发：先 DLL 扣备弹，完成后再 SetClipAmmo(clip+1)
--- 抓取生成表演弹不走此函数；仅入仓结算调用。串行队列，避免双发连入抢 pendingAction。
---@param offsets table WEAPON_PROFILES.<type>
---@return boolean queued
function M.apply_shell_insert(offsets)
    local off = offsets or WEAPON_PROFILES.shotgun
    local weapon, _, pawn = M.get_equipped_weapon()
    if weapon == nil then
        bridge_log(AMMO_CTRL_TAG, "Shell insert: weapon=nil")
        return false
    end
    if pawn == nil then
        bridge_log(AMMO_CTRL_TAG, "Shell insert: pawn=nil")
        return false
    end
    local clip = M.read_clip_ammo(weapon, off)
    local clip_size = M.read_clip_size(weapon, off)
    if clip == nil or clip_size == nil then
        bridge_log(AMMO_CTRL_TAG, "Shell insert: read clip failed")
        return false
    end
    if clip >= clip_size then
        bridge_log(AMMO_CTRL_TAG, string.format("Shell insert: clip already full (%d/%d)", clip, clip_size))
        return false
    end

    local st = M.sh2_state()
    if type(st.shellInsertQueue) ~= "table" then
        st.shellInsertQueue = {}
    end
    st.shellInsertQueue[#st.shellInsertQueue + 1] = { offsets = off }
    bridge_log(AMMO_CTRL_TAG, string.format(
        "Shell insert queued (depth=%d) clip=%d/%d",
        #st.shellInsertQueue + (shell_insert_busy(st) and 1 or 0),
        clip, clip_size
    ))
    shell_insert_start_next(st)
    return true
end

--- 备弹减一发（2026-09-22：同步走 Items:RemoveItem，不再经 SH2.dll）
---@param offsets table WEAPON_PROFILES.<type>（备弹已不依赖 offsets，仅为兼容签名保留）
function M.reserve_sub_one(offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    local weapon, ranged, pawn = M.get_equipped_weapon()
    if pawn == nil then
        bridge_log(AMMO_CTRL_TAG, "Reserve -1: pawn=nil (equip a weapon first)")
        return
    end
    local cur, err = M.read_reserve_ammo(pawn, off)
    if cur == nil then
        bridge_log(AMMO_CTRL_TAG, "Reserve -1: read failed: " .. tostring(err))
        return
    end
    local target = math.max(cur - 1, 0)
    local ok, werr = M.write_reserve_ammo(pawn, target, off)
    if not ok then
        bridge_log(AMMO_CTRL_TAG, "Reserve -1: write failed: " .. tostring(werr))
        return
    end
    bridge_log(AMMO_CTRL_TAG, string.format("Reserve -1: %d -> %d", cur, target))
end

--- 备弹清零（2026-09-22：同步走 Items:RemoveItem，不再经 SH2.dll）
---@param offsets table WEAPON_PROFILES.<type>（备弹已不依赖 offsets，仅为兼容签名保留）
function M.reserve_clear(offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    local weapon, ranged, pawn = M.get_equipped_weapon()
    if pawn == nil then
        bridge_log(AMMO_CTRL_TAG, "Reserve Clear: pawn=nil (equip a weapon first)")
        return
    end
    local cur, err = M.read_reserve_ammo(pawn, off)
    if cur == nil then
        bridge_log(AMMO_CTRL_TAG, "Reserve Clear: read failed: " .. tostring(err))
        return
    end
    local ok, werr = M.write_reserve_ammo(pawn, 0, off)
    if not ok then
        bridge_log(AMMO_CTRL_TAG, "Reserve Clear: write failed: " .. tostring(werr))
        return
    end
    bridge_log(AMMO_CTRL_TAG, string.format("Reserve Clear: %d -> 0", cur))
end

--- 退弹：弹夹>keep_rounds 时留 keep_rounds 发，其余转入备弹；弹夹=0 时不改弹药
---@param offsets table WEAPON_PROFILES.<type>
---@param keep_rounds number 退弹时弹夹保留的弹药数（手枪/步枪=1，霰弹枪不适用）
---@return table result { ok, error, clip_before, clip_after, moved_to_reserve, needs_rack }
function M.apply_mag_eject(offsets, keep_rounds)
    local off = offsets or WEAPON_PROFILES.pistol
    local keep = math.floor(tonumber(keep_rounds) or 1)
    if keep < 0 then keep = 0 end
    local weapon, _, pawn = M.get_equipped_weapon()
    local result = {
        ok = false,
        error = nil,
        clip_before = nil,
        clip_after = nil,
        reserve_before = nil,
        reserve_after = nil,
        moved_to_reserve = 0,
        needs_rack = false,
    }
    if weapon == nil then
        result.error = "weapon=nil"
        return result
    end
    if pawn == nil then
        result.error = "pawn=nil"
        return result
    end

    local clip_before = M.read_clip_ammo(weapon, off)
    if clip_before == nil then
        result.error = "read_clip_failed"
        return result
    end
    result.clip_before = clip_before

    -- 仅弹夹真正打空(=0)时才算空仓挂机，需要拉栓；余弹>=1时走战术换弹（膛内留 keep 发）
    -- 注意：判定阈值是 clip==0，不能用 clip<=keep，否则余弹=1 时也会错误触发拉栓
    if clip_before <= 0 then
        result.ok = true
        result.clip_after = clip_before
        result.needs_rack = true
        bridge_log(AMMO_CTRL_TAG, string.format(
            "Mag eject: clip %d empty, no ammo change, needs_rack=true",
            clip_before
        ))
        return result
    end

    local moved = clip_before - keep

    local ok_addr, pawn_addr = pcall(function() return pawn:get_address() end)
    if not ok_addr or pawn_addr == nil then
        result.error = "pawn:get_address() failed"
        return result
    end

    local st = M.sh2_state()
    st.magEjectClipBefore = clip_before
    st.magEjectMoved = moved
    st.magEjectOffsets = off
    sh2_write_log(string.format(
        "===== Mag eject: reserve +%d via DLL, then clip -> %d =====",
        moved, keep
    ))
    sh2_begin_reserve_read(pawn_addr, "mag_eject_reserve", off)

    result.ok = true
    result.clip_after = keep
    result.moved_to_reserve = moved
    result.needs_rack = false
    return result
end

--- 插弹：从备弹扣减；clip=0 时可 defer_clip_fill，等拉栓后再补满弹夹
---@param offsets table WEAPON_PROFILES.<type>
---@param opts table|nil { defer_clip_fill: boolean }
---@return table result { ok, error, clip_before, clip_after, added, reserve_before, reserve_after, deferred_clip_fill }
function M.apply_mag_insert(offsets, opts)
    local off = offsets or WEAPON_PROFILES.pistol
    opts = type(opts) == "table" and opts or {}
    local defer_clip_fill = opts.defer_clip_fill == true
    local weapon, _, pawn = M.get_equipped_weapon()
    local result = {
        ok = false,
        error = nil,
        clip_before = nil,
        clip_after = nil,
        clip_size = nil,
        added = 0,
        reserve_before = nil,
        reserve_after = nil,
        deferred_clip_fill = false,
    }
    if weapon == nil then
        result.error = "weapon=nil"
        return result
    end
    if pawn == nil then
        result.error = "pawn=nil"
        return result
    end

    local clip_before = M.read_clip_ammo(weapon, off)
    local clip_size = M.read_clip_size(weapon, off) or 10
    if clip_before == nil then
        result.error = "read_clip_failed"
        return result
    end
    result.clip_before = clip_before
    result.clip_size = clip_size

    local rounds_needed = clip_size - clip_before
    if rounds_needed <= 0 then
        result.ok = true
        result.clip_after = clip_before
        result.added = 0
        bridge_log(AMMO_CTRL_TAG, string.format("Mag insert: clip already full (%d/%d)", clip_before, clip_size))
        return result
    end

    local st = M.sh2_state()
    st.magInsertClipBefore = clip_before
    st.magInsertClipSize = clip_size
    st.magInsertDeferClipFill = defer_clip_fill
    st.magInsertOffsets = off

    -- 空仓挂机：插弹时只设标记，不读/写备弹，等拉栓时统一处理
    if defer_clip_fill then
        sh2_write_log(string.format(
            "===== Mag insert (defer): clip=%d size=%d, reserve ops deferred until rack =====",
            clip_before, clip_size
        ))
        result.ok = true
        result.deferred_clip_fill = true
        result.clip_after = clip_before
        return result
    end

    -- 战术换弹：插弹时立即读备弹→写备弹→写弹夹（原逻辑保持不变）
    local ok_addr, pawn_addr = pcall(function() return pawn:get_address() end)
    if not ok_addr or pawn_addr == nil then
        result.error = "pawn:get_address() failed"
        return result
    end

    sh2_write_log(string.format(
        "===== Mag insert: need %d rounds, reserve read via DLL =====",
        rounds_needed
    ))
    sh2_begin_reserve_read(pawn_addr, "mag_insert_reserve", off)

    result.ok = true
    result.deferred_clip_fill = defer_clip_fill
    result.clip_after = defer_clip_fill and clip_before or clip_size
    return result
end

--- 拉栓时统一处理：读备弹 → 写备弹（扣减）→ 写弹夹（min(备弹, clip_size)）
--- 复用 mag_insert_reserve / mag_insert_reserve_set handler 链路（参考战术换弹）
---@param offsets table WEAPON_PROFILES.<type>
---@return table result { ok, error }
function M.rack_fill(offsets)
    local off = offsets or WEAPON_PROFILES.pistol
    local weapon, _, pawn = M.get_equipped_weapon()
    local result = { ok = false, error = nil }
    if weapon == nil then
        result.error = "weapon=nil"
        return result
    end
    if pawn == nil then
        result.error = "pawn=nil"
        return result
    end

    local clip_before = M.read_clip_ammo(weapon, off)
    local clip_size = M.read_clip_size(weapon, off) or 10
    if clip_before == nil then
        result.error = "read_clip_failed"
        return result
    end

    local rounds_needed = clip_size - clip_before
    if rounds_needed <= 0 then
        result.ok = true
        bridge_log(AMMO_CTRL_TAG, string.format("Rack fill: clip already full (%d/%d)", clip_before, clip_size))
        return result
    end

    local ok_addr, pawn_addr = pcall(function() return pawn:get_address() end)
    if not ok_addr or pawn_addr == nil then
        result.error = "pawn:get_address() failed"
        return result
    end

    local st = M.sh2_state()
    st.magInsertClipBefore = clip_before
    st.magInsertClipSize = clip_size
    -- 拉栓时不再 defer，让 mag_insert_reserve_set handler 直接排队写弹夹
    st.magInsertDeferClipFill = false
    st.magInsertOffsets = off
    sh2_write_log(string.format(
        "===== Rack fill: need %d rounds, reserve read via DLL =====",
        rounds_needed
    ))
    sh2_begin_reserve_read(pawn_addr, "mag_insert_reserve", off)

    result.ok = true
    return result
end

---------------------------------------------------------------------------
-- 下沉通用工具函数（从 pistol_reload.lua / shotgun_reload.lua 迁移）
-- 纯数学、纯 UE 通用算法，与具体武器无关
---------------------------------------------------------------------------

--- UObject 有效性检查（UEVR_UObjectHook.exists 或 uevrUtils.getValid 回退）
---@param obj userdata|nil
---@return boolean
function M.uobject_valid(obj)
    if obj == nil then
        return false
    end
    if rawget(_G, "UEVR_UObjectHook") ~= nil and UEVR_UObjectHook.exists ~= nil then
        local ok, exists = pcall(function()
            return UEVR_UObjectHook.exists(obj)
        end)
        return ok and exists == true
    end
    local ok, valid = pcall(function()
        return uevrUtils.getValid(obj) ~= nil
    end)
    return ok and valid == true
end

--- FName 转 String（FName:to_string 或 tostring 回退）
---@param bone_fname userdata|nil
---@return string
function M.bone_name_to_string(bone_fname)
    if bone_fname == nil then
        return ""
    end
    local ok, text = pcall(function()
        return bone_fname:to_string()
    end)
    if ok and text ~= nil then
        return text
    end
    return tostring(bone_fname)
end

--- 获取 EBoneSpaces.ComponentSpace 常量（UE4 骨骼空间枚举）
---@return number
function M.bone_space_component()
    if rawget(_G, "EBoneSpaces") ~= nil and EBoneSpaces.ComponentSpace ~= nil then
        return EBoneSpaces.ComponentSpace
    end
    return 1
end

--- Rotator → {Pitch, Yaw, Roll} 表（供 start_slide 欧拉插值；避免 userdata 字段偶发读空）
---@param rot userdata|nil
---@return table|nil
function M.rotator_to_slide_table(rot)
    if rot == nil then
        return nil
    end
    local pitch, yaw, roll = 0, 0, 0
    pcall(function()
        pitch = rot.Pitch or 0
        yaw = rot.Yaw or 0
        roll = rot.Roll or 0
    end)
    return { Pitch = pitch, Yaw = yaw, Roll = roll }
end

--- 世界坐标系旋转偏移合成
--- 与 compose_local_rot_offset 对应，但 offset 在世界坐标系应用。
--- 用途：当 socket 局部轴不对应世界轴时（如 socket 局部 Z 是水平的），避免欧拉角万向锁。
--- 合成顺序：composeRotators(base_rot, local_rot)
---   - UE ComposeRotators(A=base_rot, B=local_rot) = local_quat * base_quat
---   - 应用顺序：base_rot 先（orient 到 socket），local_rot 后（世界坐标系偏移）
---   - 结果：pitch=世界 Y, yaw=世界 Z (垂直), roll=世界 X
---@param base_rot userdata|nil  socket 基础旋转
---@param offset table|nil  { pitch=, yaw=, roll= } 世界坐标系偏移（度）
---@return userdata|nil  合成后的旋转（失败时 fallback 到简单加法）
function M.compose_world_rot_offset(base_rot, offset)
    if base_rot == nil then
        return nil
    end
    local pitch = (offset and offset.pitch) or 0
    local yaw = (offset and offset.yaw) or 0
    local roll = (offset and offset.roll) or 0
    if pitch == 0 and yaw == 0 and roll == 0 then
        return base_rot
    end
    local local_rot = uevrUtils.rotator(pitch, yaw, roll)
    local composed = nil
    pcall(function()
        -- 世界坐标系 offset：composeRotators(base, local)
        -- vs local 版的 composeRotators(local, base)
        composed = mathLib.composeRotators(base_rot, local_rot)
    end)
    if composed ~= nil then
        return composed
    end
    -- fallback：简单加法（近似世界坐标系，不精确但避免 nil）
    return uevrUtils.sumRotators(base_rot, {
        Pitch = pitch, Yaw = yaw, Roll = roll,
    }) or base_rot
end

--- 局部坐标系旋转偏移合成（2026-07-30 新增，从 shotgun_reload.lua 私有版本下沉为公共工具）
--- offset 在 socket 局部坐标系应用，枪怎么转 offset 跟着转 → 入膛角度相对枪身始终不变。
--- 合成顺序：composeRotators(local_rot, base_rot)
---   - UE ComposeRotators(A=local_rot, B=base_rot) = base_quat * local_quat
---   - 应用顺序：local_rot 先（局部偏移），base_rot 后（orient 到 socket）
---   - 结果：offset 始终在 socket 局部 frame，枪旋转时 offset 随之旋转
---@param base_rot userdata|nil  socket 基础旋转
---@param offset table|nil  { pitch=, yaw=, roll= } 局部坐标系偏移（度）
---@return userdata|nil  合成后的旋转（失败时 fallback 到简单加法）
function M.compose_local_rot_offset(base_rot, offset)
    if base_rot == nil then
        return nil
    end
    local pitch = (offset and offset.pitch) or 0
    local yaw = (offset and offset.yaw) or 0
    local roll = (offset and offset.roll) or 0
    if pitch == 0 and yaw == 0 and roll == 0 then
        return base_rot
    end
    local local_rot = uevrUtils.rotator(pitch, yaw, roll)
    local composed = nil
    pcall(function()
        -- 局部坐标系 offset：composeRotators(local, base)
        -- 枪怎么歪都稳定（offset 跟随 socket 局部 frame）
        composed = mathLib.composeRotators(local_rot, base_rot)
    end)
    if composed ~= nil then
        return composed
    end
    -- fallback：简单加法（近似，不精确但避免 nil）
    return uevrUtils.sumRotators(base_rot, {
        Pitch = pitch, Yaw = yaw, Roll = roll,
    }) or base_rot
end

--- 组件树 DFS 遍历（AttachChildren 递归）
---@param root userdata|nil  根 USceneComponent
---@param visit function  访问回调
function M.foreach_component_tree(root, visit)
    if root == nil or type(visit) ~= "function" then
        return
    end
    local stack = { root }
    while #stack > 0 do
        local comp = table.remove(stack, #stack)
        visit(comp)
        local children = comp.AttachChildren
        if type(children) == "table" then
            for i = 1, #children do
                table.insert(stack, children[i])
            end
        end
    end
end

--- 复制源组件世界变换到目标组件（K2_GetComponentToWorld → K2_SetWorldTransform，或 Location+Rotation 回退）
---@param source_comp userdata|nil
---@param dest_comp userdata|nil
---@return boolean
function M.copy_component_world_transform(source_comp, dest_comp)
    if source_comp == nil or dest_comp == nil then
        return false
    end
    local ok = pcall(function()
        if source_comp.K2_GetComponentToWorld ~= nil and dest_comp.K2_SetWorldTransform ~= nil then
            local wt = source_comp:K2_GetComponentToWorld()
            dest_comp:K2_SetWorldTransform(wt, false, reusable_hit_result, false)
        else
            local loc = M.get_component_world_location(source_comp)
            if loc ~= nil and dest_comp.K2_SetWorldLocation ~= nil then
                dest_comp:K2_SetWorldLocation(
                    uevrUtils.vector(loc.X, loc.Y, loc.Z), false, reusable_hit_result, false)
            end
            local rot = M.get_component_world_rotation(source_comp)
            if rot ~= nil and dest_comp.K2_SetWorldRotation ~= nil then
                dest_comp:K2_SetWorldRotation(
                    uevrUtils.rotator(rot.Pitch or rot.X or 0, rot.Yaw or rot.Y or 0, rot.Roll or rot.Z or 0),
                    false, reusable_hit_result, false)
            end
        end
    end)
    return ok
end

--- 设置 PoseableMesh 渲染标志（SetRenderInMainPass + SetVisibility + SetHiddenInGame）
---@param mesh_comp userdata|nil
function M.apply_poseable_render_flags(mesh_comp)
    if mesh_comp == nil then
        return
    end
    pcall(function()
        if mesh_comp.SetRenderInMainPass ~= nil then
            mesh_comp:SetRenderInMainPass(true)
        end
        mesh_comp:SetVisibility(true, true)
        mesh_comp:SetHiddenInGame(false, true)
    end)
end

--- 获取 Actor 根组件（RootComponent 或 K2_GetComponentsByClass 回退）
---@param actor userdata|nil
---@return userdata|nil
function M.get_actor_root(actor)
    if actor == nil then
        return nil
    end
    local root = uevrUtils.getValid(actor, {"RootComponent"}) or actor.RootComponent
    if root ~= nil then
        return root
    end
    local sm_class = uevrUtils.get_class("Class /Script/Engine.StaticMeshComponent")
    if sm_class ~= nil and actor.K2_GetComponentsByClass ~= nil then
        local ok, comps = pcall(function()
            return actor:K2_GetComponentsByClass(sm_class)
        end)
        if ok and type(comps) == "table" and #comps > 0 then
            return comps[1]
        end
    end
    return nil
end

--- 获取掉落场景组件（优先 scene_comp，回退到 Actor 根组件）
---@param actor userdata|nil
---@param scene_comp userdata|nil
---@return userdata|nil
function M.get_drop_scene_component(actor, scene_comp)
    if scene_comp ~= nil and uevrUtils.getValid(scene_comp) ~= nil then
        return scene_comp
    end
    return M.get_actor_root(actor)
end

--- 准备生成的 Actor 可见（SetActorHiddenInGame(false) + 递归遍历组件树设可见）
---@param actor userdata|nil
function M.prepare_spawned_actor_visible(actor)
    if actor == nil then
        return
    end
    pcall(function()
        actor:SetActorHiddenInGame(false)
    end)
    local root = M.get_actor_root(actor)
    M.foreach_component_tree(root, function(comp)
        pcall(function()
            if comp.SetVisibility ~= nil then
                comp:SetVisibility(true, true)
            end
            if comp.SetHiddenInGame ~= nil then
                comp:SetHiddenInGame(false, true)
            end
        end)
    end)
end

--- 读取骨骼缩放（GetBoneScaleByName）
---@param mesh_comp userdata|nil
---@param bone_name string
---@param bone_space number|nil  默认 M.bone_space_component()
---@return userdata|nil
function M.read_bone_scale(mesh_comp, bone_name, bone_space)
    if mesh_comp == nil or mesh_comp.GetBoneScaleByName == nil then
        return nil
    end
    local scale = nil
    pcall(function()
        scale = mesh_comp:GetBoneScaleByName(uevrUtils.fname_from_string(bone_name), bone_space or M.bone_space_component())
    end)
    return scale
end

--- 组件显示名（调试用，返回 get_full_name 或 "<invalid>"）
--- 注意：已有 local function component_display_name 在 L664，现导出为 M.xxx
---@param comp userdata|nil
---@return string
M.component_display_name = component_display_name

-- 导出 WEAPON_PROFILES 供上层使用（reload_tools.WEAPON_PROFILES.pistol 等）
M.WEAPON_PROFILES = WEAPON_PROFILES

---------------------------------------------------------------------------
-- 旋转工具（B 类公共工具，2026-07-25 新增，步枪 B-3 拉栓旋转驱动用）
-- 设计原则：通用命名（非 bolt 特有），未来其他旋转驱动场景可复用
---------------------------------------------------------------------------

--- 旋转角度线性/缓动插值
--- 用于 4 阶段状态机的 rotate_up / rotate_down 阶段
--- progress 应由 calc_slide_rotate_anchored 的手势浮点提供（跟手）；勿用时间伪造 progress
---@param progress number 0~1 当前阶段进度
---@param start_angle number 起始角度（度）
---@param end_angle number 终止角度（度）
---@param ease_mode string|nil "linear"（默认）| "smooth"（smoothstep）| "ease_in" | "ease_out"
---@return number 当前角度
function M.calc_rotation_lerp(progress, start_angle, end_angle, ease_mode)
    local t = progress or 0
    if t <= 0.0 then return start_angle end
    if t >= 1.0 then return end_angle end
    local mode = ease_mode or "linear"
    local u = t
    if mode == "smooth" then
        u = M.ease(t)
    elseif mode == "ease_in" then
        u = t * t
    elseif mode == "ease_out" then
        u = 1.0 - (1.0 - t) * (1.0 - t)
    end
    return start_angle + (end_angle - start_angle) * u
end

--- 判断角度是否到达目标（考虑最短路径环绕）
--- 用于 rotate_up/rotate_down 阶段到位判断
---@param current_angle number 当前角度（度）
---@param target_angle number 目标角度（度）
---@param tolerance number|nil 容差（度），默认 1.0
---@return boolean 是否到位
function M.is_angle_reached(current_angle, target_angle, tolerance)
    local tol = tolerance or 1.0
    if current_angle == nil or target_angle == nil then
        return false
    end
    local diff = math.abs(current_angle - target_angle)
    -- 考虑 360° 环绕
    if diff > 180.0 then
        diff = 360.0 - diff
    end
    return diff <= tol
end

--- 安全调用 SetBoneRotationByName（含 pcall + 失败返回 false）
--- B-3 核心：4 阶段状态机旋转驱动 + pull/push 阶段保持旋转
---@param mesh_comp userdata|nil PoseableMesh 或 SkeletalMeshComponent
---@param bone_name string 骨骼名
---@param pitch number Pitch（度）
---@param yaw number Yaw（度）
---@param roll number Roll（度）
---@param space number|nil EBoneSpaces，默认 M.bone_space_component()
---@return boolean 是否成功
function M.set_bone_rotation_by_name_safe(mesh_comp, bone_name, pitch, yaw, roll, space)
    if mesh_comp == nil or mesh_comp.SetBoneRotationByName == nil then
        return false
    end
    if bone_name == nil or bone_name == "" then
        return false
    end
    local ok = pcall(function()
        local bone_fname = uevrUtils.fname_from_string(bone_name)
        local rotator = uevrUtils.rotator(pitch or 0, yaw or 0, roll or 0)
        mesh_comp:SetBoneRotationByName(bone_fname, rotator, space or M.bone_space_component())
    end)
    return ok
end

--- 将 PoseableMesh 的某 socket 对齐到真枪 mesh 同名 socket 世界位置
--- 读 source 上 socket 世界坐标，读 poseable 上同名 socket 世界坐标，差分 → K2_AddWorldOffset
---@param poseable userdata PoseableMesh 组件
---@param source userdata 真枪 mesh 组件
---@param socket_name string socket / bone 名称
---@return boolean 是否成功
function M.align_poseable_socket(poseable, source, socket_name)
    if poseable == nil or source == nil or socket_name == nil or socket_name == "" then
        return false
    end
    local target = M.get_socket_world_location(source, socket_name)
    local current = M.get_socket_world_location(poseable, socket_name)
    if target == nil or current == nil or poseable.K2_AddWorldOffset == nil then
        return false
    end
    local dx = target.X - current.X
    local dy = target.Y - current.Y
    local dz = target.Z - current.Z
    local ok = pcall(function()
        poseable:K2_AddWorldOffset(uevrUtils.vector(dx, dy, dz), false, reusable_hit_result, false)
    end)
    return ok
end

-- §17: UI 开关 —— 拦截自动收枪（Scripts Generated UI 区域）
-- 不依赖 rifle_diagnose.lua，热重载后会重新注册
if uevr and uevr.sdk and uevr.sdk.callbacks then
    if rawget(_G, "__SH2_BLOCK_UNEQUIP_UI_REGISTERED") ~= true then
        -- 冷启动 / 热重载后主动查询 DLL 状态
        M.get_block_unequip()
        uevr.sdk.callbacks.on_draw_ui(function()
            local ok_ui, ui_err = pcall(function()
                imgui.separator()
                imgui.text_colored("Block Unequip Weapon", 0xFFFF8800)

                local st = M.sh2_state()
                local bu = st.blockUnequip or {}
                local bu_enabled = (bu.enabled == true) or (tonumber(bu.enabled) == 1)

                local changed, new_val = imgui.checkbox("Block auto unequip", bu_enabled)
                if changed then
                    M.set_block_unequip(new_val and true or false)
                end

                local bu_hits = bu.hits or 0
                local bu_hook_id = bu.hook_id
                local bu_col = bu_enabled and 0xFF00FF00 or 0xFFAAAAAA
                imgui.text_colored(
                    string.format("  Hook: %s | Hits: %d",
                        tostring(bu_hook_id or "N/A"),
                        bu_hits),
                    bu_col)
            end)
            if not ok_ui then
                -- silently ignore UI errors
            end
        end)
        _G.__SH2_BLOCK_UNEQUIP_UI_REGISTERED = true
    end
end

return M
