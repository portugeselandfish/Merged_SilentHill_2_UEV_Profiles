-- =============================================================================
-- UEVR_11_EventFeedback - 事件反馈模块
-- 职责: 把游戏事件(换弹动作等)映射到手柄震动 + 背心体感; 上层 reload 文件调用, 底层 UEVR_05 驱动播放
-- 架构:
--   UEVR_05_haptics                 = 底层驱动 (TouchHapticsPlayer / HapticPlayer / 背心桥接)
--   UEVR_11_EventFeedback (本文件)  = 事件→震动映射层 (换弹/推门/remote_grab 到手)
--   pistol/shotgun/rifle_reload.lua / remote_grab.lua = 上层调用方
-- =============================================================================

local module_name = "UEVR_11_EventFeedback"

-- =============================================================================
-- 热重载守卫
-- 已装载则复用表，避免 collision callback 重复注册；缺 API 时在文件末尾补丁
-- =============================================================================
local existing_module = package.loaded[module_name]
local already_installed = existing_module ~= nil and type(existing_module.play_reload_haptic) == "function"

-- 1.0.2 推门震动：11 文件直接 require collision，独立注册 contact callback
-- main.lua 只负责物理推力(AddPhysicForce)，本文件只负责震动反馈，互不耦合
local collision = require("libs.collision")
local uevrUtils = require("libs/uevr_utils")

local eventFeedback = already_installed and existing_module or {}

-- 背心体感: 与手柄左右侧一致 (05 companion tact 已注册)
local VEST_LEFT  = "PlayerBowPullLeft_1"
local VEST_RIGHT = "PlayerBowPullRight_1"

-- =============================================================================
-- 取全局 haptic_player (UEVR_08 创建的 HapticPlayer 实例, 内含 touch_player)
-- =============================================================================
local function get_haptic_player()
    local env = rawget(_G, "VREnvironment")
    if type(env) ~= "table" then
        local enhancer = rawget(_G, "VR_ENHANCER")
        env = type(enhancer) == "table" and enhancer.environment or nil
    end
    if type(env) ~= "table" then
        return nil
    end
    return env.hapticPlayer
end

-- =============================================================================
-- 换弹动作震动配置
-- =============================================================================
-- 直接复用 05 createCompanionDefaults 生成的 TouchHaptics 对象
-- 05 的 defaults 已绑定左右手 + 对应 samples，无需重复生成
local function get_default_haptics()
    local env = rawget(_G, "VREnvironment")
    if type(env) ~= "table" then
        local enhancer = rawget(_G, "VR_ENHANCER")
        env = type(enhancer) == "table" and enhancer.environment or nil
    end
    if type(env) == "table" then
        return env.defaultHaptics
    end
    return nil
end

-- 换弹动作 → 左右侧 ("left" / "right"), 手柄与体感袖子共用
local RELOAD_HAND = {
    mag_drop        = "right", -- 退弹
    mag_insert      = "right", -- 插弹匣
    mag_release     = "left",  -- 松手掉弹
    pull_slide      = "left",  -- 拉栓
    slide_snap      = "left",  -- 套筒回弹
    pump_back       = "left",  -- 后拉到位
    pump_fwd        = "left",  -- 前推完成
    shell_insert    = "right", -- 子弹滑入
    bolt_rotate_up  = "left",  -- 步枪枪栓旋转↑
    bolt_pull       = "left",  -- 步枪枪栓后拉到位
    bolt_push       = "left",  -- 步枪枪栓前推到位
    bolt_rotate_down = "left", -- 步枪枪栓旋转↓
    bolt_complete   = "left",  -- 步枪拉栓全流程完成
}

-- "left" / "right" → TouchHaptics + 背心 tact
local function resolve_hand_feedback(hand)
    local defaults = get_default_haptics()
    if defaults == nil then
        return nil, nil
    end
    if hand == "left" then
        return defaults.Touch_Enter_Left, VEST_LEFT
    elseif hand == "right" then
        return defaults.Touch_Enter_Right, VEST_RIGHT
    end
    return nil, nil
end

--- 公共播放：手柄 + 背心（channel 区分并发槽，如 "reload" / "remote_grab" / "door"）
-- @param channel string
-- @param hand "left"|"right"
-- @return boolean
local function play_hand_feedback(channel, hand)
    if type(channel) ~= "string" or channel == "" then
        return false
    end
    local pattern, vest = resolve_hand_feedback(hand)
    if pattern == nil and vest == nil then
        return false
    end
    local hp = get_haptic_player()
    if hp == nil or type(hp.play_registered) ~= "function" then
        return false
    end
    local played = false
    if pattern ~= nil then
        local ok = pcall(function()
            hp:play_registered(channel, pattern, "enter")
        end)
        if ok == true then
            played = true
        end
    end
    if vest ~= nil then
        local ok = pcall(function()
            hp:play_registered(channel .. "_vest", vest, "enter")
        end)
        if ok == true then
            played = true
        end
    end
    return played
end

-- =============================================================================
-- 公开 API（薄包装；语义入口留给调用方，底层共用 play_hand_feedback）
-- =============================================================================

--- 触发换弹动作手柄震动 + 对应体感背心震动 (pistol/shotgun/rifle 共用)
-- @param action string: "mag_drop" | "mag_insert" | "mag_release" | "pull_slide" | "slide_snap"
--                        | "pump_back" | "pump_fwd" | "shell_insert"
--                        | "bolt_rotate_up" | "bolt_pull" | "bolt_push" | "bolt_rotate_down" | "bolt_complete"
-- @return boolean 是否至少成功入队一种反馈
function eventFeedback.play_reload_haptic(action)
    return play_hand_feedback("reload", RELOAD_HAND[action])
end

-- 兼容接口 (保持模块签名完整, 供热重载守卫/外部调用)
function eventFeedback.init()
    return true
end

function eventFeedback.ensureInstalled(_enhancer)
    return true
end

--- remote_grab：表演体飞到左手并 attach 到手骨时触发左手震动
-- @return boolean 是否至少成功入队一种反馈
function eventFeedback.play_remote_grab_haptic()
    return play_hand_feedback("remote_grab", "left")
end

--- 拉门栓完成：触发左手震动
-- @return boolean 是否至少成功入队一种反馈
function eventFeedback.play_latch_haptic()
    return play_hand_feedback("latch", "left")
end

--- 推拉门(glide)开始/续拉：长振动弱震（Touch_Ancient_Impact_L = 时长1s、强度1.0）+ 体感袖子(VEST_LEFT)
-- 连续过程用的"开始拉/断点续拉"反馈，区别于拉到位时的强震动(play_latch_haptic)。
-- 体感袖子沿用现有 VEST_LEFT 机制，独立 channel "glide_pull" 与 reload/latch 隔离。
-- @return boolean 是否至少成功入队一种反馈
function eventFeedback.play_glide_pull_haptic()
    local defaults = get_default_haptics()
    if defaults == nil then
        return false
    end
    local pattern = defaults.Touch_Ancient_Impact_L
    local vest = VEST_LEFT
    local hp = get_haptic_player()
    if hp == nil or type(hp.play_registered) ~= "function" then
        return false
    end
    local played = false
    if pattern ~= nil then
        local ok = pcall(function()
            hp:play_registered("glide_pull", pattern, "enter")
        end)
        if ok == true then
            played = true
        end
    end
    if vest ~= nil then
        local ok = pcall(function()
            hp:play_registered("glide_pull_vest", vest, "enter")
        end)
        if ok == true then
            played = true
        end
    end
    return played
end

--- 触发推门手柄震动 + 对应体感背心震动 (那只手碰门震那只手)
-- @param handed number: 0=左手, 1=右手 (与 collision.registerContactCallback 的 handed 一致)
-- @return boolean 是否至少成功入队一种反馈
function eventFeedback.play_door_haptic(handed)
    local hand = nil
    if handed == 0 then
        hand = "left"
    elseif handed == 1 then
        hand = "right"
    else
        return false
    end
    -- 通道仍用 reload：与旧行为一致（与换弹共用并发槽）
    return play_hand_feedback("reload", hand)
end

-- =============================================================================
-- 推门震动：注册碰撞回调，那只手碰门震那只手
-- 物理推力由 main.lua 的另一个 contact callback 处理，本回调只负责震动反馈
-- =============================================================================
local DOOR_HAPTIC_COOLDOWN = 0.3  -- 推门震动节流（秒），避免每帧触发
local door_haptic_last_time = { [0] = 0, [1] = 0 }

-- 检测碰撞对象是否为门（Owner 含 DoorMovement 组件，与 main.lua getDoorMovement 一致）
local function isDoorHit(hitComp)
    if hitComp == nil then return false end
    local owner = hitComp.GetOwner and hitComp:GetOwner() or nil
    if owner == nil then return false end
    local candidates = { owner.DoorMovement, owner.LeftDoorMovement, owner.RightDoorMovement }
    for i = 1, #candidates do
        if candidates[i] ~= nil and candidates[i].AddPhysicForce ~= nil then
            return true
        end
    end
    return false
end

if not already_installed then
    collision.registerContactCallback(function(id, handVelocity, hitResult, collider, handed)
        if handVelocity == nil or hitResult == nil then return end
        local hit = uevrUtils.getCleanHitResult(hitResult)
        local hitComp = hit and uevrUtils.getValid(hit.Component) or nil
        if hit == nil or hitComp == nil then return end

        -- 只对门触发震动
        if not isDoorHit(hitComp) then return end

        -- 速度阈值：避免轻微触碰触发震动
        local speed = math.sqrt(handVelocity.X * handVelocity.X + handVelocity.Y * handVelocity.Y + handVelocity.Z * handVelocity.Z)
        if speed < 0.5 then return end

        -- 节流：同一只手 0.3 秒内只触发一次
        local now = os.clock()
        local last = door_haptic_last_time[handed] or 0
        if now - last < DOOR_HAPTIC_COOLDOWN then return end
        door_haptic_last_time[handed] = now

        eventFeedback.play_door_haptic(handed)
    end)
end

package.loaded[module_name] = eventFeedback
return eventFeedback
