--[[
================================================================================
SH2 武器后座力调用层 (recoil.lua)
================================================================================
把 libs/recoil_tools 纯逻辑库接入 SH2 UEVR 运行时。
按 sh2_recoil_port_plan.md §2.0 / §2.2 重构：
    1. 仅做后座力位移/旋转；零震动（震动由现有 UEVR_05/10/11 承担）
    2. 不使用 register_weapon_module（避免覆盖换弹 module 槽位）
    3. Seed 由 UEVR_09 trigger_right_fire_action（RT enter）回调 M.on_fire_success
       （abandon RequestManualFire / register_fire_listener）
    4. pre_engine_tick 更新弹簧；不注册 post_engine_tick
    5. main.lua 在唯一 K2_SetWorld* 写入前调用 M.apply_to_aim_transform 合成变换
    6. 单发，无虚拟 ID；三枪参数仅在本层持有
    7. 把 recoil_randomness、recoil_vertical_spread、recoil_horizontal_spread、recoil_roll_intensity 调到 0，或上层改成固定 random_01 = 0.5，每发就完全一致

依赖：
    - libs/uevr_utils                    （vector / rotator / rotateVector）
    - libs/core/math_lib                 （composeRotators：四元数等价旋转合成）
    - UEVR_00_init_globals (vr_globals)  （getCurrentWeaponType / KEYS）
    - libs/recoil_tools                  （后座力纯逻辑库）
    - libs/configui / hands / ik         （解析右手可视握持组件）
    - json                               （UEVR 全局，由 UEVR_00_init_globals 安装 shim）
    - UEVR_09 Immersion Enhancer         （trigger_right_fire_action enter → on_fire_success）

单位转换：
    RE9 spring 值以米/弧度为单位；UE4 K2_SetWorldLocation 用厘米，Rotator 用度。
    位置偏移 ×100（米→厘米）；旋转偏移 math.deg()（弧度→度）。
    旋转合成用 mathLib.composeRotators(recoil_delta, base_rotation)，
    不对 Pitch/Yaw/Roll 逐字段相加。

可视后座枢轴：
    IK Arms：在 IK 求解写 hand_r_bn 之前，把后坐力旋转合成进目标姿态（RE9 motion 集成思路）。
    Forearms：仍可对 hand_r_bn 做 ComponentSpace 旋转（无 IK 每帧覆盖）。
    不写真实控制器追踪。Root 瞄准 / FirePoint 仍独立写入。
================================================================================
]]--

local uevrUtils = require("libs/uevr_utils")
local mathLib = require("libs/core/math_lib")
local vr_globals = require("UEVR_00_init_globals")
local recoil_tools = require("libs/recoil_tools")
local configui = require("libs/configui")
local hands = require("libs/hands")
local ik = require("libs/ik")

local M = {}

-- =============================================================================
-- [1] 模块级状态
-- =============================================================================

local recoil_state = nil                    -- recoil_tools.new_state() 实例
local weapon_intensity_overrides = {}       -- per-weapon intensity 倍率（从 CONFIG 加载）
local last_tick_now = nil                   -- 上一帧 os.clock()，用于计算 dt
local seeded_weapon_type = nil              -- 上一次 seed 的武器类型；换枪时 reset 弹簧
local pre_tick_registered = false           -- trampoline 是否已 on_pre_engine_tick

-- 右手握持骨可视后座（Forearms 骨写入 / IK 目标合成）
local HAND_BONE_NAME = "hand_r_bn"
local HandsType = { None = 1, Forearms = 2, IKArms = 3 }
local hand_bone_base_rot = nil              -- {Pitch,Yaw,Roll} ComponentSpace（仅 Forearms）
local hand_bone_dirty = false               -- Forearms 手骨已被改写，idle 时需还原
local hand_bone_comp_ref = nil              -- 最近一次写入的手组件（换枪/还原用）
local visual_rotation_applied = false       -- 本帧 IK 已合成可视旋转（Root 勿再叠旋转）

-- =============================================================================
-- [2] 配置路径与单位
-- =============================================================================

-- json.load_file 用带后缀路径；configui.createConfigPanel 的 saveFile 不带后缀（库内会自动拼 .json）
local RECOIL_CFG_FILE = "recoil_intensity"
local RECOIL_CFG_PATH = RECOIL_CFG_FILE .. ".json"
local RECOIL_POS_UNIT_SCALE = 100.0  -- 米 → 厘米

-- =============================================================================
-- [3] SH2 武器参数表（无虚拟 ID；仅本层持有）
-- =============================================================================

local SH2_WEAPON_RECOIL = {
    pistol  = { kick_up_scale = 1.1,  is_heavy = false, is_hard_vertical = false },
    shotgun = { kick_up_scale = 1.52, is_heavy = true,  is_hard_vertical = true  },
    rifle   = { kick_up_scale = 1.30, is_heavy = false, is_hard_vertical = true  },
}

-- =============================================================================
-- [4] 当前武器上下文读取
-- 复用 vr_globals 已发布的 _G.__sh2_current_weapon_type
-- =============================================================================

local function get_current_weapon_type()
    return vr_globals.getCurrentWeaponType()  -- "pistol"|"shotgun"|"rifle"|"none"
end

local function is_stabilized()
    -- SH2 两手稳定判定：
    --   1) g_is_two_hand_aiming_active（双手瞄准）
    --   2) g_is_support_docked（副手 docked）
    local two_hand = rawget(_G, "g_is_two_hand_aiming_active") == true
    local docked = rawget(_G, "g_is_support_docked") == true
    if recoil_tools.CONFIG.recoil_stabilized_requires_both then
        return docked and two_hand
    end
    return docked or two_hand
end

local function finite_num(v)
    return type(v) == "number" and v == v and v > -1e12 and v < 1e12
end

local function read_xyz(v)
    if v == nil then return nil end
    local x, y, z = nil, nil, nil
    pcall(function()
        x, y, z = v.X, v.Y, v.Z
    end)
    if finite_num(x) and finite_num(y) and finite_num(z) then
        return x, y, z
    end
    return nil
end

local function read_pyr(v)
    if v == nil then return nil end
    local p, y, r = nil, nil, nil
    pcall(function()
        p, y, r = v.Pitch, v.Yaw, v.Roll
    end)
    if finite_num(p) and finite_num(y) and finite_num(r) then
        return p, y, r
    end
    return nil
end

local function bone_space_cs()
    if rawget(_G, "EBoneSpaces") ~= nil and EBoneSpaces.ComponentSpace ~= nil then
        return EBoneSpaces.ComponentSpace
    end
    return 1
end

local function clear_hand_bone_base()
    hand_bone_base_rot = nil
end

local function hand_bone_fname()
    return uevrUtils.fname_from_string(HAND_BONE_NAME)
end

--- 组件上是否存在 hand_r_bn（无效 UObject / 无骨 API / 索引无效 → false）
---@param hand_comp any
---@return boolean
local function hand_comp_has_grip_bone(hand_comp)
    if uevrUtils.getValid(hand_comp) == nil then
        return false
    end
    if hand_comp.GetBoneIndex == nil or hand_comp.GetBoneRotationByName == nil
        or hand_comp.SetBoneRotationByName == nil then
        return false
    end
    local ok = false
    pcall(function()
        local idx = hand_comp:GetBoneIndex(hand_bone_fname())
        ok = type(idx) == "number" and idx >= 0
    end)
    return ok
end

--- 与 main grip 回调同一选择逻辑：仅 Forearms / IKArms 有可视手骨；None（控制器）禁用可视后座
---@param hand_comp any|nil 可选：已解析的右手组件；nil 时自行解析
---@return any|nil
function M.resolve_right_hand_component(hand_comp)
    if hand_comp ~= nil then
        if hand_comp_has_grip_bone(hand_comp) then
            return hand_comp
        end
        return nil
    end

    local hands_type = HandsType.None
    pcall(function()
        hands_type = configui.getValue("hands_type") or HandsType.None
    end)

    local comp = nil
    if hands_type == HandsType.Forearms then
        pcall(function()
            if rawget(_G, "Handed") ~= nil then
                comp = hands.getHandComponent(Handed.Right)
            end
        end)
    elseif hands_type == HandsType.IKArms then
        pcall(function()
            comp = ik.getCurrentMesh()
        end)
    else
        -- HandsType.None：控制器不是可视握持骨，禁用可视后座
        return nil
    end

    if hand_comp_has_grip_bone(comp) then
        return comp
    end
    return nil
end

--- 缓存 hand_r_bn ComponentSpace 基准旋转（仅在尚未缓存时写入）
---@param hand_comp any|nil
---@return boolean
function M.cache_hand_bone_base(hand_comp)
    if hand_bone_base_rot ~= nil then
        return true
    end
    local comp = M.resolve_right_hand_component(hand_comp)
    if comp == nil then
        return false
    end
    local ok = false
    pcall(function()
        local rot = comp:GetBoneRotationByName(hand_bone_fname(), bone_space_cs())
        local rp, ry, rr = read_pyr(rot)
        if rp ~= nil then
            hand_bone_base_rot = { Pitch = rp, Yaw = ry, Roll = rr }
            hand_bone_comp_ref = comp
            ok = true
        end
    end)
    return ok
end

--- 把 hand_r_bn 还原为缓存基准旋转（不清除缓存）
---@param hand_comp any|nil
---@return boolean
function M.restore_hand_bone_base(hand_comp)
    if hand_bone_base_rot == nil then
        return false
    end
    local comp = M.resolve_right_hand_component(hand_comp) or hand_bone_comp_ref
    if not hand_comp_has_grip_bone(comp) then
        return false
    end
    local ok = pcall(function()
        local base = uevrUtils.rotator(
            hand_bone_base_rot.Pitch,
            hand_bone_base_rot.Yaw,
            hand_bone_base_rot.Roll
        )
        comp:SetBoneRotationByName(hand_bone_fname(), base, bone_space_cs())
    end)
    return ok == true
end

--- 弹簧是否仍在驱动后座
---@return boolean
function M.is_active()
    return recoil_state ~= nil
        and (recoil_state.recoil_active == true or recoil_state.recoil_attack_active == true)
end

-- Root/aim 与手骨旋转安全上限
local AIM_MAX_POS_CM = 80.0
local HAND_MAX_ROT_DEG = 35.0
-- 双手时右手骨后坐倍率（Mesh 已单独上扬，手感需更明显才跟得上枪）
local TWO_HAND_HAND_RECOIL_SCALE = 1.85
local HAND_MAX_ROT_DEG_TWO_HAND = 55.0

--- 读取当前弹簧旋转增量（度），已 clamp；非 active 返回 nil
---@return number|nil pitch_deg, number|nil yaw_deg, number|nil roll_deg
local function get_recoil_rotation_delta_deg()
    if not M.is_active() then
        return nil
    end
    if get_current_weapon_type() ~= seeded_weapon_type then
        return nil
    end
    local recoil = nil
    pcall(function() recoil = recoil_tools.get_recoil_state_table(recoil_state) end)
    if type(recoil) ~= "table" then
        return nil
    end
    local pitch = recoil.pitch or 0.0
    local yaw = recoil.yaw or 0.0
    local roll = recoil.roll or 0.0
    if not (finite_num(pitch) and finite_num(yaw) and finite_num(roll)) then
        return nil
    end
    local pitch_deg = math.deg(pitch)
    local yaw_deg = math.deg(yaw)
    local roll_deg = math.deg(roll)
    if not (finite_num(pitch_deg) and finite_num(yaw_deg) and finite_num(roll_deg)) then
        return nil
    end
    if pitch_deg > HAND_MAX_ROT_DEG then pitch_deg = HAND_MAX_ROT_DEG end
    if pitch_deg < -HAND_MAX_ROT_DEG then pitch_deg = -HAND_MAX_ROT_DEG end
    if yaw_deg > HAND_MAX_ROT_DEG then yaw_deg = HAND_MAX_ROT_DEG end
    if yaw_deg < -HAND_MAX_ROT_DEG then yaw_deg = -HAND_MAX_ROT_DEG end
    if roll_deg > HAND_MAX_ROT_DEG then roll_deg = HAND_MAX_ROT_DEG end
    if roll_deg < -HAND_MAX_ROT_DEG then roll_deg = -HAND_MAX_ROT_DEG end
    return pitch_deg, yaw_deg, roll_deg
end

local function two_hand_mesh_owns_recoil_flag()
    -- WeaponDriver 已把后坐写入可见 Mesh → Root 勿再 apply_to_aim_transform
    return rawget(_G, "__sh2_two_hand_world_drive") == true
        or rawget(_G, "__sh2_two_hand_mesh_recoil_applied") == true
end

--- 右手可视后坐增量；双手时放大，使手跟上武器上扬
---@return number|nil, number|nil, number|nil
local function get_hand_recoil_rotation_delta_deg()
    local pitch_deg, yaw_deg, roll_deg = get_recoil_rotation_delta_deg()
    if pitch_deg == nil then
        return nil
    end
    if not two_hand_mesh_owns_recoil_flag() then
        return pitch_deg, yaw_deg, roll_deg
    end
    local s = TWO_HAND_HAND_RECOIL_SCALE
    local maxd = HAND_MAX_ROT_DEG_TWO_HAND
    local function clamp_deg(v)
        if v > maxd then return maxd end
        if v < -maxd then return -maxd end
        return v
    end
    return clamp_deg(pitch_deg * s), clamp_deg(yaw_deg * s), clamp_deg(roll_deg * s)
end

--- IK 在写 hand_r_bn 前调用：把后坐力旋转叠到当前 IK 目标姿态上（不写控制器）
--- 成功合成时置 visual_rotation_applied，供 main Root 路径避免双重旋转
--- 双手时仍合成右手骨震动（Mesh 另走 long_gun 轴向）；Root 由 two_hand_mesh_owns_recoil 跳过
---@param base_rot any
---@return any
function M.compose_visual_rotation(base_rot)
    if base_rot == nil then
        return base_rot
    end
    local pitch_deg, yaw_deg, roll_deg = get_hand_recoil_rotation_delta_deg()
    if pitch_deg == nil then
        return base_rot
    end
    local ok, composed = pcall(function()
        local recoil_delta = uevrUtils.rotator(pitch_deg, yaw_deg, roll_deg)
        return mathLib.composeRotators(recoil_delta, base_rot)
    end)
    if ok and composed ~= nil then
        visual_rotation_applied = true
        return composed
    end
    return base_rot
end

--- main Root：双手 Mesh 已含完整后坐时跳过二次叠加
---@return boolean
function M.two_hand_mesh_owns_recoil()
    return two_hand_mesh_owns_recoil_flag()
end

--- 本帧 IK 是否已把可视旋转写入手骨目标
---@return boolean
function M.was_visual_rotation_applied()
    return visual_rotation_applied == true
end

--- main 消费标志后清除
function M.clear_visual_rotation_flag()
    visual_rotation_applied = false
end

--- 手骨是否被 Forearms 路径改写过、idle 时需要还原
---@return boolean
function M.hand_needs_restore()
    return hand_bone_dirty == true
end

--- idle / 换枪 / 复位：还原手骨并清缓存（Forearms）
---@param hand_comp any|nil
function M.finish_hand_recoil(hand_comp)
    if hand_bone_dirty and hand_bone_base_rot ~= nil then
        M.restore_hand_bone_base(hand_comp)
    end
    hand_bone_dirty = false
    hand_bone_comp_ref = nil
    clear_hand_bone_base()
end

--- Forearms：把弹簧旋转叠到 hand_r_bn（无 IK 覆盖时可存活到渲染）
--- IK Arms 勿走此路径——由 compose_visual_rotation 在求解器内合成
---@param hand_comp any|nil
---@return boolean
function M.apply_hand_bone_recoil(hand_comp)
    if not M.is_active() then
        return false
    end
    local comp = M.resolve_right_hand_component(hand_comp)
    if comp == nil then
        return false
    end
    if hand_bone_base_rot == nil then
        if not M.cache_hand_bone_base(comp) then
            return false
        end
    end

    local pitch_deg, yaw_deg, roll_deg = get_hand_recoil_rotation_delta_deg()
    if pitch_deg == nil then
        return false
    end

    local ok, err = pcall(function()
        if not M.restore_hand_bone_base(comp) then
            return
        end
        local base_rot = uevrUtils.rotator(
            hand_bone_base_rot.Pitch,
            hand_bone_base_rot.Yaw,
            hand_bone_base_rot.Roll
        )
        if base_rot == nil then
            return
        end
        local recoil_delta = uevrUtils.rotator(pitch_deg, yaw_deg, roll_deg)
        local new_rot = mathLib.composeRotators(recoil_delta, base_rot)
        if new_rot == nil then
            return
        end
        local np, ny, nr = read_pyr(new_rot)
        if np == nil then
            return
        end
        local write_rot = uevrUtils.rotator(np, ny, nr)
        comp:SetBoneRotationByName(hand_bone_fname(), write_rot, bone_space_cs())
        hand_bone_dirty = true
        hand_bone_comp_ref = comp
    end)

    if not ok then
        print("[RECOIL] apply_hand_bone_recoil error: " .. tostring(err))
        return false
    end
    return hand_bone_dirty == true
end

-- =============================================================================
-- [5] Seed 入口：UEVR_09 trigger_right_fire_action enter 回调
-- =============================================================================

function M.on_fire_success(ranged_subcomp, weapon_type)
    if recoil_state == nil then
        return
    end
    if not recoil_tools.CONFIG.enabled then
        return
    end
    local wt = weapon_type or get_current_weapon_type()
    local params = SH2_WEAPON_RECOIL[wt]
    if params == nil then
        return  -- "none" 或未知武器不 seed
    end

    -- 开火瞬间缓存右手握持骨基准（枪 Mesh 已附着 hand_r_bn，随手同转）
    pcall(function()
        M.cache_hand_bone_base(M.resolve_right_hand_component())
    end)

    local now = os.clock()
    local intensity_mult = weapon_intensity_overrides[wt]
        or recoil_tools.CONFIG.intensity_multiplier
    local stabilized = is_stabilized()
    local seed_ok, seed_err = pcall(function()
        recoil_tools.seed_recoil(recoil_state, {
            kick_up_scale = params.kick_up_scale,
            intensity_mult = intensity_mult,
            stabilized = stabilized,
            is_auto = false,  -- SH2 全部单发
            is_heavy = params.is_heavy,
            is_hard_vertical = params.is_hard_vertical,
            source = "trigger_right_fire_action",
            now = now,
            random_01 = math.random(),
        })
    end)
    if not seed_ok then
        print("[RECOIL] seed_recoil error: " .. tostring(seed_err))
        return
    end
    seeded_weapon_type = wt
end

-- =============================================================================
-- [6] Tick：更新弹簧（仅 pre_engine_tick；不注册 post_engine_tick）
-- =============================================================================

function M.on_pre_engine_tick(engine, delta)
    if recoil_state == nil then return end
    visual_rotation_applied = false
    local now = os.clock()

    if not recoil_tools.CONFIG.enabled then
        if recoil_state.recoil_active or recoil_state.recoil_attack_active then
            pcall(recoil_tools.reset_spring, recoil_state)
        end
        seeded_weapon_type = nil
        last_tick_now = now
        return
    end

    -- 换枪或收枪：不允许上一把枪的回弹施加到下一把枪
    local current_type = get_current_weapon_type()
    if seeded_weapon_type ~= nil and current_type ~= seeded_weapon_type then
        pcall(recoil_tools.reset_spring, recoil_state)
        seeded_weapon_type = nil
        pcall(function()
            M.finish_hand_recoil(M.resolve_right_hand_component() or hand_bone_comp_ref)
        end)
    end

    -- dt 由本层 clamp 后传给工具层（工具层不读时钟）
    local dt = 0.0
    if last_tick_now ~= nil then
        dt = now - last_tick_now
        if dt < 0.0 then dt = 0.0 end
        if dt > 0.05 then dt = 0.05 end
    end
    last_tick_now = now

    pcall(recoil_tools.update_recoil_spring, recoil_state, dt)
    local snap_ok, snap = pcall(recoil_tools.get_recoil_state_table, recoil_state)
    if snap_ok and type(snap) == "table" then
        _G.__vr_recoil_state = snap
    end
end

-- =============================================================================
-- [7] 变换合成：main 在 attachment 基准变换算出、但尚未写 Root 时调用
-- 只返回变换；绝不读取/写入 Root/手骨（写入由 main 负责）
-- =============================================================================

--- 合成 base 变换与当前 recoil delta
--- 单位：位置 ×100（米→厘米），旋转 math.deg()（弧度→度）
--- 旋转合成用 mathLib.composeRotators（四元数等价），不直接欧拉相加
--- opts.long_gun_mesh_axes：步枪/霰弹 Mesh 本地轴与手枪手骨不同，上扬走 Roll（Pitch 会侧偏）
---@param base_loc table UEVR Vector（基准世界位置）
---@param base_rot table UEVR Rotator（基准世界旋转）
---@param opts table|nil { long_gun_mesh_axes = bool }
---@return table new_loc, table new_rot
function M.apply_to_aim_transform(base_loc, base_rot, opts)
    if recoil_state == nil then
        return base_loc, base_rot
    end
    if not (recoil_state.recoil_active or recoil_state.recoil_attack_active) then
        return base_loc, base_rot
    end
    -- 当前武器与 seed 时武器类型不一致：reset 并放行（避免把上一把枪的回弹施加到新枪）
    if get_current_weapon_type() ~= seeded_weapon_type then
        pcall(recoil_tools.reset_spring, recoil_state)
        seeded_weapon_type = nil
        pcall(function()
            M.finish_hand_recoil(M.resolve_right_hand_component() or hand_bone_comp_ref)
        end)
        return base_loc, base_rot
    end

    local bx, by, bz = read_xyz(base_loc)
    local bp, bya, br = read_pyr(base_rot)
    if bx == nil or bp == nil then
        return base_loc, base_rot
    end

    local long_gun_mesh = type(opts) == "table" and opts.long_gun_mesh_axes == true

    local ok, result_loc, result_rot = pcall(function()
        local recoil = recoil_tools.get_recoil_state_table(recoil_state)
        if type(recoil) ~= "table" then
            return base_loc, base_rot
        end
        local py = recoil.pos_y or 0.0
        local pz = recoil.pos_z or 0.0
        local pitch = recoil.pitch or 0.0
        local yaw = recoil.yaw or 0.0
        local roll = recoil.roll or 0.0
        if not (finite_num(py) and finite_num(pz) and finite_num(pitch) and finite_num(yaw) and finite_num(roll)) then
            return base_loc, base_rot
        end

        -- 沿武器 up / fwd 偏移：recoil.pos_y > 0 = kick up；recoil.pos_z < 0 = kick back
        local up = uevrUtils.rotateVector(uevrUtils.vector(0, 0, 1), base_rot)  -- UE4 up = Z
        local fwd = uevrUtils.rotateVector(uevrUtils.vector(1, 0, 0), base_rot)  -- UE4 forward = X
        local ux, uy, uz = read_xyz(up)
        local fx, fy, fz = read_xyz(fwd)
        if ux == nil or fx == nil then
            return base_loc, base_rot
        end
        local dx = (ux * py + fx * pz) * RECOIL_POS_UNIT_SCALE
        local dy = (uy * py + fy * pz) * RECOIL_POS_UNIT_SCALE
        local dz = (uz * py + fz * pz) * RECOIL_POS_UNIT_SCALE
        if not (finite_num(dx) and finite_num(dy) and finite_num(dz)) then
            return base_loc, base_rot
        end
        -- Root 瞄准偏移也封顶，避免异常值写入 K2_SetWorld*
        if dx > AIM_MAX_POS_CM then dx = AIM_MAX_POS_CM elseif dx < -AIM_MAX_POS_CM then dx = -AIM_MAX_POS_CM end
        if dy > AIM_MAX_POS_CM then dy = AIM_MAX_POS_CM elseif dy < -AIM_MAX_POS_CM then dy = -AIM_MAX_POS_CM end
        if dz > AIM_MAX_POS_CM then dz = AIM_MAX_POS_CM elseif dz < -AIM_MAX_POS_CM then dz = -AIM_MAX_POS_CM end
        local new_loc = uevrUtils.vector(bx + dx, by + dy, bz + dz)

        local pitch_deg = math.deg(pitch)
        local yaw_deg = math.deg(yaw)
        local roll_deg = math.deg(roll)
        if not (finite_num(pitch_deg) and finite_num(yaw_deg) and finite_num(roll_deg)) then
            return base_loc, base_rot
        end
        if pitch_deg > HAND_MAX_ROT_DEG then pitch_deg = HAND_MAX_ROT_DEG elseif pitch_deg < -HAND_MAX_ROT_DEG then pitch_deg = -HAND_MAX_ROT_DEG end
        if yaw_deg > HAND_MAX_ROT_DEG then yaw_deg = HAND_MAX_ROT_DEG elseif yaw_deg < -HAND_MAX_ROT_DEG then yaw_deg = -HAND_MAX_ROT_DEG end
        if roll_deg > HAND_MAX_ROT_DEG then roll_deg = HAND_MAX_ROT_DEG elseif roll_deg < -HAND_MAX_ROT_DEG then roll_deg = -HAND_MAX_ROT_DEG end
        -- 长枪 Mesh：弹簧“上扬”(pitch) 映到 Roll；取反使枪管上扬（正号会变成枪托上抬）
        local recoil_delta
        if long_gun_mesh then
            recoil_delta = uevrUtils.rotator(roll_deg, yaw_deg, -pitch_deg)
        else
            recoil_delta = uevrUtils.rotator(pitch_deg, yaw_deg, roll_deg)
        end
        local new_rot = mathLib.composeRotators(recoil_delta, base_rot)
        if new_rot == nil then
            return base_loc, base_rot
        end

        return new_loc, new_rot
    end)

    if not ok then
        print("[RECOIL] apply_to_aim_transform error: " .. tostring(result_loc))
        return base_loc, base_rot
    end
    return result_loc, result_rot
end

--- IK 本帧已合成可视旋转时，Root 只补位置 kick，避免旋转双重叠加
---@param base_loc any
---@param base_rot any
---@return any, any
function M.apply_position_kick_only(base_loc, base_rot)
    if recoil_state == nil then
        return base_loc, base_rot
    end
    if not (recoil_state.recoil_active or recoil_state.recoil_attack_active) then
        return base_loc, base_rot
    end
    if get_current_weapon_type() ~= seeded_weapon_type then
        pcall(recoil_tools.reset_spring, recoil_state)
        seeded_weapon_type = nil
        return base_loc, base_rot
    end

    local bx, by, bz = read_xyz(base_loc)
    if bx == nil then
        return base_loc, base_rot
    end

    local ok, result_loc = pcall(function()
        local recoil = recoil_tools.get_recoil_state_table(recoil_state)
        if type(recoil) ~= "table" then
            return base_loc
        end
        local py = recoil.pos_y or 0.0
        local pz = recoil.pos_z or 0.0
        if not (finite_num(py) and finite_num(pz)) then
            return base_loc
        end
        local up = uevrUtils.rotateVector(uevrUtils.vector(0, 0, 1), base_rot)
        local fwd = uevrUtils.rotateVector(uevrUtils.vector(1, 0, 0), base_rot)
        local ux, uy, uz = read_xyz(up)
        local fx, fy, fz = read_xyz(fwd)
        if ux == nil or fx == nil then
            return base_loc
        end
        local dx = (ux * py + fx * pz) * RECOIL_POS_UNIT_SCALE
        local dy = (uy * py + fy * pz) * RECOIL_POS_UNIT_SCALE
        local dz = (uz * py + fz * pz) * RECOIL_POS_UNIT_SCALE
        if not (finite_num(dx) and finite_num(dy) and finite_num(dz)) then
            return base_loc
        end
        if dx > AIM_MAX_POS_CM then dx = AIM_MAX_POS_CM elseif dx < -AIM_MAX_POS_CM then dx = -AIM_MAX_POS_CM end
        if dy > AIM_MAX_POS_CM then dy = AIM_MAX_POS_CM elseif dy < -AIM_MAX_POS_CM then dy = -AIM_MAX_POS_CM end
        if dz > AIM_MAX_POS_CM then dz = AIM_MAX_POS_CM elseif dz < -AIM_MAX_POS_CM then dz = -AIM_MAX_POS_CM end

        return uevrUtils.vector(bx + dx, by + dy, bz + dz)
    end)

    if not ok then
        print("[RECOIL] apply_position_kick_only error: " .. tostring(result_loc))
        return base_loc, base_rot
    end
    return result_loc, base_rot
end

-- =============================================================================
-- [8] 初始化
-- =============================================================================

function M.init()
    -- 热重载 / 重新 init：先清掉上一轮可能残留的手骨偏移
    pcall(function()
        M.finish_hand_recoil(hand_bone_comp_ref)
    end)

    recoil_state = recoil_tools.new_state()

    -- 加载持久化配置（json 由 UEVR_00_init_globals 安装的全局 shim）
    -- 兼容两套键：apply_settings 协议键，以及 configui 面板 widget id
    local data = nil
    pcall(function() data = json.load_file(RECOIL_CFG_PATH) end)
    if type(data) == "table" then
        local settings = {
            enabled = data.enabled,
            intensity_multiplier = data.intensity_multiplier,
            recoil_stabilized_impulse_mult = data.recoil_stabilized_impulse_mult,
            recoil_stabilized_requires_both = data.recoil_stabilized_requires_both,
            weapon_intensity_overrides = data.weapon_intensity_overrides,
        }
        -- configui 扁平 widget id → 协议键（面板存档优先）
        if data.recoil_enabled ~= nil then settings.enabled = data.recoil_enabled end
        if data.recoil_intensity ~= nil then settings.intensity_multiplier = data.recoil_intensity end
        if data.recoil_stab_impulse ~= nil then settings.recoil_stabilized_impulse_mult = data.recoil_stab_impulse end
        if data.recoil_stab_requires_both ~= nil then settings.recoil_stabilized_requires_both = data.recoil_stab_requires_both end
        if settings.weapon_intensity_overrides == nil then
            local ov = {}
            if type(data.override_pistol) == "number" and data.override_pistol > 0 then ov.pistol = data.override_pistol end
            if type(data.override_shotgun) == "number" and data.override_shotgun > 0 then ov.shotgun = data.override_shotgun end
            if type(data.override_rifle) == "number" and data.override_rifle > 0 then ov.rifle = data.override_rifle end
            if next(ov) ~= nil then settings.weapon_intensity_overrides = ov end
        end
        recoil_tools.apply_settings(settings)

        -- 其余面板滑块直接写 CONFIG（非开发者模式跳过 UI 时仍生效）
        local direct = {
            recoil_pos_intensity = "recoil_position_intensity",
            recoil_rot_intensity = "recoil_rotation_intensity",
            recoil_randomness = "recoil_randomness",
            recoil_stack_cap = "recoil_stack_cap",
            recoil_stiffness = "recoil_spring_stiffness",
            recoil_damping = "recoil_spring_damping",
            recoil_attack_duration = "recoil_attack_duration",
            recoil_unsup_heavy = "recoil_unsupported_heavy_mult",
            recoil_unsup_light = "recoil_unsupported_light_mult",
            recoil_kick_up_ratio = "recoil_kick_up_ratio",
            recoil_hard_vert_mult = "recoil_unsupported_hard_vertical_mult",
            recoil_hard_stiffness_mul = "recoil_hard_return_stiffness_mul",
            recoil_hard_damping_mul = "recoil_hard_return_damping_mul",
            recoil_sustained_damping = "recoil_sustained_damping",
            recoil_sustained_window = "recoil_sustained_window",
            recoil_yaw_ratio = "recoil_yaw_ratio",
            recoil_roll_intensity = "recoil_roll_intensity",
        }
        for wid, key in pairs(direct) do
            local val = data[wid]
            if type(val) == "number" and val == val then
                recoil_tools.CONFIG[key] = val
            end
        end
    end
    weapon_intensity_overrides = recoil_tools.CONFIG.weapon_intensity_overrides or {}

    -- Seed 由 UEVR_09 trigger_right_fire_action enter → M.on_fire_success（不再 register_fire_listener）

    -- 高优先级 preEngineTick：先更新弹簧，再让 IK 求解器 compose_visual_rotation
    if not pre_tick_registered then
        uevrUtils.registerPreEngineTickCallback(function(engine, delta)
            return M.on_pre_engine_tick(engine, delta)
        end, 10000)
        pre_tick_registered = true
    end

    -- 发布弹簧快照与模块表（供 UEVR_09 / ik.lua 调用）
    _G.__vr_recoil_state = { active = false, pos_y = 0, pos_z = 0, pitch = 0, yaw = 0, roll = 0 }
    _G.__sh2_recoil_module = M

    print("[RECOIL] SH2 recoil module initialized (motion only; seed=trigger_right_fire_action)")
end

-- =============================================================================
-- [9] 配置 UI（内嵌在 recoil.lua 中）
-- 使用 configui 系统创建滑块面板，持久化到 recoil_intensity.json。
-- =============================================================================

-- 重建 weapon_intensity_overrides 表（从 configui 滑块值）
local function sync_overrides_to_config()
    if configui == nil then return end
    local ov = {}
    local p = configui.getValue("override_pistol")
    local s = configui.getValue("override_shotgun")
    local r = configui.getValue("override_rifle")
    if p and p > 0 then ov["pistol"] = p end
    if s and s > 0 then ov["shotgun"] = s end
    if r and r > 0 then ov["rifle"] = r end
    recoil_tools.CONFIG.weapon_intensity_overrides = ov
    -- 同步到本地缓存，确保 on_fire_success 对新值生效
    weapon_intensity_overrides = ov
end

-- 从 configui 已加载的 JSON 值同步到 recoil_tools.CONFIG
local function sync_all_to_config()
    if configui == nil then return end
    local function v(id, default)
        local val = configui.getValue(id)
        if val == nil then return default end
        return val
    end

    recoil_tools.CONFIG.enabled = v("recoil_enabled", true)
    recoil_tools.CONFIG.intensity_multiplier = v("recoil_intensity", 3.0)
    recoil_tools.CONFIG.recoil_position_intensity = v("recoil_pos_intensity", 0.0105)
    recoil_tools.CONFIG.recoil_rotation_intensity = v("recoil_rot_intensity", 0.072)
    recoil_tools.CONFIG.recoil_randomness = v("recoil_randomness", 0.22)
    recoil_tools.CONFIG.recoil_stack_cap = v("recoil_stack_cap", 2.0)
    recoil_tools.CONFIG.recoil_spring_stiffness = v("recoil_stiffness", 120.0)
    recoil_tools.CONFIG.recoil_spring_damping = v("recoil_damping", 20.0)
    recoil_tools.CONFIG.recoil_attack_duration = v("recoil_attack_duration", 0.024)
    -- SH2 不支持单手开火；双手稳定后座与未稳定同为 1.0（避免“吸住枪飘”的弱后座感）
    recoil_tools.CONFIG.recoil_stabilized_impulse_mult = v("recoil_stab_impulse", 1.0)
    recoil_tools.CONFIG.recoil_unsupported_heavy_mult = v("recoil_unsup_heavy", 1.9)
    recoil_tools.CONFIG.recoil_unsupported_light_mult = v("recoil_unsup_light", 1.18)
    recoil_tools.CONFIG.recoil_kick_up_ratio = v("recoil_kick_up_ratio", 0.85)
    recoil_tools.CONFIG.recoil_unsupported_hard_vertical_mult = v("recoil_hard_vert_mult", 1.48)
    recoil_tools.CONFIG.recoil_hard_return_stiffness_mul = v("recoil_hard_stiffness_mul", 0.58)
    recoil_tools.CONFIG.recoil_hard_return_damping_mul = v("recoil_hard_damping_mul", 0.82)
    recoil_tools.CONFIG.recoil_sustained_damping = v("recoil_sustained_damping", 30.0)
    recoil_tools.CONFIG.recoil_sustained_window = v("recoil_sustained_window", 0.12)
    recoil_tools.CONFIG.recoil_yaw_ratio = v("recoil_yaw_ratio", 0.50)
    recoil_tools.CONFIG.recoil_roll_intensity = v("recoil_roll_intensity", 0.022)
    recoil_tools.CONFIG.recoil_stabilized_requires_both = v("recoil_stab_requires_both", false)
    sync_overrides_to_config()
end

function M.init_config_ui()
    if configui == nil or configui.createConfigPanel == nil then
        print("[RECOIL] configui not available, skipping config UI")
        return
    end

    local widgets = {
        -- Enable
        { widgetType = "checkbox",   id = "recoil_enabled",          label = "Enable Recoil",          initialValue = true },

        -- Intensity
        { widgetType = "tree_node",  id = "recoil_tree_intensity",   label = "Intensity",              initialOpen = true },
        { widgetType = "slider_float", id = "recoil_intensity",       label = "Global Multiplier",     initialValue = 3.0,   range = {0, 10},      format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_pos_intensity",   label = "Position Intensity",    initialValue = 0.0105, range = {0, 0.05},    format = "%.4f" },
        { widgetType = "slider_float", id = "recoil_rot_intensity",   label = "Rotation Intensity",    initialValue = 0.072,  range = {0, 0.5},     format = "%.4f" },
        { widgetType = "slider_float", id = "recoil_randomness",      label = "Randomness",            initialValue = 0.22,   range = {0, 1},       format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_stack_cap",       label = "Stack Cap",             initialValue = 2.0,    range = {0, 5},       format = "%.1f" },
        { widgetType = "tree_pop" },

        -- Spring
        { widgetType = "tree_node",  id = "recoil_tree_spring",     label = "Spring Physics",         initialOpen = false },
        { widgetType = "slider_float", id = "recoil_stiffness",      label = "Stiffness",             initialValue = 120.0,  range = {0, 500},     format = "%.0f" },
        { widgetType = "slider_float", id = "recoil_damping",        label = "Damping",               initialValue = 20.0,   range = {0, 100},     format = "%.0f" },
        { widgetType = "slider_float", id = "recoil_attack_duration", label = "Attack Duration (sec)", initialValue = 0.024,  range = {0, 0.1},     format = "%.4f" },
        { widgetType = "slider_float", id = "recoil_sustained_damping", label = "Sustained Damping",  initialValue = 30.0,   range = {0, 100},     format = "%.0f" },
        { widgetType = "slider_float", id = "recoil_sustained_window",  label = "Sustained Window",   initialValue = 0.12,   range = {0, 0.5},     format = "%.3f" },
        { widgetType = "tree_pop" },

        -- Stabilization
        { widgetType = "tree_node",  id = "recoil_tree_stab",       label = "Stabilization",          initialOpen = false },
        { widgetType = "checkbox",   id = "recoil_stab_requires_both", label = "Stabilized Requires Both Hands", initialValue = false },
        { widgetType = "slider_float", id = "recoil_stab_impulse",    label = "Stabilized Impulse Mult", initialValue = 1.0, range = {0, 1},     format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_unsup_heavy",     label = "Unsupported Heavy Mult",  initialValue = 1.9,  range = {0, 5},     format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_unsup_light",     label = "Unsupported Light Mult",  initialValue = 1.18, range = {0, 5},     format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_hard_vert_mult",  label = "Hard Vertical Mult",      initialValue = 1.48, range = {0, 5},     format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_hard_stiffness_mul", label = "Hard Return Stiffness",  initialValue = 0.58, range = {0, 1},  format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_hard_damping_mul",   label = "Hard Return Damping",    initialValue = 0.82, range = {0, 1},  format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_kick_up_ratio",     label = "Kick Up Ratio",          initialValue = 0.85, range = {0, 2},  format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_yaw_ratio",         label = "Yaw Ratio",              initialValue = 0.50, range = {0, 1},  format = "%.2f" },
        { widgetType = "slider_float", id = "recoil_roll_intensity",    label = "Roll Intensity",         initialValue = 0.022, range = {0, 0.1}, format = "%.4f" },
        { widgetType = "tree_pop" },

        -- Per-Weapon Override
        { widgetType = "tree_node",  id = "recoil_tree_override",   label = "Per-Weapon Override",     initialOpen = false },
        { widgetType = "text",       label = "0 = use global multiplier" },
        { widgetType = "slider_float", id = "override_pistol",       label = "Pistol",                initialValue = 0,     range = {0, 5},       format = "%.2f" },
        { widgetType = "slider_float", id = "override_shotgun",      label = "Shotgun",               initialValue = 0,     range = {0, 5},       format = "%.2f" },
        { widgetType = "slider_float", id = "override_rifle",        label = "Rifle",                 initialValue = 0,     range = {0, 5},       format = "%.2f" },
        { widgetType = "tree_pop" },
    }

    -- saveFile 不带 .json（configui 内部会拼 fileName .. ".json"）
    configui.createConfigPanel("Recoil Config", RECOIL_CFG_FILE, widgets)

    -- 从 JSON 加载后同步到 recoil_tools.CONFIG
    sync_all_to_config()

    -- 注册实时同步回调
    configui.onUpdate("recoil_enabled", function(value)
        recoil_tools.CONFIG.enabled = value
    end)
    configui.onUpdate("recoil_intensity", function(value)
        recoil_tools.CONFIG.intensity_multiplier = value
    end)
    configui.onUpdate("recoil_pos_intensity", function(value)
        recoil_tools.CONFIG.recoil_position_intensity = value
    end)
    configui.onUpdate("recoil_rot_intensity", function(value)
        recoil_tools.CONFIG.recoil_rotation_intensity = value
    end)
    configui.onUpdate("recoil_randomness", function(value)
        recoil_tools.CONFIG.recoil_randomness = value
    end)
    configui.onUpdate("recoil_stack_cap", function(value)
        recoil_tools.CONFIG.recoil_stack_cap = value
    end)
    configui.onUpdate("recoil_stiffness", function(value)
        recoil_tools.CONFIG.recoil_spring_stiffness = value
    end)
    configui.onUpdate("recoil_damping", function(value)
        recoil_tools.CONFIG.recoil_spring_damping = value
    end)
    configui.onUpdate("recoil_attack_duration", function(value)
        recoil_tools.CONFIG.recoil_attack_duration = value
    end)
    configui.onUpdate("recoil_stab_requires_both", function(value)
        recoil_tools.CONFIG.recoil_stabilized_requires_both = value
    end)
    configui.onUpdate("recoil_stab_impulse", function(value)
        recoil_tools.CONFIG.recoil_stabilized_impulse_mult = value
    end)
    configui.onUpdate("recoil_unsup_heavy", function(value)
        recoil_tools.CONFIG.recoil_unsupported_heavy_mult = value
    end)
    configui.onUpdate("recoil_unsup_light", function(value)
        recoil_tools.CONFIG.recoil_unsupported_light_mult = value
    end)
    configui.onUpdate("recoil_hard_vert_mult", function(value)
        recoil_tools.CONFIG.recoil_unsupported_hard_vertical_mult = value
    end)
    configui.onUpdate("recoil_hard_stiffness_mul", function(value)
        recoil_tools.CONFIG.recoil_hard_return_stiffness_mul = value
    end)
    configui.onUpdate("recoil_hard_damping_mul", function(value)
        recoil_tools.CONFIG.recoil_hard_return_damping_mul = value
    end)
    configui.onUpdate("recoil_sustained_damping", function(value)
        recoil_tools.CONFIG.recoil_sustained_damping = value
    end)
    configui.onUpdate("recoil_sustained_window", function(value)
        recoil_tools.CONFIG.recoil_sustained_window = value
    end)
    configui.onUpdate("recoil_kick_up_ratio", function(value)
        recoil_tools.CONFIG.recoil_kick_up_ratio = value
    end)
    configui.onUpdate("recoil_yaw_ratio", function(value)
        recoil_tools.CONFIG.recoil_yaw_ratio = value
    end)
    configui.onUpdate("recoil_roll_intensity", function(value)
        recoil_tools.CONFIG.recoil_roll_intensity = value
    end)
    configui.onUpdate("override_pistol", function(_)
        sync_overrides_to_config()
    end)
    configui.onUpdate("override_shotgun", function(_)
        sync_overrides_to_config()
    end)
    configui.onUpdate("override_rifle", function(_)
        sync_overrides_to_config()
    end)

    print("[RECOIL] Recoil config UI registered")
end

return M
