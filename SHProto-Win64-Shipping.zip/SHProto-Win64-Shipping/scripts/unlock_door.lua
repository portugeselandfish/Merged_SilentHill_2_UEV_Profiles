--[[
Door Latch Grab：左手拉门栓横杆（DoorLatchBar）
- Phase 0：枚举器 + 3m 内全量缓存
- Phase 1：吸附、高亮、滑动（grip）、回弹、状态机
- 目标 mesh：DoorLatchBar（非 DoorLatch 底座、非 DoorLatchSocket）
- Phase 1.b：藏本体 DoorLatchBar + spawn 同 mesh 表演体跟手拖动
-- 参考：remote_grab.lua、reload_tools.lua、rifle_diagnose B-3 摆位
-- 诊断：diagnose_open_latch.lua
--
--[[修改说明（缓存自愈 native/BP 对照，2026-08-31）：
1. 门栓(latch)/钥匙(key-on-door)：查 Class /Script/Engine.StaticMeshComponent（同一 SMC 扫描，仅按 mesh 名分 latch/key）；
   滑门(glide)：查 Class /Script/SHProto.SHSlidingDoor —— 均 /Script/ native 类，类指针稳定，无需 clearClassCache 自愈。
   为何 native 无需自愈：类对象常驻不过期，空结果本就有意义（该区域确实无实例），且 SMC 是全图大枚举，
   清缓存立即重扫只会翻倍最贵路径开销、清不出新东西。正确降级是 latch_cache_valid=false + 周期重建，非 heal。
2. 抽屉(drawer)：查 BlueprintGeneratedClass /Game/.../InteractiveDrawer_Base_ABP_C（BP 蓝图类）——
   读档/切场景后 BP 类可能 GC/重载，classCache 旧引用失配 → get_objects_by_class 空表扫不出（读档后要重载脚本的根因）。
   故抽屉查询必须走 query_with_heal 自愈：nil/空 → clearClassCache → 重扫；仍空由统一 5+2 重试兜底（见下方 check_cache_invalidation）。抽屉是同 L1 内唯一需自愈的扫描。
]]
--[[修改说明（推柜双单点吸附 → 正方形吸附面，2026-09-01）：
1. PUSH_SPOT_A/X=-65、PUSH_SPOT_B/X=+60（用户把 B 由 +65 改 +60，与诊断脚本 SPOT_B_LOCAL.X=60 同步）作为吸附面中心不动。
2. 新增常量 PUSH_FACE_HALF_Y=20 / PUSH_FACE_HALF_Z=20：把每个锚点从"单点"升级为"以锚点为中心、柜前面板本地 Y-Z 平面上的 40×40 正方形吸附面"。
3. find_push_nearest 由"手到锚点距离"改为"手到吸附面最近点距离"：dvec = 手-中心，投影到本地 Y/Z，clamp 到 ±HALF，最近点距离² = 面外分量² + 面内残差²。
4. 新增 state.push_anchor_local：本次吸附点落在面内的本地偏移（Y/Z 被 clamp），供挂手复用；A/B 分组仍看 push_spot_local 常量引用，不变。
5. 正方形随柜移动每帧跟随：检测阶段基于 get_push_root_pose 实时根 pose 每帧重算；吸附后手刚性挂柜 StaticMesh、面定义在柜本地系内随柜 TeleportAbsolute 移动。实现零新增底层库（复用 math_lib.childWorldTransform / vectorRotate / vectorDot）。
]]
--[[修改说明（推车阶段3 自由跟手移动，2026-09-02）：
1. 移动模型 = 自由跟手（照抄诊断脚本 diagnose_cart.lua on_tick_follow，用户定案纠正计划 §6 原"复用推柜轴向链路"）：
   抓握瞬间（begin_push_cart_move 只执行一次）记 cart_start_world = 车根实时世界位（Z 锁基准）、
   cart_anchor_offset = 投影点 C′ 世界（get_cart_proj_world，t 已冻结）− 车根世界（常量锚点偏移）。
2. update_push_cart 每帧：目标根 X/Y = 手位置 − cart_anchor_offset（X/Y 1:1 跟手、任意方向），
   目标 Z = cart_start_world.Z（锁死，小车不能上下移动）→ entry.SHPushable:TeleportAbsolute（转角天然锁定）。
3. 无轴向投影、无 calc_slide_pull_anchored/capture_slide_anchor/horizontalYawDir 驱动、无灵敏度系数。
4. on_grab_tick：ATTACHED cart 分支 grip 按下 → PHASE.PUSHING；PUSHING 分支按 current_type 分流
   （cart 走 begin_push_cart_move + update_push_cart；push 走原轴向链路 begin_push_move + update_push）。
5. 音效/震动严格留阶段4（本阶段不播 StartPush、不震动）；本阶段不加诊断（用户定案，纯移动逻辑）。
]]
--[[修改说明（推车碰撞：全部组件关 Pawn 碰撞，2026-09-02）：
1. 曾收敛为只关折叠把手锚点 StaticMesh_Handle_R，实车测试证明仍不够（车身/轮轴挡手），
   用户定案改回"对车全部 PrimitiveComponent 关对角色(Pawn)碰撞"（与 diagnose_cart 按钮3 同法）。
2. 实现：set_cart_pawn_collision 改为遍历 get_cart_comp_cache(actor) 取得的全部 PrimitiveComponent，
   逐个 SetCollisionResponseToChannel(2,0)/(2,2)，关/开对称；恢复逻辑（on_cart_target_cleared）不变。
3. resolve_cart_handle + CART_HANDLE_COMP_NAMES 保留（attach/最近点检测仍按名定位锚点），不解绑。
4. 幂等守卫 / L2 命中即关、离开3米即恢复的时机全部不变，仅把"单组件"换成"全组件"。
]]
--[[修改说明（命中关碰撞改分帧 + mesh 不缓存，2026-09-04）：
1. 背景：L2 命中帧原本同步做"枚举该车全部 PrimitiveComponent + 逐个 SetCollisionResponseToChannel"，首次接近会卡顿一下。
2. 定案（用户）：命中改分帧——命中帧只登记守卫 + 待办任务，真正枚举全组件(每车约 9 mesh：4轮+4把手+1本体)并设碰撞放下一次 update_l2_cache(≤1s)执行；碰撞晚一点无碍，1s 内完成即可。
3. mesh 不再缓存：去除 cart_comp_cache/state.cart_comp_cache；get_cart_comp_cache 退化为纯即时枚举，不跨生命周期持有 mesh 指针，连带根治"小车销毁→地址复用→假命中旧列表→碰撞开关无效"的野指针隐患。
4. self-cancel：待办任务每次驱动检查 state.cart_collision_off_actor 仍==本车才 apply；离场/切换/到位恢复(置空守卫)后自动丢弃，不会迟到再关。恢复路径(set_cart_pawn_collision(false))保持同步，因恢复是事件触发非逐车热路径、必须即时。
]]
--[[修改说明（branch_poll_check 轮询补扫优化——方案1 每分支独立休眠，2026-09-04）：
1. 问题：原触发条件 is_empty=(push==0)or(PushNClimb==0) 下，缺任一族的地图（无柜/无车/两样全无）会
   永久每 30s 触发一趟 find_all_of(PUSH_BASE_CLASS) 全量重扫（大图 ~175ms/趟），造成周期性卡顿。
2. 方案1（纯 Lua，扫描层不变——仍一次 find_all_of 整体刷新两分支）：
   - 触发条件改为按分支"为空 且 未休眠"：push_needs/pn_needs 独立判定，任一需扫才触发本轮重扫。
   - 重扫后逐分支结算（settle_branch）：计数>0 → attempts 清零、解除休眠（满意即停）；
     计数==0 → attempts+1，达 POLL_DORMANT_AFTER(3) → dormant=true 本关休眠（3次×30s=90s 流送窗口封顶）。
   - 两分支来自同一次扫描，任一分支需扫都会整体刷新另一分支，故两分支都结算（带空/带满对称）。
   - 换关/切场景/pawn 变化触发 L1 重建时重置 attempts/dormant，新关重新学习。
3. 效果：缺族地图由"每 30s 永久卡"降为"进关最坏 3 次 + 休眠后零扫描"；两族都有的地图行为不变。
4. 热重载兼容：state 复用旧对象时给 POLL_DORMANT_AFTER/push_attempts/pn_attempts/push_dormant/pn_dormant 补默认。
5. 休眠分支由诊断脚本的 World.Levels 流送哨兵（方案2）在真正流送关卡加载时唤醒（见 diagnose_pushable.lua）。
]]
--[[修改说明（新增目标车到位三态只读 getter，2026-09-04）：
1. 新增 M.get_cart_arrival_state(cart_actor)，只读返回 nil(配不到spot)/false(配到未到位)/true(配到且到位)，
   供 diagnose_cart.lua 打印主脚本【真实】三态。不修改任何状态。
2. 需要原因：主脚本各到位分支（L2 命中/PUSHING 轮询内联，原 is_cart_in_desired_spot 已内联删除）
   把"配不到"折叠成 false，无法区分"配到未到位"vs"配不到"，而"配不到"(读档后 L1 未自愈)正是要定位的场景；诊断据此暴露。
3. 实现：内部用主脚本 L1 索引 state.desired_spot_by_managed(keyed by cart addr) 取 spot，
   实时调 spot:IsManagedActorInDesiredSpot() 判到位；只读，不改 state。
]]
--[[修改说明（推车阶段4 音效落地 Grab/StartPush/StopPush，2026-09-02）：
1. 震动：仅开始推车单次（begin_push_cart_move 末尾 play_glide_pull_haptic，复用推柜/推拉门震动，
   不改 11 号文件；cart_start_world==nil 守卫天然每次抓握推车震一次）。
2. 音效：诊断脚本三按钮已验证 → 正式落码（play_cart_audio_event 读 cart_target 的 SHPushableAudio
   组件字段，经 libs.audio.play_event_on_component 播放，同 push 链路）：
   - begin_cart_attach（左手吸附）→ GrabSoundEvent
   - begin_push_cart_move（开始推动）→ StartPushSoundEvent
   - detach_from_latch（脱手，仅 cart 型）→ StopPushSoundEvent
   失败静默跳过、严禁控制台；复用 __sh2_audio_module，日志走 l1/diagnose 文件。
]]
--[[修改说明（推车 detach 反吸附冷却 1s，全分支生效，2026-09-02）：
1. 现象：松手(刻意 detach)的瞬间，若手仍在 Handle 吸附范围内，下一帧 IDLE 自动吸附又把它吸回 →"松手→又被吸回"跳变。
2. 方案：detach_from_latch 是全部类型共用的唯一脱手入口 ⇒ 冷却加在共享函数里，全分支生效。
   detach 时置 state.detach_cooldown_until = os.clock()+1.0；on_grab_tick 的 IDLE/APPROACHING
   自动吸附前门控：冷却期内不自动吸回，给玩家 1s 从容离手。冷却结束才恢复自动吸附。
]]
--[[修改说明（推车到位守卫：已到位=IsManagedActorInDesiredSpot 则不关碰撞 + 推中轮询强制脱手，2026-09-02）：
1. 已到位读取：DesiredSpot 配对 + IsManagedActorInDesiredSpot()，与 diagnose_cart.lua do_spot_scan 完完全全同法
   （uevrUtils.find_all_of(DESIRED_SPOT_CLASS,false) → spot.ManagedActor==cart_actor 配对 → IsManagedActorInDesiredSpot）。
   弃用 Timeline_CollapsingHandlesAnim 折叠 alpha 读取（实测即使折叠开始播放位置也读不出）。
2. L2 命中（on_cart_target_selected）：每次刷到新条目先判已到位，true → 不枚举 primitive component、
   不关 Pawn 碰撞，并打 complete 标记（state.cart_completed，keyed by actor:get_address()）。
3. 推车中（PUSHING cart 分支）：每 CART_FOLD_CHECK_INTERVAL=0.3s 轮询已到位，一旦 true →
   打 complete 标记 + 强制 detach_from_latch + 恢复全部组件碰撞（ECC_Pawn→Block）。
4. complete 标记防回退：后续 L2 命中同一车直接跳过碰撞管理（防下一帧又把碰撞关了）；
   L1 重建时清空 complete 标记与状态（换关后 actor 全新；同车仍到位则 L2 到位检测重新标记）。
5. 日志：l1_trace_add（内存）+ cart_trace("FOLD")（写 diagnose_cart.log，受 CART_DIAG_ENABLED 管理），严禁控制台。
]]
--[[修改说明（L2 glide 条目只读透传完整字段，2026-09-02）：
1. 仅 update_l2_cache 内 L2 结果表对 glide 分支新增只读引用字段：
   actor / door_mesh / spot / spot_rot / spot_axis / open_sign / movement（全部取自 L1 entry，不改任何行为）。
2. 目的：diagnose_open_latch.lua 的 B 点探测 / Door 解锁测试 / alpha 滑块等改读 L2（唯一对象门）即用，
   不再依赖诊断脚本自建 diag.latch_cache。L2 每次 update_l2_cache 重建全新表，只读引用无副作用。
3. 纯新增字段，不改既有字段、不改 L1 构建、不改 L3 find_nearest_to_hand 判定。
]]
--[[修改说明（glide 滑块实时预览：原地重挂 + force_reattach 死引用修复，2026-09-03）：
1. 现象：诊断面板 glide 偏移/旋转滑块拖动后画面不变，须松手重新吸附才能看到新参数。
   根因：force_reattach 先捕获 target=state.perf_mesh，再 remove_grip_anim()（内部 destroy_perf
   销毁表演体、perf_mesh=nil），然后把已销毁的旧 target 传给 apply_grip_anim；
   apply_grip_anim 内 `tgt = target or state.perf_mesh or ...` 优先命中死引用 → 挂手静默失败
   （面板还打印 reattach=true）。
2. 修复 force_reattach：不再预先捕获 target，remove_grip_anim 后由 apply_grip_anim 现选
   （perf 族现场重生表演体，switch 族用 state.latch_component），全类型滑块预览恢复可用。
3. 新增 M.update_glide_hand_attach()：仿 update_switch_hand_attach 的原地重挂（不 detach、
   不销毁表演体），用最新 GLIDE_HAND_OFFSET/_REV + A/B 吸附条 t 插值重算 loc/rot 后重新
   on_accessory_attach，glide 滑块拖动即时生效、无闪烁。诊断面板 glide 分支优先走此函数，
   失败时回退 force_reattach。
4. apply_grip_anim 的 glide loc/rot 计算（offset 选组/反向门判定/yaw+180/吸附条落点并入）
   原样抽出到本地函数 compute_glide_hand_pose，供 apply_grip_anim 与 update_glide_hand_attach
   复用；纯搬运不改行为，诊断面板 glide 滑块重挂一次即调一次，无副作用。
]]
--[[修改说明（DesiredSpot 配对索引上移 L1，去小车首接近卡顿，2026-09-04）：
1. 问题：get_cart_desired_spot 原在 L2 命中帧对每辆新车首接近跑一次 find_all_of(CART_DESIRED_SPOT_CLASS)
   全图扫描（BP 类）后按车缓存，是"首接近小车卡一下"的主要来源。
2. 方案：把 DesiredSpot 上移为 L1 全局索引，由共享函数 rebuild_desired_spot_index() 建立
   （自愈同 query_with_heal：读档 GC/重载→clearClassCache 重扫），按 spot.ManagedActor 建成
   state.desired_spot_by_managed[cart_addr]=spot；L2 get_cart_desired_spot 改为 O(1) 查表，零全图扫描、零自愈。
3. 同步性：DesiredSpot 与 PushNClimb 1:1 成对且为关卡静态对象，故在两处小车扫描处各调一次
   rebuild_desired_spot_index()——build_l1_cache 全量重建（读档/切关）+ branch_poll_check 分支轮询（流送），
   保证"小车进入 L1"与"它的 spot 配对入索引"完全同步，杜绝"车在 L1、spot 索引没有它→已到位车误关碰撞"。
   顺带修掉原 cart_desired_spot_cache"L1 清理命中的是同名全局死变量、真正 local 缓存从未被重建清空"的旧隐患。
4. 索引未收录（无配对/极早期）→ 返回 nil → 视为未到位，行为安全。
5. 仅 DesiredSpot 上移；mesh 组件枚举缓存 cart_comp_cache 的野指针问题，由下一轮"改分帧 + 不缓存"（见文件顶 2026-09-04 块）一并吸收根治。
]]

--[[修改说明（2026-09-04，统一 pawn 检测，方案A）：
1. pawn 变化检测上移到 main.lua（check_pawn_globally 广播 on_pawn_changed）。
2. 本文件 check_cache_invalidation 删除自检测 pawn 块，只保留 L1 重建调度执行 + 2s 重试 + PUSH 补扫。
3. 新增 M.on_pawn_changed(reason)：pawn_nil 清 pending/retry；pawn_changed/level_change 调度重建。
4. 不新增诊断日志（复用现有 diag_log(UDOOR) 通路）。
5. 补修（code-review）：get_l1_diag().last_pawn_ref 与 get_l1_trace() 的 pawn 字段改读权威全局
   _G.__sh2_global_pawn_ref（原 state.last_pawn_ref 已随自检测删除，恒为 nil 失效）。
]]

local uevrUtils = require("libs/uevr_utils")
local reload_tools = require("libs/reload_tools")
local controllers = require("libs/controllers")
local hands = require("libs/hands")
local vr_globals = require("UEVR_00_init_globals")
local eventFeedback = require("UEVR_11_EventFeedback")
local math_lib = require("libs.core.math_lib")
local uevr_lib = require("libs/core/uevr_lib") -- 仅用 clearClassCache（与 uevrUtils 同一实例）

local M = {}

-- 每帧取 _G：模块若早于 uevr_utils init 加载，缓存 upvalue 会一直是 nil
local function get_reusable_hit()
    return rawget(_G, "reusable_hit_result")
end

-- =============================================================================
-- 门栓横杆 + 钥匙白名单
-- DoorLatchBar: 门栓横杆（须写全，勿用 DoorLatch——会误匹配底座/Socket）
-- KeyFlat: 钥匙已在门上的门锁（key-on-door，需拧动解锁）
-- =============================================================================
local WHITELIST = { "DoorLatchBar", "KeyFlat" }

local function mesh_name_matches(name)
    if name == nil then return false end
    for _, w in ipairs(WHITELIST) do
        if string.find(name, w, 1, true) then
            return true
        end
    end
    return false
end

--- 根据 mesh 名判定缓存条目类型
--- @param mesh_name string|nil StaticMesh 全名
--- @return string|nil "latch" / "key" / nil（不匹配白名单）
local function get_entry_type(mesh_name)
    if mesh_name == nil then return nil end
    if string.find(mesh_name, "DoorLatchBar", 1, true) then return "latch" end
    if string.find(mesh_name, "KeyFlat", 1, true) then return "key" end
    return nil
end

-- 不同型号 latch bar 的滑动完成阈值（cm）
-- DoorLatchBar_01_A：8cm（默认）
-- DoorLatchBar_01_B：15cm
-- DoorLatchBar_02_A：15cm（与 01_B 相同，后续可独立调整）
local SLIDE_THRESHOLD_DEFAULT_CM = 8.0
local SLIDE_THRESHOLD_B_CM = 15.0
local SLIDE_THRESHOLD_02_A_CM = 15.0

local function get_slide_threshold(mesh_name)
    if mesh_name and string.find(mesh_name, "DoorLatchBar_01_B", 1, true) then
        return SLIDE_THRESHOLD_B_CM
    end
    if mesh_name and string.find(mesh_name, "DoorLatchBar_02_A", 1, true) then
        return SLIDE_THRESHOLD_02_A_CM
    end
    return SLIDE_THRESHOLD_DEFAULT_CM
end

-- 反向门栓(latch)参数组选择：以「正向参数」为 fallback，反向时是否用 REV 组由 mesh 型号单独决定。
-- 已实测：01_B(圆形)反向用 REV；02_A(方形)反向仍用正向参数(fallback)。
-- 后续新增型号在此追加；默认反向走正向组(fallback)。
local function get_latch_uses_rev(mesh_name)
    if mesh_name and string.find(mesh_name, "DoorLatchBar_01_B", 1, true) then
        return true
    end
    return false
end

-- =============================================================================
-- 扫描参数
-- =============================================================================
local SCAN_INTERVAL_MS = 1000  -- L2 3m 近距过滤间隔（原 300ms 全图扫描，现为 L2 缓存筛选）
local SCAN_RANGE_CM = 300  -- 3m（以玩家为中心，缓存所有范围内门栓）

-- =============================================================================
-- Phase 1 参数
-- =============================================================================
local PROXIMITY_CM = 12         -- latch/key 吸附距离阈值（cm）
local GLIDE_PROXIMITY_CM = 10   -- glide 推拉门吸附距离阈值（cm，门体更大，放宽到 20）
local SWITCH_PROXIMITY_CM = 10  -- switch 折叠楼梯杠杆吸附距离阈值（cm，用户指定 15，目标=硬编码锚点 Fusebox_12_D）
local LIGHT_SWITCH_PROXIMITY_CM = 10 -- light_switch 吸附距离阈值（cm）。2026-09-03 探针重定位吸附点后恢复 15
                                     -- （吸附点新值 = Probe Snap 采样 local=(-6.47, 5.30, 22.78)，见 LIGHT_SPOT_OFFSET）
local SLIDE_THRESHOLD_CM = 8.0  -- 滑动完成阈值（默认值；_01_B 型号用 get_slide_threshold 取 15.0）
local RETURN_DURATION = 0.15    -- 松开回弹动画时长
local COMPLETED_HOLD_SEC = 0  -- COMPLETED 后立即销毁表演体恢复本体
-- 各类型左手抓握动画（hands_parameters.json 中已定义）
-- latch/key 保持原手势 pull_lock；glide 推拉门 & light_switch 开灯操纵杆用 flashlight
local GRIP_ANIM_BY_TYPE = {
    latch = "pull_lock",
    key = "pull_lock",
    glide = "flashlight",
    light_switch = "flashlight",
    push = "push_wardrobe",    -- 阶段2：可推柜，手摊平手势（面板 attachments 已注册，可微调）
    cart = "drink_potion",     -- 阶段2：推车（PushNClimb），复用手喝药手势（半握拳锁死，§5.2/§9 定案，无 JSON 改动）
}

-- 左手吸附偏移/旋转（已通过诊断脚本滑块调试硬编码）
local LATCH_HAND_OFFSET = { x = -4.25, y = 1.5, z = 5.875 }
local LATCH_HAND_ROTATION = { pitch = 156.375, yaw = -144.0, roll = -14.625 }

-- 反向门栓(latch, 镜像)独立手部偏移参数：默认与正向完全一致，供镜像门单独微调。
-- 镜像判定：门栓本体 up 的 Z 分量 < 0（缩放/摆放镜像，非转 180°）。
-- 以下 REV 值已在诊断面板硬编码固化（用户实测调好）。
local LATCH_HAND_OFFSET_REV = { x = 1.371, y = 1.824, z = -4.395 }
local LATCH_HAND_ROTATION_REV = { pitch = -86.595, yaw = -169.298, roll = -38.919 }

-- 钥匙手部偏移（Phase 2 诊断校准，初始值抄 Latch，待滑块调整后替换）
local KEY_HAND_OFFSET = { x = -5.5, y = -3.25, z = 0.25 }
local KEY_HAND_ROTATION = { pitch = 42.75, yaw = -102.375, roll = 56.25 }

-- 推拉门(glide)手部偏移（2026-09-03：吸附点 A 已含实测把手偏移 {0,11,150}，
-- 手相对吸附点的位置偏移归零，只保留 rotation；待实机复测后再调）
-- 2026-09-03 诊断面板（正向门，Reverse 未勾选）截图定稿：Offset X/Y/Z = 0/0/0（原值一致未改），
-- Rotation P/Y/R = 55.125 / -85.500 / 75.375 原样硬编码（面板值即配置值）。
local GLIDE_HAND_OFFSET = { x = 0, y = 0, z = 0 }
local GLIDE_HAND_ROTATION = { pitch = 55.125, yaw = -85.500, roll = 75.375 }

-- 反向门(glide, side<0)独立手部偏移参数：与正向门完全相同的基准（offset 归零 + 同一组旋转），
-- 用户在正向定稿值基础上再单独微调反向门。
-- 禁止在应用时对反向门做 loc 取反/yaw+180。
local GLIDE_HAND_OFFSET_REV = { x = 0, y = 0, z = 0 }
local GLIDE_HAND_ROTATION_REV = { pitch = 55.125, yaw = -85.500, roll = 75.375 }

-- 开关（折叠楼梯杠杆）左手吸附偏移/旋转：2026-08-29 WoodSide 实机调试定稿
-- 目标 = 硬编码锚点 Fusebox_12_D（entry.component）；吸附 15cm 阈值
-- 滑块路径：SW Loc X / Y / Z + SW Rot P / Y / R（诊断面板）
-- 2026-08-29 WoodSide 实机诊断面板定稿值（用户截图 SW Loc X/Y/Z + SW Rot Y 原样硬编码）
local SWITCH_HAND_OFFSET       = { x = -5.436, y = 2.251, z = 9.56 }
local SWITCH_HAND_ROTATION     = { pitch = 0.0, yaw = 110.25, roll = 0.0 }

-- LightSwitch（监狱开灯操纵杆）左手吸附偏移/旋转
-- 2026-09-03 探针重定位（诊断面板 Probe Snap 抓握采样，锚点 mesh 本地全精度）：
--   采样 local=(x=-6.47, y=5.30, z=22.78) = 手伸到期望吸附位时相对锚点 mesh 根的本地偏移。
-- 新定义：吸附点 LIGHT_SPOT_OFFSET = 采样值（直接落在 mesh 上）；
--         手部偏移 LIGHT_HAND_OFFSET = (0,0,0)（手相对吸附点零偏移，effective loc = SPOT + HAND）。
-- 旋转沿用旧定稿（9.0, -105.75, -2.25），探针只采了位置，待实测再调。
local LIGHT_HAND_OFFSET        = { x = 0, y = 0, z = 0 }
local LIGHT_HAND_ROTATION      = { pitch = 9.0, yaw = -105.75, roll = -2.25 }
-- LightSwitch 吸附点：锚点 mesh（LightSwithPrison_02_A）本地 (-6.47, 5.30, 22.78)（2026-09-03 探针采样定）。
-- 手部偏移 LIGHT_HAND_OFFSET 相对该吸附点；effective loc = SPOT_OFFSET + HAND_OFFSET。
local LIGHT_SPOT_OFFSET        = { x = 1.3, y = -5, z = 22 }

-- Phase 2 (Pushable Wardrobe, sh2 推柜) 吸附抓取载体参数（2026-08-30 方案定稿）
-- 载体：直挂柜本体 StaticMesh + 后续 TeleportAbsolute 逐帧搬柜，无表演体、不隐藏本体。
-- 双吸附点（柜子本地坐标，经根节点姿态换算世界锚点）：
--   点 A = 根节点本地 (-65, 0, +150cm)（与诊断脚本吸附点一致，Phase 0 定案）
--   点 B = A 镜像，本地 X 正 +60cm，即 (+65, 0, +150cm)
-- 阶段2 L3：手进 PUSH_PROXIMITY_CM 内，吸附最近锚点（A 或 B）。
-- 手偏移/旋转相对各自吸附锚点，A/B 各一组独立参数（诊断面板 A/B 滑块校准后硬编码）。
local PUSH_SPOT_A = { x = -65, y = 0, z = 150 }
local PUSH_SPOT_B = { x = 65, y = 0, z = 150 }
local PUSH_PROXIMITY_CM = 10   -- L3 吸附判定阈值（用户要求 15→20）
local PUSH_FACE_HALF_Y = 20    -- 吸附面半宽：锚点本地 Y ±20（前方左右容错）
local PUSH_FACE_HALF_Z = 20    -- 吸附面半高：锚点本地 Z ±20（上下容错）；与 Y 组成 40×40 前面板吸附面
local PUSH_HAND_OFFSET_A = { x = 2.25, y = 0.749, z = 0 }   -- A 组（相对锚点 A），已定稿
local PUSH_HAND_ROTATION_A = { pitch = 105.75, yaw = -65.25, roll = 18.0 }  -- A 组，已定稿
local PUSH_HAND_OFFSET_B = { x = -3.2, y = 0.7, z = 0.0 }   -- B 组（相对锚点 B），诊断滑块定稿值
local PUSH_HAND_ROTATION_B = { pitch = 113.6, yaw = 103.5, roll = 2.25 }  -- B 组，诊断滑块定稿值
-- 阶段3 移动：1cm 手位移 = 1cm 柜位移（同 glide 手感）
-- 表 {val} 供诊断滑块运行时调整（不改 JSON，调好硬编码 val 即可）
local PUSH_MOVE_SCALE = { val = 1.0 }

-- =============================================================================
-- Phase 2 cart（sh2 推车，PushNClimb）：吸附条 A→B 吸附 + 直挂 Handle_R（阶段2只吸附+落定位姿，不移动）
-- attach 父 == 锚点组件（StaticMesh_Handle_R），抓握 offset = 投影点 C′ 的 Handle_R 本地坐标零换算
--   （= (t×BAR_LEN, A_Y, A_Z) + 手偏移，t 抓握瞬间冻结；推柜挂柜本体 StaticMesh 同理）。
-- A/B 每帧现算跟随 mesh（find_cart_nearest 里经 childWorldTransform 投影到世界做判定）。
-- 手势 drink_potion（§5.2/§9 定案，无 JSON 改动）；栏位经诊断滑块校准后硬编码，初值合理猜测待实机定稿。
-- =============================================================================
local CART_GRIP_PROXIMITY_CM = 10   -- 手距吸附条线段 A→B 阈值（初值15cm，2026-09-02 用户调为10cm）
local CART_HOLD_PROXIMITY_CM = 30   -- ATTACHED 保持复检阈值（手柄位置 vs 投影点 C′，比吸附阈值宽松防误脱离）
-- 吸附条 A/B 顶点（Handle_R 本地坐标，诊断 5c2 抓握记录第3次实测固化 + 取整）：
-- A、B 同 y=17、z=16.5（吸附条水平，AB 同 y/z）；x 由 A_X 起沿本地 X 延伸到 B_X
local CART_BAR_A_X = 8              -- A 端点本地 X（靠身体端，实测 x≈8）
local CART_BAR_B_X = 79             -- B 端点本地 X（远端，实测 x≈79，细长条无影响可取实测）
local CART_BAR_A_Y = 17             -- A/B 本地 Y（取整固定，AB 相同）
local CART_BAR_A_Z = 16.5           -- A/B 本地 Z（取整固定，AB 相同）
local CART_BAR_LEN  = CART_BAR_B_X - CART_BAR_A_X   -- 吸附线长（沿本地 X，用于落点换算）
local CART_HAND_OFFSET   = { x = 0.0, y = -11.94, z = -11.25 }             -- 手相对吸附点 C′ 的偏移（Handle_R 本地，诊断 5 滑块实机校准 2026-09-02）
local CART_HAND_ROTATION = { pitch = -13.5, yaw = -60.75, roll = 83.25 }   -- 手相对吸附点 C′ 的旋转（诊断 5 滑块实机校准 2026-09-02）
-- 推车中"已到位"检测轮询间隔（秒，2026-09-02 用户定案"几百毫秒一次"取 300ms）：
-- 到位检测 = DesiredSpot 配对 + IsManagedActorInDesiredSpot（与诊断脚本同法）→ 强制脱手 + 恢复碰撞 + complete 标记
local CART_FOLD_CHECK_INTERVAL = 0.3

-- Phase 2 下压校准（待诊断滑块实机定稿，初值合理猜测）
-- 直驱路径唯一校准：alpha = clamp(世界Z下落距离 / TRAVEL, 0, 1)；SENSITIVITY 为备用比例系数
local SWITCH_PRESS_TRAVEL      = 10    -- 到位行程阈值 cm（手世界Z落差到此即 alpha=1）
local SWITCH_PRESS_SENSITIVITY = 1.0   -- 位移→alpha 敏感系数（乘数，调试用）

-- lever 音效（Phase 3）：走 audio.play_event_on_component 通用组件直播（非 lever 专用）。
-- 事件资产路径静态已知（同诊断面板 diagnose_switch.lua LEVER_EVENT_PATH）。
local SWITCH_LEVER_EVENT_NAME = "Play_Event_FoldingStaircase_Lever"
local SWITCH_LEVER_EVENT_PATH =
    "/Game/WWiseAudio/Events/Events/CustomizedForLevels/BlueCreek/"
    .. SWITCH_LEVER_EVENT_NAME .. "." .. SWITCH_LEVER_EVENT_NAME

-- 开关族类型判断：staircase_switch(折叠楼梯杠杆) / light_switch(灯开关,未来) 共用"开关族"分支逻辑
-- （偏移/音效各自独立，通过 current_type 区分；此处统一入口便于 light_switch 平滑接入）
local function is_switch_family(t)
    return t == "staircase_switch" or t == "light_switch"
end

-- 推拉门(glide)吸附条端点 A/B（2026-09-02 §30：原 GLIDE_SPOT_OFFSET 重命名为 _A，并新增 _B）
-- A = 近端点、B = 远端；B-3 起两点连成横向吸附条，手握条上任意位置（落点 = A/B 按 t 插值）
-- 2026-09-03 用户实测定案：正向门 y=-2，反向门 y=7；Z 钉死 150cm
-- 正向/反向按玩家相对 DoorMesh 的侧向（flip_side = side_v < 0）选组，与 GLIDE_HAND_OFFSET_REV 同一判定
local GLIDE_SPOT_OFFSET_A = { x = 2, y = -2, z = 142 }
local GLIDE_SPOT_OFFSET_B = { x = 110, y = -2, z = 142 }
local GLIDE_SPOT_OFFSET_A_REV = { x = 2, y = 7, z = 142 }
local GLIDE_SPOT_OFFSET_B_REV = { x = 110, y = 7, z = 142 }

-- B-3 回退开关（2026-09-03 §30.5）：true = A/B 线段吸附条（手握条上任意位置，t 插值落点）；
-- false = 回退 B-2 双点离散吸附（手靠 A/B 哪端吸哪端，t 退化为 0/1）。两路径共用 A/B 常量，互不污染
local GLIDE_USE_BAR = true

-- 推拉门(glide)敏感系数：
local GLIDE_SENSITIVITY = 0.01

-- Phase 2 临时诊断接口（Phase 6 删除）
-- 日志写入受诊断脚本 diag.enabled (Enable Logging) 控制；本表不再单独设 enabled
local M_DIAGNOSTIC = {
    key_hand_offset = nil,  -- 诊断滑块写入的 6 轴偏移（nil 时用硬编码 KEY_HAND_OFFSET）
    -- 钥匙旋转轴诊断切换：local_x(Forward) / local_y(Right) / local_z(Up)
    -- 诊断期面板按钮切换，不用改代码重载
    axis_mode = "local_y",
    -- 钥匙旋转灵敏度系数：手拧角度 * sensitivity = 有效转角
    -- 默认 3.0（手拧 30° → 有效 90° 解锁），面板滑块可调
    sensitivity = 3.0,
}

-- 状态前向声明：供早定义函数在 state 赋值前引用
local state

-- 阶段4：push 音效播放辅助（前向声明，定义在 push 段；detach_from_latch 在定义之前调用）
local play_push_audio_event
-- 阶段4：cart 推车音效播放辅助（前向声明，定义在 push/cart 段；detach_from_latch / begin_cart_attach 在定义之前调用）
local play_cart_audio_event

-- 播放拉门栓音效 Play_Sliding_Bolt_Open（参考 diagnose_open_latch.lua:886-1014）
-- 多种调用方式自动回退，确保在 SH2 不同 Wwise 配置下都能出声
local function play_sliding_bolt_sound()
    local event_name = "Play_Sliding_Bolt_Open"
    local uevr = rawget(_G, "uevr")
    if uevr == nil or uevr.api == nil then return end

    local pawn = uevrUtils.get_local_pawn()
    if pawn == nil then return end

    local ak_class = uevr.api:find_uobject("Class /Script/AkAudio.AkGameplayStatics")
    if ak_class == nil then return end
    local cdo = ak_class:get_class_default_object()
    if cdo == nil then return end

    -- Method 1: cdo:PostEventByName(event_name, pawn, true)
    local ok1 = pcall(function()
        cdo:PostEventByName(event_name, pawn, true)
    end)
    if ok1 then
        return
    end

    -- Method 2: AkAudioEvent 对象 PostOnActor
    local event_path = "AkAudioEvent /Game/WWiseAudio/Events/Enviro/Doors/"
                       .. event_name .. "." .. event_name
    local ak_event = uevr.api:find_uobject(event_path)
    if ak_event ~= nil then
        local ok2 = pcall(function()
            ak_event:PostOnActor(pawn, true)
        end)
        if ok2 then
            return
        end
    end

    -- Method 3: PostEventAtLocationByName（在 pawn 位置播放）
    local loc = nil
    pcall(function() loc = pawn:K2_GetActorLocation() end)
    if loc ~= nil then
        local rot = nil
        pcall(function() rot = pawn:K2_GetActorRotation() end)
        if rot == nil then rot = uevrUtils.rotator(0, 0, 0) end
        local ok3 = pcall(function()
            cdo:PostEventAtLocationByName(event_name, loc, rot, nil)
        end)
        if ok3 then
            return
        end
    end
end

-- 播放钥匙开锁音效 Play_Key_Unlock（Phase 4 新增）
-- 复用 play_sliding_bolt_sound 的多回退调用模式，仅改事件名
-- SDK 事实表 §6.1 确认：钥匙门专用，不可用 Play_Sliding_Bolt_Open
local function play_key_unlock_sound()
    local event_name = "Play_Key_Unlock"
    local uevr = rawget(_G, "uevr")
    if uevr == nil or uevr.api == nil then return end

    local pawn = uevrUtils.get_local_pawn()
    if pawn == nil then return end

    local ak_class = uevr.api:find_uobject("Class /Script/AkAudio.AkGameplayStatics")
    if ak_class == nil then return end
    local cdo = ak_class:get_class_default_object()
    if cdo == nil then return end

    -- Method 1: cdo:PostEventByName(event_name, pawn, true)
    local ok1 = pcall(function()
        cdo:PostEventByName(event_name, pawn, true)
    end)
    if ok1 then
        return
    end

    -- Method 2: AkAudioEvent 对象 PostOnActor
    local event_path = "AkAudioEvent /Game/WWiseAudio/Events/Enviro/Doors/"
                       .. event_name .. "." .. event_name
    local ak_event = uevr.api:find_uobject(event_path)
    if ak_event ~= nil then
        local ok2 = pcall(function()
            ak_event:PostOnActor(pawn, true)
        end)
        if ok2 then
            return
        end
    end

    -- Method 3: PostEventAtLocationByName（在 pawn 位置播放）
    local loc = nil
    pcall(function() loc = pawn:K2_GetActorLocation() end)
    if loc ~= nil then
        local rot = nil
        pcall(function() rot = pawn:K2_GetActorRotation() end)
        if rot == nil then rot = uevrUtils.rotator(0, 0, 0) end
        local ok3 = pcall(function()
            cdo:PostEventAtLocationByName(event_name, loc, rot, nil)
        end)
        if ok3 then
            return
        end
    end
end

-- 播放推拉门系统音效（glide）— §31.7 落地（2026-09-03 实机验证有效）
-- 主路径 A：ak_comp:SimplePostAssociatedAkEvent() —— 直 post 组件 Associated Event，
--   音色/循环层全部由组件资产自带 Switch（DoorTypeSwitch/DoorLockState_* 编辑器资产）决定，
--   绕开 Play_Doors_System 手动 Switch 猜谜（§31.6：滑门原生链无 Door_State/Door_Status 成员，
--   手动矩阵从未命中 SlidingDoors_Prison 叶子 → 全 OK 全无声的根因）。
-- 复用回退 A'：libs/audio.play_event_on_component(ak_comp, nil, ak_comp.AkAudioEvent)
--   与 A 同语义（贴组件 post 其事件、继承组件 Switch），A 方法缺失时经 audio 脚本复用。
--   （方案 B ProcessOnOpenAnimPlayedNative 与旧手动 Switch 矩阵 set_door_audio_switches /
--   LightMetalFence / pawn play_segment 均已移除，见 plan §31.6/§31.7）
-- 停止：松手 stop_sliding_door_sound() 在 state._glide_sound_comp 上 Stop，与实测一致。
-- @param door_actor table|nil 门 Actor（SHSlidingDoor），nil 时只落日志
local function play_sliding_door_sound(door_actor)
    local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
    local function diag(level, msg)
        if log_fn ~= nil then
            pcall(log_fn, level, "[GLIDE_SOUND] " .. msg)
        end
    end

    if door_actor == nil then
        diag("WARN", "door_actor = nil，方案 A 无法播放")
        return false
    end

    -- 解析门音频组件（Associated Event 的宿主）
    local ak_comp = nil
    pcall(function() ak_comp = door_actor.SHAkSlidingDoorComponent end)
    if ak_comp == nil then
        diag("WARN", "door_actor.SHAkSlidingDoorComponent = nil，方案 A 无法播放 ("
            .. tostring(door_actor:get_full_name()) .. ")")
        return false
    end

    -- 方案 A：直 post 组件自带 Associated Event（组件资产 Switch 全生效，实测有声）
    if ak_comp.SimplePostAssociatedAkEvent ~= nil then
        local ok, ret = pcall(function() return ak_comp:SimplePostAssociatedAkEvent() end)
        if ok then
            diag("INFO", string.format("OK: SimplePostAssociatedAkEvent (%s) ret=%s",
                tostring(ak_comp:get_full_name()), tostring(ret)))
            -- 记录门组件引用，供 stop_sliding_door_sound 停音用
            state._glide_sound_comp = ak_comp
            -- 判断 one-shot / 循环层：读事件 MaximumDuration。
            -- 循环层（旧 Middle_Opened 设计）松手必须显式 Stop；one-shot 让它自然播完，
            -- detach 立即 Stop 会把刚开始播的音掐掉（2026-09-03 实测无声的根因）。
            local max_dur = nil
            pcall(function() max_dur = ak_comp.AkAudioEvent.MaximumDuration end)
            state._glide_sound_loop = (max_dur == nil or max_dur <= 0 or max_dur > 8.0)
            diag("INFO", string.format("event max_dur=%s -> loop=%s（detach %s）",
                tostring(max_dur), tostring(state._glide_sound_loop),
                state._glide_sound_loop and "会 Stop" or "不 Stop，自然播完"))
            return true
        end
        diag("WARN", "SimplePostAssociatedAkEvent err: " .. tostring(ret))
    else
        diag("WARN", "ak_comp 无 SimplePostAssociatedAkEvent 方法，尝试 A' 复用 libs/audio")
    end

    -- 复用回退 A'：经 libs/audio 贴组件 post 其 Associated Event（同一语义，换调用入口）
    local audio = rawget(_G, "__sh2_audio_module")
    if audio ~= nil and type(audio.play_event_on_component) == "function" then
        local evt = nil
        pcall(function() evt = ak_comp.AkAudioEvent end)
        if evt ~= nil then
            local ok2, played = pcall(audio.play_event_on_component, ak_comp, nil, evt)
            if ok2 and played == true then
                diag("INFO", "OK: A' libs/audio play_event_on_component (Associated Event)")
                state._glide_sound_comp = ak_comp
                local max_dur = nil
                pcall(function() max_dur = evt.MaximumDuration end)
                state._glide_sound_loop = (max_dur == nil or max_dur <= 0 or max_dur > 8.0)
                diag("INFO", string.format("A' event max_dur=%s -> loop=%s",
                    tostring(max_dur), tostring(state._glide_sound_loop)))
                return true
            end
            diag("WARN", "A' play_event_on_component 失败 (ok=" .. tostring(ok2)
                .. ", played=" .. tostring(played) .. ")")
        else
            diag("WARN", "A' ak_comp.AkAudioEvent = nil")
        end
    else
        diag("WARN", "libs/audio 未加载，无 A' 回退")
    end

    return false
end

--- 停止推拉门滑动音效（Middle_Opened 是滑动循环层，松手/到位需显式停止）。
--- 在 begin_glide 时的门 SHAkSlidingDoorComponent 上 Stop，避免循环无限响。
local function stop_sliding_door_sound()
    local comp = state._glide_sound_comp
    if comp == nil then
        return
    end
    pcall(function() comp:Stop() end)
    if comp.WwiseObject ~= nil then
        pcall(function() comp.WwiseObject:Stop() end)
    end
    state._glide_sound_comp = nil
end

-- =============================================================================
-- 状态机：IDLE → APPROACHING → ATTACHED → SLIDING → COMPLETED
--                                    ↓
--                              RETURNING → APPROACHING/IDLE
-- =============================================================================
local PHASE = {
    IDLE = 0,
    APPROACHING = 1,  -- 12cm 内，高亮中，即将吸附
    ATTACHED = 2,     -- 已吸附，等待 grip 按下
    SLIDING = 3,      -- grip 按住，滑动中（门栓）
    COMPLETED = 4,    -- 完成
    ROTATING = 5,     -- grip 按住，旋转中（钥匙）
    GLIDING = 6,      -- grip 按住，推拉门滑动中（glide）
    SWITCH = 7,       -- grip 按住，折叠楼梯开关下压中（switch）
    PUSHING = 8,      -- grip 按住，可推柜（阶段2：只吸附不移动；阶段3移动接入）
}

-- =============================================================================
-- 状态缓存
-- =============================================================================
state = rawget(_G, "OPEN_LATCH_MODULE")
if type(state) ~= "table" then
    state = {
        -- Phase 0: 枚举缓存
        cached_latches = {},
        enabled = true,
        scan_interval_registered = false,
        -- L1 三级检测缓存
        latch_cache = nil,          -- L1 全图门栓列表
        latch_cache_valid = false,
        last_pawn_ref = nil,        -- 上次 pawn 引用（检测 nil→valid）
        -- Phase 1: 吸附 + 滑动状态
        phase = PHASE.IDLE,
        grab_tick_registered = false,
        latch_component = nil,      -- DoorLatchBar / KeyStaticMesh 本体
        latch_origin_loc = nil,     -- 吸附瞬间的世界位置
        latch_origin_rot = nil,
        current_mesh_name = nil,    -- 当前吸附的 mesh 全名（用于型号区分滑动阈值）
        current_type = nil,         -- "latch" / "key"（吸附时记录）
        -- Phase push (sh2 推柜，阶段1): 唯一目标柜（3米内筛选，存 latch_cache 条目引用）
        push_target = nil,          -- 阶段1；阶段2吸附据此接入，不进 cached_latches 防误抓
        -- Phase 6: push/PushNClimb 分支 10s 判空轮询补扫（streaming 分段加载漏扫覆盖，2026-09-01）
        branch_next_poll = 0,       -- 下一次判空轮询时刻（os.clock 基准；游戏暂停时轮询也应暂停）
        branch_scanning = false,    -- 防并发标志（重扫中置位，避免与 L1 重建叠加）
        branch_scan_hits = 0,       -- 诊断：最近一次轮询重扫 push+PushNClimb 总条数
        branch_scan_cdo = 0,        -- 诊断：最近一次轮询剔除 CDO（loc==(0,0,0)）条数
        -- 2026-09-04 方案1：每分支独立"满意即停 + 有限尝试封顶休眠"。
        -- 根治周期卡顿：原 OR 判空下缺任一族就永久每 30s 重扫（大图 ~175ms/st）。
        -- attempts = "扫了仍空"的连续次数；达 POLL_DORMANT_AFTER(3) → dormant=true 本关休眠不再盲扫。
        -- 换关/pawn 变化触发 L1 重建时清零重建（见 build_l1_cache 末尾）。
        -- 扫描层不变：仍一次 find_all_of(PUSH_BASE_CLASS) 整体刷新两分支，这里只改"要不要扫/扫完是否停"。
        push_attempts = 0,          -- push 分支连续空扫次数
        pn_attempts = 0,            -- PushNClimb 分支连续空扫次数
        push_dormant = false,       -- push 分支本关休眠标志
        pn_dormant = false,         -- PushNClimb 分支本关休眠标志
        -- Phase 6 常量（就近定义，本文件内唯一使用点）
        POLL_DORMANT_AFTER = 1,     -- 无CDO证据分支连续空扫达该次数 → 本关休眠（2026-09-05 用户改定：重试1次即休）
        -- 2026-09-05：子类 CDO 证据 + 保险丝封顶（用户拍板）。
        -- CDO 只作"本关疑似有该族"证据、不入库；两分支各自独立结算。
        cdo_push = 0,               -- 最近一次轮询重扫累计的 push 分支子类 CDO 证据
        cdo_pn = 0,                 -- 最近一次轮询重扫累计的 PushNClimb 分支子类 CDO 证据
        POLL_CDO_DORMANT_AFTER = 20, -- 有子类CDO证据时该分支的保险丝封顶（防 CDO 恒在却无实例的极端图，20次×30s=10分钟）
        -- Phase cart (sh2 推车，阶段1-L2): 唯一目标车（3米内筛选，存 latch_cache 条目引用）
        -- L1 完全复用现有 PushNClimb 登记（type 不改、不加字段，用户定案 2026-08-31）
        cart_target = nil,          -- L2 3米内选中目标车；阶段2吸附据此接入，不进 cached_latches
        cart_collision_off_actor = nil, -- 当前 Pawn 碰撞已关闭的目标车 actor（幂等守卫；nil=无关闭中目标）
        -- 2026-09-04：mesh 解析不再缓存（改分帧关碰撞。每台车 9 mesh，命中帧登记、下次 update_l2_cache(≤1s)枚举+设置）
        cart_parse = nil,           -- 命中帧登记的待分帧"关碰撞"任务 { actor, addr }；离场/切换/恢复即自取消，结果不缓存
        desired_spot_by_managed = {}, -- L1 建索引：keyed by cart addr → 配对的 DesiredSpot actor（ManagedActor==cart；无配对不收录）
                                    -- 2026-09-04：DesiredSpot 从 L2 每车首接近全图扫，上移到 L1 全量扫一次建索引，L2 只查表（去首接近卡顿）
        cart_completed = {},        -- keyed by actor:get_address() → 已到位(complete)标记（到位=IsManagedActorInDesiredSpot，2026-09-02 用户定案）
                                    -- 命中的车永不再枚举组件/关 Pawn 碰撞（防下一帧又关碰撞）
        cart_fold_check_last_t = 0, -- 推车(PUSHING)中"已到位"检测轮询时刻（os.clock 基准，CART_FOLD_CHECK_INTERVAL 一次）
        -- 阶段4：松手刻意 detach 后的反吸附冷却（全分支共用，detach_from_latch 设定）
        -- 冷却期间手即使仍在吸附范围内也不自动吸回，给玩家 1s 从容把手移开，杜绝"松手→又被吸回"跳变
        detach_cooldown_until = 0,  -- os.clock 基准的冷却截止时刻；<=now 视为已失效
        -- Phase 2 push 吸附抓取状态（阶段2：只吸附不移动）
        push_static_mesh = nil,     -- 当前吸附柜的 StaticMesh（直挂本体，非表演体）
        push_spot_local = nil,      -- 本次吸附选的锚点本地偏移（PUSH_SPOT_A / PUSH_SPOT_B）
        push_anchor_local = nil,    -- 本次吸附点落在吸附面内的本地偏移（Y/Z 被 clamp ±HALF，挂手用）
        push_spot_world = nil,      -- 本次吸附锚点的世界位置（距离复检用）
        push_anchor_offset = nil,   -- 锚点相对根节点的世界偏移（阶段3逐帧跟随用，预留）
        -- Phase 2 cart 吸附抓取状态（阶段2：只吸附不移动；attach 直挂 StaticMesh_Handle_R=锚点，零换算）
        cart_handle = nil,          -- 当前吸附的 StaticMesh_Handle_R（attach 父==锚点）
        cart_t = 0,                 -- 吸附瞬间投影参数 t（C′ = A + t(B−A)，Handle_R 本地，t 冻结手不动）
        cart_proj_world = nil,      -- 吸附瞬间投影点 C′ 世界（ATTACHED 复检基准，随 mesh 搬动需现算见 find_cart_nearest）
        -- 阶段3 自由跟手移动（照抄诊断脚本 on_tick_follow，见顶部修改说明）
        cart_anchor_offset = nil,   -- 抓握瞬间：投影点 C′ 世界 − 车根世界（常量锚点偏移，X/Y 跟手 1:1 用）
        cart_start_world = nil,     -- 抓握瞬间：车根实时世界位（Z 锁基准；每帧目标 Z 锁死，小车不能上下移动）
        -- 阶段3 移动（TeleportAbsolute 逐帧搬柜）
        push_axis = nil,             -- 柜移动轴（本地 X 的水平投影，begin_push_attach 时算一次）
        push_start_dist = nil,       -- 抓握瞬间：手沿 push_axis 相对 latch_origin_loc 的投影基准（capture_slide_anchor）
        push_start_world = nil,      -- 抓握瞬间：柜根节点世界位置（每帧 TeleportAbsolute 目标 = start_world + axis × signed_pull）
        _glide_sound_comp = nil,    -- 推拉门滑动音效的 SHAkSlidingDoorComponent 引用（松手停止用）
        slide_axis = nil,           -- 门栓局部 forward 单位向量
        start_anchor_dist = nil,    -- 锚定基准标量
        signed_pull = 0,            -- 当前滑动距离（cm）
        progress = 0,               -- 0~1
        -- Phase 2: 钥匙旋转状态
        key_start_pitch = 0,        -- 抓取时左手 Pitch 基准值
        key_rotation_delta = 0,     -- 当前旋转角度（度）
        key_completed = false,      -- Phase 4: 拧到位标记（true=已振动+解锁，松手直接 detach）
        slide_completed = false,    -- Phase 4: 拉栓到位标记（同 key_completed 语义）
        -- Phase 2: 推拉门(glide)状态
        glide_completed = false,    -- 推拉门全开标记（未来 update_glide 用）
        glide_start_dist = nil,     -- 本抓取手位移锚定基准标量（capture_slide_anchor）
        glide_base_alpha = 0,       -- 引擎 DoorMovementAlphaSave 续拉基准
        glide_bar_t = nil,          -- B-3 吸附条：吸附瞬间冻结的 t（0=A 端，1=B 端，中间=条上落点）
        glide_lock_comp = nil,      -- 门 Actor.LockComponent（begin_glide 记录；锁门不拦 begin_glide，由 update_glide 拦 alpha 驱动）
        movement = nil,             -- 门 Actor.DoorMovement（begin_glide 现场回读）
        spot_axis = nil,            -- 门滑动投影轴（本地 X 按 open_sign 翻转）
        open_sign = 1,              -- 开合符号（±1）
        -- highlight_applied = false,  -- CustomDepth 是否已开启（已禁用）
        grip_anim_applied = false,  -- 左手 grip animation 是否已设置
        last_attach_error = nil,    -- 最后一次吸附错误信息
        last_attach_info = nil,     -- 最后一次吸附成功信息（组件名称）
        -- 回弹动画
        returning = false,
        return_start_t = 0,
        return_start_progress = 0,
        -- Phase 1.b: 表演体
        perf_actor = nil,    -- 表演体 Actor（自由 spawn，不受 BP 限制）
        perf_mesh = nil,     -- 表演体 StaticMeshComponent
        perf_origin = nil,   -- 表演体初始世界位置
        perf_hidden_body = nil,  -- §27：被隐藏的本体组件（生成时记录，销毁时恢复，勿死写 latch_component）
        -- Phase 2: COMPLETED 时短按 A 键的释放状态（持久化以防热重载泄漏 refcount）
        a_button_pressed = false,
        -- Phase 3: COMPLETED 后表演体停留时长（1 秒后强制销毁恢复本体）
        completed_start_t = 0,
    }
    _G.OPEN_LATCH_MODULE = state
end

-- 2026-09-04：方案1 push 分支休眠字段兼容补齐（热重载时 state 复用旧对象，不走上面 L565 定义段，
-- 需对缺字段的旧 state 补默认值，防 branch_poll_check 读到 nil）
if state.POLL_DORMANT_AFTER == nil then state.POLL_DORMANT_AFTER = 3 end
if state.push_attempts == nil then state.push_attempts = 0 end
if state.pn_attempts == nil then state.pn_attempts = 0 end
if state.push_dormant == nil then state.push_dormant = false end
if state.pn_dormant == nil then state.pn_dormant = false end
-- 2026-09-05 热重载兼容：CDO 证据字段 + 保险丝常量补默认
if state.cdo_push == nil then state.cdo_push = 0 end
if state.cdo_pn == nil then state.cdo_pn = 0 end
if state.POLL_CDO_DORMANT_AFTER == nil then state.POLL_CDO_DORMANT_AFTER = 20 end

-- =============================================================================
-- L1 全图扫描（仅关卡加载时调用，替代原 scan_latches 的全图遍历）
-- 记录全图所有 DoorLatchBar，不做 3m 距离过滤（L2 负责）
-- =============================================================================
-- =============================================================================
-- L1 重建诊断 trace（排查存档加载后楼梯不进 L1 的问题）
-- 纯内存记录（不打印控制台、不写文件），仅诊断脚本手动按钮 Snapshot Rebuild 读取
-- =============================================================================
local l1_trace = {}
local function l1_trace_add(msg)
    l1_trace[#l1_trace + 1] = string.format("[%.1fs] %s", os.clock(), msg)
    if #l1_trace > 80 then table.remove(l1_trace, 1) end
end

-- 前向声明：CART_DESIRED_SPOT_CLASS 定义在本文件下方（L1667），但 build_l1_cache/branch_poll_check 建 DesiredSpot 索引先用到
local CART_DESIRED_SPOT_CLASS
-- 前向声明：rebuild_desired_spot_index 定义在本文件下方（L1668 之后），build_l1_cache/branch_poll_check 都先调用它
local rebuild_desired_spot_index

local function build_l1_cache()
    if not state.enabled then
        l1_trace_add("build skipped: state.enabled=false")
        return
    end

    local all_comps = nil
    pcall(function()
        all_comps = uevrUtils.find_all_of("Class /Script/Engine.StaticMeshComponent", true)
    end)
    if all_comps == nil then
        l1_trace_add("build abort: find_all_of(StaticMeshComponent)=nil")
        state.latch_cache_valid = false
        return
    end

    -- 旧 switch 条目快照（重建后扫描为空时保留仍有效的，防 1→0 丢失）
    local prev_switches = {}
    if state.latch_cache ~= nil then
        for _, pe in ipairs(state.latch_cache) do
            if pe.type == "staircase_switch" or pe.type == "light_switch" then
                prev_switches[#prev_switches + 1] = pe
            end
        end
    end

    local matches = {}
    local perf_mesh = state.perf_mesh
    local perf_actor = state.perf_actor

    -- 先按 mesh 名过滤（DoorLatchBar 极少），再算距离；避免对全图 SMC 做 GetOwner
    for _, comp in ipairs(all_comps) do
        if comp == perf_mesh then goto continue end

        local mesh_name = nil
        pcall(function()
            local sm = comp.StaticMesh
            if sm ~= nil then
                mesh_name = sm:get_full_name()
            end
        end)
        if not mesh_name_matches(mesh_name) then goto continue end

        if perf_actor ~= nil then
            local owner = nil
            pcall(function() owner = comp:GetOwner() end)
            if owner == perf_actor then goto continue end
        end

        local comp_loc = reload_tools.get_component_world_location(comp)
        if comp_loc == nil then goto continue end

        local comp_rot = nil
        pcall(function()
            comp_rot = reload_tools.get_component_world_rotation(comp)
        end)

        table.insert(matches, {
            component = comp,
            loc = comp_loc,
            rot = comp_rot,
            mesh_name = mesh_name,
            completed = false,
            type = get_entry_type(mesh_name),
        })

        ::continue::
    end

    state.latch_cache = matches
    state.latch_cache_valid = true
    l1_trace_add(string.format("latch: %d matches from %d SMCs", #matches, #all_comps))
    local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
    if log_fn then
        pcall(log_fn, "INFO", string.format("[OPEN_LATCH] L1 cache built: %d latches from %d SMCs", #matches, #all_comps))
    end

    -- =========================================================================
    -- Phase 1: 追加 SHSlidingDoor Actor 扫描（并入 latch_cache，type="glide"）
    -- =========================================================================
    local all_doors = nil
    pcall(function()
        all_doors = uevrUtils.find_all_of("Class /Script/SHProto.SHSlidingDoor", false)
    end)
    if all_doors ~= nil then
        local glide_count = 0
        for _, actor in ipairs(all_doors) do
            -- 吸附点：DoorMesh 门体（不再用 InteractionProximitySphere 球体，
            -- 球体体积大、旋转参考系混乱，且碰门会触发红色线框球副作用）
            local spot = nil
            local spot_loc = nil
            pcall(function() spot = actor.DoorMesh end)
            if spot ~= nil then
                spot_loc = reload_tools.get_component_world_location(spot)
            end
            if spot_loc == nil then goto continue_door end

            -- 门 Actor 世界旋转（本地轴 Spot Offset 变换用；rot 为 actor 级）
            local spot_rot = nil
            pcall(function()
                if actor.K2_GetActorRotation ~= nil then spot_rot = actor:K2_GetActorRotation() end
            end)

            -- DoorMovement（OverrideDoorAlpha 用；Phase 1：仅供 L1 字段，正式 L2 不依赖）
            local movement = nil
            pcall(function() movement = actor.DoorMovement end)

            -- 投影轴：门 Actor 本地 -X（负 forward）→ 世界空间 → 压平水平面(Z=0) → 归一化
            -- 统一取负 forward 作为开合正方向（与 resolve_glide_runtime 一致，见 plan §20）
            local axis = nil
            pcall(function()
                local rot = nil
                if actor.K2_GetActorRotation ~= nil then rot = actor:K2_GetActorRotation() end
                if rot ~= nil then
                    axis = math_lib.horizontalYawDir(rot.Yaw or 0, -1)
                end
            end)
            -- open_sign：仅供诊断记录（MovementDirection 在负 forward 轴上的投影符号），不参与方向
            local open_sign = 1
            pcall(function()
                if movement ~= nil and movement.MovementDirection ~= nil and axis ~= nil then
                    local md = movement.MovementDirection
                    local proj = (md.X or 0) * (axis.X or 0) + (md.Y or 0) * (axis.Y or 0)
                    if proj < 0 then open_sign = -1 end
                end
            end)

            -- DoorMesh 名（偏移表查找用）
            local door_mesh_name = nil
            pcall(function()
                local dm = actor.DoorMesh
                if dm ~= nil then door_mesh_name = dm:get_name() end
            end)

            table.insert(matches, {
                actor = actor,               -- 诊断用；正式 L2/L3 不依赖
                door_mesh = spot,            -- 门体/球体组件（诊断用）
                component = spot,            -- ★ 吸附点组件 = InteractionProximitySphere（fallback DoorMesh）
                spot = spot,
                loc = spot_loc,              -- 距离基准 = 吸附点世界位置
                spot_rot = spot_rot,         -- 门 Actor 世界旋转（本地轴 Spot Offset 变换用）
                spot_axis = axis,            -- 方案 B 现场回读；此处仅供 L1 兜底/诊断
                open_sign = open_sign,
                movement = movement,         -- 方案 B 现场回读；此处仅 L1 持有
                mesh_name = door_mesh_name or "?",
                completed = false,
                type = "glide",
            })
            glide_count = glide_count + 1
            ::continue_door::
        end
        if glide_count > 0 then
            if log_fn then
                pcall(log_fn, "INFO", string.format("[OPEN_LATCH] L1 cache: +%d SHSlidingDoor (glide) appended", glide_count))
            end
        end
    end

    -- =========================================================================
    -- Phase 1: 追加 InteractionSwitch Actor 扫描（并入 latch_cache，type="staircase_switch"）
    -- 对应 plans/sh2_stairecase_switch_plan.md §9 Phase 1
    -- 规则：
    --   1) 扫描用全类名 InteractionSwitch_Base_BP_C + includeDefault=false（排除 CDO）
    --   2) 杠杆锚点走硬编码映射表（Phase 0 确认两处折叠楼梯开关杠杆 mesh 均
    --      Fusebox_12_D），缓存构建时直接 actor.Fusebox_12_D 直读，不运行时判哪块随 alpha
    --   3) entry 并入 latch_cache，type 按 subclass 区分：staircase_switch/light_switch，
    --      带锚点组合/Generic_A/Staircase/bUsed 字段
    --      供 diagnostics（diagnose_switch.lua）读取；L2/L3 与门栓共用链路
    --   4) 严格按 Phase 0 同一扫描（diagnose_switch collect_candidates）：
    --      marker 用 "InteractionSwitch"，排除 "MusicSwitch"/"SwitchVolume"/"LightSwitchManager"，
    --      不收 "FoldingStaircase"（防楼梯基类 FoldingStaircase__Base_BP_C 误入）
    -- =========================================================================
    local switch_count = 0
    local all_switch_actors = nil
    local switch_class_name =
        "BlueprintGeneratedClass /Game/Game/Gameplay/Interactions/Others/Switches/InteractionSwitch_Base_BP.InteractionSwitch_Base_BP_C"
    pcall(function()
        all_switch_actors = uevrUtils.find_all_of(switch_class_name, false)  -- includeDefault=false 排除 CDO
    end)
    -- 僵尸类缓存排查/自愈：读存档后 BP 类可能被引擎 GC/重载，classCache 旧引用
    -- get_objects_by_class 返回空。清缓存重解析一次（get_class 会重新 find_uobject）
    if all_switch_actors == nil or #all_switch_actors == 0 then
        l1_trace_add("switch scan empty → clearClassCache + rescan")
        pcall(function() uevr_lib.clearClassCache(switch_class_name) end)
        pcall(function()
            all_switch_actors = uevrUtils.find_all_of(switch_class_name, false)
        end)
    end
    if all_switch_actors ~= nil then
        l1_trace_add(string.format("switch scan: find_all_of(InteractionSwitch_Base)=%d actors", #all_switch_actors))
        for si, actor in ipairs(all_switch_actors) do
            local cls = nil
            pcall(function() cls = actor:get_class():get_full_name() end)
            -- 逐 actor trace：全名 + 接受/拒绝原因（存档加载后 accepted=0 排查用，手动按钮读取）
            local actor_full = "<unreadable>"
            pcall(function() actor_full = actor:get_full_name() end)
            if cls == nil then
                l1_trace_add(string.format("switch[%d] REJECT: get_class failed, actor=%s", si, actor_full))
            else
                l1_trace_add(string.format("switch[%d] cand cls=%s", si, cls))
            end
            if cls ~= nil then
                -- marker 过滤：仅收 InteractionSwitch 族，排除噪音、防楼梯基类
                if not (string.find(cls, "InteractionSwitch", 1, true)) then
                    l1_trace_add(string.format("switch[%d] REJECT: cls 无 InteractionSwitch marker", si))
                    goto continue_switch
                end
                if string.find(cls, "MusicSwitch", 1, true) or string.find(cls, "SwitchVolume", 1, true)
                    or string.find(cls, "LightSwitchManager", 1, true) then
                    l1_trace_add(string.format("switch[%d] REJECT: 噪音类名", si))
                    goto continue_switch
                end
                -- 楼梯子类标记（InteractionSwitch_FoldingStaircase_BP_C 含 FoldingStaircase）
                local is_staircase = string.find(cls, "FoldingStaircase", 1, true) ~= nil
                -- 杠杆锚点：硬编码映射表直读 Fusebox_12_D（Phase 0 确认通用）
                local anchor = nil
                pcall(function() anchor = actor.Fusebox_12_D end)
                if anchor == nil then
                    l1_trace_add(string.format("switch[%d] REJECT: actor.Fusebox_12_D=nil (staircase=%s)", si, tostring(is_staircase)))
                    goto continue_switch
                end
                local anchor_loc = reload_tools.get_component_world_location(anchor)
                if anchor_loc == nil then
                    l1_trace_add(string.format("switch[%d] REJECT: anchor loc=nil (staircase=%s)", si, tostring(is_staircase)))
                    goto continue_switch
                end
                l1_trace_add(string.format("switch[%d] ACCEPT: staircase=%s anchor_loc=(%.0f,%.0f,%.0f)",
                    si, tostring(is_staircase), anchor_loc.X or 0, anchor_loc.Y or 0, anchor_loc.Z or 0))

                -- 杠杆 mesh 名（诊断/偏移查找用）
                local lever_mesh_name = nil
                pcall(function()
                    local sm = anchor.StaticMesh
                    if sm ~= nil then lever_mesh_name = sm:get_full_name() end
                end)
                -- 证据 mesh 组件全量（Fusebox_12_D/10_D/10_C，供 diag 判定哪个随 alpha 动）
                local mesh_comps = {}
                for _, prop in ipairs({ "Fusebox_12_D", "Fusebox_10_D", "Fusebox_10_C" }) do
                    local mc = nil
                    pcall(function() mc = actor[prop] end)
                    if mc ~= nil then mesh_comps[#mesh_comps + 1] = mc end
                end
                -- 逻辑开关映射字段（直读引用，供诊断/Phase2 接线）
                local generic, staircase, bUsed, timeline = nil, nil, nil, nil
                pcall(function()
                    generic = actor.Generic_A
                    staircase = actor.Staircase
                    bUsed = actor.bUsed
                    timeline = actor.Timeline_SwitchAnim
                end)

                -- 开关 Actor 简短名（诊断/回读用）
                local actor_name = "<actor>"
                pcall(function() actor_name = actor:get_full_name() end)

                table.insert(matches, {
                    actor = actor,               -- 开关 Actor（诊断/回读用）
                    name = actor_name,
                    class = cls,                 -- 完整类名
                    subclass = is_staircase and "staircase" or "base",
                    component = anchor,          -- ★ 吸附锚点组件 = 杠杆 mesh Fusebox_12_D
                    loc = anchor_loc,            -- 距离基准 = 锚点世界位置
                    rot = reload_tools.get_component_world_rotation(anchor), -- 锚点旋转
                    mesh_name = lever_mesh_name or "?",
                    mesh_comps = mesh_comps,     -- 证据 mesh 全量（diag alpha 判定用）
                    generic = generic,           -- Generic_A（Phase2 抓握触发参考）
                    staircase = staircase,       -- Staircase 引用（楼梯子类；end_switch_press 回读）
                    bUsed = bUsed,               -- 是否已用过（Phase3 验证 bUsed 后再抓取）
                    timeline = timeline,         -- Timeline_SwitchAnim（直驱路径备查）
                    completed = false,
                    -- 类型按 subclass 区分：楼梯开关=FoldingStaircase（折叠楼梯杠杆，偏移/音效专属）；
                    -- 其余非楼梯 InteractionSwitch：L847 占位已废弃——Phase 0 实证真灯开关是独立类
                    -- （PrisonLightSwitch_BP_C），由下方独立 LightSwitch 扫描段产出 type="light_switch"。
                    -- 此处非楼梯 InteractionSwitch 归回 other_switch，避免与真 light_switch 混淆
                    type = is_staircase and "staircase_switch" or "other_switch",
                })
                switch_count = switch_count + 1
            end
            ::continue_switch::
        end
    end
    if switch_count > 0 then
        state.latch_cache = matches -- 重新挂回（switch 并入后整体）
        if log_fn then
            pcall(log_fn, "INFO", string.format("[OPEN_LATCH] L1 cache: +%d InteractionSwitch (staircase_switch/other_switch) appended", switch_count))
        end
    end
    l1_trace_add(string.format("switch accepted=%d, L1 total=%d", switch_count, state.latch_cache and #state.latch_cache or 0))
    if all_switch_actors == nil then
        l1_trace_add("switch scan: find_all_of returned NIL (class resolve failed)")
    end
    -- 扫描为空但旧条目 actor 仍有效 → 保留（防读存档后 1→0 丢失；换关/销毁时 actor 失效不保留）
    if switch_count == 0 and #prev_switches > 0 then
        local retained = 0
        for _, pe in ipairs(prev_switches) do
            local alive = false
            pcall(function()
                if pe.actor ~= nil and pe.actor:get_full_name() ~= nil then alive = true end
            end)
            if alive then
                table.insert(matches, pe)
                retained = retained + 1
            end
        end
        if retained > 0 then
            state.latch_cache = matches
            l1_trace_add(string.format("switch retained=%d (scan empty but actor valid)", retained))
        else
            l1_trace_add("switch retained=0 (old actors invalid — 真换关/销毁)")
        end
    end

    -- =========================================================================
    -- Phase 1 (Light Switch): 追加 LightSwitch 族 Actor 扫描（并入 latch_cache，type="light_switch"）
    -- 对应 plans/sh2_light_switch_plan.md §9 Phase 1 / §3.1
    -- 该族类（PrisonLightSwitch_BP_C，LightSwitch_BP_C 子类）在本 SDK 不可静态解析
    -- （fact table §4.2 来源警示），运行时按类名扫：find_all_of(Actor) 全 actor 枚举 + 类名过滤
    -- （diagnose_switch.scan_lights Phase 0 已验证此方法，扫到 14 prison + controller + ow_cells）
    -- 规则：
    --   1) 类名过滤器：含 "LightSwitch" 且非 "LightSwitchManager"（噪音，主脚本先例）
    --   2) 吸附锚点 = 杠杆 mesh LightSwithPrison_02_A（Phase 0 直驱实证：02_A 随 alpha 转
    --      Roll 0→180°，01_A 为底座不动）；锚点组件直读 actor.LightSwithPrison_02_A，
    --      兜底 01_A（comp 非 nil 即用其世界位置作吸附基准）
    --   3) 与 InteractionSwitch 扫描共存：非楼梯 InteractionSwitch 已归回 other_switch，
    --      真灯开关独立为 type="light_switch"，两者不混淆
    --   4) 控制器/区域总管引用字段名 Phase 0 未确认，不在此枚举（方案D SetState 由引擎接线）
    -- =========================================================================
    -- =========================================================================
    -- Phase 1 (LightSwitch + Pushable)：两次定向类查询（性能优化 2026-08-30）
    -- 类 ObjectPath 已实机抓取（fact table）：
    --   LightSwitch: PrisonLightSwitch_BP_C（§4.2.6 ①，14 实例全命中；蓝溪无此类，0条正常）
    --   Pushable:    Pushable_Base_ABP_C（IsA 含子类；FurnitureSet01E is_a=true 已实机验证 §11.9）
    -- RangeClamp/Limiter 是独立原生类不继承 Pushable_Base → 定向天然排除，无需子串过滤
    -- 原实现 find_all_of(Engine.Actor) 全图枚举 + 每 actor get_class():get_full_name()
    -- （2 次反射调用/actor）是重建卡顿主因 → 改为定向查询，每次重建零全枚举
    -- 定向查询 pcall 失败（类路径解析异常/返回 nil）→ 回退原全枚举 + 子串分流保底
    -- =========================================================================
    state.push_target = nil -- 每次重建清空阶段1的选中目标柜
    -- cart（推车）重建清空：目标/碰撞守卫/组件枚举缓存
    -- 换关后 actor 与组件指针全部失效 → 缓存清空（旧引用不可复用）；碰撞守卫置空不恢复（杜绝红框污染新关卡）
    state.cart_target = nil
    state.cart_collision_off_actor = nil
    -- 2026-09-04：mesh 解析不再缓存；置空待分帧"关碰撞"任务（换关/重建 → 旧 actor 全部失效，丢弃在途任务）
    state.cart_parse = nil
    state.cart_completed = {}      -- 换关后 actor 全新，complete 标记随之作废（若同车仍到位，L2 到位检测会重新标记）
    -- 2026-09-04：DesiredSpot 索引从 L2 每车首接近全图扫上移到 L1，在此随 L1 重建一并清空、随后重建
    state.desired_spot_by_managed = {}
    state.cart_fold_check_last_t = 0
    -- 诊断：确认 L1 重建确实执行 + cart 状态被清空（验证"加载存档是否触发重建/complete 是否残留"）
    _G.CART_CART_REBUILT = (_G.CART_CART_REBUILT or 0) + 1
    pcall(function()
        if rawget(_G, "CART_DIAG_ENABLED") then
            local f2, e2 = io.open("diagnose_cart.log", "a")
            if f2 then
                f2:write(string.format("[CART][L1] rebuild ran #%d: cart_target/comp_cache/completed all reset\n", _G.CART_CART_REBUILT))
                f2:close()
            end
        end
    end)
    local light_count = 0
    local push_count = 0
    local pn_count = 0

    -- 定向类查询路径（实机抓取：LightSwitch §4.2.6 ① / Pushable §11.9）
    local LIGHT_SWITCH_CLASS =
        "BlueprintGeneratedClass /Game/Game/Gameplay/Interactions/Others/LightSwitch/PrisonLightSwitch_BP.PrisonLightSwitch_BP_C"
    local PUSH_BASE_CLASS =
        "BlueprintGeneratedClass /Game/Game/Gameplay/Interactions/PushableObjects/Pushable_Base_ABP.Pushable_Base_ABP_C"

    -- actor 处理函数（定向 + 回退共用，避免两遍重复逻辑）
    -- LightSwitch：吸附锚点 = 杠杆 mesh LightSwithPrison_02_A（Phase 0 直驱实证：02_A 随 alpha
    --   转 Roll 0→180°，01_A 为底座不动）；锚点组件直读 actor.LightSwithPrison_02_A，兜底 01_A
    local function collect_light_switch(actor)
        local anchor = nil
        pcall(function() anchor = actor.LightSwithPrison_02_A end)
        if anchor == nil then
            pcall(function() anchor = actor.LightSwithPrison_01_A end)
        end
        if anchor == nil then
            l1_trace_add("light switch REJECT: anchor mesh nil")
            return false
        end
        local anchor_loc = reload_tools.get_component_world_location(anchor)
        if anchor_loc == nil then
            l1_trace_add("light switch REJECT: anchor loc=nil")
            return false
        end
        -- Phase 6: CDO 剔除（与 collect_pushable 同款）——默认对象锚点位置恒为 (0,0,0)
        if (anchor_loc.X or 0) == 0 and (anchor_loc.Y or 0) == 0 and (anchor_loc.Z or 0) == 0 then
            l1_trace_add("light switch REJECT: CDO loc=(0,0,0)")
            return false
        end

        local lever_mesh_name = nil
        pcall(function()
            local sm = anchor.StaticMesh
            if sm ~= nil then lever_mesh_name = sm:get_full_name() end
        end)
        local generic, timeline, timeline2, switch_state, is_on = nil, nil, nil, nil, nil
        pcall(function()
            generic = actor.Generic_A          -- Generic_A（Phase2 抓握触发参考）
            timeline = actor.ChangeStateTimeline -- alpha 直驱 set_playback 用
            timeline2 = actor.t_ChangeState    -- 监狱版第二条时间线
            switch_state = actor.State         -- 开关状态
            is_on = actor.IsOn                 -- 是否开灯
        end)

        -- 开关 Actor 简短名（诊断/回读用）
        local actor_name = "<actor>"
        pcall(function() actor_name = actor:get_full_name() end)

        table.insert(matches, {
            actor = actor,               -- 开关 Actor（诊断/回读用）
            name = actor_name,
            class = LIGHT_SWITCH_CLASS,  -- 定向类路径（全为监狱子类）
            subclass = "prison",         -- 定向查监狱子类，恒 prison
            component = anchor,          -- ★ 吸附锚点组件 = 杠杆 mesh LightSwithPrison_02_A
            loc = anchor_loc,            -- 距离基准 = 锚点世界位置
            rot = reload_tools.get_component_world_rotation(anchor), -- 锚点旋转
            mesh_name = lever_mesh_name or "?",
            generic = generic,           -- Generic_A
            timeline = timeline,         -- ChangeStateTimeline（alpha 直驱用）
            timeline2 = timeline2,       -- t_ChangeState（监狱版）
            state = switch_state,        -- 开关状态
            is_on = is_on,               -- 是否开灯
            completed = false,
            type = "light_switch",       -- ★ 真灯开关独立类型
        })
        -- 逐 actor trace（存档加载后 accepted=0 排查用）
        l1_trace_add(string.format("light switch[%d] ACCEPT: subclass=prison anchor_loc=(%.0f,%.0f,%.0f)",
            light_count + 1, anchor_loc.X or 0, anchor_loc.Y or 0, anchor_loc.Z or 0))
        return true
    end

    -- Pushable：类名分流 push 族 vs PushNClimb 族（PushNClimb 继承基类会扫到，只登记不抓取）
    local function collect_pushable(actor, cls)
        local entry_type = nil
        if string.find(cls, "PushNClimb", 1, true) ~= nil then
            entry_type = "PushNClimb"
        else
            entry_type = "push"
        end

        local root_loc = nil
        pcall(function()
            if actor.K2_GetActorLocation ~= nil then root_loc = actor:K2_GetActorLocation() end
        end)
        if root_loc == nil then return false end
        -- Phase 6: CDO 剔除——默认对象位置恒为 (0,0,0)（未 spawn 的真实柜），不入库、不计数。
        -- 2026-09-05 定案：CDO 证据只由 branch_poll_check 轮询路负责（includeDefault=true 单独识别），
        -- build_l1_cache 主扫仍剔除 CDO，避免 CDO 入库污染 latch_cache 判空（push_count 误判非空 → 不触发轮询）。
        if (root_loc.X or 0) == 0 and (root_loc.Y or 0) == 0 and (root_loc.Z or 0) == 0 then
            state.branch_scan_cdo = (state.branch_scan_cdo or 0) + 1
            l1_trace_add("push REJECT: CDO loc=(0,0,0)")
            return false
        end

        local root_rot = nil
        pcall(function()
            if actor.K2_GetActorRotation ~= nil then root_rot = actor:K2_GetActorRotation() end
        end)

        local sh_pushable = nil
        pcall(function() sh_pushable = actor.SHPushable end)

        -- 阶段4：推柜音效组件（Grab/StartPush/StopPush AkEvent 字段宿主）
        local sh_push_audio = nil
        pcall(function() sh_push_audio = actor.SHPushableAudio end)

        table.insert(matches, {
            actor = actor,               -- 柜 actor（阶段2吸附/移动用）
            class = cls,                 -- 完整类名（L2 分流用）
            className = cls,             -- 兼容 diagnose 别名
            sub_type = entry_type,       -- "push" / "PushNClimb"
            type = entry_type,           -- ★ 主抓取链路据此分流（阶段1 push 不参与抓取）
            component = nil,             -- StaticMesh（阶段2吸附载体决定后再填）
            loc = root_loc,              -- 距离基准 = 根节点世界位置（3米筛选）
            rot = root_rot,              -- 根节点世界旋转（算吸附锚点 + 本地 X 轴向）
            SHPushable = sh_pushable,    -- 移动阶段用
            SHPushableAudio = sh_push_audio, -- 阶段4 音效用
            completed = false,
        })
        return true
    end

    -- ── 定向查询（正常路径，零全枚举）──
    local ok1, ok2 = true, true

    -- 僵尸类缓存自愈（同 InteractionSwitch 扫描 L804 先例）：读存档/切场景后 BP 类可能被
    -- 引擎 GC/重载，classCache 旧引用 → get_objects_by_class 空表（类指针失配）。
    -- 空表/nil 时清缓存重解析一次；仍空则交由重试机制（3s 后再走此自愈）。
    -- include_default：临时观察阶段（2026-09-05）push 查询传 true 以把 CDO 一起搜出验证，light 仍 false。
    local function query_with_heal(class_path, include_default)
        local list = nil
        pcall(function() list = uevrUtils.find_all_of(class_path, include_default) end)
        if list == nil or #list == 0 then
            l1_trace_add(string.format("directed scan empty → clearClassCache + rescan (%s)",
                (list ~= nil and #list or 0) .. " hits"))
            pcall(function() uevr_lib.clearClassCache(class_path) end)
            pcall(function() list = uevrUtils.find_all_of(class_path, include_default) end)
        end
        return list
    end

    local light_switches = nil
    pcall(function()
        light_switches = query_with_heal(LIGHT_SWITCH_CLASS) -- includeDefault=false 排除 CDO
    end)
    if light_switches == nil then
        ok1 = false
    else
        for _, actor in ipairs(light_switches) do
            if collect_light_switch(actor) then light_count = light_count + 1 end
        end
    end

    local pushables = nil
    pcall(function()
        -- 2026-09-05 定案：build 主扫 includeDefault=false（CDO 剔除交由 collect_pushable），
        -- CDO 证据只由 branch_poll_check 轮询路识别。
        pushables = query_with_heal(PUSH_BASE_CLASS)
    end)
    if pushables == nil then
        ok2 = false
    else
        for _, actor in ipairs(pushables) do
            local cls = nil
            pcall(function()
                local acls = actor:get_class()
                if acls ~= nil and acls.get_full_name ~= nil then cls = acls:get_full_name() end
            end)
            if cls ~= nil then
                if collect_pushable(actor, cls) then
                    if string.find(cls, "PushNClimb", 1, true) ~= nil then pn_count = pn_count + 1
                    else push_count = push_count + 1 end
                end
            end
        end
    end

    -- 日志 + 挂回（定向成功与否都执行）
    if light_count > 0 and log_fn then
        pcall(log_fn, "INFO", string.format("[OPEN_LATCH] L1 cache: +%d LightSwitch (light_switch) appended", light_count))
    end
    if log_fn then
        pcall(log_fn, "INFO", string.format(
            "[OPEN_LATCH] L1 cache: +%d push (push=%d PushNClimb=%d) appended", push_count + pn_count, push_count, pn_count))
    end
    state.latch_cache = matches -- 重新挂回（light/push 并入后整体）
    l1_trace_add(string.format("light_switch accepted=%d, L1 total=%d", light_count, state.latch_cache and #state.latch_cache or 0))
    l1_trace_add(string.format("push accepted: total=%d (push=%d PushNClimb=%d), L1 total=%d",
        push_count + pn_count, push_count, pn_count, state.latch_cache and #state.latch_cache or 0))

    -- ── DesiredSpot 全局索引（2026-09-04：从 L2 每车首接近全图扫上移到 L1）──
    -- 全量扫一次 DesiredSpot 自愈建索引，与小车扫描同触发（全量重建/branch 轮询两处），保证"车进 L1"与
    -- "spot 配对进索引"完全同步。L2 get_cart_desired_spot 查此表（O(1)，零全图扫描），消除首接近卡顿。
    rebuild_desired_spot_index()

    -- ── 定向查询异常（类路径解析失败/返回 nil）→ 回退全枚举 + 子串分流 ──
    -- 【已注释 2026-08-30：用户确认删除回退路径，杜绝任何全图枚举（含异常时的兜底）】
    -- 定向查询类路径已实机验证（LightSwitch §4.2.6 ① / Pushable §11.9 is_a=true），
    -- 正常重建零全枚举；若定向查询失败则此分支不再收集（light/push 计 0 条）
    --[[
    if not ok1 or not ok2 then
        l1_trace_add(string.format("light/push directed scan FAILED (ok1=%s ok2=%s) → fallback full enumeration", tostring(ok1), tostring(ok2)))
        local all_scan_actors = nil
        if pcall(function()
            all_scan_actors = uevrUtils.find_all_of("Class /Script/Engine.Actor", false)
        end) and all_scan_actors ~= nil then
            for _, actor in ipairs(all_scan_actors) do
                local cls = nil
                pcall(function()
                    local acls = actor:get_class()
                    if acls ~= nil and acls.get_full_name ~= nil then cls = acls:get_full_name() end
                end)
                if cls == nil then goto continue_fb end

                -- 分支1：LightSwitch（仅当定向失败才收集，避免重复）
                if not ok1 and string.find(cls, "LightSwitch", 1, true) ~= nil
                    and string.find(cls, "LightSwitchManager", 1, true) == nil then
                    if collect_light_switch(actor) then light_count = light_count + 1 end
                    goto continue_fb
                end

                -- 分支2：push / PushNClimb（仅当定向失败才收集）
                if not ok2 and (string.find(cls, "PushNClimb", 1, true) ~= nil
                    or (string.find(cls, "Pushable", 1, true) ~= nil
                        and string.find(cls, "RangeClamp", 1, true) == nil
                        and string.find(cls, "Limiter", 1, true) == nil)) then
                    local is_pn = string.find(cls, "PushNClimb", 1, true) ~= nil
                    if collect_pushable(actor, cls) then
                        if is_pn then pn_count = pn_count + 1 else push_count = push_count + 1 end
                    end
                end
                ::continue_fb::
            end
        else
            l1_trace_add("light/push scan: find_all_of(Actor)=nil (class resolve failed)")
        end
    end
    ]]

    -- Phase 6: L1 重建完成 → 重置分支 10s 判空轮询计时 + 分支休眠/尝试计数（2026-09-01/2026-09-04）
    -- （换关/切场景/pawn 变化触发重建 → 新关重新进入判空轮询，休眠清零重学习）
    state.branch_next_poll = os.clock()
    state.push_attempts = 0
    state.pn_attempts = 0
    state.push_dormant = false
    state.pn_dormant = false
    -- 2026-09-05：CDO 证据计数随重建清零（并入新关判空轮询重新学习）
    state.cdo_push = 0
    state.cdo_pn = 0
end

-- =============================================================================
-- Phase 6: 轮询补扫用的 push entry 构建（与 build_l1_cache 内 collect_pushable 等效，
-- 但并入目标为 state.latch_cache 并去重）。保持 entry 结构完全一致（type=push/PushNClimb）。
-- ⚠️ 注意：此函数必须定义在 branch_poll_check 之前，后者会调用它（Lua 词法查找规则）
-- =============================================================================
local function collect_push_entry_for_poll(actor, cls)
    if cls == nil then return false end
    local entry_type = nil
    if string.find(cls, "PushNClimb", 1, true) ~= nil then
        entry_type = "PushNClimb"
    else
        entry_type = "push"
    end

    local root_loc = nil
    pcall(function()
        if actor.K2_GetActorLocation ~= nil then root_loc = actor:K2_GetActorLocation() end
    end)
    if root_loc == nil then return false end
    -- CDO 剔除：默认对象位置恒为 (0,0,0)。2026-09-05 改动：
    -- CDO 只作"本关疑似有该族"的轮询证据（计入 state.cdo_push/cdo_pn），不入库（防 L2 推车崩溃）。
    -- 家族基类 CDO（Pushable_Base_ABP / PushNClimb_Base_ABP）恒在、任意关卡都有，不计入证据。
    if (root_loc.X or 0) == 0 and (root_loc.Y or 0) == 0 and (root_loc.Z or 0) == 0 then
        state.branch_scan_cdo = (state.branch_scan_cdo or 0) + 1
        local is_base = (string.find(cls, "Pushable_Base_ABP", 1, true) ~= nil)
            or (string.find(cls, "PushNClimb_Base_ABP", 1, true) ~= nil)
        if not is_base then
            if entry_type == "PushNClimb" then
                state.cdo_pn = (state.cdo_pn or 0) + 1
            else
                state.cdo_push = (state.cdo_push or 0) + 1
            end
        end
        return false -- CDO 不入库
    end

    local root_rot = nil
    pcall(function()
        if actor.K2_GetActorRotation ~= nil then root_rot = actor:K2_GetActorRotation() end
    end)
    local sh_pushable = nil
    pcall(function() sh_pushable = actor.SHPushable end)
    local sh_push_audio = nil
    pcall(function() sh_push_audio = actor.SHPushableAudio end)

    -- 去重：同一 actor 已在 latch_cache —— 若已是真实条目则跳过；
    -- 若为 CDO 特征（loc==nil 或 loc==(0,0,0)，历史遗留/加载未就位）则当作不存在，
    -- 删除旧 CDO 后由下方把真实场景重新并入（真实柜替换占位 CDO）。
    local stale_idx = nil
    if state.latch_cache ~= nil then
        for i, pe in ipairs(state.latch_cache) do
            if pe.actor == actor then
                local is_cdo = (pe.loc == nil)
                    or ((pe.loc.X or 0) == 0 and (pe.loc.Y or 0) == 0 and (pe.loc.Z or 0) == 0)
                if not is_cdo then
                    return false -- 已是真实条目，跳过
                end
                stale_idx = i -- 旧 CDO，待移除
                break
            end
        end
    end
    if state.latch_cache ~= nil and stale_idx ~= nil then
        table.remove(state.latch_cache, stale_idx)
    end

    local new_entry = {
        actor = actor,
        class = cls,
        className = cls,
        sub_type = entry_type,
        type = entry_type,
        component = nil,
        loc = root_loc,
        rot = root_rot,
        SHPushable = sh_pushable,
        SHPushableAudio = sh_push_audio,
        completed = false,
    }
    table.insert(state.latch_cache, new_entry)
    return true
end

-- =============================================================================
-- Phase 6: push/PushNClimb 分支 10s 判空轮询补扫（2026-09-01，用户定案）
-- streaming 分段加载覆盖：真实柜所在子关卡可能晚于 L1 重建时点才加载，日志中"远处柜
-- 一直是 CDO"即由此产生。机制：每 10s 必做一次判空检查（纯 Lua 零扫描）；仅当某分支
-- 计数为 0 才触发一次重扫；重扫用新结果整体写回 push/PushNClimb 两分支计数
--（两分支来自同一次 PUSH_BASE_CLASS 查询，扫一个会把它俩都带空/带满）。
-- 隔离：独立函数，不触碰 L1 重建调度 / L2 / on_grab_tick / find_nearest_to_hand。
-- ⚠️ 调用 collect_push_entry_for_poll，后者必须在此函数之前定义（已满足）
-- =============================================================================
-- 2026-09-03 卡顿排查（用户拍板）：本文件日志写 open latch 通道（diagnose_open_latch.log），
-- 不与 item_door 混用；write_log(level, message) 两参数约定，落盘行自带日期时间前缀
local function diag_log(level, msg)
    local fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
    if fn ~= nil then
        pcall(fn, level, msg)
    end
end

local function branch_poll_check()
    -- 门控：游戏暂停时 os.clock 不走（轮询也应暂停），间隔须满 30s
    -- 2026-09-03 定案（用户拍板）：10s → 30s（曾临时改 100s 隔离实验实锤重扫为周期卡顿真凶）。
    -- 30s + 单次枚举：大图每 30s 卡 ~175ms 一次（原 10s 卡 350ms），平时无感。
    if os.clock() - state.branch_next_poll < 30.0 then return end

    -- 玩家在抓握/保持阶段不扫（避免指针翻转干扰抓取吸附）
    if state.current_type ~= nil then
        state.branch_next_poll = os.clock() -- 本周期跳过，但保持 10s 节奏
        return
    end
    -- 不与 L1 重建并发，防重复扫描
    if state.l1_rebuild_pending or state.branch_scanning then return end

    -- 判空：纯 Lua 遍历 latch_cache，数 push / PushNClimb 各自计数（均为 CDO 剔除后条目）
    local push_count, pn_count = 0, 0
    if state.latch_cache ~= nil then
        for _, pe in ipairs(state.latch_cache) do
            if pe.type == "push" then push_count = push_count + 1
            elseif pe.type == "PushNClimb" then pn_count = pn_count + 1 end
        end
    end

    -- 2026-09-04 方案1：触发条件从"任一分支为空"改为"某分支为空 且 未休眠"。
    -- 扫描本身仍一次 find_all_of 整体刷新两分支；这里只决定要不要扫、扫到后每分支各自是否停。
    --   · 某分支 非空    → 该分支满意即停（永不触发，同原语义）
    --   · 某分支 空+未休眠 → 需要扫（本周期触发重扫，顺带刷新另一分支结果）
    --   · 某分支 空+已休眠 → 不再因它触发（"扫了 N 次仍空"=本关没有这一族的证据，封顶合理）
    -- 两分支都不需扫 → 只有判空，零扫描。
    local push_needs = (push_count == 0 and not state.push_dormant)
    local pn_needs = (pn_count == 0 and not state.pn_dormant)
    if not push_needs and not pn_needs then
        state.branch_next_poll = os.clock()
        return
    end

    -- 至少一个分支为空 → 重扫一趟（两分支结果整体刷新）
    state.branch_scanning = true
    state.branch_scan_hits = 0
    state.branch_scan_cdo = 0
    -- 2026-09-05：子类 CDO 证据计数（重扫前清零，仅本次采集结果）
    state.cdo_push = 0
    state.cdo_pn = 0
    local poll_t0 = os.clock() -- 卡顿排查 2026-09-03：重扫耗时统计

    local push_cls = "BlueprintGeneratedClass /Game/Game/Gameplay/Interactions/PushableObjects/Pushable_Base_ABP.Pushable_Base_ABP_C"
    local list = nil
    -- 2026-09-03 卡顿修复（100s 隔离实验实锤 + 用户拍板）：删除"空结果 → clearClassCache → 二次枚举"重试。
    -- 原因：UClass 是全局对象不随关卡卸载，类指针不会过期；clearClassCache 只清 get_class 的类对象
    -- 缓存（一条 Lua 表记录），与实例枚举无关——第二次 find_all_of 必然复现空结果，纯浪费一次全量
    -- 枚举（大图 ~175ms，占重扫成本一半）。保留 clearClassCache 本身（微秒级）作类指针保鲜。
    -- 2026-09-05：includeDefault=true 把子类 CDO 一并扫出作"本关疑似有该族"证据（collect_push_entry_for_poll 内识别）。
    pcall(function() list = uevrUtils.find_all_of(push_cls, true) end)
    if list ~= nil and #list == 0 then
        pcall(function() uevr_lib.clearClassCache(push_cls) end)
    end

    -- 定向查询重扫：对每个对象按类名分流 push / PushNClimb，CDO 剔除 + 已存在去重后并入
    if list ~= nil then
        for _, actor in ipairs(list) do
            local cls = nil
            pcall(function()
                local acls = actor:get_class()
                if acls ~= nil and acls.get_full_name ~= nil then cls = acls:get_full_name() end
            end)
            if collect_push_entry_for_poll(actor, cls) then
                state.branch_scan_hits = state.branch_scan_hits + 1
            end
        end
        -- 2026-09-04：两处小车扫描同触发带 spot 配对。DesiredSpot 与 PushNClimb 1:1 成对且是关卡静态对象，
        -- 本趟扫到小车时 spot 必已在场 → 刷新配对索引，保证"车进 L1"= "spot 配对进索引"，二者永远一致
        -- （读档那次由 build_l1_cache 全量重建覆盖其 query_with_heal 自愈）。
        rebuild_desired_spot_index()
    end

    -- 重扫后重新统计并整体写回两分支计数（供诊断）
    local npush, npn = 0, 0
    if state.latch_cache ~= nil then
        for _, pe in ipairs(state.latch_cache) do
            if pe.type == "push" then npush = npush + 1
            elseif pe.type == "PushNClimb" then npn = npn + 1 end
        end
    end
    -- 2026-09-04 方案1：重扫后逐分支独立更新 尝试计数/休眠标志（扫描一次，两分支各自结算）。
    -- 2026-09-05 扩展（用户拍板三情况 + 保险丝封顶）：
    --   · 分支扫到实例(>0)      → 满意即停：attempts 清零、解除休眠
    --   · 分支仍有子类CDO证据   → 本关疑似有该族，空扫计数用 POLL_CDO_DORMANT_AFTER(20) 封顶
    --                            （保险丝防 CDO 恒在却始终无实例的极端图）
    --   · 分支无实例也无CDO证据 → 本关确无该族，用 POLL_DORMANT_AFTER(1) 封顶（2026-09-05 用户改定：重试1次即休）
    --   两分支独立结算：一分支扫到不牵连另一分支（各自用各自 count/cdo 判定，互不清算）。
    local function settle_branch(count, cdo, attempts_k, dormant_k)
        if count > 0 then
            state[attempts_k] = 0
            state[dormant_k] = false
        else
            state[attempts_k] = (state[attempts_k] or 0) + 1
            -- 有子类CDO证据 → 用大封顶(20，保险丝)；无证据 → 用小封顶(3，确无该族)
            local cap = (cdo ~= nil and cdo > 0) and state.POLL_CDO_DORMANT_AFTER or state.POLL_DORMANT_AFTER
            if state[attempts_k] >= cap then
                state[dormant_k] = true
            end
        end
    end
    settle_branch(npush, state.cdo_push or 0, "push_attempts", "push_dormant")
    settle_branch(npn, state.cdo_pn or 0, "pn_attempts", "pn_dormant")
    l1_trace_add(string.format("branch poll rescan: hits=%d CDO=%d push=%d(cdo%d) PushNClimb=%d(cdo%d) (sleep push=%s%d pn=%s%d)",
        state.branch_scan_hits, state.branch_scan_cdo, npush, state.cdo_push or 0, npn, state.cdo_pn or 0,
        tostring(state.push_dormant), state.push_attempts or 0,
        tostring(state.pn_dormant), state.pn_attempts or 0))
    -- 卡顿排查 2026-09-03：重扫走 find_all_of（结果为空时还 clearClassCache 强制下次全量重枚举），
    -- 无柜/无车地图两分支恒为 0 → 每 10s 无限重扫，疑似周期性卡顿来源，耗时落盘验证
    diag_log("UDOOR", string.format(
        "[BRANCH-POLL] rescan took %.1fms hits=%d CDO=%d push=%d->%d(cdo%d) PushNClimb=%d->%d(cdo%d) (sleep push=%s/%d pn=%s/%d)",
        (os.clock() - poll_t0) * 1000, state.branch_scan_hits, state.branch_scan_cdo,
        push_count, npush, state.cdo_push or 0, pn_count, npn, state.cdo_pn or 0,
        tostring(state.push_dormant), state.push_attempts or 0,
        tostring(state.pn_dormant), state.pn_attempts or 0))

    state.branch_scanning = false
    state.branch_next_poll = os.clock()
end

-- =============================================================================
-- cart（推车）碰撞管理 —— L2 层实现（sh2_push_cart_plan.md §4.2；方法 §11.11 定案，Phase 0 实测通过）
-- 关：SetCollisionResponseToChannel(2, 0)  ECC_Pawn → ECR_Ignore（手能贴到把手，不关无法开始推车）
-- 开：SetCollisionResponseToChannel(2, 2)  ECC_Pawn → ECR_Block（对称恢复）
-- ★ L1 完全复用现有 PushNClimb 登记（用户定案：严禁改 L1）。组件枚举放 L2：
--   2026-09-04：枚举不再缓存。命中改分帧——命中帧登记待办任务，真正枚举全组件并逐组件设碰撞由
--   on_cart_parse_tick 在下一次 update_l2_cache(≤1s) 内即时执行，结果不跨生命周期持有 mesh 指针。
-- ★ 2026-09-02 用户再审定案：只关 StaticMesh_Handle_R 测试不够，改回对**车全部 PrimitiveComponent**
--   关对角色(Pawn)碰撞（车体/轮轴/把手全 ECC_Pawn→Ignore，避免车身挡角色）。
--   组件枚举 get_cart_comp_cache（现为即时枚举）用于逐组件开关。
-- 严禁 SetActorEnableCollision(false) / SetCollisionEnabled(0)（粒度过粗）
-- =============================================================================
local PRIMITIVE_COMP_CLASS = "Class /Script/Engine.PrimitiveComponent"

-- 枚举单车的全部 PrimitiveComponent（首选 K2_GetComponentsByClass 反射类，兜底 get_components(true) 类名过滤）
local function list_cart_primitive_components(actor)
    if actor == nil then return nil end
    local primCls = nil
    pcall(function() primCls = uevrUtils.get_class(PRIMITIVE_COMP_CLASS) end)
    if primCls ~= nil and actor.K2_GetComponentsByClass ~= nil then
        local ok, comps = pcall(function() return actor:K2_GetComponentsByClass(primCls) end)
        if ok and comps ~= nil and type(comps) == "table" and #comps > 0 then
            return comps
        end
    end
    local out = {}
    local ok, all_comps = pcall(function() return actor:get_components(true) end)
    if ok and all_comps ~= nil then
        for _, c in ipairs(all_comps) do
            local cname = nil
            pcall(function()
                local ccls = c:get_class()
                if ccls ~= nil and ccls.get_full_name ~= nil then cname = ccls:get_full_name() end
            end)
            if cname ~= nil and string.find(cname, "PrimitiveComponent", 1, true) ~= nil then
                table.insert(out, c)
            end
        end
        if #out > 0 then return out end
    end
    return nil
end

-- 取某车的 PrimitiveComponent 列表（2026-09-04：去除缓存，每次即时枚举，不跨生命周期持有 mesh 指针）。
-- 每台车量极小（约 9 个 mesh：4 轮 + 4 把手 + 1 本体），即时枚举无感知；且杜绝"小车销毁→地址复用→假命中旧列表"的野指针隐患。
local function get_cart_comp_cache(actor)
    if actor == nil then return nil end
    return list_cart_primitive_components(actor)
end

-- 折叠把手锚点组件名（Handle_R + 镜像 Handle_L，2026-09-05 新增第二把手）
-- 左手互斥二选一：近哪根抓哪根；吸附条几何常量 AB(=CD) 共享，仅生效于不同把手组件
local CART_HANDLE_COMP_NAMES = { "StaticMesh_Handle_R", "StaticMesh_Handle_L" }

-- 解析该车折叠把手锚点组件（StaticMesh_Handle_R / StaticMesh_Handle_L）。
-- ① 属性访问优先：diagnose_cart 已验证 entry.actor.StaticMesh_Handle_X 能稳定取到锚点组件。
-- ② 失败再走 L2 已缓存组件列表按名匹配兜底（复用 get_cart_comp_cache，只枚举一次）。
-- comp_name 指定则只解析该名；nil 则按 CART_HANDLE_COMP_NAMES 顺序返回首根存在的（兜底 R→L）。
--@param actor userdata|nil
--@param comp_name string|nil
--@return userdata|nil
local function resolve_cart_handle(actor, comp_name)
    if actor == nil then return nil end
    local names = comp_name and { comp_name } or CART_HANDLE_COMP_NAMES
    -- ① 属性访问优先
    for _, cname in ipairs(names) do
        local direct = nil
        pcall(function() direct = actor[cname] end)
        if direct ~= nil then return direct end
    end
    -- ② L2 已缓存组件列表按名匹配兜底（只枚举一次）
    local comps = get_cart_comp_cache(actor)
    if comps == nil then return nil end
    for _, cname in ipairs(names) do
        for _, comp in ipairs(comps) do
            if comp ~= nil then
                local name = nil
                pcall(function() name = comp:get_name() end)
                if name == cname then return comp end
            end
        end
    end
    return nil
end

-- 对车全部 PrimitiveComponent 关/开 Pawn 碰撞（ignore=true 关(2,0)，false 开(2,2)）
-- 2026-09-02 用户再审：仅关 StaticMesh_Handle_R 测试不够，改为遍历车全部组件关对角色(Pawn)碰撞
-- 2026-09-04：本函数退化为同步"设置/恢复"入口。命中"关"(ignore=true)已改由 on_cart_parse_tick 分帧执行(不缓存)，
--           此处仅被各"恢复"(ignore=false)路径同步调用；mesh 即时枚举不缓存。
local function set_cart_pawn_collision(actor, ignore)
    if actor == nil then return false end
    local comps = get_cart_comp_cache(actor)
    if comps == nil then return false end
    local resp = ignore and 0 or 2
    local n = 0
    for _, comp in ipairs(comps) do
        if comp ~= nil then
            pcall(function()
                if comp.SetCollisionResponseToChannel ~= nil then
                    comp:SetCollisionResponseToChannel(2, resp)
                    n = n + 1
                end
            end)
        end
    end
    return n > 0
end

-- =============================================================================
-- cart 到位检测 + complete 标记（2026-09-02 用户定案）
-- 到位信号 = DesiredSpot 配对后 IsManagedActorInDesiredSpot()（与诊断脚本 do_spot_scan 完完全全同法）；
-- 弃用 Timeline_CollapsingHandlesAnim 折叠播放位置（实测折叠开始也读不出）；到位判定改用下方
-- DesiredSpot 配对 + IsManagedActorInDesiredSpot()，实现在 L2 命中内联分支（on_cart_target_selected）。
-- =============================================================================
-- actor → 缓存 key（同 cart_comp_cache 的 get_address 键控法）
local function cart_actor_key(actor)
    local addr = nil
    pcall(function()
        if actor.get_address ~= nil then addr = actor:get_address() end
    end)
    return addr
end

-- 已到位检测：DesiredSpot 配对 + IsManagedActorInDesiredSpot()（2026-09-02 用户定案）
-- 读法与 diagnose_cart.lua do_spot_scan / on_tick_spot_poll 完完全全一致：
--   uevrUtils.find_all_of(DESIRED_SPOT_CLASS,false) → 每 spot.ManagedActor==cart_actor(配对)
--   → 配对 spot:IsManagedActorInDesiredSpot()==true 即"已到位"（替代原 Timeline alpha 读法，timeline 根本读不出）。
-- 注意：放弃 Timeline_CollapsingHandlesAnim 折叠检测（实测即使折叠开始也读不出播放位置）。
-- =============================================================================
CART_DESIRED_SPOT_CLASS =
    "BlueprintGeneratedClass /Game/Game/Gameplay/Interactions/PushableObjects/PushNClimbDesiredSpot_BP.PushNClimbDesiredSpot_BP_C"

-- DesiredSpot 全局索引重建（2026-09-04）：build_l1_cache 全量重建 与 branch_poll_check 分支轮询 两处小车扫描
-- 各调用一次，保证"小车进入 L1"与"它的 DesiredSpot 配对入索引"完全同步。
-- DesiredSpot 与 PushNClimb 1:1 成对且为关卡静态对象，扫到小车时 spot 必已在场。
-- BP 类自愈同 query_with_heal 先例：find_all_of 空表/nil → clearClassCache → 重扫（读档 GC/重载后兜底）。
-- 索引未收录的车 → get_cart_desired_spot 返回 nil → 视为未到位，行为安全。
rebuild_desired_spot_index = function()
    state.desired_spot_by_managed = {}
    local spots = nil
    pcall(function()
        spots = uevrUtils.find_all_of(CART_DESIRED_SPOT_CLASS, false)
        if spots == nil or #spots == 0 then
            pcall(function() uevr_lib.clearClassCache(CART_DESIRED_SPOT_CLASS) end)
            spots = uevrUtils.find_all_of(CART_DESIRED_SPOT_CLASS, false)
        end
    end)
    local spot_count = 0
    if spots ~= nil then
        for _, spot in ipairs(spots) do
            local managed = nil
            pcall(function() managed = spot.ManagedActor end)
            if managed ~= nil then
                local maddr = nil
                pcall(function() if managed.get_address ~= nil then maddr = managed:get_address() end end)
                if maddr ~= nil and state.desired_spot_by_managed[maddr] == nil then
                    state.desired_spot_by_managed[maddr] = spot
                    spot_count = spot_count + 1
                end
            end
        end
    end
    l1_trace_add("desired_spot index built=" .. tostring(spot_count))
end

-- DesiredSpot 配对索引已上移 L1（state.desired_spot_by_managed，2026-09-04）：
-- L1 重建时用 query_with_heal 全量扫一次建成，L2 只做 O(1) 查表，不再在此全图扫描。

-- 前向声明：cart_trace 在下面定义，但 get_cart_desired_spot 先用到，必须先占位
local cart_trace

-- 取与 cart 配对的 DesiredSpot（ManagedActor == cart_actor），源 = L1 建的全局索引。
-- 2026-09-04：原实现在此对每辆新车首接近跑 find_all_of(CART_DESIRED_SPOT_CLASS) 全图扫描（按车缓存），
-- 正是"首接近小车卡顿"主要来源；改为查 L1 索引 → 零全图扫描、零自愈，随 L1 生命周期自动失效/刷新。
-- 索引未收录该车（新区域/尚未 L1 重建/无配对）→ 返回 nil → 视为未到位，行为安全。
local function get_cart_desired_spot(cart_actor)
    if cart_actor == nil then return nil end
    local key = cart_actor_key(cart_actor)
    if key == nil then return nil end
    local v = state.desired_spot_by_managed[key]
    return v
end

-- 标记小车 complete（已折叠到位）：后续 L2 命中永不再枚举组件/关 Pawn 碰撞
local function mark_cart_completed(actor)
    local key = cart_actor_key(actor)
    if key ~= nil then state.cart_completed[key] = true end
end

-- 查询小车是否已 complete
local function is_cart_completed(actor)
    local key = cart_actor_key(actor)
    return key ~= nil and state.cart_completed[key] == true
end

-- 吸附链路诊断日志：写 diagnose_cart.log，受 _G.CART_DIAG_ENABLED（诊断脚本总开关）管理，严禁控制台
-- 节流：每分类 0.5s 一条，避免检测帧高频刷盘（吸取诊断脚本"日志致卡顿"教训）
-- 覆盖 DETECT（吸附检测卡点）、HANDLE（锚点组件解析方式）、GRIP（进入吸附）
local function vec3str(v)
    if v == nil then return "nil" end
    return string.format("(%.1f,%.1f,%.1f)", v.X or 0, v.Y or 0, v.Z or 0)
end
local cart_trace_last = {}
cart_trace = function(kind, msg)
    if not rawget(_G, "CART_DIAG_ENABLED") then return end
    local now = os.clock()
    local last = cart_trace_last[kind]
    if last ~= nil and (now - last) < 0.5 then return end
    cart_trace_last[kind] = now
    local f, err = io.open("diagnose_cart.log", "a")
    if f then
        f:write(string.format("[CART][%s] %s\n", kind, msg))
        f:close()
    end
end

-- L2 命中瞬间调用（幂等守卫）：写入目标即关 Pawn 碰撞；目标切换先恢复上一车
-- detach 不恢复（用户定案）：L2 内保持关闭以便续抓/再推，松手不代表离开作用范围
-- 2026-09-02 用户定案：L2 刷到新条目先判"已到位"（DesiredSpot + IsManagedActorInDesiredSpot，与诊断脚本同法），
-- 已到位 → 不枚举 primitive component、不关碰撞，并打 complete 标记
local function on_cart_target_selected(entry)
    local actor = entry ~= nil and entry.actor or nil
    if actor == nil then return end
    local addr = tostring(cart_actor_key(actor))
    -- complete 守卫提到最前：已配对上位(complete)的车，整体跳过扫组件/关碰撞逻辑。
    -- 若其碰撞仍处于关闭（更早一拍被关但未恢复），先恢复一次再跳过，杜绝"日志未关、实际已关"。
    if is_cart_completed(actor) then
        if state.cart_collision_off_actor == actor then
            set_cart_pawn_collision(actor, false)
            state.cart_collision_off_actor = nil
            cart_trace("L2", string.format("L2 hit COMPLETED: restored still-closed collision (addr=%s)", addr))
        end
        cart_trace("L2", string.format("L2 hit: COMPLETED mark (addr=%s) -> skip collision OFF", addr))
        l1_trace_add("cart L2 hit: completed mark hit, skip collision OFF")
        return
    end
    if state.cart_collision_off_actor == actor then return end -- 幂等：同一目标不重复操作
    if state.cart_collision_off_actor ~= nil then
        -- 目标切换：先恢复上一目标碰撞（complete 早退也必须先恢复，防上一车碰撞永远挂关）
        if set_cart_pawn_collision(state.cart_collision_off_actor, false) then
            cart_trace("L2", string.format("switch target: restored PREV cart collision (addr=%s)", tostring(cart_actor_key(state.cart_collision_off_actor))))
        end
        state.cart_collision_off_actor = nil
    end
    -- 已到位检查（DesiredSpot 配对 + IsManagedActorInDesiredSpot，与诊断脚本同法）：
    -- 分 "配对(pair)" 与 "到位(in_spot)" 两步，用于区分加载存档后指针问题(pair失败) vs 判定不在位
    local spot = get_cart_desired_spot(actor)
    local arrived = false
    if spot ~= nil then
        pcall(function() arrived = spot:IsManagedActorInDesiredSpot() end)
    end
    cart_trace("L2", string.format("L2 hit addr=%s spot=%s in_desired_spot=%s -> %s", addr,
        spot ~= nil and tostring(cart_actor_key(spot)) or "nil(pair-fail)",
        tostring(arrived), arrived and "ARRIVED(skip collision OFF)" or "not-arrived(proceed collision OFF)"))
    if arrived then
        -- 到位(complete)车：不再关碰撞；但若此前该车碰撞仍被关闭(守卫仍指向它)，必须立即恢复。
        -- 原则(用户指令)：不论是否到位，碰撞只在"进入L2时关、退出L2或到位时恢复"。
        if state.cart_collision_off_actor == actor then
            set_cart_pawn_collision(actor, false)
            state.cart_collision_off_actor = nil
            cart_trace("L2", string.format("ARRIVED: restored collision (addr=%s)", addr))
        end
        mark_cart_completed(actor)
        l1_trace_add("cart L2 hit: in desired spot (arrived), mark completed, skip collision OFF")
        cart_trace("FOLD", string.format("L2 hit arrived addr=%s -> completed, collision touched", addr))
        return
    end
    -- 2026-09-04：命中关 Pawn 碰撞改分帧（用户定案：不缓存 mesh 指针，碰撞晚一点无所谓，1s 内完成即可）。
    -- 命中帧只登记守卫 + 待办任务；真正枚举全部组件(9 mesh)+SetCollision 放下一次 update_l2_cache(≤1s)执行，
    -- 不再在命中帧同步做完整枚举，避免接近卡顿。
    state.cart_collision_off_actor = actor -- 守卫立即置位，保证恢复路径能识别当前关闭中目标
    state.cart_parse = { actor = actor, addr = addr } -- 待分帧"关碰撞"任务
    cart_trace("L2", string.format("collision OFF scheduled (deferred apply, addr=%s)", addr))
    l1_trace_add("cart L2 hit: collision OFF scheduled (deferred apply)")
    return
end

-- 2026-09-04：命中"关碰撞"待办任务的逐帧(1s cadence)驱动。每次 update_l2_cache 检查一次：
--   自取消守卫：off_actor 已不再指向本车(离场/切换/到位恢复) → 丢弃，不迟到 apply；
--   否则本次枚举全组件(9 mesh)并逐一把 ECC_Pawn 设 Ignore，结果不缓存。
local function on_cart_parse_tick()
    local t = state.cart_parse
    if t == nil then return end
    state.cart_parse = nil -- 无论成败，仅执行一次
    if state.cart_collision_off_actor ~= t.actor then
        cart_trace("L2", "collision OFF deferred: abort (off_actor no longer this cart)")
        return -- 已离场/切换/恢复，丢弃
    end
    local actor, addr = t.actor, t.addr
    local comps = get_cart_comp_cache(actor) -- 即时枚举，不缓存
    local n = 0
    if comps ~= nil then
        for _, comp in ipairs(comps) do
            if comp ~= nil then
                pcall(function()
                    if comp.SetCollisionResponseToChannel ~= nil then
                        comp:SetCollisionResponseToChannel(2, 0) -- ECC_Pawn=2, ECR_Ignore=0
                        n = n + 1
                    end
                end)
            end
        end
    end
    if n > 0 then
        cart_trace("L2", string.format("collision OFF applied (deferred, %d comps, addr=%s)", n, tostring(addr)))
        l1_trace_add("cart L2 hit: collision OFF applied (deferred)")
    else
        cart_trace("L2", string.format("collision OFF FAILED (deferred, addr=%s)", tostring(addr)))
        l1_trace_add("cart L2 hit: collision OFF FAILED (deferred, no primitive resolved)")
    end
end

-- 目标清空（离开3米/条目消失/脚本重置）：恢复碰撞并置空守卫
-- 换关不走这里（组件指针失效）——build_l1_cache 直接置空不恢复
local function on_cart_target_cleared(reason)
    if state.cart_collision_off_actor ~= nil then
        set_cart_pawn_collision(state.cart_collision_off_actor, false)
        cart_trace("L2", string.format("target cleared (%s): collision restored", tostring(reason or "?")))
        state.cart_collision_off_actor = nil
        l1_trace_add("cart target cleared: pawn collision restored (" .. (reason or "?") .. ")")
    end
end

-- =============================================================================
-- L2：每秒从 L1 缓存筛选 3m 内门栓 → 写入 state.cached_latches
-- （替代原 on_scan_tick → scan_latches；find_nearest_to_hand 不改）
-- pawn/pawn_loc 由 on_scan_tick 复用传入（1s 一次）；其它调用点（重建后立即刷新）为 nil 时内部兜底
-- =============================================================================
local function update_l2_cache(pawn, pawn_loc)
    on_cart_parse_tick() -- 2026-09-04：命中"关碰撞"待办任务的(1s cadence)驱动；空任务即返回
    if not state.latch_cache_valid or state.latch_cache == nil then return end

    if pawn == nil then
        pcall(function() pawn = uevrUtils.get_local_pawn() end)
    end
    if pawn == nil then return end
    if pawn_loc == nil then
        pcall(function()
            if pawn.K2_GetActorLocation ~= nil then
                pawn_loc = pawn:K2_GetActorLocation()
            end
        end)
    end
    if pawn_loc == nil then return end

    local results = {}
    local range_sq = SCAN_RANGE_CM * SCAN_RANGE_CM
    -- 阶段1 push: 唯一目标柜（3米内筛选）单独存 state.push_target，不进 cached_latches
    -- （push 抓取/吸附在阶段2实现；阶段1仅缓存，避免 find_nearest_to_hand 误当滑栓抓取）
    local push_target = nil
    -- 阶段1 cart(推车): 唯一目标车（3米内筛选）单独存 state.cart_target，不进 cached_latches
    -- L1 完全复用现有 PushNClimb 登记（type 不改）；命中即关 Pawn 碰撞（§4.2）
    local cart_target = nil
    for _, entry in ipairs(state.latch_cache) do
        -- Phase 0: 移除 completed 过滤，便于反复测试已解锁的门
        -- Phase 6 验收前恢复此过滤逻辑
        -- getValid 校验已移除：L1 缓存条目来自 build_l1_cache 的 find_all_of，
        -- 跨关卡/存档加载时缓存会重建，引用有效性由生命周期保证
        -- glide：吸附点用门体当前世界位置。门被 OverrideDoorAlpha 驱动后 DoorMesh
        -- 会物理位移，若用 L1 建缓存时的旧点，门拉开后吸附点就失效、无法再次吸附。
        -- 实时读 DoorMesh 位置（读失败回退 L1 缓存点）。
        -- 阶段1 push/PushNClimb：不进 cached_latches（防 find_nearest_to_hand 误抓）。
        -- 仅对 push 族做 3 米筛选，选唯一目标柜存 state.push_target；PushNClimb（推车）同法
        -- 选唯一目标车存 state.cart_target，且命中瞬间关 Pawn 碰撞（§4.2）。
        if entry.type == "push" or entry.type == "PushNClimb" then
            -- 2026-09-05：build 主扫已恢复 CDO 剔除，latch_cache 无 cdo 字段条目，
            -- 无需此处 skip（CDO 证据仅轮询路内部计数，不入库）。
            if entry.type == "push" and entry.loc ~= nil then
                local pdist_sq = math_lib.vectorDistanceSquaredSafe(entry.loc, pawn_loc)
                if pdist_sq <= range_sq then
                    if push_target == nil or pdist_sq < push_target.dist_sq then
                        push_target = { entry = entry, dist_sq = pdist_sq }
                    end
                end
            elseif entry.type == "PushNClimb" and entry.loc ~= nil then
                local cdist_sq = math_lib.vectorDistanceSquaredSafe(entry.loc, pawn_loc)
                if cdist_sq <= range_sq then
                    if cart_target == nil or cdist_sq < cart_target.dist_sq then
                        cart_target = { entry = entry, dist_sq = cdist_sq }
                    end
                end
            end
            goto continue_push_l2
        end
        local base_loc = entry.loc
        if entry.type == "glide" then
            pcall(function()
                if entry.door_mesh ~= nil then
                    base_loc = reload_tools.get_component_world_location(entry.door_mesh)
                end
            end)
            if base_loc == nil then base_loc = entry.loc end
        end
        local dist_sq = math_lib.vectorDistanceSquaredSafe(base_loc, pawn_loc)
        if dist_sq <= range_sq then
            -- glide 吸附点偏移（仅 glide 生效）：L3 吸附判定用偏移后的点
            -- Spot Offset 为门本地轴偏移：经门 Actor yaw 旋转变换到世界轴再叠加
            -- 2026-09-03：A/B 双点离散吸附（非线段）——两个点各转一次世界，
            -- L3 find_nearest_to_hand 取距手更近的点，便于实机分别验证 A/B 位置
            local eff_loc = base_loc
            local eff_b = nil
            if entry.type == "glide" then
                -- 门本地 → 世界：绕 Z 轴旋转（Yaw 逆时针为正）
                local spot_yaw = entry.spot_rot and entry.spot_rot.Yaw or 0
                -- 反向门判定（与 apply_grip_anim 的 flip_side 同一标准）：
                -- 玩家 pawn 在 DoorMesh right 负侧 = 反向，用 REV 组偏移
                local flip_rev = false
                pcall(function()
                    local right = nil
                    if entry.door_mesh ~= nil and entry.door_mesh.GetRightVector ~= nil then
                        right = entry.door_mesh:GetRightVector()
                    end
                    if right == nil then
                        -- fallback：由门 yaw 合成 right（与 apply_grip_anim 的 fallback 一致）
                        local yaw = math.rad(spot_yaw)
                        local cy, sy = math.cos(yaw), math.sin(yaw)
                        right = { X = -sy, Y = cy, Z = 0 }
                    end
                    local dx = (pawn_loc.X or 0) - (base_loc.X or 0)
                    local dy = (pawn_loc.Y or 0) - (base_loc.Y or 0)
                    local dz = (pawn_loc.Z or 0) - (base_loc.Z or 0)
                    flip_rev = (dx * (right.X or 0) + dy * (right.Y or 0) + dz * (right.Z or 0)) < 0
                end)
                local off_a = flip_rev and GLIDE_SPOT_OFFSET_A_REV or GLIDE_SPOT_OFFSET_A
                local off_b = flip_rev and GLIDE_SPOT_OFFSET_B_REV or GLIDE_SPOT_OFFSET_B
                eff_loc = math_lib.rotateOffset2D(
                    base_loc, off_a,
                    spot_yaw
                )
                eff_b = math_lib.rotateOffset2D(
                    base_loc, off_b,
                    spot_yaw
                )
            elseif entry.type == "light_switch" then
                -- light_switch 距离基准 = 吸附点 = 锚点 mesh 根 + 本地 Z 抬升(LIGHT_SPOT_OFFSET) 旋转到世界。
                -- 手部偏移相对该吸附点；距离检测也必须用吸附点，而非 mesh 根节点。
                -- 复用 math_lib.vectorRotate（本地向量→rotator→世界），比 glide 仅绕 Yaw 的 rotateOffset2D 更通用。
                local spot_world = math_lib.vectorRotate(
                    { X = LIGHT_SPOT_OFFSET.x, Y = LIGHT_SPOT_OFFSET.y, Z = LIGHT_SPOT_OFFSET.z },
                    entry.rot, false
                )
                eff_loc = { X = base_loc.X + spot_world.X, Y = base_loc.Y + spot_world.Y, Z = base_loc.Z + spot_world.Z }
            end
            local result = {
                component = entry.component,
                loc = eff_loc,
                rot = entry.rot,
                mesh_name = entry.mesh_name,
                dist_to_pawn_cm = math.sqrt(dist_sq),
                type = entry.type,
                spot_orig_loc = entry.loc,  -- 原始吸附点（诊断用）
            }
            -- 诊断用只读透传（2026-09-02）：仅 glide 携带完整 L1 字段，
            -- 供 diagnose_open_latch 读 L2 即用；纯引用，不改主脚本任何行为
            if entry.type == "glide" then
                result.actor = entry.actor
                result.door_mesh = entry.door_mesh
                result.spot = entry.spot
                result.spot_rot = entry.spot_rot
                result.spot_axis = entry.spot_axis
                result.spot_b_loc = eff_b   -- B 吸附点世界（L3 双点取近用）
                result.open_sign = entry.open_sign
                result.movement = entry.movement
            end
            table.insert(results, result)
        end
        ::continue_push_l2::
    end
    state.cached_latches = results  -- 直接写入，L3（find_nearest_to_hand）不用改
    state.push_target = push_target and push_target.entry or nil

    -- cart：写入目标 + L2 命中即关碰撞 / 目标清空即恢复（§4.2 碰撞管理）
    local new_cart_entry = cart_target and cart_target.entry or nil
    if new_cart_entry ~= nil then
        on_cart_target_selected(new_cart_entry)
    elseif state.cart_target ~= nil then
        on_cart_target_cleared("out of 3m range / entry gone")
    end
    state.cart_target = new_cart_entry
end

-- =============================================================================
-- Pawn 生命周期检测（on_grab_tick 开头调用，检测 pawn 引用变化触发 L1 重建）
-- 覆盖：首帧、加载存档、关卡切换（pawn UObject 指针变化即触发）
-- 延迟 5 秒重建：等关卡资源加载完成后再扫 find_all_of
-- =============================================================================
-- 统一调度 L1 重建（延迟 5 秒 + 0 条目时持久重试）
-- 触发路径：pawn 引用变化（首帧/加载存档/关卡切换）
-- 持久重试（排查存档加载问题）：L1 为 0 条目时每 2 秒重试一次，最多 2 次，
-- 直到扫到条目为止——关卡资源/子关卡流送慢时 5s+2s 重试覆盖；2 次仍空即放弃
local function schedule_l1_rebuild(reason)
    state.l1_rebuild_pending = true
    state.l1_rebuild_time = os.clock()
    state.l1_retry_pending = false
    state.l1_retry_count = 0
    l1_trace_add("rebuild scheduled: " .. (reason or "?"))
end

local function check_cache_invalidation()
    -- pawn 变化检测已统一到 main.lua（check_pawn_globally），经 M.on_pawn_changed 喂入；
    -- 此处不再 get_local_pawn，pawn==nil 清理也由 on_pawn_changed("pawn_nil") 处理。

    -- 首次重建：延迟 5 秒等关卡资源加载
    if state.l1_rebuild_pending and os.clock() - state.l1_rebuild_time > 5.0 then
        local cutscene_once = state.l1_cutscene_once == true
        state.l1_cutscene_once = false
        build_l1_cache()
        update_l2_cache()
        state.l1_rebuild_pending = false
        local after_count = state.latch_cache and #state.latch_cache or 0
        l1_trace_add(string.format("auto rebuild fired: L1 total=%d", after_count))

        -- 过场结束的立即重建：建出 0 条也【不】进入 0 条目 2s 重试（用户定案，与常规路径不同）
        if after_count == 0 and not cutscene_once then
            state.l1_retry_pending = true
            state.l1_retry_time = os.clock()
            state.l1_retry_count = 0
        end
    end

    -- 持久重试：L1 仍为 0 条目时每 2 秒再扫一次（最多 2 次，扫到即停）
    if state.l1_retry_pending and os.clock() - state.l1_retry_time > 2.0 then
        build_l1_cache()
        update_l2_cache()
        state.l1_retry_count = (state.l1_retry_count or 0) + 1
        local after_count = state.latch_cache and #state.latch_cache or 0
        l1_trace_add(string.format("retry #%d fired: L1 total=%d", state.l1_retry_count, after_count))

        if after_count > 0 or state.l1_retry_count >= 2 then
            state.l1_retry_pending = false
            if after_count == 0 then
                l1_trace_add("retry gave up: 2 attempts, L1 still empty")
            end
        else
            state.l1_retry_time = os.clock() -- 继续 2 秒后再试
        end
    end

    -- Phase 6: push/PushNClimb 判空轮询补扫（随 check_cache_invalidation 每帧自然调用）
    -- 2026-09-04 方案1落地后恢复启用：每分支独立"满意即停 + 3次封顶休眠"根治周期卡顿。
    -- 缺族地图（无柜/无车）：进关至多重扫 POLL_DORMANT_AFTER(3) 次（90s 流送窗口）后本关休眠，
    -- 不再因空分支触发，平时只有纯 Lua 判空（零扫描）。另可通过诊断脚本的 Levels 哨兵在真正
    -- 流送关卡加载时唤醒休眠分支（方案2，见 diagnose_pushable.lua）。恢复 = 取消下一行注释。
    branch_poll_check()
end

-- =============================================================================
-- 高亮（已禁用：CustomDepth 高亮无实际效果）
-- =============================================================================
-- local function apply_highlight(comp)
--     pcall(function()
--         comp:SetRenderCustomDepth(true)
--         comp:SetCustomDepthStencilValue(100)
--     end)
-- end

-- local function remove_highlight(comp)
--     pcall(function()
--         comp:SetRenderCustomDepth(false)
--     end)
-- end

-- =============================================================================
-- 吸附、Grip 动画、滑动、回弹
-- =============================================================================

-- 左手 grip：09 gripLeft.enter/leave（主链路），VREnvironment.state.leftGrip（fallback）
local function is_left_grip_pressed()
    if vr_globals ~= nil and type(vr_globals.isLeftGripHeld) == "function" then
        if vr_globals.isLeftGripHeld() == true then
            return true
        end
    end
    local env = rawget(_G, "VREnvironment")
    if type(env) == "table" then
        local left_grip = env.state and env.state.leftGrip
        if left_grip == true then
            return true
        end
        if type(left_grip) == "number" and left_grip > 0.5 then
            return true
        end
    end
    return false
end

-- 吸附：通过 accessories 回调系统派发 on_accessory_attach，
-- 让 hands.lua 内部处理手部组件查找、saveHandSnapshot、K2_AttachTo
-- @param target 可选，默认为表演体（state.perf_mesh）；ATTACHED 一律先生成表演体再挂手
-- §27：spawn_current_perf / hide_perf_body / destroy_perf / read_comp_state 定义于后，前向声明
local spawn_current_perf
local hide_perf_body
local destroy_perf
local read_comp_state
local perf_log
local read_latch_orient

-- push 手附加参数按吸附锚点区分 A/B：spot_local == PUSH_SPOT_B 时用 B 组，否则 A 组
-- 热重载后 push_spot_local 为 nil 时默认 A 组
--@return table offset {x,y,z}, table rotation {pitch,yaw,roll}
local function get_push_hand_params()
    if state.push_spot_local == PUSH_SPOT_B then
        return PUSH_HAND_OFFSET_B, PUSH_HAND_ROTATION_B
    end
    return PUSH_HAND_OFFSET_A, PUSH_HAND_ROTATION_A
end

-- glide 手部位姿计算（2026-09-03 自 apply_grip_anim glide 分支原样抽出，纯搬运不改行为）
-- 内容：offset 选组（正向 / REV）、反向门判定（玩家在 DoorMesh right 负侧）、yaw+180、
-- A/B 吸附条 t 插值落点并入。只读 state 与常量，供 apply_grip_anim 与
-- update_glide_hand_attach（诊断滑块原地重挂）复用。
--@return table loc {x,y,z}, table rot {pitch,yaw,roll}
local function compute_glide_hand_pose()
    local loc = {
        GLIDE_HAND_OFFSET.x,
        GLIDE_HAND_OFFSET.y,
        GLIDE_HAND_OFFSET.z,
    }
    local rot = { GLIDE_HAND_ROTATION.pitch, GLIDE_HAND_ROTATION.yaw, GLIDE_HAND_ROTATION.roll }

    -- §16.3/16.5：标定门 _5 在 DoorMesh +right。side<0 时镜像抓握。
    -- 证据：无修正手指冲自己(180°)；yaw/roll 取反变 90°；yaw+180 朝向对了，
    -- 但只翻 loc.y 时手漂在门外更近处（网格随 yaw+180 朝玩家伸出，水平偏移未跟着转）。
    -- 正确：水平偏移绕 Up 转 180° → (x,y)→(-x,-y)，与 yaw+180 一致；Z 抬升不动。
    local flip_side = false
    local side_v, front_v = 0, 0
    pcall(function()
        -- §27：侧边手性判断必须用真 DoorMesh（state.latch_component），不用 perf（tgt 是其 owner 无 DoorMesh）
        local mesh = state.latch_component
        local owner = nil
        if mesh ~= nil and mesh.GetOwner ~= nil then owner = mesh:GetOwner() end
        if owner ~= nil and owner.DoorMesh ~= nil then mesh = owner.DoorMesh end

        local mesh_loc, right, fwd
        if mesh ~= nil then
            if mesh.K2_GetComponentLocation ~= nil then mesh_loc = mesh:K2_GetComponentLocation() end
            if mesh.GetRightVector ~= nil then right = mesh:GetRightVector() end
            if mesh.GetForwardVector ~= nil then fwd = mesh:GetForwardVector() end
        end
        if (right == nil or fwd == nil) and owner ~= nil and owner.K2_GetActorRotation ~= nil then
            local arot = owner:K2_GetActorRotation()
            local yaw = math.rad((arot and (arot.Yaw or arot.yaw)) or 0)
            local cy, sy = math.cos(yaw), math.sin(yaw)
            if fwd == nil then fwd = { X = cy, Y = sy, Z = 0 } end
            if right == nil then right = { X = -sy, Y = cy, Z = 0 } end
        end

        local pawn = uevrUtils.get_local_pawn()
        local pawn_loc = nil
        if pawn ~= nil and pawn.K2_GetActorLocation ~= nil then pawn_loc = pawn:K2_GetActorLocation() end
        if mesh_loc == nil or right == nil or pawn_loc == nil then return end

        local dx = (pawn_loc.X or 0) - (mesh_loc.X or 0)
        local dy = (pawn_loc.Y or 0) - (mesh_loc.Y or 0)
        local dz = (pawn_loc.Z or 0) - (mesh_loc.Z or 0)
        side_v = dx * (right.X or 0) + dy * (right.Y or 0) + dz * (right.Z or 0)
        if fwd ~= nil then
            front_v = dx * (fwd.X or 0) + dy * (fwd.Y or 0) + dz * (fwd.Z or 0)
        end
        flip_side = side_v < 0
    end)
    if flip_side then
        -- 反向门(side<0)：使用独立偏移参数组 GLIDE_HAND_OFFSET_REV / GLIDE_HAND_ROTATION_REV
        -- 保留反转逻辑(yaw+180)；offset 基于 REV 参数，可在诊断面板单独微调（如 y 轴 ±3cm），不影响正向门
        loc[1] = GLIDE_HAND_OFFSET_REV.x
        loc[2] = GLIDE_HAND_OFFSET_REV.y
        loc[3] = GLIDE_HAND_OFFSET_REV.z
        rot = { GLIDE_HAND_ROTATION_REV.pitch, GLIDE_HAND_ROTATION_REV.yaw, GLIDE_HAND_ROTATION_REV.roll }
        rot[2] = rot[2] + 180      -- yaw+180：朝向转到玩家一侧
    end

    -- 吸附点偏移并入手的 RelativeLocation：
    -- glide 吸附条（B-3 2026-09-03）：落点 = GLIDE_SPOT_OFFSET_A/B 按 state.glide_bar_t 逐分量插值，
    -- 手握条上任意位置；GLIDE_USE_BAR=false 时 t 退化为 0/1（= B-2 双点离散选点）。
    -- 2026-09-03：正向/反向门各自独立 y（正向 -2 / 反向 7），按 flip_side 选组，
    -- 判定标准与 L2 缓存一致（玩家在 DoorMesh right 负侧 = 反向）。
    -- 手相对吸附父的偏移 = 吸附点偏移 + 手偏移，attach 时立即到位，
    -- 避免"手先掉到根节点、再弹到 +1.5m"的同帧未就位闪烁。
    local off_a = flip_side and GLIDE_SPOT_OFFSET_A_REV or GLIDE_SPOT_OFFSET_A
    local off_b = flip_side and GLIDE_SPOT_OFFSET_B_REV or GLIDE_SPOT_OFFSET_B
    -- B-3 吸附条：落点 = A/B 按 t 逐分量插值（t 吸附瞬间冻结于 state.glide_bar_t；
    -- z 因 A.z==B.z==150 插值恒 150，"Z 钉死"语义不破坏）；GLIDE_USE_BAR=false 时 t 退化为 0/1
    local tt = state.glide_bar_t or 0
    local glide_spot = {
        x = off_a.x + (off_b.x - off_a.x) * tt,
        y = off_a.y + (off_b.y - off_a.y) * tt,
        z = off_a.z + (off_b.z - off_a.z) * tt,
    }
    loc[1] = (loc[1] or 0) + glide_spot.x
    loc[2] = (loc[2] or 0) + glide_spot.y
    loc[3] = (loc[3] or 0) + glide_spot.z

    return loc, rot
end

local function apply_grip_anim(target)
    if state.grip_anim_applied then return end

    -- 开关族（switch）：不生成表演体、不隐藏本体（用户裁决 2026-08-29）。
    -- timeline 直驱的是真杠杆本体，所见即所得；表演体会把真本体藏起来导致
    -- "下压时杠杆视觉不动、松手才弹到位"。手直接挂真本体（复用 accessories 回调，
    -- 与其他族同一条吸附路径）。
    if is_switch_family(state.current_type) then
        local tgt = state.latch_component
        if tgt == nil then
            state.last_attach_error = "switch body is nil"
            return
        end
        -- 开关族偏移按类型分表：staircase_switch 用 SWITCH（定稿），light_switch 用 LIGHT（滑块校准中）
        local loc, rot
        if state.current_type == "light_switch" then
            -- effective = 吸附点(LIGHT_SPOT_OFFSET，锚点本地+Z 25cm) + 手偏移(LIGHT_HAND_OFFSET)，相对锚点 mesh 根
            loc = { LIGHT_HAND_OFFSET.x + LIGHT_SPOT_OFFSET.x,
                    LIGHT_HAND_OFFSET.y + LIGHT_SPOT_OFFSET.y,
                    LIGHT_HAND_OFFSET.z + LIGHT_SPOT_OFFSET.z }
            rot = { LIGHT_HAND_ROTATION.pitch, LIGHT_HAND_ROTATION.yaw, LIGHT_HAND_ROTATION.roll }
        else
            loc = { SWITCH_HAND_OFFSET.x, SWITCH_HAND_OFFSET.y, SWITCH_HAND_OFFSET.z }
            rot = { SWITCH_HAND_ROTATION.pitch, SWITCH_HAND_ROTATION.yaw, SWITCH_HAND_ROTATION.roll }
        end
        pcall(function()
            uevrUtils.executeUEVRCallbacks("on_accessory_attach",
                Handed.Left, tgt, nil, 0, loc, rot)
        end)
        -- grip animation：switch 族暂用 latch 手势（未来可按类型分表）
        pcall(function()
            local anim_name = GRIP_ANIM_BY_TYPE[state.current_type] or GRIP_ANIM_BY_TYPE.latch
            hands.setHoldingAttachment(0, anim_name)
        end)
        state.grip_anim_applied = true
        state.last_attach_error = nil
        return
    end

    -- Phase 2 cart（sh2 推车）：直挂 StaticMesh_Handle_R，无表演体、不隐藏本体。
    -- attach 父 == 锚点组件（Handle_R），offset 在 Handle_R 本地零换算（推柜挂柜本体 StaticMesh 同理）。
    -- 吸附条 A/B 每帧现算世界（find_cart_nearest），投影点 C′ 的 Handle_R 本地 = (t×BAR_LEN, A_Y, A_Z)，t 冻结。
    if state.current_type == "cart" then
        local tgt = state.cart_handle
        if tgt == nil then
            -- attach 前未解析则现场解析：复用 L2 缓存按名取该车 StaticMesh_Handle_R
            local entry = state.cart_target
            if entry ~= nil then tgt = resolve_cart_handle(entry.actor) end
            if tgt ~= nil then state.cart_handle = tgt end
        end
        if tgt == nil then
            state.last_attach_error = "cart handle is nil"
            return
        end
        -- effective loc = 投影点 C′ 的 Handle_R 本地偏移 + 手偏移（t 抓握瞬间冻结）
        -- C′ 在吸附线 A 端 X + t×LEN 处（A、B 同 y/z，故 y/z 直接取 A_Y/A_Z）
        local px = CART_BAR_A_X + (state.cart_t or 0) * CART_BAR_LEN
        local loc = {
            CART_HAND_OFFSET.x + px,
            CART_HAND_OFFSET.y + CART_BAR_A_Y,
            CART_HAND_OFFSET.z + CART_BAR_A_Z,
        }
        local rot = { CART_HAND_ROTATION.pitch, CART_HAND_ROTATION.yaw, CART_HAND_ROTATION.roll }
        pcall(function()
            uevrUtils.executeUEVRCallbacks("on_accessory_attach",
                Handed.Left, tgt, nil, 0, loc, rot)
        end)
        -- 吸附瞬间调 drink_potion 手势（§5.2/§9 定案，半握拳锁死握把手）
        pcall(function()
            local anim_name = GRIP_ANIM_BY_TYPE["cart"] or GRIP_ANIM_BY_TYPE.latch
            hands.setHoldingAttachment(0, anim_name)
        end)
        state.grip_anim_applied = true
        state.last_attach_error = nil
        return
    end

    -- Phase 2 push（sh2 可推柜）：直挂柜本体 StaticMesh，无表演体、不隐藏本体。
    -- 载体定案（2026-08-30）：柜本体可直接 TeleportAbsolute 搬动，mask 不生成表演体。
    -- 手 attach 到柜 StaticMesh（兜底根组件），相对偏移 = 吸附锚点(PUSH_SPOT_A/B) + 手偏移(按锚点取 A/B 组)
    if state.current_type == "push" then
        local tgt = state.push_static_mesh
        if tgt == nil then
            -- attach 前未解析则现场解析：柜 actor.StaticMesh 兜底 RootComponent
            local entry = state.push_target
            if entry ~= nil and entry.actor ~= nil then
                pcall(function() tgt = entry.actor.StaticMesh end)
                if tgt == nil then pcall(function() tgt = entry.actor.RootComponent end) end
            end
            if tgt ~= nil then state.push_static_mesh = tgt end
        end
        if tgt == nil then
            state.last_attach_error = "push body is nil"
            return
        end
        -- effective loc = 吸附面内落点 + 手偏移（锚点分组 A/B 不变，落点随吸附面 clamp）
        local spot = state.push_anchor_local or state.push_spot_local or PUSH_SPOT_A
        local hoff, hrot = get_push_hand_params()
        local loc = {
            (hoff.x or 0) + spot.x,
            (hoff.y or 0) + spot.y,
            (hoff.z or 0) + spot.z,
        }
        local rot = { hrot.pitch, hrot.yaw, hrot.roll }
        pcall(function()
            uevrUtils.executeUEVRCallbacks("on_accessory_attach",
                Handed.Left, tgt, nil, 0, loc, rot)
        end)
        -- 吸附瞬间调用 push_wardrobe 手势（配置面板中可微调）
        pcall(function()
            local anim_name = GRIP_ANIM_BY_TYPE[state.current_type] or GRIP_ANIM_BY_TYPE.latch
            hands.setHoldingAttachment(0, anim_name)
        end)
        state.grip_anim_applied = true
        state.last_attach_error = nil
        return
    end

    -- §27：其余族（latch/key/glide）一律先有表演体，再挂手；生成失败禁止回退挂本体（glide 会红框）
    if state.perf_mesh == nil then
        local body = state.latch_component
        perf_log("INFO", string.format(
            "apply_grip_anim: spawn perf start type=%s body=%s",
            tostring(state.current_type), body == nil and "nil" or "set"))
        if body ~= nil then
            if not spawn_current_perf(body) then
                state.last_attach_error = "spawn_current_perf failed"
                perf_log("ERROR", "apply_grip_anim: spawn_current_perf failed, err=" .. tostring(state.last_attach_error))
                return
            end
            hide_perf_body(body)
            perf_log("INFO", "apply_grip_anim: perf spawned + body hidden")
            perf_log("INFO", "hide check: " .. read_comp_state(body, "body") .. " | " .. read_comp_state(state.perf_mesh, "perf"))
        end
    end

    local tgt = target or state.perf_mesh or state.latch_component
    if tgt == nil then
        state.last_attach_error = "target is nil"
        return
    end

    -- 派发 accessories 吸附事件（hands.lua 监听此事件完成吸附）
    -- 根据 type 选择手部偏移
    local loc, rot
    if state.current_type == "key" then
        loc = { KEY_HAND_OFFSET.x, KEY_HAND_OFFSET.y, KEY_HAND_OFFSET.z }
        rot = { KEY_HAND_ROTATION.pitch, KEY_HAND_ROTATION.yaw, KEY_HAND_ROTATION.roll }
    elseif is_switch_family(state.current_type) then
        -- 开关族：按类型分表取各自偏移/旋转（楼梯 SWITCH 定稿；灯 LIGHT 滑块校准中）
        if state.current_type == "light_switch" then
            loc = { LIGHT_HAND_OFFSET.x, LIGHT_HAND_OFFSET.y, LIGHT_HAND_OFFSET.z }
            rot = { LIGHT_HAND_ROTATION.pitch, LIGHT_HAND_ROTATION.yaw, LIGHT_HAND_ROTATION.roll }
        else
            loc = { SWITCH_HAND_OFFSET.x, SWITCH_HAND_OFFSET.y, SWITCH_HAND_OFFSET.z }
            rot = { SWITCH_HAND_ROTATION.pitch, SWITCH_HAND_ROTATION.yaw, SWITCH_HAND_ROTATION.roll }
        end
    elseif state.current_type == "glide" then
        -- §27：手 attach 到表演体（无碰撞副本，相对门本地轴，自动跟随门朝向，换门不错位）。
        -- 吸附点抬升（A/B 吸附条上 t 插值落点，门根上方默认 Z=150）在吸附前并入 loc，
        -- 手的偏移 = 条上落点 + GLIDE_HAND_OFFSET，相对表演体即相对门根。
        -- 2026-09-03：loc/rot 计算（offset 选组/反向门判定/yaw+180/吸附条落点）原样抽出到
        -- compute_glide_hand_pose，与诊断滑块原地重挂 update_glide_hand_attach 共用一份。
        loc, rot = compute_glide_hand_pose()
    else
        -- §27：latch 反向门检测。镜像(up.Z<0)前提下，是否用 REV 组由 mesh 型号单独决定
        -- (get_latch_uses_rev)，正向参数为 fallback。日志确认：01_B(圆形)反向用 REV；02_A(方形)反向走正向。
        local latch_flip = false
        pcall(function()
            local comp = state.latch_component
            if comp ~= nil and comp.GetUpVector ~= nil then
                local uv = comp:GetUpVector()
                latch_flip = (uv.Z or 0) < 0 and get_latch_uses_rev(state.current_mesh_name)
            end
        end)
        if latch_flip then
            loc = { LATCH_HAND_OFFSET_REV.x, LATCH_HAND_OFFSET_REV.y, LATCH_HAND_OFFSET_REV.z }
            rot = { LATCH_HAND_ROTATION_REV.pitch, LATCH_HAND_ROTATION_REV.yaw, LATCH_HAND_ROTATION_REV.roll }
        else
            loc = { LATCH_HAND_OFFSET.x, LATCH_HAND_OFFSET.y, LATCH_HAND_OFFSET.z }
            rot = { LATCH_HAND_ROTATION.pitch, LATCH_HAND_ROTATION.yaw, LATCH_HAND_ROTATION.roll }
        end

        -- §诊断：打印门栓本体朝向基矢量 + flip 判定
        perf_log("INFO", "LATCH_ORIENT: " .. read_latch_orient(state.latch_component)
            .. " latch_flip=" .. tostring(latch_flip))
    end

    -- 2026-09-03：glide 吸附点偏移并入已随 glide 分支整体移入 compute_glide_hand_pose
    -- （与 update_glide_hand_attach 共用），此处不再重复处理。

    pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_attach",
            Handed.Left, tgt, nil, 0, loc, rot)
    end)

    -- §17.2A：glide 吸附后门框红线 — 只关手碰撞，不动 DoorMesh
    if state.current_type == "glide" then
        pcall(function()
            local hand = hands.getHandComponent(0)
            if hand ~= nil then
                if hand.SetCollisionEnabled ~= nil then hand:SetCollisionEnabled(0) end
                if hand.SetGenerateOverlapEvents ~= nil then hand:SetGenerateOverlapEvents(false) end
            end
        end)
    end

    -- grip animation（按当前类型选手势；默认 latch 的 pull_lock）
    pcall(function()
        local anim_name = GRIP_ANIM_BY_TYPE[state.current_type] or GRIP_ANIM_BY_TYPE.latch
        hands.setHoldingAttachment(0, anim_name)
    end)
    state.last_attach_error = nil
    state.last_attach_info = nil
    state.grip_anim_applied = true

    -- 记录吸附成功信息（供诊断脚本读取）
    local tgt_name = "nil"
    pcall(function() tgt_name = tgt:get_full_name() end)
    state.last_attach_info = string.format("attached: Handed.Left -> %s", tgt_name)
end

local function remove_grip_anim()
    if not state.grip_anim_applied then return end
    -- 通过 accessories 回调系统 detach（hands.lua 监听 restoreHandSnapshot）
    pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_detach", Handed.Left)
    end)
    -- grip animation
    pcall(function()
        hands.setHoldingAttachment(0, nil)
    end)
    state.grip_anim_applied = false
    -- §27：销毁统一由 remove_grip_anim 负责（覆盖松手/离开/脱手/切门所有路径）
    destroy_perf()
end

-- 销毁表演体 + 恢复被隐藏的本体可见
destroy_perf = function()
    -- 1. 销毁表演体
    if state.perf_actor ~= nil then
        pcall(function() state.perf_actor:SetHiddenInGame(true, true) end)
        local ok_destroy, err_destroy = pcall(function()
            uevrUtils.destroy_actor(state.perf_actor)
        end)
    end
    state.perf_actor = nil
    state.perf_mesh = nil
    state.perf_origin = nil

    -- 2. 恢复被隐藏的本体可见性（§27：用 perf_hidden_body，勿死写 latch_component）
    --    §14.x.9.4-1：恢复 propagate 与 hide_perf_body 对称（glide=false，只恢复 DoorMesh 自己，
    --    不把子树里默认 Hidden 的 Shape 强制 Visible&&!HiddenInGame，避免 shipping 画线红框）
    local body = state.perf_hidden_body
    if body ~= nil then
        local propagate = true
        if state.current_type == "glide" then
            propagate = false
        end
        pcall(function()
            body:SetVisibility(true, propagate)
        end)
        pcall(function()
            body:SetHiddenInGame(false, propagate)
        end)
    end
    state.perf_hidden_body = nil
end

local function rot_pitch_yaw_roll(rot)
    if rot == nil then return 0, 0, 0 end
    return rot.Pitch or rot.pitch or 0, rot.Yaw or rot.yaw or 0, rot.Roll or rot.roll or 0
end

-- 对齐 remote_grab：对 mesh 调 K2_SetWorldLocation，第三参必须是 HitResult
local function set_perf_world_transform(loc, rot)
    local mesh = state.perf_mesh
    local hit = get_reusable_hit()
    if mesh == nil or loc == nil or hit == nil then
        return false
    end
    local ok = pcall(function()
        if mesh.SetMobility ~= nil then
            mesh:SetMobility(2)
        end
        if mesh.SetVisibility ~= nil then
            mesh:SetVisibility(true, true)
        end
        if mesh.SetHiddenInGame ~= nil then
            mesh:SetHiddenInGame(false, true)
        end
        mesh:K2_SetWorldLocation(
            uevrUtils.vector(loc.X, loc.Y, loc.Z), false, hit, false)
        if rot ~= nil then
            local pitch, yaw, roll = rot_pitch_yaw_roll(rot)
            mesh:K2_SetWorldRotation(
                uevrUtils.rotator(pitch, yaw, roll), false, hit, false)
        end
    end)
    return ok
end

local function read_perf_world_loc()
    local loc = nil
    pcall(function()
        if state.perf_mesh ~= nil and state.perf_mesh.K2_GetComponentLocation ~= nil then
            loc = state.perf_mesh:K2_GetComponentLocation()
        elseif state.perf_actor ~= nil and state.perf_actor.K2_GetActorLocation ~= nil then
            loc = state.perf_actor:K2_GetActorLocation()
        end
    end)
    return loc
end

-- §27：生成当前类型的表演体（只生成，不挂手；挂手由 apply_grip_anim 统一处理）
-- @param body 本体组件（glide=DoorMesh，latch=DoorLatchBar，key=KeyStaticMesh）
-- @return boolean 成功 true；失败返回 false（不挂本体）
-- 诊断日志 helper：走专用诊断脚本 write_log（受 diag.enabled 开关管理，非控制台）
perf_log = function(level, msg)
    local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
    if log_fn then pcall(log_fn, level, "[PERF_DIAG] " .. msg) end
end

-- §诊断：读取门栓本体朝向基矢量 + Actor yaw，用于确认镜像门
read_latch_orient = function(comp)
    if comp == nil then return "comp=nil" end
    local out = {}
    pcall(function()
        local owner = nil
        if comp.GetOwner ~= nil then owner = comp:GetOwner() end
        local yaw, pitch, roll = "?", "?", "?"
        if owner ~= nil and owner.K2_GetActorRotation ~= nil then
            local arot = owner:K2_GetActorRotation()
            yaw = tostring(arot and (arot.Yaw or arot.yaw) or "?")
            pitch = tostring(arot and (arot.Pitch or arot.pitch) or "?")
            roll = tostring(arot and (arot.Roll or arot.roll) or "?")
        end
        local rvec, fvec, upvec = "?", "?", "?"
        if comp.GetRightVector ~= nil then
            local v = comp:GetRightVector()
            rvec = string.format("(%.2f,%.2f,%.2f)", v.X or 0, v.Y or 0, v.Z or 0)
        end
        if comp.GetForwardVector ~= nil then
            local v = comp:GetForwardVector()
            fvec = string.format("(%.2f,%.2f,%.2f)", v.X or 0, v.Y or 0, v.Z or 0)
        end
        if comp.GetUpVector ~= nil then
            local v = comp:GetUpVector()
            upvec = string.format("(%.2f,%.2f,%.2f)", v.X or 0, v.Y or 0, v.Z or 0)
        end
        out[1] = string.format("yaw=%s pitch=%s roll=%s right=%s fwd=%s up=%s",
            yaw, pitch, roll, rvec, fvec, upvec)
    end)
    return out[1] or "read failed"
end

-- 安全读取组件的可见/隐藏/碰撞状态，用于确认隐藏是否真正生效
read_comp_state = function(comp, tag)
    if comp == nil then
        return tag .. "=nil"
    end
    local vis, hidd, col = "?", "?", "?"
    pcall(function()
        if comp.IsVisible ~= nil then vis = tostring(comp:IsVisible()) end
        if comp.IsHidden ~= nil then hidd = tostring(comp:IsHidden()) end
        if comp.GetCollisionEnabled ~= nil then
            local ce = comp:GetCollisionEnabled()
            col = (ce ~= nil) and tostring(ce) or "?"
        end
    end)
    return string.format("%s vis=%s hidd=%s col=%s", tag, vis, hidd, col)
end

spawn_current_perf = function(body)
    if state.perf_mesh ~= nil then
        return true
    end
    if body == nil then
        state.last_attach_error = "spawn_current_perf: body is nil"
        perf_log("ERROR", "spawn_current_perf FAIL: body is nil")
        return false
    end

    local body_loc = { X = 0, Y = 0, Z = 0 }
    local body_rot = nil
    local mesh_asset = nil
    pcall(function()
        mesh_asset = body.StaticMesh
        local cl = reload_tools.get_component_world_location(body)
        if cl ~= nil then body_loc = { X = cl.X, Y = cl.Y, Z = cl.Z } end
        local cr = reload_tools.get_component_world_rotation(body)
        if cr ~= nil then body_rot = cr end
    end)
    if mesh_asset == nil then
        state.last_attach_error = "spawn_current_perf: mesh_asset is nil"
        perf_log("ERROR", "spawn_current_perf FAIL: mesh_asset is nil")
        return false
    end

    state.perf_origin = { X = body_loc.X, Y = body_loc.Y, Z = body_loc.Z }
    state.perf_hidden_body = body

    local spawn_tf = reload_tools.make_spawn_transform(body_loc, body_rot)
    local perf_actor = nil
    pcall(function()
        perf_actor = uevrUtils.spawn_actor(spawn_tf, 1, nil)
    end)
    if perf_actor == nil then
        state.last_attach_error = "spawn_current_perf: spawn_actor failed"
        perf_log("ERROR", "spawn_current_perf FAIL: spawn_actor failed")
        return false
    end

    local perf_mesh = nil
    pcall(function()
        perf_mesh = uevrUtils.createStaticMeshComponent(mesh_asset, {
            manualAttachment = true,
            relativeTransform = spawn_tf,
            deferredFinish = false,
            parent = perf_actor,
            collisionEnabled = false,
            visible = true,
        })
    end)
    if perf_mesh == nil then
        pcall(function() uevrUtils.destroy_actor(perf_actor) end)
        state.perf_hidden_body = nil
        state.perf_origin = nil
        state.last_attach_error = "spawn_current_perf: createStaticMeshComponent failed"
        perf_log("ERROR", "spawn_current_perf FAIL: createStaticMeshComponent failed")
        return false
    end

    pcall(function()
        if perf_mesh.SetMobility ~= nil then
            perf_mesh:SetMobility(2)
        end
        if perf_actor.K2_SetRootComponent ~= nil then
            perf_actor:K2_SetRootComponent(perf_mesh)
        end
    end)

    state.perf_actor = perf_actor
    state.perf_mesh = perf_mesh

    if not set_perf_world_transform(body_loc, body_rot) then
        destroy_perf()
        state.last_attach_error = "spawn_current_perf: set_perf_world_transform failed"
        perf_log("ERROR", "spawn_current_perf FAIL: set_perf_world_transform failed")
        return false
    end

    pcall(function() uevrUtils.copyMaterials(body, perf_mesh) end)

    local actual = read_perf_world_loc()
    local drift = 0
    if actual ~= nil then
        drift = math.sqrt(math_lib.vectorDistanceSquaredSafe(actual, body_loc))
    end
    if actual == nil or drift > 50 then
        destroy_perf()
        state.last_attach_error = "spawn_current_perf: perf spawn location invalid"
        perf_log("ERROR", "spawn_current_perf FAIL: perf spawn location invalid drift=" .. tostring(drift))
        return false
    end

    return true
end

-- §27：隐藏本体（glide 只藏门扇 propagate=false，不藏交互/音频子件；latch/key 用现网 propagate=true）
hide_perf_body = function(body)
    if body == nil then
        return
    end
    local propagate = true
    if state.current_type == "glide" then
        propagate = false
    end
    pcall(function() body:SetVisibility(false, propagate) end)
    pcall(function() body:SetHiddenInGame(true, propagate) end)
end

-- forward declaration：begin_slide 早于 Phase 2 helper 定义，需前置声明避免 upvalue 解析为 nil
-- [方案 B：press_a_button_once 已禁用，不再需要 forward declaration
-- local press_a_button_once
-- ]

-- 从 latch/key 组件导航到 DoorLock（unlock_door_directly 前半段抽取，Phase 5）
-- 导航路径：component → GetOwner() → AttachParent*Door → DoorLock
-- @param component DoorLatchBar / KeyStaticMesh 的 StaticMeshComponent
-- @return USHDoorLockBaseComponent 或 nil
-- 必须定义在 begin_slide / begin_rotate 之前（local 作用域），供锁状态预检使用
local function navigate_to_door_lock(component)
    if component == nil then
        return nil
    end

    -- Step 1: 拥有 Actor（门栓 SlidingBolt / 锁 Lock Actor）
    local owner_actor = nil
    pcall(function() owner_actor = component:GetOwner() end)
    if owner_actor == nil then
        return nil
    end

    -- Step 2: 取父 Actor（单门 AttachParentSingleDoor 为主，双门 AttachParentDoubleDoor 为 fallback）
    -- 单门: ADA_SingleDoor_Base_BP_C → ASingleDoor_BP_C (offset 0x0340)
    -- 双门: ADA_DoubleDoor_Base_BP_C → ASHDoubleDoorSD (offset 0x0348)
    -- 事实表 §10.2 / §10.2b
    local door_actor = nil
    pcall(function() door_actor = owner_actor.AttachParentSingleDoor or owner_actor.AttachParentDoubleDoor end)
    if door_actor == nil then
        return nil
    end

    -- Step 3: DoorLock (直接属性访问，诊断已验证可行)
    local door_lock = nil
    pcall(function() door_lock = door_actor.DoorLock end)
    return door_lock
end

local function begin_slide(latch)
    -- §27：表演体在 ATTACHED 已生成，此处只判断进入滑动，不再生成/换挂。
    -- 若 ATTACHED 生成失败（perf_mesh 为 nil），禁止回退挂真本体，直接不动作。
    if state.perf_mesh == nil then
        return
    end
    -- Phase 5: 锁状态预检 — 门已解锁（或导航失败）则不进入 SLIDING，保持 ATTACHED
    -- 手仍吸附在表演体，但拉不动（所有门通用，不做分支）
    local door_lock = navigate_to_door_lock(state.latch_component)
    if door_lock == nil or not door_lock:IsLocked() then
        return
    end

    state.phase = PHASE.SLIDING
    state.latch_origin_loc = { X = latch.loc.X, Y = latch.loc.Y, Z = latch.loc.Z }
    state.latch_origin_rot = latch.rot
    -- 保留现网 nil rotator → {1,0,0} 回退：math_lib.getForwardVector 的 nil 语义是 0 向量，
    -- 会让 slide_axis 变 {0,0,0} 导致门栓沿轴位移为 0 拉不动。
    -- 禁止改 math_lib.getForwardVector 的 nil 语义（uevr_utils/mouse/ik 已依赖现网 0 向量）。
    local fwd
    if latch.rot == nil then
        fwd = { X = 1, Y = 0, Z = 0 }
    else
        fwd = math_lib.getForwardVector(latch.rot)
    end
    state.slide_axis = { X = -fwd.X, Y = -fwd.Y, Z = -fwd.Z }
    state.signed_pull = 0
    state.slide_completed = false
    state.progress = 0

    local body_loc = { X = latch.loc.X, Y = latch.loc.Y, Z = latch.loc.Z }
    local left_hand_loc = controllers.getControllerLocation(0)
    if left_hand_loc ~= nil and state.slide_axis ~= nil then
        state.start_anchor_dist = reload_tools.capture_slide_anchor(
            left_hand_loc, body_loc, state.slide_axis
        )
    end

    -- 播放拉门栓音效
    play_sliding_bolt_sound()
end

-- =============================================================================
-- Phase 2：拖动完成后直接调 DoorLock:SetLocked(false) 解锁
-- 方案 B：不走 A 键 / 不播动画 / 不触发音效，纯 UFUNCTION 调用
-- 导航路径（事实表 §10.2）：
--   DoorLatchBar → GetOwner() → SlidingBoltActor
--     → AttachParentSingleDoor → ASHDoor → DoorLock → SetLocked(false, true)
-- =============================================================================
-- [[A 键触发代码已禁用（方案 B 不再需要模拟 A 键）
-- local A_BUTTON_HOLD_MS = 100  -- 短按 100ms 自释放
--
-- local function get_gamepad()
--     return rawget(_G, "VRGamepad")
-- end
--
-- local function release_a_button()
--     if not state.a_button_pressed then return end
--     local gp = get_gamepad()
--     if gp ~= nil and type(gp.setVirtualButton) == "function" and gp.Button ~= nil then
--         pcall(function() gp.setVirtualButton(gp.Button.A, false) end)
--     end
--     state.a_button_pressed = false
-- end
--
-- -- 拉栓开始即按下 A，100ms 后自释放（用 refcount 守护避免重复按下）
-- function press_a_button_once()
--     if state.a_button_pressed then
--         -- 上一次短按的 100ms 窗口尚未结束：先释放再按下，保证 refcount 不累积
--         release_a_button()
--     end
--     local gp = get_gamepad()
--     if gp == nil or type(gp.setVirtualButton) ~= "function" or gp.Button == nil then
--         return
--     end
--     local ok = pcall(function() gp.setVirtualButton(gp.Button.A, true) end)
--     if not ok then
--         return
--     end
--     state.a_button_pressed = true
--     setTimeout(A_BUTTON_HOLD_MS, function()
--         release_a_button()
--     end)
-- end
-- ]]

-- 直接解锁门：从 DoorLatchBar 组件导航到 DoorLock 并调用 SetLocked(false, true)
-- SkipDetectableManagement=true 跳过交互系统检查（事实表 §10.3）
-- @param latch_component DoorLatchBar 的 StaticMeshComponent
-- @return boolean 成功与否
local function unlock_door_directly(latch_component)
    if latch_component == nil then
        return false
    end

    -- Step 1-3: 复用导航（Phase 5 抽取为独立函数）
    local door_lock = navigate_to_door_lock(latch_component)
    if door_lock == nil then
        return false
    end

    -- Step 4: SetLocked(false, true)
    local ok = pcall(function()
        door_lock:SetLocked(false, true)
    end)
    return ok
end

local function end_slide(completed)
    if completed then
        state.phase = PHASE.COMPLETED
        -- 记录进入 COMPLETED 的时间戳，on_grab_tick 据此判断 1 秒停留是否结束
        state.completed_start_t = os.clock()
        -- 拉栓完成：方案 B 直接调 SetLocked(false) 解锁（替代原 press_a_button_once）
        unlock_door_directly(state.latch_component)
        -- 触发左手震动反馈
        eventFeedback.play_latch_haptic()
        -- 标记 L1 缓存中对应门栓为已完成（L2/L3 后续跳过）
        if state.latch_cache ~= nil and state.latch_component ~= nil then
            for _, entry in ipairs(state.latch_cache) do
                if entry.component == state.latch_component then
                    entry.completed = true
                    break
                end
            end
        end
    else
        if state.progress > 0 then
            state.returning = true
            state.return_start_t = os.clock()
            state.return_start_progress = state.progress
        else
            -- 没有滑动：销毁表演体，恢复本体，重新吸附
            destroy_perf()
            state.phase = PHASE.ATTACHED
            apply_grip_anim()
        end
    end
end

local function detach_from_latch()
    -- 阶段4 音效：脱手播放 StopPush（push/cart 型；任意 detach 都播，字段清理前判断）
    if state.current_type == "push" then
        play_push_audio_event("StopPushSoundEvent")
    elseif state.current_type == "cart" then
        play_cart_audio_event("StopPushSoundEvent")
    end
    -- 停止推拉门滑动音效：仅循环层事件需要显式 Stop（Middle_Opened 旧设计）。
    -- §31.7 方案 A 的 Associated Event 为 one-shot，松手立即 Stop 会掐掉刚播的音
    -- （2026-09-03 实测无声根因）→ one-shot 不 Stop，自然播完，仅清引用。
    if state._glide_sound_loop == false then
        state._glide_sound_comp = nil
    else
        stop_sliding_door_sound()
    end
    remove_grip_anim()
    -- if state.highlight_applied and state.latch_component ~= nil then
    --     remove_highlight(state.latch_component)
    --     state.highlight_applied = false
    -- end
    -- Phase 3: 无论何种 phase（含 COMPLETED）都销毁表演体并恢复本体
    destroy_perf()
    state.latch_component = nil
    state.latch_origin_loc = nil
    state.current_mesh_name = nil
    state.current_type = nil
    state.slide_axis = nil
    state.signed_pull = 0
    state.progress = 0
    state.last_attach_info = nil
    state.completed_start_t = 0
    -- Phase 2/4: 清理滑动+钥匙旋转相关字段
    state.slide_completed = false
    state.key_start_pitch = 0
    state.key_rotation_delta = 0
    state.key_completed = false
    state.key_axis = nil
    state.key_body_rot = nil
    -- Phase 2: 清理推拉门(glide)字段
    state.movement = nil
    state.spot_axis = nil
    state.open_sign = 1
    state.glide_completed = false
    state.glide_start_dist = nil
    state.glide_base_alpha = 0
    state.glide_bar_t = nil     -- B-3 吸附条 t（随抓取周期清理）
    state.glide_spot_is_b = nil -- B-3 退役：原 B-2 双点选点标记，统一由 glide_bar_t 表达（0=A，1=B）
    -- Phase 2: 清理折叠楼梯开关(switch)字段
    state.switch_timeline = nil
    state.switch_staircase = nil
    state.switch_length = 1
    state.switch_base_z = nil
    state.switch_alpha = 0
    state.switch_completed = false
    -- Phase 2 (push)：清理推柜吸附状态
    state.push_static_mesh = nil
    state.push_spot_local = nil
    state.push_anchor_local = nil
    state.push_spot_world = nil
    state.push_anchor_offset = nil
    state.push_axis = nil
    state.push_start_dist = nil
    state.push_start_world = nil
    -- Phase 2 (cart)：清理推车吸附状态
    state.cart_handle = nil
    state.cart_t = 0
    state.cart_proj_world = nil
    state.cart_anchor_offset = nil
    state.cart_start_world = nil
    state.phase = PHASE.IDLE

    -- 阶段4：松手刻意 detach 后的 1s 反吸附冷却（共享 detach 入口 ⇒ 全分支生效）
    -- 冷却期间手即使仍在吸附范围也不自动吸回，给玩家 1s 从容离手，杜绝"松手→又被吸回"跳变
    state.detach_cooldown_until = os.clock() + 1.0

    -- 松手后立即刷新 L2：门可能已随 glide 移动，马上重读门体当前位置刷新吸附点，
    -- 保证冷却结束后能立刻再次吸附（不用等下一次 1s on_scan_tick）
    update_l2_cache()
end

local function update_latch_position(offset_cm)
    if state.perf_mesh == nil or state.perf_origin == nil or state.slide_axis == nil then
        return
    end
    local new_loc = {
        X = state.perf_origin.X + state.slide_axis.X * offset_cm,
        Y = state.perf_origin.Y + state.slide_axis.Y * offset_cm,
        Z = state.perf_origin.Z + state.slide_axis.Z * offset_cm,
    }
    set_perf_world_transform(new_loc, nil)
end

-- =============================================================================
-- Phase 2: 钥匙旋转（ROTATING 状态）
-- 位置钉死，只 Pitch 跟手（绕 key_axis 旋转）
-- =============================================================================

-- 旋转阈值（度）：转够 90° 解锁
local KEY_ROTATE_THRESHOLD_DEG = 90

-- begin_rotate：只进入旋转（表演体在 ATTACHED 已生成）+ 记录 key_start_pitch
local function begin_rotate(latch)
    local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
    if log_fn then pcall(log_fn, "INFO", "[KEY_DIAG] begin_rotate called, type=" .. tostring(state.current_type)) end

    -- §27：表演体在 ATTACHED 已生成，此处只进入旋转，不再生成/换挂。
    if state.perf_mesh == nil then
        return
    end

    -- Phase 5: 锁状态预检 — 门已解锁（或导航失败）则不进入 ROTATING，保持 ATTACHED
    -- 手仍吸附在表演体，但转不动（所有门通用，不做分支）
    local door_lock = navigate_to_door_lock(state.latch_component)
    if door_lock == nil or not door_lock:IsLocked() then
        if log_fn then
            pcall(log_fn, "INFO", "[KEY_DIAG] begin_rotate SKIP: door already unlocked or lock not found")
        end
        return
    end

    state.phase = PHASE.ROTATING
    state.latch_origin_loc = { X = latch.loc.X, Y = latch.loc.Y, Z = latch.loc.Z }
    state.latch_origin_rot = latch.rot
    state.key_rotation_delta = 0
    state.key_completed = false
    state.progress = 0

    -- 旋转轴初值先置 nil，待读到 body 后用其局部轴覆盖
    state.key_axis = nil

    -- 目标：KeyStaticMesh 本体（仍存在，仅被隐藏；读取局部轴/初始旋转供旋转计算）
    local body = state.latch_component
    local body_rot = latch.rot
    pcall(function()
        if body ~= nil then
            local cr = reload_tools.get_component_world_rotation(body)
            if cr ~= nil then body_rot = cr end
        end
    end)

    -- 旋转轴 = 钥匙本体局部轴（世界空间方向会跟着门走，不写死世界轴）
    -- GetForwardVector / GetRightVector / GetUpVector 是 USceneComponent UFUNCTION，含 Roll
    -- axis_mode 由诊断面板切换：local_x / local_y / local_z
    local axis = nil
    local mode = M_DIAGNOSTIC.axis_mode or "local_y"
    pcall(function()
        if body ~= nil then
            if mode == "local_x" then
                axis = body:GetForwardVector()
            elseif mode == "local_z" then
                axis = body:GetUpVector()
            else
                axis = body:GetRightVector()
            end
        end
    end)
    if axis ~= nil then
        state.key_axis = { X = axis.X or 0, Y = axis.Y or 0, Z = axis.Z or 0 }
    else
        -- fallback：仅当组件方法调用失败时使用
        state.key_axis = { X = 0, Y = 1, Z = 0 }
    end
    if log_fn then
        pcall(log_fn, "INFO", string.format(
            "[KEY_DIAG] axis_mode=%s axis=(%.3f,%.3f,%.3f) body_rot=(p=%.1f,y=%.1f,r=%.1f)",
            mode,
            state.key_axis.X, state.key_axis.Y, state.key_axis.Z,
            body_rot.Pitch or 0, body_rot.Yaw or 0, body_rot.Roll or 0))
    end

    -- 记录左手 Pitch 基准值
    local hand_rot = controllers.getControllerRotation(0)
    state.key_start_pitch = (hand_rot ~= nil) and (hand_rot.Pitch or 0) or 0

    -- 记录本体初始旋转（用于每帧 compose）
    state.key_body_rot = body_rot

    -- Phase 4: 播放钥匙开锁音效（与 begin_slide 末尾播放门栓音效一致）
    play_key_unlock_sound()
end

-- update_key_rotation_by_progress：根据 progress (0~1) 更新表演体旋转（回弹用）
-- Phase 3: 回弹方向与旋转方向一致（负值 = 逆时针）
local function update_key_rotation_by_progress(progress)
    if state.perf_mesh == nil or state.perf_origin == nil then
        return
    end
    local angle_deg = -progress * KEY_ROTATE_THRESHOLD_DEG
    local delta_rot = math_lib.rotatorFromAxisAndAngle(state.key_axis, angle_deg)
    local new_rot = math_lib.composeRotators(state.key_body_rot, delta_rot)
    -- 位置钉死
    set_perf_world_transform(state.perf_origin, new_rot)
end

-- update_key_rotation：每帧根据手部 Pitch delta 更新表演体旋转
local function update_key_rotation()
    if state.perf_mesh == nil or state.perf_origin == nil or state.key_axis == nil then
        return
    end

    local hand_rot = controllers.getControllerRotation(0)
    if hand_rot == nil then return end

    local delta_pitch = (hand_rot.Pitch or 0) - state.key_start_pitch
    state.key_rotation_delta = delta_pitch

    -- 灵敏度系数：手拧角度放大为有效转角
    -- 例：sensitivity=3.0，手拧 30° → 有效 90° 解锁
    local sensitivity = M_DIAGNOSTIC.sensitivity or 3.0
    local effective_delta = delta_pitch * sensitivity

    -- Phase 3: 限定方向 — 只允许逆时针（负 delta_pitch 方向）旋转
    -- 正方向（顺时针）时 effective_delta 归零，progress 保持 0，钥匙不动
    if effective_delta > 0 then
        effective_delta = 0
    end

    -- Phase 3: 限定最大 90° — 不能超过解锁阈值
    -- 未加此 clamp 前 effective_delta 可达 -106°，钥匙转过头
    if effective_delta < -KEY_ROTATE_THRESHOLD_DEG then
        effective_delta = -KEY_ROTATE_THRESHOLD_DEG
    end

    state.progress = math.abs(effective_delta) / KEY_ROTATE_THRESHOLD_DEG

    -- 表演体旋转 = 本体初始旋转 + 绕 key_axis 旋转 effective_delta（负值 = 逆时针）
    local delta_rot = math_lib.rotatorFromAxisAndAngle(state.key_axis, effective_delta)
    local new_rot = math_lib.composeRotators(state.key_body_rot, delta_rot)
    -- 位置钉死
    set_perf_world_transform(state.perf_origin, new_rot)

    -- Phase 4: 拧到位立即触发振动 + 解锁，但不 detach（玩家松手才 detach）
    -- 用 key_completed 标记防重复触发，phase 保持 ROTATING
    if state.progress >= 1.0 and not state.key_completed then
        state.key_completed = true
        -- 触发左手震动反馈（立即）
        eventFeedback.play_latch_haptic()
        -- 拧钥匙完成：调 SetLocked(false) 解锁（立即）
        unlock_door_directly(state.latch_component)
        -- 标记 L1 缓存中对应条目为已完成
        if state.latch_cache ~= nil and state.latch_component ~= nil then
            for _, entry in ipairs(state.latch_cache) do
                if entry.component == state.latch_component then
                    entry.completed = true
                    break
                end
            end
        end
    end

    -- 诊断日志（每 30 帧打印一次，受 diag.enabled 控制）
    state._diag_tick = (state._diag_tick or 0) + 1
    if state._diag_tick % 30 == 0 then
        local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
        if log_fn ~= nil then
            pcall(log_fn, "INFO", string.format(
                "[KEY_DIAG] delta_pitch=%.1f eff=%.1f progress=%.2f sens=%.2f hand_pitch=%.1f start_pitch=%.1f axis=(%.3f,%.3f,%.3f) mode=%s",
                delta_pitch, effective_delta, state.progress, sensitivity,
                hand_rot.Pitch or 0, state.key_start_pitch,
                state.key_axis.X, state.key_axis.Y, state.key_axis.Z,
                tostring(M_DIAGNOSTIC.axis_mode)))
        end
    end
end

-- end_rotate：完成走 unlock_door_directly + 震动；未完成回弹
local function end_rotate(completed)
    if completed then
        state.phase = PHASE.COMPLETED
        state.completed_start_t = os.clock()
        -- 拧钥匙完成：调 SetLocked(false) 解锁
        unlock_door_directly(state.latch_component)
        -- 触发左手震动反馈
        eventFeedback.play_latch_haptic()
        -- 标记 L1 缓存中对应条目为已完成
        if state.latch_cache ~= nil and state.latch_component ~= nil then
            for _, entry in ipairs(state.latch_cache) do
                if entry.component == state.latch_component then
                    entry.completed = true
                    break
                end
            end
        end
    else
        if state.progress > 0 then
            state.returning = true
            state.return_start_t = os.clock()
            state.return_start_progress = state.progress
        else
            -- 没有旋转：销毁表演体，恢复本体，重新吸附
            destroy_perf()
            state.phase = PHASE.ATTACHED
            apply_grip_anim()
        end
    end
end

-- =============================================================================
-- Phase 2: 推拉门(glide) — begin_glide
-- 方案 B：不从 L2/L3 抄 movement/spot_axis，grip 按下时现场回读
-- =============================================================================

--- 现场解析推拉门运行时字段：comp(=DoorMesh) → GetOwner() → DoorMovement + 本地X轴 + open_sign
---@param comp table|nil 吸附点组件（DoorMesh）
---@return table|nil { actor, movement, spot_axis, open_sign }
local function resolve_glide_runtime(comp)
    local actor, movement, axis, open_sign = nil, nil, nil, 1
    pcall(function() actor = comp:GetOwner() end)
    if actor == nil then return nil end
    pcall(function() movement = actor.DoorMovement end)

    -- 投影轴：门 Actor 本地 -X（负 forward）→ 世界空间 → 压平水平面(Z=0) → 归一化。
    -- 统一取负 forward 作为开合正方向，不再用 MovementDirection/open_sign 决定翻转。
    -- 实测（plan §20）：方向正确 ⟺ spot_axis = -forward；open_sign 仅作诊断记录。
    pcall(function()
        local rot = nil
        if actor.K2_GetActorRotation ~= nil then rot = actor:K2_GetActorRotation() end
        if rot ~= nil then
            axis = math_lib.horizontalYawDir(rot.Yaw or 0, -1)
        end
    end)

    -- open_sign：仅供诊断记录（MovementDirection 在负 forward 轴上的投影符号），不参与方向
    pcall(function()
        if movement ~= nil and movement.MovementDirection ~= nil and axis ~= nil then
            local md = movement.MovementDirection
            local proj = (md.X or 0) * (axis.X or 0) + (md.Y or 0) * (axis.Y or 0)
            if proj < 0 then open_sign = -1 end
        end
    end)
    return { actor = actor, movement = movement, spot_axis = axis, open_sign = open_sign }
end

--- glide 专用锁组件导航：comp(=DoorMesh) → GetOwner() → ASHSlidingDoor → LockComponent
--- 与 navigate_to_door_lock（AttachParent*Door → DoorLock）不同，推拉门无 AttachParent 导航，
--- 直接用门 Actor 自身的 LockComponent（事实表 §2.1 0x0338；诊断 §8.1 已验证 IsLocked 可读）
---@param comp table|nil 吸附点组件（DoorMesh）
---@return table|nil USHSlidingDoorLockComponent 或 nil
local function get_glide_door_lock(comp)
    if comp == nil then return nil end
    local actor = nil
    pcall(function() actor = comp:GetOwner() end)
    if actor == nil then return nil end
    local door_lock = nil
    pcall(function() door_lock = actor.LockComponent end)
    return door_lock
end

--- begin_glide：grip 按下时进入 GLIDING，现场回读 DoorMovement/投影轴/open_sign，
--- 读引擎 α 作续拉基准，捕获手位移锚定基准，吸附（ATTACHED 已吸附过则为 no-op）。
--- 锁预检：不阻止进入 GLIDING（音效/震动照常播放），由 update_glide 拦 alpha 驱动（门不动）。
local function begin_glide(latch)
    -- §27：表演体在 ATTACHED 已生成，此处只进入滑动，不再生成/换挂。
    if state.perf_mesh == nil then
        return
    end

    -- §27：锁预检 — 只记录锁组件、不阻止进入 GLIDING：音效/震动照常播放，
    -- 由 update_glide 拦 alpha 驱动（门不动）。glide 专用导航：
    -- DoorMesh → GetOwner() → actor.LockComponent → IsLocked()
    -- （navigate_to_door_lock 走 AttachParent*Door 导航，对推拉门失效返回 nil，不可用）
    local door_lock = get_glide_door_lock(state.latch_component)
    state.glide_lock_comp = door_lock

    state.phase = PHASE.GLIDING
    state.glide_completed = false

    -- 方案 B：latch_component(=DoorMesh) → GetOwner() → DoorMovement + 本地X轴/open_sign
    local rt = resolve_glide_runtime(state.latch_component)
    if rt == nil or rt.movement == nil or rt.spot_axis == nil then
        state.phase = PHASE.ATTACHED
        local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
        if log_fn ~= nil then
            pcall(log_fn, "ERROR", "[GLIDE_DIAG] begin_glide FAIL: resolve_glide_runtime nil (movement/axis 回读失败)")
        end
        return
    end
    state.movement = rt.movement
    state.spot_axis = rt.spot_axis
    state.open_sign = rt.open_sign

    -- 播放推拉门音效（门自带 SHAkSlidingDoorComponent 继承引擎 Door_Type Switch → 金属音色）
    play_sliding_door_sound(rt.actor)

    -- 开始/续拉长振动弱震（Touch_Ancient_Cast_L = 时长1s、强度0.2 手柄长弱震 + 体感袖子）。
    -- begin_glide 每次 grip 按下都调用（含断点续拉重新抓取），因此一处即覆盖两者。
    eventFeedback.play_glide_pull_haptic()

    -- 读取引擎当前 α 作为续拉基准（引擎记录，lua 不记录 progress）
    local engine_alpha = 0
    pcall(function()
        engine_alpha = state.movement.DoorMovementAlphaSave or 0
    end)
    state.glide_base_alpha = engine_alpha

    -- 吸附：ATTACHED 时已吸附过则 grip_anim_applied=true，此处通常是 no-op；保险再调一次
    apply_grip_anim()

    -- 捕获本抓取手位移基准（latch_origin_loc = nearest.loc，glide 已含所选吸附点 A/B 偏移）
    local lh = controllers.getControllerLocation(0)
    if lh ~= nil and state.latch_origin_loc ~= nil and state.spot_axis ~= nil then
        state.glide_start_dist = reload_tools.capture_slide_anchor(
            lh, state.latch_origin_loc, state.spot_axis)
    end

    -- 诊断日志（走专用诊断脚本 write_log，受 diag.enabled 开关控制，非控制台）
    local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
    if log_fn ~= nil then
        local locked_flag = false
        pcall(function()
            if state.glide_lock_comp ~= nil then
                locked_flag = state.glide_lock_comp:IsLocked()
            end
        end)
        pcall(log_fn, "INFO", string.format(
            "[GLIDE_DIAG] begin_glide: engine_alpha=%.3f start_dist=%s open_sign=%d axis=(%.3f,%.3f,%.3f) mesh=%s locked=%s phase=GLIDING",
            engine_alpha,
            tostring(state.glide_start_dist),
            state.open_sign or 1,
            state.spot_axis.X or 0, state.spot_axis.Y or 0, state.spot_axis.Z or 0,
            tostring(state.current_mesh_name),
            tostring(locked_flag)))
    end
end

--- update_glide：每帧按手位移增量驱动门（增量式，无回弹、无阈值）
--- target_alpha = 引擎基准 α + signed_pull × sensitivity，clamp 0~1；
--- α 到 1 时本抓取首次触发震动。不写 state.progress（门位移全由引擎驱动）。
---@param lh table|nil 可选：由调用方传入已读取的左手位置（复用）；nil 时内部自读
local function update_glide(lh)
    if lh == nil then
        lh = controllers.getControllerLocation(0)
    end
    if lh == nil or state.latch_origin_loc == nil or state.spot_axis == nil then return end

    -- signed_pull = 手沿投影轴相对抓取基准的带符号位移（cm）
    local signed_pull = 0
    pcall(function()
        signed_pull = reload_tools.calc_slide_pull_anchored(
            lh, state.latch_origin_loc, state.spot_axis,
            state.glide_start_dist, 1.0 / GLIDE_SENSITIVITY, nil)
    end)
    state.signed_pull = signed_pull or 0

    -- 增量式：目标 α = 引擎基准 α + 手位移增量（不做绝对 progress）
    local target_alpha = state.glide_base_alpha + state.signed_pull * GLIDE_SENSITIVITY
    target_alpha = math.max(0, math.min(1, target_alpha))

    -- §27：锁门只拦 alpha 驱动（门不动），音效/震动已在 begin_glide 播放
    local glide_locked = false
    pcall(function()
        if state.glide_lock_comp ~= nil then
            glide_locked = state.glide_lock_comp:IsLocked()
        end
    end)

    -- 不限制方向：手往回拉 → signed_pull 为负 → target_alpha 减小（跟随引擎）
    if state.movement ~= nil and not glide_locked then
        pcall(function() state.movement:OverrideDoorAlpha(target_alpha) end)
    end

    -- §27：Override 之后再抄真 DoorMesh → 表演体（先动门再追平，避免 1 帧落后）
    -- latch_component 即 glide 的 DoorMesh；隐藏后仍随 DoorMovement 移动，每帧读其世界位追平副本。
    if state.perf_mesh ~= nil and state.latch_component ~= nil then
        pcall(function()
            local me = state.latch_component
            local cl = reload_tools.get_component_world_location(me)
            local cr = reload_tools.get_component_world_rotation(me)
            if cl ~= nil then
                set_perf_world_transform(cl, cr)
            end
        end)
    end

    -- α 到 1 标记完成（本抓取首次，防重复震动；门保持全开）
    -- 锁门时门不动，不触发全开震动
    if target_alpha >= 1.0 and not state.glide_completed and not glide_locked then
        state.glide_completed = true
        eventFeedback.play_latch_haptic()
    end

    -- 诊断日志（每 30 帧打印一次，受 diag.enabled 开关控制）
    state._diag_tick = (state._diag_tick or 0) + 1
    if state._diag_tick % 30 == 0 then
        local log_fn = rawget(_G, "OPEN_LATCH_DIAG_WRITE_LOG")
        if log_fn ~= nil then
            pcall(log_fn, "INFO", string.format(
                "[GLIDE_DIAG] update_glide: signed_pull=%.2f target_alpha=%.3f base_alpha=%.3f locked=%s completed=%s",
                state.signed_pull, target_alpha, state.glide_base_alpha,
                tostring(glide_locked),
                tostring(state.glide_completed)))
        end
    end
end

-- =============================================================================
-- Phase 2: 折叠楼梯开关下压（SWITCH 状态）
-- 直驱路径（Phase 0 裁决 alpha 可经 Timeline_SwitchAnim:SetPlaybackPosition 驱动杠杆）。
-- 世界 Z 下落投影：进入时记录手世界 Z 基准 → 每帧落差 / TRAVEL → alpha(0~1) → 驱动 timeline。
-- 与 SLIDING/GLIDING 一致：进入 SWITCH 后跳过距离检测，仅松手/手丢失追踪才脱离。
-- =============================================================================
-- 从 L1 缓存取当前吸附的 switch entry（含已验证的 timeline/staircase，与诊断脚本同源，
-- 而非 GetOwner 回读——后者实测常失败导致 SetPlaybackPosition 驱动失效）
local function find_switch_entry()
    local new_latch_cache = state.latch_cache or {}
    for _, e in ipairs(new_latch_cache) do
        if is_switch_family(e.type) and e.component ~= nil and e.component == state.latch_component then
            return e
        end
    end
    return nil
end

--- play_switch_lever_sound：下压开始播放杠杆音效（Phase 3）。
--- 走 audio 通用组件直播函数 audio.play_event_on_component：贴到 e.actor.SHAk_Lever 组件，
--- 用 SimplePostAkEvent(AkEvent对象)/PostAkEvent 播放，继承组件 Switch 音色（贴合杠杆）。
local function play_switch_lever_sound(e)
    if e == nil or e.actor == nil then
        return false
    end
    local comp = nil
    pcall(function() comp = e.actor.SHAk_Lever end)
    if comp == nil then
        return false
    end
    local audio = rawget(_G, "__sh2_audio_module")
    if audio == nil or type(audio.play_event_on_component) ~= "function" then
        return false
    end
    return audio.play_event_on_component(comp, SWITCH_LEVER_EVENT_PATH, nil)
end

local function begin_switch_press()
    -- 记录世界 Z 基准（手世界坐标，字段大写 .Z）
    local lh = controllers.getControllerLocation(0)
    if lh == nil then
        state.phase = PHASE.ATTACHED
        return
    end
    -- 复用 L1 缓存已验证的 timeline/staircase（GetOwner 回读不可靠，见 find_switch_entry 说明）
    local e = find_switch_entry()
    local timeline = e ~= nil and e.timeline or nil
    state.switch_timeline = timeline
    state.switch_staircase = e ~= nil and e.staircase or nil

    -- Phase 3 反馈（begin 即触发）：左手长震动（复用弹拉门）+ 杠杆音效（SHAk_Lever 通用组件直播）
    eventFeedback.play_glide_pull_haptic()
    play_switch_lever_sound(e)

    state.switch_length = 1
    if timeline ~= nil then
        pcall(function()
            local len = timeline:GetTimelineLength()
            if len ~= nil and len > 0 then state.switch_length = len end
        end)
    end
    state.switch_base_z = lh.Z or 0
    state.switch_alpha = 0
    state.switch_completed = false
    state.phase = PHASE.SWITCH

    -- 诊断日志：走 diagnose_switch 模块 write_log（受其 Enable Logging 开关管理；此前误用
    -- 不存在的 OPEN_LATCH_DIAG_WRITE_LOG 全局导致日志被静默丢弃）
    local diag_mod = rawget(_G, "__sh2_switch_diag_module")
    if type(diag_mod) == "table" and type(diag_mod.write_log) == "function" then
        pcall(diag_mod.write_log, string.format(
            "[SWITCH_DIAG] begin_switch_press: base_z=%.2f len=%.3f timeline=%s",
            state.switch_base_z, state.switch_length, tostring(timeline ~= nil)))
    end
end

--- update_switch_press：每帧按手世界 Z 下落驱动杠杆 alpha；到位触发 haptic + 楼梯展开。
--- 松手/手丢失追踪由调用方(终点分支)处理，本函数仅做下压计算。
local function update_switch_press()
    local lh = controllers.getControllerLocation(0)
    if lh == nil or state.switch_base_z == nil then return end

    -- 世界 Z 下落投影：下压 → cur_z 减小 → drop 增大 → alpha 增大
    local drop = state.switch_base_z - (lh.Z or 0)
    local alpha = math.max(0, math.min(1,
        (drop / math.max(SWITCH_PRESS_TRAVEL, 0.01)) * SWITCH_PRESS_SENSITIVITY))
    state.switch_alpha = alpha
    -- 记录取证数据（不打印，仅供诊断面板手动 Snapshot Press 读取）
    state.switch_cur_z = lh.Z or 0
    state.switch_drop = drop

    -- 直驱杠杆（bFireEvents=false 防误触发 OnSwitchUsed；bFireUpdate=true 才移动网格）
    if state.switch_timeline ~= nil then
        local ok, err = pcall(function()
            state.switch_timeline:SetPlaybackPosition(alpha * state.switch_length, false, true)
        end)
        state.switch_drive_ok = ok
        state.switch_drive_err = ok and nil or tostring(err)
    else
        state.switch_drive_ok = false
        state.switch_drive_err = "timeline=nil"
    end

    -- 到位：alpha 到 1 本抓取首次 → 震动 + 按类型触发
    if alpha >= 1.0 and not state.switch_completed then
        state.switch_completed = true
        eventFeedback.play_latch_haptic()
        local e2 = find_switch_entry()
        if state.current_type == "light_switch" then
            -- 方案 D：直接对 Actor SetState(true)，引擎自动带出杠杆动画+倒计时（Phase 0 已裁决）
            local actor = e2 ~= nil and e2.actor or nil
            if actor ~= nil then
                pcall(function() actor:SetState(true) end)
                -- spark FX：诊断面板"Play Sparks FX"已验证有效（e.actor:PlaySparksFX），到位时同步触发电弧
                pcall(function() actor:PlaySparksFX() end)
            end
        else
            -- 楼梯展开（引用在 begin 已从 entry 取并缓存（state.switch_staircase），统一用之）
            if state.switch_staircase ~= nil then
                pcall(function() state.switch_staircase:OnStaircaseActivated() end)
            end
        end
    end
end

--- end_switch_press：结束下压。未到位(grip 中途松开)则回弹杠杆(timeline 归 0)，随后脱离。
local function end_switch_press()
    -- 未到位松开 → 回弹杠杆（避免停在半压）
    if not state.switch_completed and state.switch_timeline ~= nil then
        pcall(function() state.switch_timeline:SetPlaybackPosition(0, false, true) end)
    end
    detach_from_latch()
end

-- =============================================================================
-- Phase 2 push（sh2 可推柜）：L3 双吸附点检测
-- push 条目不进 cached_latches（find_nearest_to_hand 扫不到），单独在 push_target
-- 上做 A/B 双锚点距离判定。
-- 返回最近的 push 条目标记：
--   { entry, spot_local, spot_world, dist_sq } 或 nil（3米外/push 空时）
-- =============================================================================

-- push 根节点**实时**世界位 + 旋转（glide DoorMesh 实时读的同款模式）
-- 柜被 TeleportAbsolute 搬动后必须读 actor.K2_GetActorLocation，entry.loc 是 L1 缓存时静态快照
local function get_push_root_pose(entry)
    if entry == nil then return nil, nil end
    local loc, rot = nil, nil
    pcall(function()
        if entry.actor ~= nil and entry.actor.K2_GetActorLocation ~= nil then
            loc = entry.actor:K2_GetActorLocation()
        end
    end)
    pcall(function()
        if entry.actor ~= nil and entry.actor.K2_GetActorRotation ~= nil then
            rot = entry.actor:K2_GetActorRotation()
        end
    end)
    -- 兜底：L1 缓存时的静态快照（柜未被推动过时等于实时值）
    if loc == nil then loc = entry.loc end
    if rot == nil then rot = entry.rot end
    return loc, rot
end

local function find_push_nearest(left_hand_loc, proximity_cm)
    if state.push_target == nil or left_hand_loc == nil then return nil end
    local entry = state.push_target
    -- 实时根 pose（柜被 TeleportAbsolute 搬动后会变）
    local root_loc, root_rot = get_push_root_pose(entry)
    if root_rot == nil then return nil end
    proximity_cm = proximity_cm or PUSH_PROXIMITY_CM
    local best = nil
    for _, spot in ipairs({ PUSH_SPOT_A, PUSH_SPOT_B }) do
        -- 吸附面中心：锚点本地偏移经根节点姿态变换到世界（用实时根 pose，不用 entry.loc/rot）
        local center_w = nil
        pcall(function()
            center_w = math_lib.childWorldTransform(root_loc, root_rot, spot, nil)
        end)
        if center_w == nil then goto continue_spot end
        -- 手相对吸附面中心的世界位移
        local hx = left_hand_loc.X or left_hand_loc[1] or 0
        local hy = left_hand_loc.Y or left_hand_loc[2] or 0
        local hz = left_hand_loc.Z or left_hand_loc[3] or 0
        local dv = { X = hx - (center_w.X or 0), Y = hy - (center_w.Y or 0), Z = hz - (center_w.Z or 0) }
        -- 前面板本地 Y/Z 的世界方向（root_rot 保证非 nil，见函数头）
        local dirY = math_lib.vectorRotate({ X = 0, Y = 1, Z = 0 }, root_rot)
        local dirZ = math_lib.vectorRotate({ X = 0, Y = 0, Z = 1 }, root_rot)
        local yOff = math_lib.vectorDot(dv, dirY)  -- 手在面板本地 Y 的偏移
        local zOff = math_lib.vectorDot(dv, dirZ)  -- 手在面板本地 Z 的偏移
        -- clamp 到正方形内 → 吸附面内最近点（本地偏移）
        local cy = math.max(-PUSH_FACE_HALF_Y, math.min(PUSH_FACE_HALF_Y, yOff))
        local cz = math.max(-PUSH_FACE_HALF_Z, math.min(PUSH_FACE_HALF_Z, zOff))
        -- 手到吸附面最近点距离² = 面外分量² + 面内残差²
        local out_sq = math.max(0,
            math_lib.vectorDistanceSquaredSafe(center_w, left_hand_loc) - yOff * yOff - zOff * zOff)
        local in_sq = (yOff - cy) * (yOff - cy) + (zOff - cz) * (zOff - cz)
        local dist_sq = out_sq + in_sq
        if dist_sq <= proximity_cm * proximity_cm and
           (best == nil or dist_sq < best.dist_sq) then
            -- 落点本地偏移（挂手用）；世界点（复检/跟随用）
            local anchor_local = { x = spot.x, y = spot.y + cy, z = spot.z + cz }
            local spot_world = nil
            pcall(function()
                spot_world = math_lib.childWorldTransform(root_loc, root_rot, anchor_local, nil)
            end)
            best = { entry = entry, spot_local = spot, anchor_local = anchor_local,
                     spot_world = spot_world, dist_sq = dist_sq }
        end
        ::continue_spot::
    end
    return best
end

-- =============================================================================
-- Phase 2 cart（sh2 推车,PushNClimb）：吸附条 A→B 检测 + 直挂 Handle_R
-- 判定与 attach 全是"推柜同款"：A/B(=C/D) 为把手本地偏移经组件实时世界姿态投影到世界，
-- pointSegmentDistanceSquared(手, A, B)；attach 直接挂对应 StaticMesh_Handle_R/L（附件父==锚点），
-- offset = 投影点 C′ 的把手本地坐标零换算（推柜挂柜本体 StaticMesh 同理）。手势 drink_potion。
-- 2026-09-05：新增镜像把手 Handle_L。对每根存在的把手(R/L)各自现算 A→B 线，取全车
-- 最近且 ≤ 阈值者（左手互斥二选一，近谁抓谁）；t 相对该把手的 A_X 起算。
-- 本阶段只吸附+落定位姿，不移动（移动归阶段3，见 sh2_push_cart_plan.md §10 阶段2/3）。
-- 返回 { entry, handle, handle_rot, t, dist_sq } 或 nil（cart 空/手不在吸附条 CART_GRIP_PROXIMITY_CM 内时）
-- =============================================================================
local function find_cart_nearest(left_hand_loc, proximity_cm)
    if state.cart_target == nil or left_hand_loc == nil then return nil end
    local entry = state.cart_target
    proximity_cm = proximity_cm or CART_GRIP_PROXIMITY_CM
    local best = nil
    for _, cname in ipairs(CART_HANDLE_COMP_NAMES) do
        local handle = resolve_cart_handle(entry.actor, cname)
        if handle == nil then goto continue_handle end
        local hloc, hrot = nil, nil
        pcall(function()
            if handle.K2_GetComponentLocation ~= nil then hloc = handle:K2_GetComponentLocation() end
        end)
        pcall(function()
            if handle.K2_GetComponentRotation ~= nil then hrot = handle:K2_GetComponentRotation() end
        end)
        if hrot == nil then goto continue_handle end
        -- A/B(=C/D) 本地偏移（相对该把手原点 C）：实测固化的吸附条，沿本地 X 轴延伸，A/B 同 y/z
        local A_local = { X = CART_BAR_A_X, Y = CART_BAR_A_Y, Z = CART_BAR_A_Z }
        local B_local = { X = CART_BAR_B_X, Y = CART_BAR_A_Y, Z = CART_BAR_A_Z }
        -- 本地→世界（推柜同款 childWorldTransform，A/B 每帧现算跟随 mesh/搬车/折叠）
        local A_w, B_w = nil, nil
        pcall(function()
            A_w = math_lib.childWorldTransform(hloc, hrot, A_local, nil)
            B_w = math_lib.childWorldTransform(hloc, hrot, B_local, nil)
        end)
        if A_w == nil or B_w == nil then goto continue_handle end
        -- 判定：手到线段 A→B 距离² < 阈值²（复用底层 math_lib，返回 d² 与 t，零新增公式）
        local dist_sq, t = math_lib.pointSegmentDistanceSquared(left_hand_loc, A_w, B_w)
        if dist_sq ~= nil and t ~= nil and dist_sq <= proximity_cm * proximity_cm then
            if best == nil or dist_sq < best.dist_sq then
                best = { entry = entry, handle = handle, handle_rot = hrot, t = t, dist_sq = dist_sq }
            end
        end
        ::continue_handle::
    end
    return best
end

-- cart 吸附投影点 C′ 现算世界位置（ATTACHED 复检基准）：
-- C′ 本地 = (A_X + t×LEN, A_Y, A_Z)，t 用 state.cart_t（吸附瞬间冻结）；
-- 每帧按 state.cart_handle（R 或 L，抓哪根用哪根）现算 → 车/把手移动时复检基准跟随，不冻结世界点。
-- 返回世界坐标 table 或 nil。
local function get_cart_proj_world()
    local handle = state.cart_handle
    if handle == nil and state.cart_target ~= nil then
        handle = resolve_cart_handle(state.cart_target.actor)
        if handle ~= nil then state.cart_handle = handle end
    end
    if handle == nil then return nil end
    local hloc, hrot = nil, nil
    pcall(function()
        if handle.K2_GetComponentLocation ~= nil then hloc = handle:K2_GetComponentLocation() end
    end)
    pcall(function()
        if handle.K2_GetComponentRotation ~= nil then hrot = handle:K2_GetComponentRotation() end
    end)
    if hloc == nil or hrot == nil then return nil end
    local local_p = {
        X = CART_BAR_A_X + (state.cart_t or 0) * CART_BAR_LEN,
        Y = CART_BAR_A_Y,
        Z = CART_BAR_A_Z,
    }
    local ok, w = pcall(math_lib.childWorldTransform, hloc, hrot, local_p, nil)
    if ok then return w end
    return nil
end

-- 进入 cart 吸附：记录吸附条投影参数 t（冻结），置 ATTACHED，并吸附+调手势（直挂抓取到的 Handle_R/L）
local function begin_cart_attach(found)
    cart_trace("GRIP", "attach cart t=" .. tostring(found and found.t or 0) ..
        " rot=" .. tostring(found and found.handle_rot and
            (string.format("%.1f,%.1f,%.1f", found.handle_rot.Pitch or 0,
                found.handle_rot.Yaw or 0, found.handle_rot.Roll or 0)) or "nil"))
    -- cart 无 latch_component：直挂 StaticMesh_Handle_R，路径经 apply_grip_anim 的 cart 分支
    state.latch_component = nil
    state.current_mesh_name = "cart_handle"
    state.current_type = "cart"
    state.cart_handle = found.handle
    state.cart_t = found.t or 0   -- 吸附条投影参数 t 抓握瞬间冻结（手不动）
    state.phase = PHASE.ATTACHED
    state.latch_origin_rot = found.handle_rot
    apply_grip_anim()
    -- 阶段4 音效：左手吸附 cart 瞬间播放 Grab
    play_cart_audio_event("GrabSoundEvent")
end

-- 阶段3：进入 PUSHING（抓握瞬间）锚定起点（自由跟手模型，照抄诊断脚本 start_following）
-- 首次调用时执行一次（cart_start_world ~= nil 后续帧自动跳过）；本阶段播 StartPush 音效/震动（阶段4）
local function begin_push_cart_move()
    -- 抓握瞬间车根实时世界位（TeleportAbsolute 目标 Z 锁基准；车被搬动后 entry.loc 是静态快照必须实时读）
    local entry = state.cart_target
    local root_world = nil
    pcall(function()
        if entry ~= nil and entry.actor ~= nil
           and entry.actor.K2_GetActorLocation ~= nil then
            root_world = entry.actor:K2_GetActorLocation()
        end
    end)
    -- 兜底：L2 缓存时捕获的 loc（车没动过，等于根节点）
    if root_world == nil and entry ~= nil then
        root_world = entry.loc
    end
    state.cart_start_world = root_world

    -- 锚点相对根偏移（常量）：投影点 C′ 世界（t 已冻结）− 车根世界；X/Y 跟手 1:1 基准
    local anchor = get_cart_proj_world()
    if anchor ~= nil and root_world ~= nil then
        state.cart_anchor_offset = {
            X = (anchor.X or 0) - (root_world.X or 0),
            Y = (anchor.Y or 0) - (root_world.Y or 0),
            Z = (anchor.Z or 0) - (root_world.Z or 0),
        }
    end
    -- 阶段4 震动：手开始推车瞬间 → 推拉门长震动（复用 play_glide_pull_haptic，不改 11 号文件）
    -- + StartPush 音效：守卫 cart_start_world == nil 天然保证每次抓握推车只触发一次
    eventFeedback.play_glide_pull_haptic()
    play_cart_audio_event("StartPushSoundEvent")
end

-- 阶段3：PUSHING 每帧驱动小车（自由跟手：目标根 X/Y = 手位置 − cart_anchor_offset，1:1 跟手；Z 锁起始值）
---@param lh table|nil 可选：由调用方传入已读取的左手位置（复用）；nil 时内部自读
local function update_push_cart(lh)
    if state.cart_start_world == nil then return end
    local entry = state.cart_target
    if entry == nil or entry.SHPushable == nil or entry.SHPushable.TeleportAbsolute == nil then return end
    if lh == nil then
        lh = controllers.getControllerLocation(0)
    end
    if lh == nil then return end

    local off = state.cart_anchor_offset
    local target = {
        X = (lh.X or 0) - (off and off.X or 0),
        Y = (lh.Y or 0) - (off and off.Y or 0),
        Z = state.cart_start_world.Z or 0,  -- 锁 Z（硬约束：小车不能上下移动）
    }
    pcall(function()
        entry.SHPushable:TeleportAbsolute(uevrUtils.vector(target.X, target.Y, target.Z))
    end)
end

-- =============================================================================
-- 阶段4：推柜音效（调用底层 audio 库 libs/audio.lua）
-- 事件对象直接取 SHPushableAudio 组件字段（GrabSoundEvent/StartPushSoundEvent/
-- StopPushSoundEvent），经 audio.play_event_on_component 播放（组件方法
-- PostAkEvent，诊断脚本已验证）。不硬编码事件路径（get_name 为空）。
-- 失败静默跳过，不打印日志（严禁控制台）。
-- 注意：这里是赋值给前向声明的同名 local（不能用 local function，否则新建
-- 遮蔽变量，定义点之前的 detach_from_latch 会捕获到 nil）。
-- =============================================================================
play_push_audio_event = function(field_name)
    if field_name == nil then return false end
    local audio = rawget(_G, "__sh2_audio_module")
    if audio == nil or type(audio.play_event_on_component) ~= "function" then
        return false
    end
    local entry = state.push_target
    if entry == nil then return false end
    local audio_comp = nil
    pcall(function() audio_comp = entry.SHPushableAudio end)
    if audio_comp == nil then return false end
    local evt = nil
    pcall(function() evt = audio_comp[field_name] end)
    if evt == nil then return false end
    return audio.play_event_on_component(audio_comp, nil, evt)
end

-- 阶段4：cart 推车音效（读取 cart_target 的 SHPushableAudio 组件字段，链路与 push 全同）
-- 注意：同样是赋值给前向声明的同名 local（不能用 local function，避免遮蔽 detach_from_latch 捕获）
play_cart_audio_event = function(field_name)
    if field_name == nil then return false end
    local audio = rawget(_G, "__sh2_audio_module")
    if audio == nil or type(audio.play_event_on_component) ~= "function" then
        return false
    end
    local entry = state.cart_target
    if entry == nil then return false end
    local audio_comp = nil
    pcall(function() audio_comp = entry.SHPushableAudio end)
    if audio_comp == nil then return false end
    local evt = nil
    pcall(function() evt = audio_comp[field_name] end)
    if evt == nil then return false end
    return audio.play_event_on_component(audio_comp, nil, evt)
end

-- 进入 push 吸附：记录选中锚点，置 ATTACHED，并吸附+调手势
local function begin_push_attach(found)
    -- push 无 latch_component：直挂柜 StaticMesh，路径经 apply_grip_anim 的 push 分支
    state.latch_component = nil
    state.current_mesh_name = "push"
    state.current_type = "push"
    state.push_spot_local = found.spot_local
    -- 吸附面内落点（Y/Z 已 clamp）：挂手时叠加手偏移
    state.push_anchor_local = found.anchor_local
    -- push_spot_world 来自修完的 find_push_nearest，已是实时锚点世界位置
    state.push_spot_world = found.spot_world

    -- 实时根 pose（glide DoorMesh 同款：柜被 TeleportAbsolute 搬动后必须读 actor 实时位置）
    local real_root_loc, real_root_rot = get_push_root_pose(state.push_target)

    -- 锚点相对根节点世界偏移（阶段3 TeleportAbsolute 逐帧跟随用）
    if found.spot_world ~= nil and real_root_loc ~= nil then
        state.push_anchor_offset = {
            X = (found.spot_world.X or 0) - (real_root_loc.X or 0),
            Y = (found.spot_world.Y or 0) - (real_root_loc.Y or 0),
            Z = (found.spot_world.Z or 0) - (real_root_loc.Z or 0),
        }
    end

    -- 阶段3：计算柜移动轴（本地 X 的水平投影，双向由 signed_pull 正负驱动）
    -- 水平压平 = Z 强制 0，避免柜子随手柄 pitch/roll 斜向上/下飘
    state.push_axis = nil
    if real_root_rot ~= nil then
        pcall(function()
            state.push_axis = math_lib.horizontalYawDir(real_root_rot.Yaw or 0, 1)
        end)
    end

    state.phase = PHASE.ATTACHED
    state.latch_origin_loc = { X = found.spot_world.X, Y = found.spot_world.Y, Z = found.spot_world.Z }
    state.latch_origin_rot = real_root_rot or state.push_target.rot
    apply_grip_anim()
    -- 阶段4 音效：左手吸附瞬间播放 Grab
    play_push_audio_event("GrabSoundEvent")
end

-- 阶段3：进入 PUSHING（抓握瞬间）锚定起点
-- 首次调用时执行一次，后续帧 start_dist != nil 自动跳过
local function begin_push_move()
    state.push_start_world = nil
    state.push_start_dist = nil

    -- 抓握瞬间柜根节点世界位置（TeleportAbsolute 目标的基准）
    local root_world = nil
    pcall(function()
        if state.push_target ~= nil and state.push_target.actor ~= nil
           and state.push_target.actor.K2_GetActorLocation ~= nil then
            root_world = state.push_target.actor:K2_GetActorLocation()
        end
    end)
    -- 兜底：L1 缓存时捕获的 loc（柜没动过，等于根节点）
    if root_world == nil and state.push_target ~= nil then
        root_world = state.push_target.loc
    end
    state.push_start_world = root_world

    -- 手沿 push_axis 的投影基准（capture_slide_anchor）
    local lh = controllers.getControllerLocation(0)
    if lh ~= nil and state.latch_origin_loc ~= nil and state.push_axis ~= nil then
        state.push_start_dist = reload_tools.capture_slide_anchor(
            lh, state.latch_origin_loc, state.push_axis)
    end

    -- 阶段4：手开始推柜瞬间 → StartPush 音效 + 推拉门震动（复用 play_glide_pull_haptic，不改 11 号文件）
    play_push_audio_event("StartPushSoundEvent")
    eventFeedback.play_glide_pull_haptic()
end

-- 阶段3：PUSHING 每帧驱动柜子沿本地 X 水平投影轴位移
-- signed_pull = 手沿 push_axis 相对抓握起点的带符号位移（cm），正=前推，负=后拉
-- 目标点 = 起始柜位 + axis × signed_pull × PUSH_MOVE_SCALE（Y/Z 锁起始值实现轴向锁定）
---@param lh table|nil 可选：由调用方传入已读取的左手位置（复用）；nil 时内部自读
local function update_push(lh)
    if state.push_start_dist == nil or state.push_start_world == nil
       or state.latch_origin_loc == nil or state.push_axis == nil then
        return
    end
    if lh == nil then
        lh = controllers.getControllerLocation(0)
    end
    if lh == nil then return end

    -- 带符号手位移 cm（threshold 只影响 progress，push 不用 progress；沿用 GLIDE_SENSITIVITY 同款换算）
    local signed_pull = 0
    pcall(function()
        signed_pull = reload_tools.calc_slide_pull_anchored(
            lh, state.latch_origin_loc, state.push_axis,
            state.push_start_dist, 1.0 / GLIDE_SENSITIVITY, nil)
    end)
    state.signed_pull = signed_pull or 0

    -- 目标柜根世界位置：X/Y 按轴投影移动，Z 锁起始值（水平移动不允许上下飘）
    local sw = state.push_start_world
    local ax = state.push_axis
    local target = {
        X = (sw.X or 0) + (ax.X or 0) * state.signed_pull * PUSH_MOVE_SCALE.val,
        Y = (sw.Y or 0) + (ax.Y or 0) * state.signed_pull * PUSH_MOVE_SCALE.val,
        Z = sw.Z or 0,
    }

    -- 驱动柜本体（SHPushable:TeleportAbsolute 只带位置，转角天然锁定）
    local entry = state.push_target
    if entry == nil or entry.SHPushable == nil or entry.SHPushable.TeleportAbsolute == nil then
        return
    end
    pcall(function()
        local v = uevrUtils.vector(target.X, target.Y, target.Z)
        entry.SHPushable:TeleportAbsolute(v)
    end)
end

local function on_grab_tick_body()
    -- L1 缓存失效检测（pawn 生命周期）
    check_cache_invalidation()

    -- 回弹动画
    if state.returning then
        local elapsed = os.clock() - state.return_start_t
        local dur = math.max(RETURN_DURATION, 0.01)
        local t = elapsed / dur
        if t > 1 then t = 1 end
        local progress = state.return_start_progress * (1 - t)
        -- 按 type 分流回弹更新
        if state.current_type == "key" then
            update_key_rotation_by_progress(progress)
        else
            local offset = progress * get_slide_threshold(state.current_mesh_name)
            update_latch_position(offset)
        end
        if t >= 1 then
            state.returning = false
            -- 回弹完成：销毁表演体，恢复本体，重新吸附到手
            destroy_perf()
            state.phase = PHASE.ATTACHED
            state.signed_pull = 0
            state.progress = 0
            apply_grip_anim()
        end
        return
    end

    -- 已完成状态：松开 grip 立即 detach 左手；1 秒后强制销毁表演体恢复本体
    if state.phase == PHASE.COMPLETED then
        local elapsed = os.clock() - state.completed_start_t
        if elapsed >= COMPLETED_HOLD_SEC then
            detach_from_latch()
        elseif not is_left_grip_pressed() and state.grip_anim_applied then
            -- 松开 grip：只 detach 左手，保留表演体在 8cm 等到点销毁
            remove_grip_anim()
        end
        return
    end

    local left_hand_loc = controllers.getControllerLocation(0)
    if left_hand_loc == nil then
        -- 手未追踪：强制 detach
        if state.phase ~= PHASE.IDLE then
            detach_from_latch()
        end
        return
    end

    local grip_pressed = is_left_grip_pressed()

    -- IDLE / APPROACHING：检测 proximity，自动吸附
    if state.phase == PHASE.IDLE or state.phase == PHASE.APPROACHING then
        -- 阶段4：反吸附冷却门控——松手刻意 detach 后的 1s 内不自动吸回（detach_from_latch 设定，全分支生效），
        -- 即使手仍在吸附范围也让玩家从容把手移开；冷却期间保持在 IDLE，不产生跳变。
        if os.clock() < state.detach_cooldown_until then
            return
        end
        local nearest = M.find_nearest_to_hand(PROXIMITY_CM, left_hand_loc)
        if nearest ~= nil then
            -- 高亮（已禁用）
            -- if not state.highlight_applied or state.latch_component ~= nearest.component then
            --     if state.latch_component ~= nil and state.latch_component ~= nearest.component then
            --         remove_highlight(state.latch_component)
            --     end
            --     apply_highlight(nearest.component)
            --     state.highlight_applied = true
            --     state.latch_component = nearest.component
            -- end
            state.latch_component = nearest.component
            state.current_mesh_name = nearest.mesh_name
            state.current_type = nearest.type
            state.glide_bar_t = nearest.glide_t or 0  -- glide 吸附条：本次吸附冻结的 t（0=A 端，1=B 端，中间=条上落点）
            state.phase = PHASE.APPROACHING

            -- 自动吸附（距离检测通过就吸附）
            state.phase = PHASE.ATTACHED
            state.latch_origin_loc = { X = nearest.loc.X, Y = nearest.loc.Y, Z = nearest.loc.Z }
            state.latch_origin_rot = nearest.rot
            apply_grip_anim()
        else
            -- 普通 latch 不在范围：尝试 push（直挂柜）双锚点检测
            local pfound = find_push_nearest(left_hand_loc)
            if pfound ~= nil then
                begin_push_attach(pfound)
            else
                -- Phase 2 cart：手距 Handle_R 吸附条 A→B 线段（找过世界判定）< 阈值可抓
                local cfound = find_cart_nearest(left_hand_loc)
                if cfound ~= nil then
                    begin_cart_attach(cfound)
                elseif state.phase ~= PHASE.IDLE then
                    -- 离开范围
                    detach_from_latch()
                end
            end
        end

    elseif state.phase == PHASE.ATTACHED then
        -- push（直挂柜）：不依赖 cached_latches 距离，用吸附锚点复检（松手/追踪丢失才脱离）
        if state.current_type == "push" then
            -- 手离开吸附锚点范围则脱离；否则 grip 按住进入 PUSHING
            if state.push_spot_world ~= nil and
               math_lib.vectorDistanceSquaredSafe(state.push_spot_world, left_hand_loc) > PUSH_PROXIMITY_CM * PUSH_PROXIMITY_CM then
                detach_from_latch()
                return
            end
            if grip_pressed then
                state.phase = PHASE.PUSHING
            end
            return
        end

        -- cart（直挂把手）：参考 push 分支提前 return，严禁落入下方通用 latch 复检——
        -- cart 不在 cached_latches，find_nearest_to_hand 必返 nil → 每帧 detach→IDLE→重新吸附，
        -- 手在吸附点与手柄自由位置之间高频跳变（实机已复现）。
        -- 复检基准 = 投影点 C′ 每帧现算世界（随 Handle_R/车移动跟随），手离开范围则脱离。
        if state.current_type == "cart" then
            local spot = get_cart_proj_world()
            if spot == nil then
                detach_from_latch()
                return
            end
            if math_lib.vectorDistanceSquaredSafe(spot, left_hand_loc) > CART_HOLD_PROXIMITY_CM * CART_HOLD_PROXIMITY_CM then
                detach_from_latch()
                return
            end
            -- 阶段3：grip 按下 → 进入 PUSHING（对齐 push 分支，见下方 PUSHING 按 type 分流）
            if grip_pressed then
                state.phase = PHASE.PUSHING
            end
            return
        end

        -- 已吸附：检查手是否还在范围内
        local nearest = M.find_nearest_to_hand(PROXIMITY_CM, left_hand_loc)
        if nearest == nil then
            detach_from_latch()
            return
        end
        -- 切换 latch
        if nearest.component ~= state.latch_component then
            -- if state.highlight_applied and state.latch_component ~= nil then
            --     remove_highlight(state.latch_component)
            -- end
            -- apply_highlight(nearest.component)
            -- state.highlight_applied = true
            state.latch_component = nearest.component
            state.current_mesh_name = nearest.mesh_name
            state.current_type = nearest.type
            state.glide_bar_t = nearest.glide_t or 0  -- glide 吸附条：换 latch 重吸时同步冻结 t
            state.latch_origin_loc = { X = nearest.loc.X, Y = nearest.loc.Y, Z = nearest.loc.Z }
            state.latch_origin_rot = nearest.rot
            -- 重新吸附到新 latch
            remove_grip_anim()
            state.grip_anim_applied = false
            apply_grip_anim()
        end

        -- Grip 按下 → 按 type 分流：key 走旋转，latch 走滑动，glide 走推拉门
        if grip_pressed then
            local latch_info = {
                component = state.latch_component,
                loc = state.latch_origin_loc,
                rot = state.latch_origin_rot,
            }
            if state.current_type == "key" then
                begin_rotate(latch_info)
            elseif state.current_type == "glide" then
                begin_glide(latch_info)
            elseif is_switch_family(state.current_type) then
                begin_switch_press()   -- Phase 2：进入 SWITCH 下压（跳过距离检测，仅松手/追踪丢失脱离）
            else
                begin_slide(latch_info)
            end
        end

    elseif state.phase == PHASE.SWITCH then
        -- 同 SLIDING/GLIDING：跳过距离检测，仅松手/手丢失追踪才脱离（用户裁决 2026-08-29）
        if not grip_pressed or left_hand_loc == nil then
            end_switch_press()
            return
        end
        update_switch_press()

    elseif state.phase == PHASE.GLIDING then
        -- 松开 Grip / 手丢失追踪：直接 detach（无回弹），门停在当前位置由引擎保持
        if not grip_pressed or left_hand_loc == nil then
            detach_from_latch()
            return
        end
        -- 手已刚性吸附在门上：门滑动不依赖 proximity，去掉脱手判定，避免门一动就误脱手
        -- （仅松开 Grip / 手丢失追踪才 detach，上面已处理）
        -- 每帧驱动门（增量式：手位移增量 + 引擎基准 α → OverrideDoorAlpha）
        update_glide(left_hand_loc)

    elseif state.phase == PHASE.PUSHING then
        -- 阶段3：TeleportAbsolute 逐帧搬柜/推车。仅松手/手丢失追踪才脱离
        if not grip_pressed or left_hand_loc == nil then
            detach_from_latch()
            return
        end
        if state.current_type == "cart" then
            -- 已到位轮询（2026-09-02 用户定案，CART_FOLD_CHECK_INTERVAL=300ms 一次）：
            -- 推车中到位检测（DesiredSpot 配对 + IsManagedActorInDesiredSpot，与诊断脚本同法）：
            -- true = 已到位 → 打 complete 标记 + 强制脱手 + 恢复全部碰撞
            local now = os.clock()
            if now - state.cart_fold_check_last_t >= CART_FOLD_CHECK_INTERVAL then
                state.cart_fold_check_last_t = now
                local entry = state.cart_target
                if entry ~= nil then
                    -- 到位诊断：轮询打印配对 spot 与 in_desired_spot 变化（kind=DSP 独立节流，非 FOLD）
                    local spot = get_cart_desired_spot(entry.actor)
                    local in_spot = false
                    if spot ~= nil then
                        pcall(function() in_spot = spot:IsManagedActorInDesiredSpot() end)
                    end
                    cart_trace("DSP", string.format("push poll addr=%s spot=%s in_desired_spot=%s",
                        tostring(cart_actor_key(entry.actor)),
                        spot ~= nil and tostring(cart_actor_key(spot)) or "nil(pair-fail)",
                        tostring(in_spot)))
                    if in_spot == true then
                        mark_cart_completed(entry.actor)
                        l1_trace_add("cart ARRIVED while pushing (in desired spot): force detach + collision restore")
                        cart_trace("FOLD", string.format("push ARRIVED addr=%s -> completed, force detach + collision restore", tostring(cart_actor_key(entry.actor))))
                        if state.cart_collision_off_actor ~= nil then
                            local restored = set_cart_pawn_collision(state.cart_collision_off_actor, false)
                            cart_trace("L2", string.format("push ARRIVED: collision restored prev_addr=%s (n>0=%s)",
                                tostring(cart_actor_key(state.cart_collision_off_actor)), tostring(restored)))
                            state.cart_collision_off_actor = nil
                        else
                            cart_trace("L2", "push ARRIVED: no cart_collision_off_actor (already restored/none)")
                        end
                        detach_from_latch() -- 内部 update_l2_cache 会重选目标，complete 标记守卫确保不再关碰撞
                        return
                    end
                end
            end
            -- 阶段3 cart 自由跟手：抓握瞬间锚定起点（cart_start_world == nil 时执行一次；续推时已在则跳过）
            if state.cart_start_world == nil then
                begin_push_cart_move()
            end
            update_push_cart(left_hand_loc)
        else
            -- push（推柜）：原轴向链路。抓握瞬间锚定起点（start_dist == nil 时执行一次；续拉时已在则跳过）
            if state.push_start_dist == nil then
                begin_push_move()
            end
            update_push(left_hand_loc)
        end

    elseif state.phase == PHASE.SLIDING then
        -- 松开 Grip：slide_completed=true 直接 detach（无回弹）；否则回弹
        if not grip_pressed then
            if state.slide_completed then
                detach_from_latch()
            else
                end_slide(false)
            end
            return
        end

        -- 滑动计算
        if state.latch_origin_loc ~= nil and state.slide_axis ~= nil then
            local threshold_cm = get_slide_threshold(state.current_mesh_name)
            local signed_pull, progress = reload_tools.calc_slide_pull_anchored(
                left_hand_loc,
                state.latch_origin_loc,
                state.slide_axis,
                state.start_anchor_dist,
                threshold_cm,
                nil
            )
            state.signed_pull = signed_pull
            state.progress = progress

            local offset = math.max(0, math.min(threshold_cm, signed_pull))
            update_latch_position(offset)

            -- Phase 4: 拉到位立即触发振动+解锁+root motion 监控，但不 detach（玩家松手才 detach）
            -- 用 slide_completed 标记防重复触发，phase 保持 SLIDING
            if progress >= 1.0 and not state.slide_completed then
                state.slide_completed = true
                -- 拉栓完成：方案 B 直接调 SetLocked(false) 解锁
                unlock_door_directly(state.latch_component)
                -- 触发左手震动反馈（立即）
                eventFeedback.play_latch_haptic()
                -- 标记 L1 缓存中对应门栓为已完成
                if state.latch_cache ~= nil and state.latch_component ~= nil then
                    for _, entry in ipairs(state.latch_cache) do
                        if entry.component == state.latch_component then
                            entry.completed = true
                            break
                        end
                    end
                end
            end

            -- §方案B：拉到底后门本体随门移动，表演体每帧同步到本体真实位置，避免手与门体错位
            if state.slide_completed then
                local body = state.latch_component
                if body ~= nil then
                    local bl = reload_tools.get_component_world_location(body)
                    local br = reload_tools.get_component_world_rotation(body)
                    if bl ~= nil then
                        set_perf_world_transform(bl, br)
                    end
                end
            end
        end

    elseif state.phase == PHASE.ROTATING then
        -- 松开 Grip：key_completed=true 直接 detach（无回弹）；否则回弹
        if not grip_pressed then
            if state.key_completed then
                detach_from_latch()
            else
                end_rotate(false)
            end
            return
        end
        update_key_rotation()
    end
end

-- 2026-09-03 卡顿排查（用户拍板）：on_grab_tick 整体自计时，>50ms 落盘 open latch 日志——
-- 定死卡顿发生时本文件是否清白（写 diagnose_open_latch.log，受其 Enable Logging 开关管理）
local function on_grab_tick()
    local t0 = os.clock()
    on_grab_tick_body()
    local dt = os.clock() - t0
    if dt > 0.05 then
        diag_log("UDOOR", string.format("[TICK-SLOW] unlock_door on_grab_tick took %.1fms", dt * 1000))
    end
end

-- =============================================================================
-- 扫描定时器
-- =============================================================================
local function on_scan_tick()
    -- 1s 一次：取 pawn/pawn_loc 复用给 L2 筛选
    local pawn = uevrUtils.get_local_pawn()
    local pawn_loc = nil
    if pawn ~= nil then
        pcall(function()
            if pawn.K2_GetActorLocation ~= nil then pawn_loc = pawn:K2_GetActorLocation() end
        end)
    end
    update_l2_cache(pawn, pawn_loc)
end

-- =============================================================================
-- 对外接口
-- =============================================================================

--- 获取所有缓存的门栓（3m 内）
---@return table { { component, loc, rot, mesh_name, dist_to_pawn_cm }, ... }
function M.get_cached_latches()
    return state.cached_latches
end

--- 获取 L1 缓存中的 switch 相关条目（type="staircase_switch"/"light_switch"）
--- 供 diagnose_switch.lua 读取（Phase 1：诊断改读主脚本缓存）
---@param ftype string|nil 仅返回该 type；nil 返回全部 switch 族
---@return table { { actor, name, class, subclass, component, loc, rot, mesh_name, mesh_comps, generic, staircase, bUsed, timeline, type }, ... }
function M.get_switch_cache(ftype)
    if state.latch_cache == nil then return {} end
    local out = {}
    for _, e in ipairs(state.latch_cache) do
        if (e.type == "staircase_switch" or e.type == "light_switch") and (ftype == nil or e.type == ftype) then
            out[#out + 1] = e
        end
    end
    return out
end

--- 获取 L1 缓存中的 push 相关条目（type="push"/"PushNClimb"）
--- 供 diagnose_pushable.lua 读取（阶段1：诊断只读主脚本缓存，不重复造轮子）
---@param ftype string|nil 仅返回该 type；nil 返回全部 push 族
---@return table { { index, name, class, type, loc, rot, SHPushable_valid }, ... }
function M.get_push_cache(ftype)
    if state.latch_cache == nil then return {} end
    local out = {}
    for _, e in ipairs(state.latch_cache) do
        if (e.type == "push" or e.type == "PushNClimb") and (ftype == nil or e.type == ftype) then
            local actor_name = "?"
            pcall(function()
                if e.actor ~= nil and e.actor.get_full_name ~= nil then actor_name = e.actor:get_full_name() end
            end)
            local shp_valid = false
            pcall(function() shp_valid = e.SHPushable ~= nil end)
            table.insert(out, {
                name = actor_name,
                class = e.class or e.className or "?",
                type = e.type,
                sub_type = e.sub_type,
                loc = e.loc,
                rot = e.rot,
                SHPushable_valid = shp_valid,
                actor = e.actor, -- 供 diagnose_pushable 继承验证（is_a PushableBase）
            })
        end
    end
    return out
end

--- 获取阶段1选中的唯一目标柜 push 条目（3米内最近）
--- 供 diagnose_pushable.lua 读取；阶段2吸附接入也据此
---@return table|nil
function M.get_push_target()
    return state.push_target
end

--- 获取阶段1选中的唯一目标车 cart 条目（3米内最近，type="PushNClimb"）
--- 供 diagnose_cart.lua 读取；阶段2吸附接入也据此
---@return table|nil
function M.get_cart_target()
    return state.cart_target
end

-- =============================================================================
-- 2026-09-04：目标车"到位"三态只读 getter（供 diagnose_cart.lua 打印主脚本真实状态）
-- 返回：nil = 配不到 DesiredSpot（L1 索引未收录/未重建）；false = 配到未到位；true = 配到且到位。
-- 只读主脚本 L1 索引 state.desired_spot_by_managed（keyed by cart addr → spot），
-- 到位布尔用引擎实时方法 spot:IsManagedActorInDesiredSpot() 判定；不修改任何状态。
-- 设计含意：主脚本各到位分支（L2 命中 / PUSHING 轮询）把"配不到 spot"折叠成 false，
-- 无法区分"配到未到位"vs"配不到"，此 getter 补齐严格三态，诊断据此定位读档未自愈等场景。
-- =============================================================================
---@param cart_actor userdata|nil
---@return boolean|nil
function M.get_cart_arrival_state(cart_actor)
    if cart_actor == nil then return nil end
    local spot = get_cart_desired_spot(cart_actor)
    if spot == nil then return nil end -- 主脚本视角：配不到 spot
    local in_spot = false
    pcall(function() in_spot = spot:IsManagedActorInDesiredSpot() end)
    return in_spot == true
end

--- 阶段3诊断：返回当前推柜运行时状态（push_axis / signed_pull / start_world / phase / target_spot）
--- 供 diagnose_pushable.lua 手动按钮读取 + 自动 0.5s 打点
---@return table
function M.get_push_runtime()
    local phase_name = "IDLE"
    for name, val in pairs(PHASE) do
        if val == state.phase then phase_name = name; break end
    end
    return {
        phase = phase_name,
        push_axis = state.push_axis,
        signed_pull = state.signed_pull,
        push_start_world = state.push_start_world,
        push_start_dist = state.push_start_dist,
        push_spot_local = state.push_spot_local,
        push_target = state.push_target and state.push_target.class or nil,
    }
end

--- 诊断用：返回主脚本 L1/L2 链路状态（供诊断脚本 L1_CHAIN 显示）
---@return table
function M.get_l1_diag()
    local entries = {}
    if state.latch_cache ~= nil then
        for i, e in ipairs(state.latch_cache) do
            local loc_str = "nil"
            if e.loc ~= nil then
                loc_str = string.format("(%.1f,%.1f,%.1f)", e.loc.X or 0, e.loc.Y or 0, e.loc.Z or 0)
            end
            local comp_valid = "no"
            pcall(function()
                if e.component ~= nil then comp_valid = "yes" end
            end)
            table.insert(entries, {
                index = i,
                type = e.type or "?",
                mesh_name = e.mesh_name or "?",
                completed = e.completed,
                comp_valid = comp_valid,
                loc = loc_str,
            })
        end
    end
    return {
        l1_valid = state.latch_cache_valid or false,
        l1_count = state.latch_cache ~= nil and #state.latch_cache or 0,
        cached_count = state.cached_latches ~= nil and #state.cached_latches or 0,
        last_pawn_ref = tostring(_G.__sh2_global_pawn_ref),
        enabled = state.enabled,
        l1_entries = entries,
    }
end

--- 手动触发一次 L1 全图扫描并返回结果
---@return table
function M.scan_now()
    l1_trace_add("manual scan_now (诊断面板手动刷新)")
    build_l1_cache()
    return state.latch_cache or {}
end

--- L1 重建诊断 trace（存档加载后楼梯不进 L1 排查用）
--- 纯内存记录，由诊断脚本手动按钮 Snapshot Rebuild 读取（手动按钮不受日志开关限制）
---@return table { trace = {string,...}, state = table }
function M.get_l1_trace()
    local out = {}
    for i, s in ipairs(l1_trace) do out[i] = s end
    local latch_total = state.latch_cache and #state.latch_cache or 0
    local sw_total = 0
    if state.latch_cache ~= nil then
        for _, e in ipairs(state.latch_cache) do
            if e.type == "staircase_switch" or e.type == "light_switch" then sw_total = sw_total + 1 end
        end
    end
    table.insert(out, string.format(
        "[now] state: enabled=%s l1_valid=%s l1_total=%d switches=%d pending=%s retry_pending=%s retry_count=%s pawn=%s",
        tostring(state.enabled), tostring(state.latch_cache_valid), latch_total, sw_total,
        tostring(state.l1_rebuild_pending), tostring(state.l1_retry_pending),
        tostring(state.l1_retry_count), tostring((_G.__sh2_global_pawn_ref ~= nil) and (_G.__sh2_global_pawn_ref ~= "nil"))))
    return out
end

--- 导出：直接解锁门（导航到 DoorLock → SetLocked(false, true)），供 unlock_item_door.lua 复用
---@param latch_component DoorLatchBar 的 StaticMeshComponent
---@return boolean 成功与否
function M.unlock_door_directly(latch_component)
    return unlock_door_directly(latch_component)
end

--- 导出：从任意门组件导航到 DoorLock（单门 AttachParentSingleDoor / 双门 AttachParentDoubleDoor），供 unlock_item_door.lua 复用
---@param component any 门上的组件（如 KeyStaticMesh）
---@return any|nil DoorLock 组件
function M.navigate_to_door_lock(component)
    return navigate_to_door_lock(component)
end

--- 供 main.lua 回调：关卡加载时调度 L1 重建（统一 5+2 机制）
---@param level any
function M.on_level_change(level)
    schedule_l1_rebuild()
end

-- 统一 pawn 检测入口（main.lua check_pawn_globally 广播调用）。
-- reason：pawn_changed / level_change → 调度 L1 重建；pawn_nil → 清理 pending/retry 防缓存僵死。
---@param reason string
function M.on_pawn_changed(reason)
    if reason == "pawn_nil" then
        state.l1_rebuild_pending = false
        state.l1_retry_pending = false
        return
    end
    schedule_l1_rebuild(reason or "pawn changed")
end

--- 供 main.lua L598 回调：过场/过门动画结束 → 立即重建一次（对齐 remote_grab，2026-09-05 用户定案）
-- 用法：过门触发动画 → 动画结束瞬间重建一次 → 建出几条就是几条；即便建出 0 条也不再来第二次。
-- 与常规 pawn/关卡重建路径独立：置 l1_rebuild_time=0 → check_cache_invalidation 的 >5.0 判定
-- 下一帧即满足（不等 5s），并用 l1_cutscene_once 标记本次为过场路径、跳过 0 条目 2s 重试。
-- 注意：main.lua L598 无 pcall 直接调用本函数，本函数内不 build（build 统一走 tick），故不会上抛。
---@param isInCutscene boolean
function M.on_cutscene_change(isInCutscene)
    if isInCutscene ~= false then
        return
    end
    state.l1_cutscene_once = true
    schedule_l1_rebuild("cutscene end (immediate)")
    state.l1_rebuild_time = 0 -- 立即（下一帧），不等 5s 延迟
end

--- 获取白名单
---@return table
function M.get_whitelist()
    return WHITELIST
end

--- 从缓存中找离左手最近的门栓/钥匙（Phase 1 抓取判定用）
---@param proximity_cm number 左手距离阈值（cm，latch/key 用，默认 12）
---@param left_hand_loc table|nil 可选：由调用方传入已读取的左手位置（复用，避免每帧重复原生调用）；nil 时内部自读
---@return table|nil 最近的 { component, loc, rot, mesh_name, dist_to_hand_cm, type }
function M.find_nearest_to_hand(proximity_cm, left_hand_loc)
    proximity_cm = proximity_cm or PROXIMITY_CM
    if left_hand_loc == nil then
        left_hand_loc = controllers.getControllerLocation(0)
    end
    if left_hand_loc == nil then return nil end

    local best = nil
    local best_dist = nil

    for _, latch in ipairs(state.cached_latches) do
        -- Phase 1.b: 跳过表演体
        if latch.component == state.perf_mesh then goto continue_nearest end

        -- 距离阈值按分支区分：latch/key 用传入值（默认 12）、glide 放宽到 20
        -- switch 用 15（目标=硬编码锚点 Fusebox_12_D，即 entry.component/loc）
        local threshold_cm = proximity_cm
        if latch.type == "glide" then threshold_cm = GLIDE_PROXIMITY_CM end
        if is_switch_family(latch.type) then threshold_cm = SWITCH_PROXIMITY_CM end
        -- light_switch 独立阈值（2026-09-03 探针重定位吸附点后恢复 15，见常量注释）
        if latch.type == "light_switch" then threshold_cm = LIGHT_SWITCH_PROXIMITY_CM end

        -- glide 吸附判定（B-3 吸附条，2026-09-03 §30.5）：
        -- GLIDE_USE_BAR=true → 手到 A(loc)→B(spot_b_loc) 线段的最近点（垂距 + 垂足 t，端点外钳 0/1，
        -- A≈B 退化安全：ab2<1e-4 → t=0，未探测占位值天然退化为 A 单点）；
        -- false → 回退 B-2 双点离散（A/B 各算距离取近者，t 退化为 0/1）。非 glide 行为不变
        local dist_sq = math_lib.vectorDistanceSquaredSafe(latch.loc, left_hand_loc)
        local spot_is_b = false
        local bar_t = nil
        if latch.type == "glide" and latch.spot_b_loc ~= nil then
            if GLIDE_USE_BAR then
                dist_sq, bar_t = math_lib.pointSegmentDistanceSquared(left_hand_loc, latch.loc, latch.spot_b_loc)
            else
                local dist_sq_b = math_lib.vectorDistanceSquaredSafe(latch.spot_b_loc, left_hand_loc)
                if dist_sq_b < dist_sq then
                    dist_sq = dist_sq_b
                    spot_is_b = true
                end
                bar_t = spot_is_b and 1 or 0
            end
        end
        if dist_sq <= threshold_cm * threshold_cm and (best_dist == nil or dist_sq < best_dist) then
            -- glide：best.loc = 线段上落点 C′ = A + t×(B−A) 逐分量（t=0/1 时恰为 A/B 本点，与 B-2 重合）
            local best_loc = latch.loc
            if latch.type == "glide" and latch.spot_b_loc ~= nil then
                local a, b = latch.loc, latch.spot_b_loc
                local tt = bar_t or 0
                best_loc = {
                    X = a.X + (b.X - a.X) * tt,
                    Y = a.Y + (b.Y - a.Y) * tt,
                    Z = a.Z + (b.Z - a.Z) * tt,
                }
            end
            best = {
                component = latch.component,
                loc = best_loc,
                rot = latch.rot,
                mesh_name = latch.mesh_name,
                dist_to_hand_cm = math.sqrt(dist_sq),
                type = latch.type,
                spot_is_b = spot_is_b,
                glide_t = bar_t,
            }
            best_dist = dist_sq
        end
        ::continue_nearest::
    end
    return best
end

--- 最近 glide 门定位诊断（供诊断脚本"Print Nearest Glide Door"按钮单帧打印）
--- 返回该帧最近推拉门的信息：吸附点(DoorMesh 世界位置)、门 Actor 根节点、玩家位置、左手位置、左手到吸附点距离
---@return table|nil
function M.get_nearest_glide_debug()
    if state.latch_cache == nil then return nil end

    local pawn = uevrUtils.get_local_pawn()
    local pawn_loc = nil
    pcall(function()
        if pawn ~= nil and pawn.K2_GetActorLocation ~= nil then
            pawn_loc = pawn:K2_GetActorLocation()
        end
    end)
    local left_hand_loc = controllers.getControllerLocation(0)

    local nearest = nil
    local nearest_dist = math.huge
    local nearest_eff = nil
    for _, e in ipairs(state.latch_cache) do
        if e.type == "glide" and e.loc ~= nil then
            -- L2 写入的 loc 已含吸附点偏移（正向/反向选组也在 L2 完成），直接使用；
            -- 旧实现在此再叠一次 GLIDE_SPOT_OFFSET_A，属双重叠加（2026-09-03 修正）
            local eff = e.loc
            local d = math_lib.vectorDistanceSquaredSafe(eff, left_hand_loc or pawn_loc)
            if d < nearest_dist then
                nearest_dist = d
                nearest = e
                nearest_eff = eff
            end
        end
    end
    if nearest == nil then return nil end
    -- nearest_eff：实际吸附点（DoorMesh + spot offset），供日志/距离显示
    if nearest_eff == nil then nearest_eff = nearest.loc end

    -- 门 Actor 根节点位置
    local actor_loc = nil
    pcall(function()
        if nearest.actor ~= nil and nearest.actor.K2_GetActorLocation ~= nil then
            actor_loc = nearest.actor:K2_GetActorLocation()
        end
    end)

    -- InteractionProximitySphere 球体位置（诊断用，对比吸附点）
    local sphere_loc = nil
    pcall(function()
        if nearest.actor ~= nil and nearest.actor.InteractionProximitySphere ~= nil then
            local sp = nearest.actor.InteractionProximitySphere
            sphere_loc = reload_tools.get_component_world_location(sp)
        end
    end)

    local dist_hand_spot = nil
    if left_hand_loc ~= nil and nearest_eff ~= nil then
        dist_hand_spot = math.sqrt(math_lib.vectorDistanceSquaredSafe(nearest_eff, left_hand_loc))
    end

    -- 门类型/朝向诊断（排查不同门偏移错位）：actor 完整名、yaw 旋转、滑动轴
    local actor_full = "?"
    pcall(function()
        if nearest.actor ~= nil then actor_full = nearest.actor:get_full_name() or "?" end
    end)
    local yaw = nil
    pcall(function()
        if nearest.spot_rot ~= nil then yaw = nearest.spot_rot.Yaw end
    end)
    local slide_axis_str = "?"
    pcall(function()
        if nearest.spot_axis ~= nil then
            slide_axis_str = string.format("(%.3f,%.3f,%.3f)", nearest.spot_axis.X or 0, nearest.spot_axis.Y or 0, nearest.spot_axis.Z or 0)
        end
    end)
    -- 门 DoorMovement 类型（若有）
    local movement_type = "?"
    pcall(function()
        if nearest.movement ~= nil then
            local cl = nearest.movement:get_class()
            if cl ~= nil then movement_type = cl:get_name() or "?" end
        end
    end)

    -- ★ DoorMesh 本体镜像诊断（专家意见：判断手反是"负缩放镜像"还是"基矢量反向"）
    -- 从 actor.DoorMesh 实读，而非 nearest.door_mesh（那是吸附球 spot）
    local dm_rot = nil          -- DoorMesh 组件旋转（对比 Actor yaw）
    local dm_fwd, dm_right, dm_up = nil, nil, nil
    local dm_scale, dm_rel_scale = nil, nil
    local det = nil             -- 手性判定：Forward×Right·Up（+1 右手系，-1 镜像）
    local md_dir = nil          -- MovementDirection（世界空间）
    pcall(function()
        local dm = nil
        if nearest.actor ~= nil then dm = nearest.actor.DoorMesh end
        if dm ~= nil then
            if dm.K2_GetComponentRotation ~= nil then dm_rot = dm:K2_GetComponentRotation() end
            if dm.GetForwardVector ~= nil then local v = dm:GetForwardVector(); dm_fwd = {X=v.X,Y=v.Y,Z=v.Z} end
            if dm.GetRightVector ~= nil then local v = dm:GetRightVector(); dm_right = {X=v.X,Y=v.Y,Z=v.Z} end
            if dm.GetUpVector ~= nil then local v = dm:GetUpVector(); dm_up = {X=v.X,Y=v.Y,Z=v.Z} end
            if dm.K2_GetComponentScale ~= nil then dm_scale = dm:K2_GetComponentScale() end
            if dm.RelativeScale3D ~= nil then
                local s = dm.RelativeScale3D
                dm_rel_scale = {X=s.X or 0, Y=s.Y or 0, Z=s.Z or 0}
            end
            if dm_fwd ~= nil and dm_right ~= nil and dm_up ~= nil then
                -- 叉积 fwd×right，与 up 点积 → 手性
                local cx = dm_fwd.Y * dm_right.Z - dm_fwd.Z * dm_right.Y
                local cy = dm_fwd.Z * dm_right.X - dm_fwd.X * dm_right.Z
                local cz = dm_fwd.X * dm_right.Y - dm_fwd.Y * dm_right.X
                det = cx * dm_up.X + cy * dm_up.Y + cz * dm_up.Z
                if det ~= nil and det ~= 0 then det = det > 0 and 1 or -1 end
            end
        end
    end)
    pcall(function()
        if nearest.movement ~= nil and nearest.movement.MovementDirection ~= nil then
            local v = nearest.movement.MovementDirection
            md_dir = {X=v.X or 0, Y=v.Y or 0, Z=v.Z or 0}
        end
    end)

    return {
        spot_loc = nearest_eff,          -- 吸附点 = DoorMesh + GLIDE_SPOT_OFFSET_A（含 Z 抬升 150cm）
        actor_loc = actor_loc,           -- 门 Actor 根节点
        sphere_loc = sphere_loc,         -- InteractionProximitySphere 球体位置
        pawn_loc = pawn_loc,             -- 玩家位置
        hand_loc = left_hand_loc,        -- 左手位置
        dist_hand_spot_cm = dist_hand_spot, -- 左手到吸附点的距离(cm)
        actor_full = actor_full,         -- 门 Actor 完整名（含类名）
        yaw = yaw,                       -- 门 Actor Yaw 旋转
        slide_axis = slide_axis_str,     -- 门滑动轴（本地 X 投影）
        movement_type = movement_type,   -- DoorMovement 类名
        mesh_name = nearest.mesh_name,
        type = nearest.type,
        dm_rot = dm_rot,                 -- DoorMesh 组件旋转
        dm_fwd = dm_fwd, dm_right = dm_right, dm_up = dm_up, -- DoorMesh 基矢量
        dm_scale = dm_scale, dm_rel_scale = dm_rel_scale,    -- DoorMesh 缩放
        det = det,                       -- Forward×Right·Up 手性（+1 右手系 / -1 镜像）
        md_dir = md_dir,                 -- MovementDirection（世界空间）
        open_sign = nearest.open_sign,   -- 开合符号（±1）
    }
end
---@return table { phase, progress, signed_pull, returning }
function M.get_grab_state()
    return {
        phase = state.phase,
        progress = state.progress,
        signed_pull = state.signed_pull,
        returning = state.returning,
        attached = state.phase == PHASE.ATTACHED or state.phase == PHASE.SLIDING or state.phase == PHASE.ROTATING or state.phase == PHASE.GLIDING or state.phase == PHASE.SWITCH,
        phase_name = state.phase == PHASE.IDLE and "IDLE"
                  or state.phase == PHASE.APPROACHING and "APPROACHING"
                  or state.phase == PHASE.ATTACHED and "ATTACHED"
                  or state.phase == PHASE.SLIDING and "SLIDING"
                  or state.phase == PHASE.ROTATING and "ROTATING"
                  or state.phase == PHASE.GLIDING and "GLIDING"
                  or state.phase == PHASE.SWITCH and "SWITCH"
                  or state.phase == PHASE.COMPLETED and "COMPLETED"
                  or "UNKNOWN",
        perf_active = state.perf_actor ~= nil,
        body_hidden = state.latch_component ~= nil and (state.phase == PHASE.SLIDING or state.phase == PHASE.ROTATING or state.phase == PHASE.GLIDING),
    }
end

--- 获取当前门栓组件（供诊断脚本读取）
function M.get_latch_component()
    return state.latch_component
end

--- 获取最后一次吸附错误（供诊断脚本读取）
function M.get_attach_error()
    return state.last_attach_error
end

--- 获取最后一次吸附成功信息（供诊断脚本读取）
function M.get_attach_info()
    return state.last_attach_info
end

--- 获取诊断接口（Phase 2 临时，Phase 6 删除）
--- diagnose 脚本可通过返回的表读写 enabled 和 key_hand_offset
---@return table
function M.get_diagnostic()
    return M_DIAGNOSTIC
end

--- 获取 Phase 1 参数
---@return table
function M.get_params()
    return {
        proximity_cm = PROXIMITY_CM,
        slide_threshold_cm = get_slide_threshold(state.current_mesh_name),
        return_duration = RETURN_DURATION,
    }
end

--- 获取当前 LATCH_HAND_OFFSET（供诊断脚本滑块读取）
---@return table {x, y, z}
function M.get_latch_hand_offset()
    return { x = LATCH_HAND_OFFSET.x, y = LATCH_HAND_OFFSET.y, z = LATCH_HAND_OFFSET.z }
end

--- 设置 LATCH_HAND_OFFSET（诊断脚本滑块写入）
---@param x number
---@param y number
---@param z number
function M.set_latch_hand_offset(x, y, z)
    LATCH_HAND_OFFSET.x = x
    LATCH_HAND_OFFSET.y = y
    LATCH_HAND_OFFSET.z = z
end

--- 获取当前 LATCH_HAND_ROTATION（供诊断脚本滑块读取）
---@return table {pitch, yaw, roll}
function M.get_latch_hand_rotation()
    return { pitch = LATCH_HAND_ROTATION.pitch, yaw = LATCH_HAND_ROTATION.yaw, roll = LATCH_HAND_ROTATION.roll }
end

--- 设置 LATCH_HAND_ROTATION（诊断脚本滑块写入）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_latch_hand_rotation(pitch, yaw, roll)
    LATCH_HAND_ROTATION.pitch = pitch
    LATCH_HAND_ROTATION.yaw = yaw
    LATCH_HAND_ROTATION.roll = roll
end

--- 获取反向门栓 LATCH_HAND_OFFSET_REV（供诊断脚本滑块读取）
---@return table {x, y, z}
function M.get_latch_hand_offset_rev()
    return { x = LATCH_HAND_OFFSET_REV.x, y = LATCH_HAND_OFFSET_REV.y, z = LATCH_HAND_OFFSET_REV.z }
end

--- 设置 LATCH_HAND_OFFSET_REV（诊断脚本滑块写入）
---@param x number
---@param y number
---@param z number
function M.set_latch_hand_offset_rev(x, y, z)
    LATCH_HAND_OFFSET_REV.x = x
    LATCH_HAND_OFFSET_REV.y = y
    LATCH_HAND_OFFSET_REV.z = z
end

--- 获取反向门栓 LATCH_HAND_ROTATION_REV（供诊断脚本滑块读取）
---@return table {pitch, yaw, roll}
function M.get_latch_hand_rotation_rev()
    return { pitch = LATCH_HAND_ROTATION_REV.pitch, yaw = LATCH_HAND_ROTATION_REV.yaw, roll = LATCH_HAND_ROTATION_REV.roll }
end

--- 设置 LATCH_HAND_ROTATION_REV（诊断脚本滑块写入）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_latch_hand_rotation_rev(pitch, yaw, roll)
    LATCH_HAND_ROTATION_REV.pitch = pitch
    LATCH_HAND_ROTATION_REV.yaw = yaw
    LATCH_HAND_ROTATION_REV.roll = roll
end

--- 获取当前 KEY_HAND_OFFSET（供诊断脚本滑块读取）
---@return table {x, y, z}
function M.get_key_hand_offset()
    return { x = KEY_HAND_OFFSET.x, y = KEY_HAND_OFFSET.y, z = KEY_HAND_OFFSET.z }
end

--- 设置 KEY_HAND_OFFSET（诊断脚本滑块写入）
---@param x number
---@param y number
---@param z number
function M.set_key_hand_offset(x, y, z)
    KEY_HAND_OFFSET.x = x
    KEY_HAND_OFFSET.y = y
    KEY_HAND_OFFSET.z = z
end

--- 获取当前 KEY_HAND_ROTATION（供诊断脚本滑块读取）
---@return table {pitch, yaw, roll}
function M.get_key_hand_rotation()
    return { pitch = KEY_HAND_ROTATION.pitch, yaw = KEY_HAND_ROTATION.yaw, roll = KEY_HAND_ROTATION.roll }
end

--- 设置 KEY_HAND_ROTATION（诊断脚本滑块写入）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_key_hand_rotation(pitch, yaw, roll)
    KEY_HAND_ROTATION.pitch = pitch
    KEY_HAND_ROTATION.yaw = yaw
    KEY_HAND_ROTATION.roll = roll
end

--- 获取当前吸附类型（供诊断脚本滑块判断调整哪组参数）
---@return string "latch" / "key" / "glide"
function M.get_current_type()
    return state.current_type
end

--- 获取当前 GLIDE_HAND_OFFSET（供诊断脚本滑块读取）
---@return table {x, y, z}
function M.get_glide_hand_offset()
    return { x = GLIDE_HAND_OFFSET.x, y = GLIDE_HAND_OFFSET.y, z = GLIDE_HAND_OFFSET.z }
end

--- 设置 GLIDE_HAND_OFFSET（诊断脚本滑块写入）
---@param x number
---@param y number
---@param z number
function M.set_glide_hand_offset(x, y, z)
    GLIDE_HAND_OFFSET.x = x
    GLIDE_HAND_OFFSET.y = y
    GLIDE_HAND_OFFSET.z = z
end

--- 获取当前 GLIDE_HAND_ROTATION（供诊断脚本滑块读取）
---@return table {pitch, yaw, roll}
function M.get_glide_hand_rotation()
    return { pitch = GLIDE_HAND_ROTATION.pitch, yaw = GLIDE_HAND_ROTATION.yaw, roll = GLIDE_HAND_ROTATION.roll }
end

--- 设置 GLIDE_HAND_ROTATION（诊断脚本滑块写入）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_glide_hand_rotation(pitch, yaw, roll)
    GLIDE_HAND_ROTATION.pitch = pitch
    GLIDE_HAND_ROTATION.yaw = yaw
    GLIDE_HAND_ROTATION.roll = roll
end

--- 获取当前 SWITCH_HAND_OFFSET（供诊断面板滑块读取）
---@return table {x, y, z}
function M.get_switch_hand_offset()
    return { x = SWITCH_HAND_OFFSET.x, y = SWITCH_HAND_OFFSET.y, z = SWITCH_HAND_OFFSET.z }
end

--- 设置 SWITCH_HAND_OFFSET（诊断面板滑块写入；调好硬编码到常量）
---@param x number
---@param y number
---@param z number
function M.set_switch_hand_offset(x, y, z)
    SWITCH_HAND_OFFSET.x = x
    SWITCH_HAND_OFFSET.y = y
    SWITCH_HAND_OFFSET.z = z
end

--- 获取当前 SWITCH_HAND_ROTATION（供诊断面板滑块读取）
---@return table {pitch, yaw, roll}
function M.get_switch_hand_rotation()
    return { pitch = SWITCH_HAND_ROTATION.pitch, yaw = SWITCH_HAND_ROTATION.yaw, roll = SWITCH_HAND_ROTATION.roll }
end

--- 设置 SWITCH_HAND_ROTATION（诊断面板滑块写入）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_switch_hand_rotation(pitch, yaw, roll)
    SWITCH_HAND_ROTATION.pitch = pitch
    SWITCH_HAND_ROTATION.yaw = yaw
    SWITCH_HAND_ROTATION.roll = roll
end

--- 获取当前 LIGHT_HAND_OFFSET（供诊断面板滑块读取；仅 light_switch）
---@return table {x, y, z}
function M.get_light_hand_offset()
    return { x = LIGHT_HAND_OFFSET.x, y = LIGHT_HAND_OFFSET.y, z = LIGHT_HAND_OFFSET.z }
end

--- 设置 LIGHT_HAND_OFFSET（诊断面板滑块写入；调好硬编码到常量）
---@param x number
---@param y number
---@param z number
function M.set_light_hand_offset(x, y, z)
    LIGHT_HAND_OFFSET.x = x
    LIGHT_HAND_OFFSET.y = y
    LIGHT_HAND_OFFSET.z = z
end

--- 获取当前 LIGHT_HAND_ROTATION（供诊断面板滑块读取；仅 light_switch）
---@return table {pitch, yaw, roll}
function M.get_light_hand_rotation()
    return { pitch = LIGHT_HAND_ROTATION.pitch, yaw = LIGHT_HAND_ROTATION.yaw, roll = LIGHT_HAND_ROTATION.roll }
end

--- 设置 LIGHT_HAND_ROTATION（诊断面板滑块写入；调好硬编码到常量）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_light_hand_rotation(pitch, yaw, roll)
    LIGHT_HAND_ROTATION.pitch = pitch
    LIGHT_HAND_ROTATION.yaw = yaw
    LIGHT_HAND_ROTATION.roll = roll
end

--- 获取指定组 PUSH 手附加偏移（slot="A"/"B"，供诊断面板滑块读取；相对各自吸附锚点）
---@param slot string "A" 或 "B"
---@return table {x, y, z}
function M.get_push_hand_offset(slot)
    local off = (slot == "B") and PUSH_HAND_OFFSET_B or PUSH_HAND_OFFSET_A
    return { x = off.x, y = off.y, z = off.z }
end

--- 设置指定组 PUSH 手附加偏移（诊断面板滑块写入；调好硬编码到常量）
---@param slot string "A" 或 "B"
---@param x number
---@param y number
---@param z number
function M.set_push_hand_offset(slot, x, y, z)
    local off = (slot == "B") and PUSH_HAND_OFFSET_B or PUSH_HAND_OFFSET_A
    off.x = x
    off.y = y
    off.z = z
end

--- 获取指定组 PUSH 手旋转（slot="A"/"B"，供诊断面板滑块读取）
---@param slot string "A" 或 "B"
---@return table {pitch, yaw, roll}
function M.get_push_hand_rotation(slot)
    local rot = (slot == "B") and PUSH_HAND_ROTATION_B or PUSH_HAND_ROTATION_A
    return { pitch = rot.pitch, yaw = rot.yaw, roll = rot.roll }
end

--- 设置指定组 PUSH 手旋转（诊断面板滑块写入；调好硬编码到常量）
---@param slot string "A" 或 "B"
---@param pitch number
---@param yaw number
---@param roll number
function M.set_push_hand_rotation(slot, pitch, yaw, roll)
    local rot = (slot == "B") and PUSH_HAND_ROTATION_B or PUSH_HAND_ROTATION_A
    rot.pitch = pitch
    rot.yaw = yaw
    rot.roll = roll
end

--- 获取当前推动灵敏系数 PUSH_MOVE_SCALE.val（诊断滑块读取；1.0 = 1:1 手推 cm = 柜移 cm）
---@return number
function M.get_push_move_scale()
    return PUSH_MOVE_SCALE.val
end

--- 设置推动灵敏系数（诊断滑块写入；不改 JSON，调好后硬编码 PUSH_MOVE_SCALE.val）
---@param v number
function M.set_push_move_scale(v)
    PUSH_MOVE_SCALE.val = v
end

--- 诊断用：按当前 PUSH_HAND_OFFSET_A/B + ROTATION_A/B 实时重挂左手（滑块改动即时生效）
--- 参照 update_switch_hand_attach 模式；push 直挂柜 StaticMesh，无表演体
---@return boolean ok
function M.update_push_hand_attach()
    if state.current_type ~= "push" then return false end
    if not state.grip_anim_applied then return false end
    local tgt = state.push_static_mesh
    if tgt == nil or uevrUtils.getValid(tgt) == nil then
        tgt = state.push_target and state.push_target.actor or nil
        if tgt ~= nil then
            pcall(function() tgt = tgt.StaticMesh end)
            if tgt == nil then return false end
        end
    end
    if tgt == nil then return false end
    local spot = state.push_anchor_local or state.push_spot_local or PUSH_SPOT_A
    local hoff, hrot = get_push_hand_params()
    local loc = {
        (hoff.x or 0) + spot.x,
        (hoff.y or 0) + spot.y,
        (hoff.z or 0) + spot.z,
    }
    local rot = { hrot.pitch, hrot.yaw, hrot.roll }
    local ok = pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_attach", Handed.Left, tgt, nil, 0, loc, rot)
    end)
    return ok
end

-- ============================================================================
-- Phase 2 cart（sh2 小推车）M 导出：供 diagnose_cart.lua 滑块校准吸附条/手偏移/旋转
-- 写法参照 push 组（直挂组件零换算）；调好值硬编码回 CART_* 常量，诊断脚本最终删除
-- ============================================================================

--- 获取 cart 吸附条参数（诊断端点 3 滑块读取；调好硬编码到常量）
---@return table {a_x, b_x, a_y, a_z, bar_len, proximity}
function M.get_cart_bar_params()
    return {
        a_x = CART_BAR_A_X,
        b_x = CART_BAR_B_X,
        a_y = CART_BAR_A_Y,
        a_z = CART_BAR_A_Z,
        bar_len = CART_BAR_B_X - CART_BAR_A_X,
        proximity = CART_GRIP_PROXIMITY_CM,
    }
end

--- 设置 cart 吸附条参数（诊断节点写；a_y/a_z 直接存，bar_len 映射为远端 B_X）
---@param a_y number
---@param a_z number
---@param bar_len number
function M.set_cart_bar_params(a_y, a_z, bar_len)
    if a_y ~= nil then CART_BAR_A_Y = a_y end
    if a_z ~= nil then CART_BAR_A_Z = a_z end
    if bar_len ~= nil then CART_BAR_B_X = CART_BAR_A_X + bar_len end
end

--- 获取 cart 手附加偏移（相对 Handle_R 本地，诊断 6 滑块 Tx/Ty/Tz 读取）
---@return table {x, y, z}
function M.get_cart_hand_offset()
    return { x = CART_HAND_OFFSET.x, y = CART_HAND_OFFSET.y, z = CART_HAND_OFFSET.z }
end

--- 设置 cart 手附加偏移（诊断 6 滑块写入；调好硬编码到常量）
---@param x number
---@param y number
---@param z number
function M.set_cart_hand_offset(x, y, z)
    CART_HAND_OFFSET.x = x
    CART_HAND_OFFSET.y = y
    CART_HAND_OFFSET.z = z
end

--- 获取 cart 手旋转（相对 Handle_R 本地，诊断 6 滑块 Rx/Ry/Rz 读取）
---@return table {pitch, yaw, roll}
function M.get_cart_hand_rotation()
    return {
        pitch = CART_HAND_ROTATION.pitch,
        yaw = CART_HAND_ROTATION.yaw,
        roll = CART_HAND_ROTATION.roll,
    }
end

--- 设置 cart 手旋转（诊断 6 滑块写入；调好硬编码到常量）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_cart_hand_rotation(pitch, yaw, roll)
    CART_HAND_ROTATION.pitch = pitch
    CART_HAND_ROTATION.yaw = yaw
    CART_HAND_ROTATION.roll = roll
end

--- 诊断用：按当前 CART_HAND_OFFSET + CART_HAND_ROTATION + 吸附条参数实时重挂左手（滑块改动即时生效）
--- 参照 update_push_hand_attach 模式；cart 直挂 StaticMesh_Handle_R，无表演体
---@return boolean ok
function M.update_cart_hand_attach()
    if state.current_type ~= "cart" then return false end
    if not state.grip_anim_applied then return false end
    local tgt = state.cart_handle
    if tgt == nil or uevrUtils.getValid(tgt) == nil then
        local entry = state.cart_target
        if entry ~= nil then tgt = resolve_cart_handle(entry.actor) end
    end
    if tgt == nil or uevrUtils.getValid(tgt) == nil then return false end
    -- C′ 在吸附线 A 端 X + t×LEN 处（A、B 同 y/z，故 y/z 直接取 A_Y/A_Z）
    local px = CART_BAR_A_X + (state.cart_t or 0) * CART_BAR_LEN
    local loc = {
        CART_HAND_OFFSET.x + px,
        CART_HAND_OFFSET.y + CART_BAR_A_Y,
        CART_HAND_OFFSET.z + CART_BAR_A_Z,
    }
    local rot = { CART_HAND_ROTATION.pitch, CART_HAND_ROTATION.yaw, CART_HAND_ROTATION.roll }
    local ok = pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_attach", Handed.Left, tgt, nil, 0, loc, rot)
    end)
    return ok
end

--- 获取当前 LIGHT_SPOT_OFFSET（吸附点偏移，仅 light_switch，诊断滑块读取）
---@return table {x, y, z}
function M.get_light_spot_offset()
    return { x = LIGHT_SPOT_OFFSET.x, y = LIGHT_SPOT_OFFSET.y, z = LIGHT_SPOT_OFFSET.z }
end

--- 设置 LIGHT_SPOT_OFFSET（吸附点偏移，诊断滑块写入；调好硬编码到常量）
---@param x number
---@param y number
---@param z number
function M.set_light_spot_offset(x, y, z)
    LIGHT_SPOT_OFFSET.x = x
    LIGHT_SPOT_OFFSET.y = y
    LIGHT_SPOT_OFFSET.z = z
end

--- 获取当前 SWITCH_PRESS_TRAVEL / SENSITIVITY（供诊断面板滑块校准）
---@return table {travel, sensitivity}
function M.get_switch_press_params()
    return { travel = SWITCH_PRESS_TRAVEL, sensitivity = SWITCH_PRESS_SENSITIVITY }
end

--- 设置 SWITCH_PRESS_TRAVEL / SENSITIVITY（诊断面板滑块写入；调好硬编码到常量）
---@param travel number 到位行程阈值 cm
---@param sensitivity number 位移→alpha 敏感系数
function M.set_switch_press_params(travel, sensitivity)
    if travel ~= nil then SWITCH_PRESS_TRAVEL = travel end
    if sensitivity ~= nil then SWITCH_PRESS_SENSITIVITY = sensitivity end
end

--- 获取 SWITCH 下压实时状态（供诊断面板手动 Snapshot Press 按钮取证，非自动打印）
---@return table
function M.get_switch_press_state()
    return {
        phase = state.phase,
        phase_name = (state.phase == PHASE.SWITCH) and "SWITCH" or "other",
        base_z = state.switch_base_z,
        cur_z = state.switch_cur_z,
        drop = state.switch_drop,
        alpha = state.switch_alpha,
        timeline = state.switch_timeline ~= nil,
        length = state.switch_length,
        drive_ok = state.switch_drive_ok,
        drive_err = state.switch_drive_err,
        completed = state.switch_completed,
        travel = SWITCH_PRESS_TRAVEL,
        sensitivity = SWITCH_PRESS_SENSITIVITY,
    }
end

--- 获取反向门(side<0) GLIDE_HAND_OFFSET_REV（诊断滑块读取）
---@return table {x, y, z}
function M.get_glide_hand_offset_rev()
    return { x = GLIDE_HAND_OFFSET_REV.x, y = GLIDE_HAND_OFFSET_REV.y, z = GLIDE_HAND_OFFSET_REV.z }
end

--- 设置反向门 GLIDE_HAND_OFFSET_REV（诊断滑块写入）
---@param x number
---@param y number
---@param z number
function M.set_glide_hand_offset_rev(x, y, z)
    GLIDE_HAND_OFFSET_REV.x = x
    GLIDE_HAND_OFFSET_REV.y = y
    GLIDE_HAND_OFFSET_REV.z = z
end

--- 获取反向门 GLIDE_HAND_ROTATION_REV（诊断滑块读取）
---@return table {pitch, yaw, roll}
function M.get_glide_hand_rotation_rev()
    return { pitch = GLIDE_HAND_ROTATION_REV.pitch, yaw = GLIDE_HAND_ROTATION_REV.yaw, roll = GLIDE_HAND_ROTATION_REV.roll }
end

--- 设置反向门 GLIDE_HAND_ROTATION_REV（诊断滑块写入）
---@param pitch number
---@param yaw number
---@param roll number
function M.set_glide_hand_rotation_rev(pitch, yaw, roll)
    GLIDE_HAND_ROTATION_REV.pitch = pitch
    GLIDE_HAND_ROTATION_REV.yaw = yaw
    GLIDE_HAND_ROTATION_REV.roll = roll
end

--- 获取 GLIDE_SPOT_OFFSET_A（A 吸附点偏移，仅 glide，诊断滑块读取）
---@return table {x, y, z}
function M.get_glide_spot_offset()
    return { x = GLIDE_SPOT_OFFSET_A.x, y = GLIDE_SPOT_OFFSET_A.y, z = GLIDE_SPOT_OFFSET_A.z }
end

--- 设置 GLIDE_SPOT_OFFSET_A（A 吸附点偏移，仅 glide，诊断滑块写入）
---@param x number
---@param y number
---@param z number
function M.set_glide_spot_offset(x, y, z)
    GLIDE_SPOT_OFFSET_A.x = x
    GLIDE_SPOT_OFFSET_A.y = y
    GLIDE_SPOT_OFFSET_A.z = z
end

--- 获取反向门(side<0) GLIDE_SPOT_OFFSET_A_REV（诊断滑块读取）
---@return table {x, y, z}
function M.get_glide_spot_offset_rev()
    return { x = GLIDE_SPOT_OFFSET_A_REV.x, y = GLIDE_SPOT_OFFSET_A_REV.y, z = GLIDE_SPOT_OFFSET_A_REV.z }
end

--- 设置反向门(side<0) GLIDE_SPOT_OFFSET_A_REV（诊断滑块写入）
---@param x number
---@param y number
---@param z number
function M.set_glide_spot_offset_rev(x, y, z)
    GLIDE_SPOT_OFFSET_A_REV.x = x
    GLIDE_SPOT_OFFSET_A_REV.y = y
    GLIDE_SPOT_OFFSET_A_REV.z = z
end

--- 强制重新吸附（诊断脚本滑块调整后实时预览）
--- ATTACHED 阶段：detach + 重新 attach，使用新 offset/rotation；有 perf 则挂 perf（不到真本体）
--- SLIDING/ROTATING/GLIDING 阶段：detach + 重新 attach 表演体，使用新 offset/rotation
--- 2026-09-03 修复：原实现在 remove_grip_anim（内部 destroy_perf 销毁表演体）之前捕获
--- target=state.perf_mesh，死引用传给 apply_grip_anim 后 `tgt = target or ...` 优先命中
--- 已销毁组件 → 挂手静默失败（glide 滑块拖动看不到变化、面板却报 reattach=true）。
--- 现改为 remove 后由 apply_grip_anim 现选目标（perf 族现场重生表演体；switch 族用 latch_component）。
function M.force_reattach()
    if state.phase ~= PHASE.ATTACHED and state.phase ~= PHASE.SLIDING
        and state.phase ~= PHASE.ROTATING and state.phase ~= PHASE.GLIDING then
        return false
    end
    -- 无可挂目标（本体与表演体均空）直接失败，不进入 detach（保持原语义）
    if state.perf_mesh == nil and state.latch_component == nil then
        return false
    end
    remove_grip_anim()
    state.grip_anim_applied = false
    state.last_attach_error = nil
    state.last_attach_info = nil
    apply_grip_anim()
    return true
end

--- 滑块实时预览（不 detach）：对当前已吸附的目标原地重新 on_accessory_attach，
--- 携带更新后的偏移/旋转。hand 会在原 parent 上 K2_AttachTo + 重置相对变换，手不消失。
--- 仅 switch 有效（phase=ATTACHED 且已应用吸附）。
---@return boolean 是否成功原地更新
function M.update_switch_hand_attach()
    if not is_switch_family(state.current_type) then return false end
    if not state.grip_anim_applied then return false end
    local tgt = nil
    if state.perf_mesh ~= nil and uevrUtils.getValid(state.perf_mesh) ~= nil then
        tgt = state.perf_mesh
    elseif state.latch_component ~= nil and uevrUtils.getValid(state.latch_component) ~= nil then
        tgt = state.latch_component
    end
    if tgt == nil then return false end
    local loc, rot
    if state.current_type == "light_switch" then
        loc = { LIGHT_HAND_OFFSET.x + LIGHT_SPOT_OFFSET.x,
                LIGHT_HAND_OFFSET.y + LIGHT_SPOT_OFFSET.y,
                LIGHT_HAND_OFFSET.z + LIGHT_SPOT_OFFSET.z }
        rot = { LIGHT_HAND_ROTATION.pitch, LIGHT_HAND_ROTATION.yaw, LIGHT_HAND_ROTATION.roll }
    else
        loc = { SWITCH_HAND_OFFSET.x, SWITCH_HAND_OFFSET.y, SWITCH_HAND_OFFSET.z }
        rot = { SWITCH_HAND_ROTATION.pitch, SWITCH_HAND_ROTATION.yaw, SWITCH_HAND_ROTATION.roll }
    end
    local ok = pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_attach", Handed.Left, tgt, nil, 0, loc, rot)
    end)
    return ok
end

--- glide 滑块实时预览（不 detach、不销毁表演体）：对当前吸附的表演体原地重新
--- on_accessory_attach，loc/rot 用最新 GLIDE_HAND_OFFSET/_REV + A/B 吸附条 t 插值重算
--- （复用 compute_glide_hand_pose）。hand 在原 parent 上 K2_AttachTo + 重置相对变换，手不消失。
--- 2026-09-03 新增：诊断面板 glide 偏移/旋转滑块拖动即时生效（此前 force_reattach 死引用失败，
--- 须松手重抓才能看到变化）。
---@return boolean 是否成功原地更新
function M.update_glide_hand_attach()
    if state.current_type ~= "glide" then return false end
    if not state.grip_anim_applied then return false end
    local tgt = nil
    if state.perf_mesh ~= nil and uevrUtils.getValid(state.perf_mesh) ~= nil then
        tgt = state.perf_mesh
    end
    if tgt == nil then return false end
    local loc, rot = compute_glide_hand_pose()
    if loc == nil or rot == nil then return false end
    local ok = pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_attach", Handed.Left, tgt, nil, 0, loc, rot)
    end)
    return ok
end

--- 启用/禁用扫描
---@param enable boolean
function M.set_enabled(enable)
    state.enabled = enable
end

--- 获取是否启用
---@return boolean
function M.is_enabled()
    return state.enabled
end

-- =============================================================================
-- 左手真实位置暴露（供 unlock_item_door 远程抓取复用）
-- unlock_door 的手部定位基于 VR 控制器（controllers.getControllerLocation(0)），
-- 即玩家真实手柄/手的位置；而 remote_grab 在 IKArms 模式解析到 IK 手臂网格
-- （小臂），导致钥匙飞到小臂。这里统一暴露控制器位置给 item 脚本引用。
-- =============================================================================
--- 获取左手世界位置（VR 控制器位置 = 真实手位置）
---@return table|nil loc 左手世界位置（{X,Y,Z}），nil 表示不可用
---@return table|nil rot 左手世界旋转（{Pitch,Yaw,Roll}），nil 表示不可用
function M.get_left_hand_world()
    local loc = controllers.getControllerLocation(0)
    if loc == nil then
        return nil, nil
    end
    local rot = controllers.getControllerRotation(0)
    return loc, rot
end

-- =============================================================================
-- Init
-- =============================================================================
function M.init()
    _G.__sh2_unlock_door_module = M  -- Phase 1: 供诊断脚本读主脚本缓存（热重载后优先取 _G）
    -- 热重载清理：只碰已知引用，禁止 find_all_of 全图扫（极卡）
    if state.latch_component ~= nil then
        pcall(function() state.latch_component:SetVisibility(true, true) end)
        pcall(function() state.latch_component:SetHiddenInGame(false, true) end)
        -- pcall(function() state.latch_component:SetRenderCustomDepth(false) end)  -- 高亮已禁用
    end
    if state.perf_actor ~= nil then
        pcall(function() state.perf_actor:SetHiddenInGame(true, true) end)
        pcall(function() uevrUtils.destroy_actor(state.perf_actor) end)
    end
    pcall(function() uevrUtils.executeUEVRCallbacks("on_accessory_detach", Handed.Left) end)
    pcall(function() hands.setHoldingAttachment(0, nil) end)
    -- Phase 2：热重载兜底，若上次有残留按下未释放则补释放一次（防 VRGamepad refcount 泄漏）
    -- [方案 B：A 键触发已禁用，不再需要 release_a_button 兜底
    -- release_a_button()
    -- ]
    state.phase = PHASE.IDLE
    state.latch_component = nil
    state.latch_origin_loc = nil
    state.latch_origin_rot = nil
    state.current_mesh_name = nil
    state.current_type = nil
    state.slide_axis = nil
    state.start_anchor_dist = nil
    -- Phase 2/4: 清理滑动+钥匙旋转相关字段
    state.slide_completed = false
    state.key_start_pitch = 0
    state.key_rotation_delta = 0
    state.key_completed = false
    state.key_axis = nil
    state.key_body_rot = nil
    state.signed_pull = 0
    state.progress = 0
    -- Phase 2: 清理推拉门(glide)字段
    state.movement = nil
    state.spot_axis = nil
    state.open_sign = 1
    state.glide_completed = false
    state.glide_start_dist = nil
    state.glide_base_alpha = 0
    state.glide_bar_t = nil     -- B-3 吸附条 t（随抓取周期清理）
    state.glide_spot_is_b = nil -- B-3 退役：原 B-2 双点选点标记，统一由 glide_bar_t 表达（0=A，1=B）
    -- Phase 2: 清理折叠楼梯开关(switch)字段
    state.switch_timeline = nil
    state.switch_staircase = nil
    state.switch_length = 1
    state.switch_base_z = nil
    state.switch_alpha = 0
    state.switch_completed = false
    -- state.highlight_applied = false  -- 高亮已禁用
    state.grip_anim_applied = false
    state.last_attach_error = nil
    state.last_attach_info = nil
    state.returning = false
    state.return_start_t = 0
    state.return_start_progress = 0
    state.perf_actor = nil
    state.perf_mesh = nil
    state.perf_origin = nil
    state.perf_hidden_body = nil
    state.completed_start_t = 0
    state.latchsocket_component = nil
    -- L1 三级检测缓存重置（热重载清空，并显式调度重建：pawn 检测已上移 main，热重载时 pawn 未变不会广播）
    state.latch_cache = nil
    state.latch_cache_valid = false
    state.last_pawn_ref = nil
    M.on_pawn_changed("pawn_changed") -- 热重载强制重建（5s 延迟后由 per-frame tick 执行）

    if not state.scan_interval_registered then
        uevrUtils.setInterval(SCAN_INTERVAL_MS, function()
            on_scan_tick()
        end)
        state.scan_interval_registered = true
    end

    if not state.grab_tick_registered then
        uevrUtils.registerPostEngineTickCallback(function()
            on_grab_tick()
        end)
        state.grab_tick_registered = true
    end

    return M
end

return M