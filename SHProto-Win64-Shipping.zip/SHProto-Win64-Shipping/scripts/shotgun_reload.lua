--[[修改说明：
1. 霰弹枪手动换弹主模块（Phase 1-4 完整实现）
2. 从 pistol_reload.lua 架构移植，核心差异：
   - proximity 每次入舱写一发子弹
   - 无弹匣分离（管状弹仓，无退弹步骤，取弹即开始装弹流程）
   - 泵动上膛（每发后必做，阻止引擎自动泵动，VR 手动后拉+前推完成）
3. A/B 类 hooks 由 libs/reload_hooks.lua 集中注册，本文件通过 M.on_xxx 回调入口接收 dispatch
   - A 类：on_fire_ready_check / on_can_be_reloaded_check /
           on_play_request_check / on_ranged_reload_check / on_montage_change_check /
           on_fire_success / on_single_action_prepare_end
           （on_out_of_ammo 已于 2026-07-21 删除：slide_locked 改由 IsFireReady 触发）
   - B 类：on_grip_update_merge / on_init_attachment
4. C 类 accessory hooks（泵动 grip+proximity）和 D 类生命周期回调由本文件自注册
5. 依据：
   - plans/sh2_shotgun_manual_reload_port_plan.md
   - plans/sh2_shotgun_manual_reload_sdk_notes.md
6. 占位符策略：未诊断清楚的 SDK 信息（CE 偏移、socket 朝向、音效时间轴等）
   暂用手枪值或合理估值，标注 TODO[shotgun]，CE 验证后修正
7. 泵动阻断策略 C（2026-07-19 实测）：开火后清零
   SingleActionPrepareAnimData @ weapon+0xC68（FPlayAnimationData 0xB0）挡自动泵；
   手动泵完成必须写回备份，否则引擎无法再开火（仅 IsFireReady allow 不够）。
   下一发再清零。表演护木：needs_pump 时预生成 PoseableMesh，成功后再藏本体。
8. 全局变量规范：
   - reload_active 复用 g_manual_reload_active（手枪已注册，不做武器区分）
   - needs_pump 为本地状态（仅霰弹枪自身关心，不发布全局）
   - 取弹信号复用 g_mag_grab_edge（UEVR_09 写入，不做武器区分）
   - 左手持弹复用 g_mag_in_left_hand（UEVR_09 消费）
9. 拋壳特效（Phase 3.1）已删除（2026-07-24）：拋壳动画由引擎在 restore_prepare_anim_data
   后自动触发，不需要 lua 脚本手动激活 Niagara 或调用 OnShellEjected UFunction。
   原 trigger_shell_eject_method_a/b/both 函数、M.trigger_shell_eject_test* 诊断入口、
   SHELL_EJECT_NIAGARA_FIELD 常量、SHItemWeaponRanged_c 本地变量已全部移除。
10. 2026-07-21 接入手枪 slide_locked 机制（禁瞄准 + dry fire 链路）：
   - 借用 g_slide_locked 全局：复用 00/09 已建好的通用禁瞄准 + dry fire 链路
   - on_tick 中读 clip_ammo（reload_tools.read_clip_ammo）+ needs_pump 判断空仓，
     不调用 weapon:IsFireReady()（会触发 hook 死锁 "resource deadlock would occur"）
   - slide_locked=true 条件：needs_pump==true（泵动未完成）或 clip_ammo<=0（弹仓空）
   - dry_fire_edge 消费条件由 state.needs_pump 改为 state.slide_locked
   - publish_globals 发布 slide_locked；换枪降沿清理 slide_locked（避免残留误禁瞄准）
   - 删除 M.on_out_of_ammo 函数：霰弹枪 slide_locked 由弹药读取触发，dry fire 由 dry_fire_edge 触发，
     无引擎自动换弹要 cancel，OnOutOfAmmoPerformed hook 无任何职责；reload_hooks.lua 的 dispatch 容错自动跳过
11. 2026-07-23 Step 1+2：左手可随时脱离护木 + 暂停泵动（plan §3.6.6）
   - on_accessory_detach 守护条件从 (needs_pump or pump_active) 收窄为 pump_active
     needs_pump=true 但 pump_active=false 时允许左手脱离（可自由去取弹装弹）
   - active_left_accessory 回调：仅在 pump_offhand_gripping=true 且 grip 按下时返回高 priority UUID
     对齐手枪 slide_rack 做法（grip 松开时不返回 UUID → 触发 detach）
     松 grip → 返回 nil → checkAccessories 触发 detach → pause_pump
     grip 按下 + offhand=true → 返回 UUID → 压过 proximity → 维持长拉行程吸附
     暂停状态下 offhand=false 或 grip 松开 → 不返回 UUID → proximity 路径接管
   - 新增 pause_pump 函数：松手/左手位置丢失时暂停泵动而非取消
     保持 pump_active=true，护木冻结在最后位置
     重新握住时恢复 pump_offhand_gripping=true，从冻结位置继续泵动
   - on_accessory_detach 松手时：needs_pump=true 调 pause_pump，否则 cancel_pump
   - tick_pump 中 pump_offhand_gripping=false 时跳过 calc_slide_pull_anchored，以冻结 progress 跟枪同步
     lh_pos=nil 时调 pause_pump 而非 cancel_pump
   - on_accessory_animation 重新握住时：pump_active=true 仅恢复握持，不重新 begin_pump
   - 泵动语义：needs_pump=true 时只有"暂停"和"完成"，没有"取消"
     取消仅用于武器切换/mesh丢失/装弹冲突等异常场景
12. 2026-07-27：check_shell_proximity 恢复 shell_2 门控（防御性）
   - 新增条件：state.shells_component == nil（shell_1 已入仓销毁）+ state.shell2_proximity_enabled == true（lerp 完成）
   - 原 2026-07-19 注释"移除门控"假设 shell_2 不会进入距离阈值，但该假设依赖参数（5cm 阈值 + 6.74cm 偏移）
   - 防御性恢复门控，与步枪保持一致；shell2_proximity_enabled 字段本就为此设计
13. 2026-07-30 迁移到新锚定 API：begin_pump / tick_pump / cancel_pump 的内联
   (lh-socket)·axis 算法 + 旧 calc_slide_pull fallback 替换为
   reload_tools.capture_slide_anchor + reload_tools.calc_slide_pull_anchored 单次调用；
   rack.start_back_dist 字段重命名为 start_anchor_dist（与手枪/步枪一致）。
   旧 calc_slide_pull / calc_slide_rotate 已从 reload_tools.lua 删除。
14. 2026-08-31 持弹时阻断护木 proximity attach（对齐 rifle_reload.lua:4518 做法）：
   - 初始化段注册 accessories.registerGripBlock(KEYS.mag_in_left_hand, "rifle_offhand")
   - 左手持弹（shells_in_hand=true → g_mag_in_left_hand）时，proximity 主路径跳过护木
     两个 marker（grip_animation 均为 rifle_offhand），防止左手被误吸附到护木
   - 弹入仓/掉落后全局清零自动恢复；泵动期间 active_left_accessory 主动吸附不受影响
]]--

local uevrUtils = require("libs/uevr_utils")
local mathLib = require("libs/core/math_lib")
local attachments = require("libs/attachments")
local accessories = require("libs/accessories")
local controllers = require("libs/controllers")
local hands = require("libs/hands")
local configui = require("libs/configui")
local vr_globals = require("UEVR_00_init_globals")
local reload_tools = require("libs/reload_tools")
local reload_hooks = require("libs/reload_hooks")
local audio = require("libs/audio")
local event_feedback = require("UEVR_11_EventFeedback")

local M = {}

local KEYS = vr_globals.KEYS

-- =============================================================================
-- 常量配置
-- =============================================================================

-- 武器识别标记
local SHOTGUN_NAME_MARKER = "WeaponShotgun"

-- Socket 名称（sdk_notes §4.3）
-- 装弹吸附：管仓底部洞口附近用 bone_magazine（勿用 FX_Chamber——那是弹膛，偏扳机/枪身内部）
-- 泵/护木：bone_forearm
local SHELL_INSERT_SOCKET = "bone_magazine"
-- 相对装弹 socket 的局部偏移（cm）
-- 坐标系（枪体本地实测）：forward=枪身轴向（负=往前/枪口），down=垂直（正=向下），right=水平（正=往左）
-- 终点：装弹口吸附点（proximity + 滑入终点）
local SHELL_INSERT_OFFSET = { forward = 1.0, down = -2.0, right = 0.0 }
-- 滑入起点相对终点再往下的距离（cm）。forward/right 强制与终点相同，避免路径左右斜穿枪身
-- （若 START.right 与 END.right 一正一负，会从右往左割枪——右手递过去时最明显）
local SHELL_SLIDE_APPROACH_DOWN = 8.0
local PUMP_BONE_NAME = "bone_forearm"          -- sdk_notes §4.3 确认

-- 装弹口：子弹滑入时 HideBoneByName，避免与表演弹壳穿模（参照 pistol_reload magazine_joint）
local LOADING_GATE_BONE = "bone_magazine"
local HIDE_BONE_PHYS_BODY = 0

-- 霰弹单发 StaticMesh 资产路径（sdk_notes §9.2 确认存在）
local SHELL_MESH_PATH = "/Game/Game/Art/Items/Shotgun/ShotgunShell_01_A.ShotgunShell_01_A"

-- attachments_parameters.json 中左手持弹条目 id（动画名 shotgun_shell_insert）
-- Phase 2.1：双弹装填，shell_1 + shell_2 两个独立 actor，各自走 json 偏移配置
local SHELL_LEFT_HAND_ATTACHMENT_ID = "shotgun_shell_1"
local SHELL_CONFIG_PREFIX = "uevr_attachments_shotgun_shell_1_"
local SHELL_LEFT_HAND_ATTACHMENT_ID_2 = "shotgun_shell_2"
local SHELL_CONFIG_PREFIX_2 = "uevr_attachments_shotgun_shell_2_"

-- 与 pistol_reload / main.lua 相同的 hands_type 枚举
local HandsType = {
    None = 1,
    Forearms = 2,
    IKArms = 3,
}

-- 策略 C：阻止引擎自动泵动（ASHItemWeaponRangedSingleAction，CXX dump）
local PREPARE_ANIM_DATA_OFF = 0xC68
local PREPARE_ANIM_DATA_SIZE = 0xB0

-- 策略 D：idle 固定值（3 次 dump 确认同会话+跨武器切换一致）
-- 用途：complete_pump 时写入，覆盖 post-fire 值，防止空仓装弹后引擎自动泵动
-- 注意：qword[2],[3] 疑似指针，跨会话可能变化；如失效需改为动态捕获 idle 值
local IDLE_PREPARE_ANIM_DATA = {
    0x000036370000FC63, -- qword[0]
    0x0000000000027A34, -- qword[1]
    0x00000000000AEE5F, -- qword[2] (疑似指针)
    0x0000000000187576, -- qword[3] (疑似指针)
    0x0000000000000000, -- qword[4]
    0x0000000000000000, -- qword[5]
    0x000000000040C3DB, -- qword[6]
    0x000000003E4CCCCD, -- qword[7]  (float 0.2)
    0x0000000000000000, -- qword[8]
    0x0000000000000000, -- qword[9]
    0x0000000000000000, -- qword[10]
    0x0000000000000000, -- qword[11]
    0x0000000000000000, -- qword[12]
    0x0000000000000000, -- qword[13]
    0x000000003E4CCCCD, -- qword[14] (float 0.2)
    0x0000000000000000, -- qword[15]
    0x0000000000000000, -- qword[16]
    0x0000000000000000, -- qword[17]
    0x0000000000000000, -- qword[18]
    0x0000000000000000, -- qword[19]
    0x0000000000000000, -- qword[20]
    0x3F80000000000001, -- qword[21] (float 1.0)
}

-- 插弹 proximity 距离（cm）
local SHELL_INSERT_DISTANCE = 5.0

-- 左手 attach socket（与 pistol 共用 hand_l_bn）
local SHELL_ATTACH_SOCKET = "hand_l_bn"

-- Phase 2.1：shell_1 despawn 后 shell_2 lerp 滑到 shell_1 初始位置（plan §2.4.2）
-- lerp 在 component relative location 上做（shell_2 始终挂左手 motion controller）
-- ease-in 曲线：t^2
local SHELL_LERP_DURATION = 0.2

-- 松手垂直掉落（与 pistol DROP_* 对齐）
local SHELL_DROP_DURATION = 0.5
local SHELL_DROP_DISTANCE = 120.0

-- 入膛滑入动画时长（秒）：斜向滑入装弹口，被枪体遮挡后 despawn
local SHELL_SLIDE_DURATION = 0.3

-- 旋转相对位移的延迟（0~0.95）：越大越晚才从斜插转成水平
-- 0=全程跟着转；0.55=前 55% 路程保持 START 倾角，后段再转到 END
local SHELL_SLIDE_ROT_DELAY = 0.30

-- 入膛统一朝向（不跟手，避免不同握持角穿模）
-- 两组都是相对 bone_magazine socket 的局部偏移（度），彼此独立、不叠加。
-- 设成完全相同 → 滑入只做直线运动、过程中不旋转。
-- 要斜插：只改 START，相对 END 上下差约 40~45°（例如 END.pitch 与 START.pitch 差 45）。
-- socket 实测：X=下 / Y=后(管仓轴) / Z=左
local SHELL_SLIDE_END_ROT_OFFSET = { pitch = 90.0, yaw = 90.0, roll = 0.0 }
local SHELL_SLIDE_START_TILT = { pitch = 90.0, yaw = 40.0, roll = 0.0 }

-- 左手 attach 选项（参照 pistol magAttachOptions）
local shellAttachOptions = {
    detachFromOriginOnGrip = true,
    maintainWorldPositionOnDetachFromOrigin = false,
    detachFromParentOnRelease = true,
    maintainWorldPositionOnDetachFromParent = false,
    reattachToOriginOnRelease = false,
    restoreTransformToOriginOnReattach = false,
    useZeroTransformOnReattach = false,
    allowChildVisibilityHandling = false,
    allowChildHiddenInGameHandling = false,
    allowRenderInMainPassHandling = false,
}

-- 泵动距离阈值（cm）：左手后拉到位的满程距离

local PUMP_PULL_THRESHOLD = 8.0
-- 泵动前推完成阈值（cm）：后拉到位后，前推离原位 < 此值算完成
local PUMP_PUSH_DONE_DIST = 8.0
-- 泵动最大骨骼位移（cm）：PoseableMesh 护木跟随 pump_value 的最大后移距离
local PUMP_BONE_MAX_DISTANCE = 8.0

-- 从 accessories_parameters.json 读取的霰弹枪左手 marker UUID（init 时填充）
-- 对应 accessories_parameters.json 中 WeaponShotgun_Alt_D_BP_C_shotgun_05_A_rig 下的条目
-- pump_marker_uuid: 本体护木 UUID（低 priority，用于泵动完成后挂回真枪）
-- pump_perf_marker_uuid: 表演护木 UUID（高 priority，泵动期间左手优先附着此 marker）
-- grip_animation 复用 accessories 已注册的 "rifle_offhand"（socket=bone_forearm），不单独定义常量
local pump_marker_uuid = nil
local pump_perf_marker_uuid = nil

-- 霰弹枪音效分段配置（硬编码，与手枪/步枪同模式）
-- diagnose 面板滑条可临时修改内存值供预览，不写入 JSON
local SHOTGUN_AUDIO_SEGMENTS = {
    shell_insert = { audio_key = "shotgun_reload", start_sec = 0.20, duration = 0.80 },
    pump_back    = { audio_key = "shotgun_pump",   start_sec = 0.00, duration = 0.30 },
    pump_fwd     = { audio_key = "shotgun_pump",   start_sec = 0.30, duration = 0.30 },
    mag_release  = { audio_key = "shotgun_pump",   start_sec = 2.00, duration = 1.70 },
    dry_fire     = { audio_key = "shotgun_dry_fire", start_sec = 0.00, duration = 1.00 },
}

-- 获取指定音效段的参数（供本模块和 diagnose 面板共用）
function M.get_audio_segment(seg_name)
    return SHOTGUN_AUDIO_SEGMENTS[seg_name]
end

-- 播放指定音效段（供面板按钮调用）
function M.play_audio_segment(seg_name)
    local seg = SHOTGUN_AUDIO_SEGMENTS[seg_name]
    if seg == nil then
        return false
    end
    audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
    return true
end

-- 临时修改音效段参数（仅 diagnose 面板预览用，不写入 JSON，不持久化）
function M.set_audio_segment(seg_name, start_sec, duration)
    local seg = SHOTGUN_AUDIO_SEGMENTS[seg_name]
    if seg == nil then
        return false
    end
    seg.start_sec = start_sec
    seg.duration = duration
    return true
end

-- Dry fire 音效事件名（sdk_notes §8 确认）
local DRY_FIRE_AUDIO_EVENT = "Play_Wpn_Shotgun_Shot_No_Ammo"
local SHOTGUN_DRY_FIRE_KEY = "shotgun_dry_fire"
-- Dry fire 音效资产完整路径（TODO[shotgun]: 确认实际路径，当前按 Wwise 目录规则推断）
local SHOTGUN_DRY_FIRE_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Shotgun/Play_Wpn_Shotgun_Shot_No_Ammo.Play_Wpn_Shotgun_Shot_No_Ammo"

-- 音效资产完整路径（TODO[shotgun]: 确认实际路径）
local SHOTGUN_RELOAD_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Shotgun/Play_Wpn_Shotgun_Reload.Play_Wpn_Shotgun_Reload"
local SHOTGUN_PUMP_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Shotgun/Play_Wpn_Shotgun_Pump_Action.Play_Wpn_Shotgun_Pump_Action"

-- Handed 全局由 libs/uevr_utils.lua 定义（Left = 0, Right = 1）

-- 前向声明：spawn/despawn 等在定义点之前就会调用；必须 local，避免与 rifle/pistol 抢全局名
local publish_globals

-- =============================================================================
-- 本地状态（热重载兼容）
-- =============================================================================

local state = rawget(_G, "__sh2_shotgun_reload_state")
if type(state) == "table" and state._was_shotgun == nil then
    state._was_shotgun = false
end
if type(state) ~= "table" then
    state = {
        -- Phase 2: 双弹装填
        reload_active = false,           -- 复用 g_manual_reload_active
        shells_in_hand = false,          -- 左手是否持有任意一发霰弹模型
        shells_actor = nil,              -- shell_1 表演模型 actor
        shells_component = nil,          -- shell_1 StaticMeshComponent（attach 到左手）
        -- Phase 2.1: shell_2 独立 actor（不再挂 comp1 下）
        shells_actor2 = nil,             -- shell_2 表演模型 actor
        shells_component2 = nil,         -- shell_2 StaticMeshComponent（独立 attach 到左手）
        shell2_proximity_enabled = false,-- shell_2 是否参与 proximity 检测（shell_1 despawn + lerp 完成后启用）
        shell2_doomed = false,           -- shell_2 注定无法入仓（reserve=0 或 clip 满），等玩家松手掉落
        shell2_lerp = nil,               -- shell_2 lerp 状态 {active, t, duration, start_loc, end_loc, start_rot, end_rot}
        shell_slide = nil,               -- 入膛滑入动画状态（reload_tools slide table）
        shell_slide2 = nil,              -- shell_2 入膛滑入动画状态（独立于 shell_1）
        shell_drop = nil,                -- 松手垂直掉落状态（reload_tools drop/fall）
        shell_drop2 = nil,               -- shell_2 松手掉落状态（独立于 shell_1）
        -- Phase 3: 泵动上膛
        needs_pump = false,              -- 每发开火后置 true，手动泵动完成后置 false（本地状态）
        pump_active = false,             -- VR 手动泵动是否进行中
        pump_completed_this_cycle = false, -- 本轮泵动是否已调用引擎同步（防重入）
        -- 策略 C：PrepareAnimData 清零备份
        prepare_anim_data_nulled = false,
        prepare_anim_data_backup = nil,  -- { weapon_addr=, bytes= {qword...} }
        last_clip_ammo = nil,            -- 弹匣变化兜底检测开火 → needs_pump
        -- Phase 3.5: PoseableMesh
        pump_poseable = nil,             -- 护木 PoseableMesh 组件
        pump_poseable_actor = nil,       -- 护木 PoseableMesh actor（销毁用）
        pump_bone_hidden = false,        -- 真枪 bone_forearm 是否已隐藏
        pump_offhand_gripping = false,   -- 左手是否正握着 rifle_offhand（开火后可自动 begin）
        post_pump_keep_left_frames = 0,  -- 拉完栓后短暂粘住左手（抗原生动画 montage 拆挂）
        pump_anchor_frozen = nil,         -- BLOCKER-1: 表演护木生成时冻结锚点，整轮泵动用同一份 {forearm_local, axis_local}
        was_empty = false,               -- 策略E：打空仓标记，上弹时每发清零PrepareAnimData直到手动泵动
        loading_gate_hidden = false,     -- 真枪 bone_magazine 是否已 HideBoneByName
        -- 武器切换检测
        last_weapon_key = nil,
        _was_shotgun = false,
        -- Phase 5: slide_locked 借用手枪机制驱动 00/09 禁瞄准 + dry fire
        -- 由 on_tick 读 weapon:IsFireReady() 决定，needs_pump 和 ammo=0 都置 true
        slide_locked = false,
        -- pump 状态由 reload_tools.new_slide_rack_state() 持有，下方 init 时补充
        pump_rack = nil,
        -- ShellSpawn 诊断：上次取弹/生成断点
        last_grab_skip = nil,
        last_spawn_fail = nil,
        last_spawn_step = nil,
        spawn_attempt_count = 0,
        spawn_success_count = 0,
    }
    state.pump_rack = reload_tools.new_slide_rack_state()
    state.shell_drop = reload_tools.new_drop_state()
    state.shell_drop.duration = SHELL_DROP_DURATION
    state.shell_drop.distance = SHELL_DROP_DISTANCE
    state.shell_drop2 = reload_tools.new_drop_state()
    state.shell_drop2.duration = SHELL_DROP_DURATION
    state.shell_drop2.distance = SHELL_DROP_DISTANCE
end
-- 热重载后确保 pump_rack 存在
if state.pump_rack == nil then
    state.pump_rack = reload_tools.new_slide_rack_state()
end
if state.prepare_anim_data_nulled == nil then
    state.prepare_anim_data_nulled = false
end
if state.shell_drop == nil then
    state.shell_drop = reload_tools.new_drop_state()
    state.shell_drop.duration = SHELL_DROP_DURATION
    state.shell_drop.distance = SHELL_DROP_DISTANCE
end
if state.shell_drop2 == nil then
    state.shell_drop2 = reload_tools.new_drop_state()
    state.shell_drop2.duration = SHELL_DROP_DURATION
    state.shell_drop2.distance = SHELL_DROP_DISTANCE
end
-- 热重载后补齐 Phase 2.1 字段
if state.shell2_proximity_enabled == nil then state.shell2_proximity_enabled = false end
if state.shell2_doomed == nil then state.shell2_doomed = false end
if state.shell2_lerp == nil then state.shell2_lerp = nil end
if state.shell_slide2 == nil then state.shell_slide2 = nil end
-- 热重载后补齐诊断字段
if state.spawn_attempt_count == nil then state.spawn_attempt_count = 0 end
if state.spawn_success_count == nil then state.spawn_success_count = 0 end
if state.pump_offhand_gripping == nil then state.pump_offhand_gripping = false end
-- 热重载后补齐 slide_locked 字段
if state.slide_locked == nil then state.slide_locked = false end
if state.post_pump_keep_left_frames == nil then state.post_pump_keep_left_frames = 0 end
if state.was_empty == nil then state.was_empty = false end

-- 关键：把 state 写回 _G，保证热重载后新模块复用同一 state 表
-- （对齐 pistol_reload.lua L207 `_G.__sh2_manual_reload_state = state`）
-- 若缺失此行：rawget 永远返回 nil → 每次热重载创建新 state → 旧 on_tick 闭包写旧 state，
-- 新模块读新 state，导致状态分叉（旧闭包写旧 state，新代码读新 state）
_G.__sh2_shotgun_reload_state = state

-- pump 视觉：始终读写共享 state，避免热重载后本地表与 state 分叉出孤儿 actor
local pump_visual = setmetatable({}, {
    __index = function(_, key)
        if key == "poseable_actor" then
            return state.pump_poseable_actor
        end
        if key == "poseable_mesh" then
            return state.pump_poseable
        end
        return nil
    end,
    __newindex = function(_, key, value)
        if key == "poseable_actor" then
            state.pump_poseable_actor = value
        elseif key == "poseable_mesh" then
            state.pump_poseable = value
        end
    end,
})

-- 重入保护：hook 与回调内禁止同步 cancel
local reload_block_guard = { cancelling = false }

-- =============================================================================
-- 通用工具函数
-- =============================================================================

-- 控制台/诊断 print：受 RELOAD_DIAG_ENABLED 门控（面板任意诊断 section 开启时为 true；默认全关）
-- 同时写入 rifle_diagnose.log（通过 diag 模块 append_line），不再只输出到控制台
local function print_log(text, logLevel, tag)
    if rawget(_G, "RELOAD_DIAG_ENABLED") ~= true then
        return
    end
    local label = tag ~= nil and tag or "SHOTGUN_RELOAD"
    local msg = "[" .. label .. "] " .. tostring(text)
    print(msg)
end

local function read_component_world_snapshot(comp)
    if comp == nil then
        return nil
    end
    local snap = { loc = nil, scale = nil, socket = nil, bone = nil }
    pcall(function()
        if comp.K2_GetComponentToWorld ~= nil then
            local wt = comp:K2_GetComponentToWorld()
            if wt ~= nil then
                pcall(function()
                    snap.loc = {
                        X = wt.Translation.X or 0,
                        Y = wt.Translation.Y or 0,
                        Z = wt.Translation.Z or 0,
                    }
                end)
                pcall(function()
                    snap.scale = {
                        X = wt.Scale3D.X or 0,
                        Y = wt.Scale3D.Y or 0,
                        Z = wt.Scale3D.Z or 0,
                    }
                end)
            end
        end
    end)
    if snap.loc == nil then
        snap.loc = reload_tools.get_component_world_location(comp)
    end
    pcall(function()
        snap.socket = reload_tools.get_socket_world_location(comp, PUMP_BONE_NAME)
    end)
    pcall(function()
        if comp.GetBoneLocationByName ~= nil then
            local space = 0
            if rawget(_G, "EBoneSpaces") ~= nil and EBoneSpaces.WorldSpace ~= nil then
                space = EBoneSpaces.WorldSpace
            end
            snap.bone = comp:GetBoneLocationByName(
                uevrUtils.fname_from_string(PUMP_BONE_NAME), space)
        end
    end)
    return snap
end

local function set_spawn_fail(step, reason)
    state.last_spawn_step = step
    state.last_spawn_fail = reason
    print_log("spawn_shells FAIL step=" .. tostring(step) .. " reason=" .. tostring(reason), LogLevel.Warn)
end

local function set_spawn_ok(detail)
    state.last_spawn_fail = nil
    state.last_spawn_step = "ok"
    state.spawn_success_count = (state.spawn_success_count or 0) + 1
    local msg = "OK " .. tostring(detail or "")
    print_log("spawn_shells " .. msg, LogLevel.Info)
end

local function set_grab_skip(reason)
    state.last_grab_skip = reason
    print_log("grab skipped: " .. tostring(reason), LogLevel.Debug)
end

local uobject_valid = reload_tools.uobject_valid

-- 触发换弹手柄震动（防御性包装：11号模块未加载或热重载陈旧时不破坏流程）
local function trigger_reload_haptic(action)
    if event_feedback and type(event_feedback.play_reload_haptic) == "function" then
        pcall(event_feedback.play_reload_haptic, action)
    end
end

-- 播放空仓扣扳机（dry fire）音效：走 audio.lua 的 SpawnAkComponentAtLocation 独立路径
-- （绕开 reload_hooks 对 PostEventByName 的 hook，规避 UEVR hook_ptr 递归锁）
local function play_dry_fire_sound()
    local ok, result = pcall(audio.play_segment, SHOTGUN_DRY_FIRE_KEY, 0, 1.0)
    return ok and result == true
end

-- =============================================================================
-- 武器识别与对象链（复用 reload_tools.resolve_combat_chain）
-- =============================================================================

local function is_shotgun_weapon(weapon)
    if weapon == nil then
        return false
    end
    local ok, name = pcall(function()
        return weapon:get_full_name()
    end)
    return ok and name ~= nil and name:find(SHOTGUN_NAME_MARKER, 1, true) ~= nil
end

local function is_shotgun_equipped()
    return rawget(_G, KEYS.current_weapon_type) == "shotgun"
end

-- 获取霰弹枪武器链：返回 weapon_mesh, chain, err
local function get_shotgun_chain()
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    local chain = reload_tools.resolve_combat_chain(pawn)
    if not is_shotgun_weapon(chain.equipped_weapon) or chain.weapon_mesh == nil then
        -- fallback: 检查右手 gripped attachment
        local gripped = attachments.getCurrentGrippedAttachment(Handed.Right)
        if gripped ~= nil then
            local ok, name = pcall(function() return gripped:get_full_name() end)
            if ok and name and name:find(SHOTGUN_NAME_MARKER, 1, true) then
                chain.weapon_mesh = gripped
                if chain.equipped_weapon == nil then
                    chain.equipped_weapon = gripped
                end
            end
        end
    end
    if not is_shotgun_weapon(chain.equipped_weapon) and not is_shotgun_weapon(chain.weapon_mesh) then
        return nil, chain, "not shotgun"
    end
    if chain.weapon_mesh == nil then
        return nil, chain, "weapon mesh nil"
    end
    return chain.weapon_mesh, chain, nil
end

-- =============================================================================
-- 策略 C：清零 SingleActionPrepareAnimData（阻止引擎自动泵动）
-- =============================================================================

local function weapon_addr_of(weapon)
    if weapon == nil or weapon.get_address == nil then
        return nil
    end
    local ok, a = pcall(function() return weapon:get_address() end)
    if ok and type(a) == "number" then
        return a
    end
    return nil
end

local function read_qword_blob(obj, offset, size)
    if obj == nil or type(obj.read_qword) ~= "function" then
        return nil
    end
    local bytes = {}
    local n = math.floor(size / 8)
    for i = 0, n - 1 do
        local ok, q = pcall(function() return obj:read_qword(offset + i * 8) end)
        if not ok then
            return nil
        end
        bytes[#bytes + 1] = q or 0
    end
    return bytes
end

local function write_qword_blob(obj, offset, bytes)
    if obj == nil or type(obj.write_qword) ~= "function" or type(bytes) ~= "table" then
        return false
    end
    for i = 1, #bytes do
        local ok = pcall(function()
            obj:write_qword(offset + (i - 1) * 8, bytes[i] or 0)
        end)
        if not ok then
            return false
        end
    end
    return true
end

local function zero_qword_blob(obj, offset, size)
    if obj == nil or type(obj.write_qword) ~= "function" then
        return false
    end
    local n = math.floor(size / 8)
    for i = 0, n - 1 do
        local ok = pcall(function()
            obj:write_qword(offset + i * 8, 0)
        end)
        if not ok then
            return false
        end
    end
    return true
end

-- PrepareAnimData 诊断：对比当前值 vs 备份，用于判断"泵动已完成"固定值
local function diag_dump_prepare_anim_data(label)
    local weapon = resolve_shotgun_weapon()
    if weapon == nil then
        return
    end
    local cur = read_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, PREPARE_ANIM_DATA_SIZE)
    local backup = state.prepare_anim_data_backup
    local backup_bytes = backup ~= nil and backup.bytes or nil

    -- 格式化为 hex 字符串（缩略：前 4 qword + 后 4 qword）
    local function fmt_qwords(bytes)
        if bytes == nil then return "nil" end
        local parts = {}
        local n = #bytes
        local max_show = 4
        for i = 1, math.min(max_show, n) do
            parts[#parts + 1] = string.format("%016X", bytes[i] or 0)
        end
        if n > max_show * 2 then
            parts[#parts + 1] = "..."
            for i = n - max_show + 1, n do
                parts[#parts + 1] = string.format("%016X", bytes[i] or 0)
            end
        elseif n > max_show then
            for i = max_show + 1, n do
                parts[#parts + 1] = string.format("%016X", bytes[i] or 0)
            end
        end
        return table.concat(parts, " ")
    end

    -- 对比：逐 qword 差异
    local diffs = {}
    if cur ~= nil and backup_bytes ~= nil then
        for i = 1, math.min(#cur, #backup_bytes) do
            if (cur[i] or 0) ~= (backup_bytes[i] or 0) then
                diffs[#diffs + 1] = string.format("[%d] %016X→%016X", i - 1, backup_bytes[i] or 0, cur[i] or 0)
            end
        end
    end

    local clip = nil
    pcall(function()
        local off = reload_tools.WEAPON_PROFILES.shotgun
        clip = reload_tools.read_clip_ammo(weapon, off)
    end)

    print_log(string.format(
        "PREP_ANIM_DIAG [%s] clip=%s needs_pump=%s cur=%s",
        label, tostring(clip), tostring(state.needs_pump), fmt_qwords(cur)), LogLevel.Info)
    if backup_bytes ~= nil then
        print_log(string.format(
            "PREP_ANIM_DIAG [%s] backup=%s",
            label, fmt_qwords(backup_bytes)), LogLevel.Info)
    end
    if #diffs > 0 then
        print_log(string.format(
            "PREP_ANIM_DIAG [%s] DIFF vs backup: %s",
            label, table.concat(diffs, " | ")), LogLevel.Info)
    else
        print_log(string.format(
            "PREP_ANIM_DIAG [%s] SAME as backup (no diff)", label), LogLevel.Info)
    end
end

local function resolve_shotgun_weapon()
    local _, chain = get_shotgun_chain()
    local weapon = chain and chain.equipped_weapon or nil
    if weapon == nil or not is_shotgun_weapon(weapon) then
        return nil
    end
    return weapon
end

--- 开火后：备份（若无）并清零 PrepareAnimData，阻止引擎自动泵动
--- 不清零在装备时持续清：否则泵完写回后又被 tick 清掉，无法开火
local function block_prepare_anim_data(reason)
    local weapon = resolve_shotgun_weapon()
    if weapon == nil then
        return false
    end
    local wa = weapon_addr_of(weapon)

    if state.prepare_anim_data_nulled
        and state.prepare_anim_data_backup ~= nil
        and state.prepare_anim_data_backup.weapon_addr == wa then
        return true
    end

    -- 已有备份（泵完写回后再次开火）：直接清零，勿用当前（已恢复）内存当备份
    if state.prepare_anim_data_backup == nil
        or state.prepare_anim_data_backup.weapon_addr ~= wa then
        local blob = read_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, PREPARE_ANIM_DATA_SIZE)
        if blob == nil then
            print_log("prepare_anim_data block FAIL: cannot backup @+0xC68", LogLevel.Warn)
            return false
        end
        -- 诊断：打印读取到的 blob 摘要（前4个qword）
        local blob_summary = {}
        for i = 1, math.min(4, #blob) do
            blob_summary[#blob_summary + 1] = string.format("q%d=0x%016X", i - 1, blob[i] or 0)
        end
        print_log("prepare_anim_data block READ blob: " .. table.concat(blob_summary, " ")
            .. " (n=" .. #blob .. ")", LogLevel.Info)
        -- 避免把已清零状态当成备份
        local all_zero = true
        for i = 1, #blob do
            if (blob[i] or 0) ~= 0 then
                all_zero = false
                break
            end
        end
        if all_zero then
            print_log("prepare_anim_data block FAIL: field already zero, no valid backup", LogLevel.Warn)
            return false
        end
        state.prepare_anim_data_backup = { weapon_addr = wa, bytes = blob }
        print_log("prepare_anim_data backup STORED weapon=0x" .. string.format("%X", wa)
            .. " qwords=" .. #blob, LogLevel.Info)
    else
        print_log("prepare_anim_data block: backup EXISTS, skip re-read (weapon=0x"
            .. string.format("%X", wa) .. ")", LogLevel.Info)
    end

    local zero_ok = zero_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, PREPARE_ANIM_DATA_SIZE)
    if not zero_ok then
        print_log("prepare_anim_data block FAIL: cannot zero @+0xC68", LogLevel.Warn)
        return false
    end

    state.prepare_anim_data_nulled = true
    print_log("prepare_anim_data BLOCKED reason=" .. tostring(reason)
        .. " weapon=" .. (wa and string.format("0x%X", wa) or "?"), LogLevel.Info)
    return true
end

--- 写回清零前的 PrepareAnimData（泵完成 / 上弹解锁开火必需）
---@param reason string
---@param discard_backup boolean|nil  true=卸枪丢备份；false/nil=保留备份供下一发再清零
local function restore_prepare_anim_data(reason, discard_backup)
    local backup = state.prepare_anim_data_backup
    if not state.prepare_anim_data_nulled then
        if discard_backup then
            state.prepare_anim_data_backup = nil
        end
        return false
    end
    if backup == nil or type(backup.bytes) ~= "table" then
        state.prepare_anim_data_nulled = false
        state.prepare_anim_data_backup = nil
        return false
    end

    local weapon = resolve_shotgun_weapon()
    local wa = weapon_addr_of(weapon)
    local write_ok = false
    if weapon ~= nil and wa ~= nil and wa == backup.weapon_addr then
        write_ok = write_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, backup.bytes)
    else
        print_log("prepare_anim_data restore skipped (weapon gone/changed), reason="
            .. tostring(reason), LogLevel.Debug)
    end

    state.prepare_anim_data_nulled = false
    if discard_backup then
        state.prepare_anim_data_backup = nil
    end
    if write_ok then
        print_log("prepare_anim_data RESTORED reason=" .. tostring(reason)
            .. " keep_backup=" .. tostring(not discard_backup), LogLevel.Info)
    end
    return write_ok
end

--- 策略 D：写入 idle 固定值到 PrepareAnimData（前推完成时调用）
--- 覆盖 post-fire 值，让引擎认为"不需泵动"，防止空仓装弹后自动泵动
local function write_idle_prepare_anim_data(reason)
    local weapon = resolve_shotgun_weapon()
    if weapon == nil then
        print_log("write_idle_prepare_anim_data FAIL: weapon nil reason=" .. tostring(reason), LogLevel.Warn)
        return false
    end
    local write_ok = write_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, IDLE_PREPARE_ANIM_DATA)
    if write_ok then
        state.prepare_anim_data_nulled = false
        print_log("prepare_anim_data IDLE WRITTEN reason=" .. tostring(reason)
            .. " (覆盖为 idle 固定值，防止自动泵动)", LogLevel.Info)
    else
        print_log("write_idle_prepare_anim_data FAIL: cannot write @+0xC68 reason=" .. tostring(reason), LogLevel.Warn)
    end
    return write_ok
end

--- 开火成功：needs_pump + 清零 PrepareAnimData（挡自动泵）
local function mark_needs_pump(source)
    if state.needs_pump and not state.pump_completed_this_cycle then
        return
    end
    state.needs_pump = true
    state.pump_completed_this_cycle = false
    block_prepare_anim_data(source)
    print_log("needs_pump = true (" .. tostring(source) .. ")", LogLevel.Info)
end

--- 弹匣弹药变化：
---   下降且 >0 = 普通开火 → mark_needs_pump（阻止自动泵动）
---   下降到 0  = 打空仓 → 不设 needs_pump（引擎不要求拉泵），设 was_empty 标记
---   上升且 was_empty = 空仓装弹 → mark_needs_pump（要求手动拉栓）+ 清零 PrepareAnimData（阻止自动泵动）
---   上升且 !was_empty = 非空仓装弹 → 清 needs_pump + 还原 PrepareAnimData（正常链路）
---   手动拉栓完成 → was_empty=false，走正常链路
local function tick_clip_fire_watch(weapon, clip)
    if weapon == nil then
        state.last_clip_ammo = nil
        return
    end
    if type(clip) ~= "number" then
        return
    end
    local prev = state.last_clip_ammo
    if prev ~= nil and clip < prev then
        if clip == 0 then
            -- 打空仓：引擎不要求拉泵，lua也不设 needs_pump（避免拉两次）
            -- 设 was_empty 标记：后续上弹时需要手动拉栓
            state.was_empty = true
            print_log("tick_clip_fire_watch EMPTY FIRE " .. tostring(prev) .. "→0 (was_empty=true, strategy E)", LogLevel.Info)
        else
            -- 普通开火：mark_needs_pump
            print_log("tick_clip_fire_watch FIRE DETECTED " .. tostring(prev) .. "→" .. tostring(clip), LogLevel.Info)
            mark_needs_pump("clip_delta " .. tostring(prev) .. "→" .. tostring(clip))
        end
    elseif prev ~= nil and clip > prev then
        if state.was_empty then
            -- 策略E：空仓后上弹，mark_needs_pump（要求手动拉栓）
            -- mark_needs_pump 内部也会 block_prepare_anim_data，但如果 needs_pump 已为 true 会跳过
            -- 所以这里额外再 block 一次，确保每发上弹都清零 PrepareAnimData（阻止引擎自动拉泵）
            mark_needs_pump("empty_reload_" .. tostring(prev) .. "→" .. tostring(clip))
            block_prepare_anim_data("empty_reload_ensure_blocked")
            print_log("tick_clip_fire_watch EMPTY_RELOAD " .. tostring(prev) .. "→" .. tostring(clip)
                .. " (needs_pump=true + PrepareAnimData blocked, strategy E)", LogLevel.Info)
        elseif state.needs_pump then
            -- 非空仓装弹 + 有 needs_pump：清 needs_pump + 还原 PrepareAnimData（正常链路）
            state.needs_pump = false
            state.pump_completed_this_cycle = true
            restore_prepare_anim_data("clip_increase", false)
            print_log("needs_pump cleared by clip increase " .. tostring(prev) .. "→" .. tostring(clip), LogLevel.Info)
        else
            print_log("tick_clip_fire_watch clip INCREASE (no needs_pump) " .. tostring(prev) .. "→" .. tostring(clip), LogLevel.Info)
        end
    end
    state.last_clip_ammo = clip
end

-- =============================================================================
-- A 类 hook 回调入口（由 reload_hooks dispatch 调用）
-- =============================================================================

-- 判断 obj 是否为玩家霰弹枪（防 AI 武器误触）
local function is_player_shotgun(obj)
    if not uobject_valid(obj) then
        return false
    end
    return is_shotgun_equipped()
end

-- 判断是否应阻止原生换弹（强制手动装弹时为 true）
-- [Phase3 CE 2026-07-18] 暂时关闭：拦截不干净会导致角色循环尝试上弹，无法用原生换弹补弹测试。
-- 恢复手动换弹拦截时改回 true。
local BLOCK_NATIVE_RELOAD = false

local function should_block_native_reload()
    if not BLOCK_NATIVE_RELOAD then
        return false
    end
    return is_shotgun_equipped()
end

-- IsFireReady 决策（reload_hooks 透传）：
--   true     = 强制 false（needs_pump，拦开火）
--   "allow"  = 强制 true（手动泵完成，可开火）
--   false    = 放行引擎原函数
function M.on_fire_ready_check(obj)
    if not is_player_shotgun(obj) then
        return false
    end
    if state.needs_pump and not state.pump_completed_this_cycle then
        return true
    elseif state.pump_completed_this_cycle and not state.needs_pump then
        return "allow"
    end
    return false
end

-- OnOutOfAmmoPerformed hook 回调：霰弹枪不需要
-- slide_locked 由 on_tick 读 weapon:IsFireReady() 触发（覆盖 needs_pump + ammo=0）
-- dry fire 由右扳机 dry_fire_edge 路径处理；霰弹枪纯手动装弹，无引擎自动换弹要 cancel
-- reload_hooks.lua 的 install_out_of_ammo_hook dispatch 时会 type~=function 跳过

-- 强制释放 VR 瞄准状态（对齐 pistol force_release_vr_aim）
-- slide_locked 变 true 时只松 LT，防止引擎看到持续瞄准输入 → 自动换弹；保留 aimMode 1
local function force_release_vr_aim(reason)
    local env = rawget(_G, "VREnvironment")
    if type(env) ~= "table" or type(env.getEnhancer) ~= "function" then
        return
    end
    local enhancer = env:getEnhancer()
    if type(enhancer) ~= "table" then
        return
    end
    pcall(function()
        local lt = enhancer._aimPistolLtAction
        if type(lt) == "table" and type(lt.leave) == "function" then
            lt:leave()
            return
        end
        if type(enhancer._aimPistolLikeAction) == "table"
            and type(enhancer._aimPistolLikeAction.leave) == "function" then
            enhancer._aimPistolLikeAction:leave()
            enhancer._twoHandAimHold = false
        end
    end)
    _G[KEYS.aim_active] = false
    if reason ~= nil then
        print_log("[SHOTGUN_SLIDE_LOCK] VR aim released: " .. tostring(reason), LogLevel.Info)
    end
end

-- CanBeReloaded hook 回调：返回 true = 阻止原生换弹
-- [Phase3] BLOCK_NATIVE_RELOAD=false 时恒为 false，放行引擎上弹
function M.on_can_be_reloaded_check(obj)
    -- return should_block_native_reload() and is_player_shotgun(obj)
    return false
end

-- PlayRequest/PlayOrOverwriteRequest hook 回调
-- [Phase3] 换弹+泵动 SKIP 均已停用，直接放行
function M.on_play_request_check(obj, locals)
    return false
end

-- OnRangedReload hook 回调：返回 true = SKIP 原生换弹入口
-- [Phase3] 暂时放行（该 UFunction 本身也常装不上，见 sdk_notes Bug-1）
function M.on_ranged_reload_check(obj)
    -- return should_block_native_reload() and is_player_shotgun(obj)
    return false
end

-- Montage 变化回调：返回 true = Montage_Stop 换弹蒙太奇
-- [Phase3] 暂时放行，避免拦一半导致角色循环尝试上弹
function M.on_montage_change_check(montage, montageName, animInstance)
    return false
end

-- RequestManualFire post hook：开火成功 → needs_pump（若 hook 不触发，由 tick_clip_fire_watch 兜底）
function M.on_fire_success(ranged_subcomp)
    if not is_shotgun_equipped() then
        return
    end
    mark_needs_pump("RequestManualFire")
end

-- OnRangedSingleActionPrepareEnd post hook
-- 策略 C 下开火后引擎通常不应再走到这里；complete_pump 主动调用时 needs_pump 已清，属预期。
function M.on_single_action_prepare_end(montage, endType)
    if not is_shotgun_equipped() then
        return
    end
    if not state.needs_pump then
        -- complete_pump / 上弹后的预期回调
        return
    end
    -- 仍 needs_pump 却收到 PrepareEnd：引擎自动泵动泄漏
    print_log("PrepareEnd while needs_pump (strategy C leak?) endType=" .. tostring(endType), LogLevel.Warn)
end

-- =============================================================================
-- B 类附件 hook 回调入口（由 reload_hooks dispatch 调用）
-- =============================================================================

-- 按 hands_type 选左手 mesh（武器/手电筒附着用）。IKArms 时是整臂骨骼 mesh。
local function resolve_left_hand_component()
    local hands_type = configui.getValue("hands_type") or HandsType.None
    if hands_type == HandsType.None then
        return controllers.getController(Handed.Left)
    elseif hands_type == HandsType.Forearms then
        return hands.getHandComponent(Handed.Left)
    elseif hands_type == HandsType.IKArms then
        local ok_ik, ik_mod = pcall(require, "libs/ik")
        if ok_ik and ik_mod and ik_mod.getCurrentMesh then
            return ik_mod.getCurrentMesh()
        end
    end
    return controllers.getController(Handed.Left)
end

-- 弹药模型必须跟 VR 左手控制器，不能挂 IK/Forearms mesh：
-- hands_type=IKArms 时 getCurrentMesh() 的 hand_l_bn 实测与控制器可差很远
-- （日志 spawn≈-21600，视觉上子弹飞到远处）。手枪 Phase2 成功路径是 attachToController。
local function resolve_shell_hand_parent()
    local mc = controllers.getController(Handed.Left)
    if mc == nil then
        pcall(function()
            controllers.createController(Handed.Left)
        end)
        mc = controllers.getController(Handed.Left)
    end
    return mc
end

-- 左手弹药 spawn/跟随：优先 MotionController 世界变换（与 attachToController 同源）
local function get_shell_hand_world_transform()
    local left_comp = resolve_shell_hand_parent()
    if left_comp == nil then
        return nil, nil, nil, "motion_controller_nil", nil
    end
    local loc = reload_tools.get_component_world_location(left_comp)
        or controllers.getControllerLocation(Handed.Left)
    local rot = reload_tools.get_component_world_rotation(left_comp)
        or controllers.getControllerRotation(Handed.Left)
    if loc == nil then
        return nil, nil, left_comp, "motion_controller_no_location", nil
    end
    return loc, rot, left_comp, nil, "motion_controller"
end

--- bone_magazine + 用户语义偏移 → 世界坐标
--- forward/down/right 含义同 SHELL_INSERT_OFFSET 注释
---@param mesh userdata
---@param offset table|nil {forward,down,right}
---@return string|nil socket_name
---@return table|nil world_loc {X,Y,Z}
local function get_shell_socket_offset_world_location(mesh, offset)
    if mesh == nil then
        return nil, nil
    end
    local base = reload_tools.get_socket_world_location(mesh, SHELL_INSERT_SOCKET)
    if base == nil then
        return nil, nil
    end
    offset = offset or {}
    local rot = nil
    pcall(function()
        if mesh.GetSocketRotation ~= nil then
            rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(SHELL_INSERT_SOCKET))
        end
    end)
    local dx, dy, dz = 0, 0, 0
    if rot ~= nil then
        -- 用户语义 → UE 底层映射（实测：X=往下，Y=向后，Z=向左）
        dx, dy, dz = reload_tools.local_offset_to_world_delta(
            rot,
            offset.down or 0,              -- UE local_forward (X轴=往下)
            -(offset.forward or 0),        -- UE local_right  (Y轴=向后，往前取负)
            offset.right or 0              -- UE local_down   (Z轴=向左)
        )
    else
        dy = -(offset.forward or 0)
        dz = -(offset.down or 0)
    end
    return SHELL_INSERT_SOCKET, {
        X = (base.X or 0) + dx,
        Y = (base.Y or 0) + dy,
        Z = (base.Z or 0) + dz,
    }
end

--- 装弹口世界坐标（proximity / 滑入终点）
---@return string|nil socket_name
---@return table|nil world_loc {X,Y,Z}
local function get_shell_insert_world_location(mesh)
    return get_shell_socket_offset_world_location(mesh, SHELL_INSERT_OFFSET)
end

--- 滑入动画固定起点：与终点同一 forward/right，只在 down 方向再退开
--- 保证路径落在枪底竖直面内，不因左右手位或 right 符号相反而斜穿枪身
---@return string|nil socket_name
---@return table|nil world_loc
local function get_shell_slide_start_world_location(mesh)
    local start_offset = {
        forward = SHELL_INSERT_OFFSET.forward or 0,
        right = SHELL_INSERT_OFFSET.right or 0,
        down = (SHELL_INSERT_OFFSET.down or 0) + (SHELL_SLIDE_APPROACH_DOWN or 0),
    }
    return get_shell_socket_offset_world_location(mesh, start_offset)
end

--- 滑入目标：同装弹口（含前移偏移）
---@return string|nil socket_name
---@return table|nil world_loc
local function resolve_shell_insert_socket(mesh)
    return get_shell_insert_world_location(mesh)
end

--- bone_magazine 世界旋转（入膛朝向基准）
---@return table|nil Rotator
local function get_shell_insert_socket_rotation(mesh)
    if mesh == nil then
        return nil
    end
    local rot = nil
    pcall(function()
        if mesh.GetSocketRotation ~= nil then
            rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(SHELL_INSERT_SOCKET))
        end
    end)
    if rot == nil then
        rot = reload_tools.get_component_world_rotation(mesh)
    end
    return rot
end

--- Rotator → start_slide 用的 {Pitch,Yaw,Roll} 表
local rotator_to_slide_table = reload_tools.rotator_to_slide_table

-- 2026-07-31：私有 compose_local_rot_offset 已下沉为 reload_tools.compose_local_rot_offset 公共工具
-- （reload_tools.lua:2504），此处改为别名引用，与 rifle_reload.lua 对齐
local compose_local_rot_offset = reload_tools.compose_local_rot_offset

--- 构造统一的滑入起止旋转（相对 bone_magazine，不跟手）
--- start / end 各自相对 socket 独立 compose；参数相同则朝向相同、滑入不旋转
---@return table|nil start_rot
---@return table|nil end_rot
local function build_shell_slide_rotations(mesh)
    local socket_rot = get_shell_insert_socket_rotation(mesh)
    if socket_rot == nil then
        return nil, nil
    end

    -- 注意：START 不得叠在 END 上，否则两组数值相同时仍会转一整段
    local end_rot = compose_local_rot_offset(socket_rot, SHELL_SLIDE_END_ROT_OFFSET)
    local start_rot = compose_local_rot_offset(socket_rot, SHELL_SLIDE_START_TILT)
    if end_rot == nil then
        end_rot = socket_rot
    end
    if start_rot == nil then
        start_rot = end_rot
    end

    return rotator_to_slide_table(start_rot), rotator_to_slide_table(end_rot)
end

--- 起止欧拉角几乎相同则不做旋转插值（只锁朝向 + 直线位移）
local function shell_slide_rots_equal(a, b)
    if a == nil or b == nil then
        return false
    end
    local eps = 0.05
    return math.abs((a.Pitch or 0) - (b.Pitch or 0)) < eps
        and math.abs((a.Yaw or 0) - (b.Yaw or 0)) < eps
        and math.abs((a.Roll or 0) - (b.Roll or 0)) < eps
end

-- 左手持弹姿势 on：shotgun_shell_insert
local function apply_left_hand_shell_pose()
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, "shotgun_shell_insert")
    end)
end

-- 左手持弹姿势 off：
-- setHoldingAttachment(nil) 会回退到 attachments.getCurrentGripAnimation，
-- 若仍缓存 shotgun_shell_insert 会继续半握。传 false 强制走 open（与 detach 后 activeGripAnimations=false 一致）
local function clear_left_hand_shell_pose()
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, false)
    end)
    -- 再清一遍 attachments 侧动画缓存，防止下一帧又写回握姿
    pcall(function()
        if attachments.setActiveAnimation ~= nil then
            attachments.setActiveAnimation(nil, Handed.Left)
        end
    end)
    print("[SHOTGUN_RELOAD] pose=off → false (force open)")
end

-- 读取左手持弹偏移参数（Phase 2.1：参数化支持 shell_1 / shell_2）
-- 不传参 = shell_1（默认）；传 SHELL_LEFT_HAND_ATTACHMENT_ID_2, SHELL_CONFIG_PREFIX_2 = shell_2
local function load_shotgun_shell_params(attachment_id, config_prefix)
    attachment_id = attachment_id or SHELL_LEFT_HAND_ATTACHMENT_ID
    config_prefix = config_prefix or SHELL_CONFIG_PREFIX
    local loc = configui.getValue(config_prefix .. "position")
    local rot = configui.getValue(config_prefix .. "rotation")
    local scale = configui.getValue(config_prefix .. "scale")
    if loc ~= nil and rot ~= nil then
        return {
            location = loc,
            rotation = rot,
            scale = scale or { 1.0, 1.0, 1.0 },
        }
    end
    local defaults = {
        location = { 0.0, 0.0, 0.0 },
        rotation = { 0.0, 0.0, 0.0 },
        scale = { 1.0, 1.0, 1.0 },
    }
    local params = json.load_file("attachments_parameters.json")
    if params ~= nil and params.attachmentOffsets ~= nil then
        for i = 1, #params.attachmentOffsets do
            local entry = params.attachmentOffsets[i]
            if entry ~= nil and entry.id == attachment_id then
                return entry
            end
        end
    end
    return defaults
end

-- 应用左手持弹偏移到 component（Phase 2.1：参数化支持 shell_1 / shell_2）
local function apply_shotgun_shell_transform(comp, attachment_id, config_prefix)
    if comp == nil then
        return
    end
    local params = load_shotgun_shell_params(attachment_id, config_prefix)
    local loc = params.location or { 0, 0, 0 }
    local rot = params.rotation or { 0, 0, 0 }
    local scale = params.scale or { 1, 1, 1 }
    pcall(function()
        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(loc))
        uevrUtils.set_component_relative_rotation(comp, uevrUtils.rotator(rot))
        uevrUtils.set_component_relative_scale(comp, uevrUtils.vector(scale))
    end)
end

local function is_left_hand_shell_component(comp)
    if state.shells_in_hand ~= true then
        return false
    end
    local shells = uevrUtils.getValid(state.shells_component)
    local other = uevrUtils.getValid(comp)
    return shells ~= nil and other ~= nil and shells == other
end

-- grip update 合并：左手持弹时挂到 MotionController（与 spawn/attach 同源，勿挂 IK mesh）
-- Phase 2.1：shell_1 优先，shell_1 为 nil 时回退 shell_2（shell_1 入膛后 shell_2 仍持弹）
function M.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
    if state.shells_in_hand ~= true then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    if uevrUtils.isInCutscene and uevrUtils.isInCutscene() then
        return rA, rM, rS, nil, nil, nil, oR, oL
    end
    -- shell_1 优先；shell_1 为 nil 时回退 shell_2
    local shells = uevrUtils.getValid(state.shells_component)
    if shells == nil and state.shells_component2 ~= nil then
        shells = uevrUtils.getValid(state.shells_component2)
    end
    if shells == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    local left_comp = resolve_shell_hand_parent()
    if left_comp == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    -- MotionController 无 hand_l_bn socket，传 nil 挂到控制器根
    return rA, rM, rS, shells, left_comp, nil, oR, shellAttachOptions
end

-- initAttachment：应用 shotgun_shells 偏移 + 持弹姿势
-- Phase 2.1：shell_1 和 shell_2 都需应用各自的 json 偏移
-- shell_2 post-lerp（proximity_enabled 或 doomed）：应用 shell_1 的偏移（lerp 终点位置）
-- shell_2 pre-lerp：应用 shell_2 自己的偏移
function M.on_init_attachment(attachment, gripHand, options)
    if gripHand ~= Handed.Left then
        return
    end
    -- 判断是 shell_1 还是 shell_2，应用对应偏移
    local comp1 = uevrUtils.getValid(state.shells_component)
    local comp2 = uevrUtils.getValid(state.shells_component2)
    local att = uevrUtils.getValid(attachment)
    if comp1 ~= nil and att ~= nil and comp1 == att then
        apply_shotgun_shell_transform(attachment)
        apply_left_hand_shell_pose()
    elseif comp2 ~= nil and att ~= nil and comp2 == att then
        if state.shell2_proximity_enabled or state.shell2_doomed then
            -- post-lerp：应用 shell_1 的偏移（保持 lerp 终点位置）
            apply_shotgun_shell_transform(attachment,
                SHELL_LEFT_HAND_ATTACHMENT_ID, SHELL_CONFIG_PREFIX)
        else
            -- pre-lerp：应用 shell_2 自己的偏移
            apply_shotgun_shell_transform(attachment,
                SHELL_LEFT_HAND_ATTACHMENT_ID_2, SHELL_CONFIG_PREFIX_2)
        end
        apply_left_hand_shell_pose()
    end
end

-- =============================================================================
-- Phase 3.5: PoseableMesh 隔离（护木视觉隔离）
-- =============================================================================

-- 从 weapon_mesh 的 bone_forearm socket 旋转提取枪体后方向单位向量
local function get_pump_backward_axis(weapon_mesh)
    if weapon_mesh == nil or weapon_mesh.GetSocketRotation == nil then
        return nil
    end
    local socket_rot = nil
    pcall(function()
        socket_rot = weapon_mesh:GetSocketRotation(uevrUtils.fname_from_string(PUMP_BONE_NAME))
    end)
    if socket_rot == nil then
        socket_rot = reload_tools.get_component_world_rotation(weapon_mesh)
    end
    if socket_rot == nil then
        return nil
    end
    local forward = uevrUtils.getForwardVector(socket_rot)
    if forward == nil then
        return nil
    end
    return { X = -(forward.X or 0), Y = -(forward.Y or 0), Z = -(forward.Z or 0) }
end

-- 护木隔离：所有骨骼 scale=1.0，仅用 HideBoneByName 隐藏兄弟骨骼
-- 祖先/目标/子孙均 scale=1 且不 Hide，只有兄弟骨骼用 HideBoneByName 隐藏
local BONE_SCALE_HIDDEN = 0.001  -- 保留常量但不再使用
local bone_space_component = reload_tools.bone_space_component
local bone_name_to_string = reload_tools.bone_name_to_string
local read_bone_scale = reload_tools.read_bone_scale

-- 骨骼隔离缓存：缓存 BoneIsChildOf 查询结果，避免每次 spawn 表演件时重复遍历
-- 骨骼层级不会变，缓存到游戏结束无需清理
-- 格式: { [bone_str] = "target"|"ancestor"|"sibling"|"descendant" }
local bone_isolation_cache = {}

--- 获取骨骼隔离缓存键（用 SkeletalMesh 资产名 + 目标骨骼名，保证同一 mesh 复用缓存）
local function get_bone_isolation_cache_key(mesh_comp, target_bone_name)
    local ok, name = pcall(function()
        local sk = mesh_comp.SkeletalMesh
        if sk ~= nil then
            return sk:get_full_name() .. "|" .. target_bone_name
        end
        return mesh_comp:get_full_name() .. "|" .. target_bone_name
    end)
    return ok and name or nil
end

local function show_only_bone(mesh_comp, bone_name)
    if mesh_comp == nil or mesh_comp.GetNumBones == nil then
        return false
    end
    local bone_space = bone_space_component()
    local scale_hidden = uevrUtils.vector(BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN)
    local keep_fname = uevrUtils.fname_from_string(bone_name)
    local count = -1
    pcall(function() count = mesh_comp:GetNumBones() end)

    -- 查找或构建缓存
    local cache_key = get_bone_isolation_cache_key(mesh_comp, bone_name)
    local iso_map = cache_key and bone_isolation_cache[cache_key] or nil

    -- 第一次时构建缓存并输出诊断
    if iso_map == nil and count > 0 and mesh_comp.GetBoneName ~= nil and mesh_comp.BoneIsChildOf ~= nil then
        iso_map = {}
        for i = 0, count - 1 do
            local bn = mesh_comp:GetBoneName(i)
            local bstr = bone_name_to_string(bn) or "?"
            if bstr == bone_name then
                iso_map[bstr] = "target"
            else
                local is_ancestor, is_descendant = false, false
                pcall(function() is_ancestor = mesh_comp:BoneIsChildOf(keep_fname, bn) end)
                pcall(function() is_descendant = mesh_comp:BoneIsChildOf(bn, keep_fname) end)
                if is_ancestor then
                    iso_map[bstr] = "ancestor"
                elseif is_descendant then
                    iso_map[bstr] = "descendant"
                else
                    iso_map[bstr] = "sibling"
                end
            end
        end
        if cache_key ~= nil then
            bone_isolation_cache[cache_key] = iso_map
        end
    end

    local ok = pcall(function()
        -- 策略（参照 pistol）：先全缩0.001，再恢复目标为 TARGET_SCALE
        -- 祖先保持0.001（避免巨大护木），兄弟/子孙已是0.001
        local TARGET_SCALE = 0.1  -- 可调：越小护木越小
        local scale_target = uevrUtils.vector(TARGET_SCALE, TARGET_SCALE, TARGET_SCALE)
        if mesh_comp.SetBoneScaleByName ~= nil then
            -- 先缩全部到0.001
            for i = 0, count - 1 do
                mesh_comp:SetBoneScaleByName(mesh_comp:GetBoneName(i), scale_hidden, bone_space)
            end
            -- 恢复目标骨骼为 TARGET_SCALE
            if iso_map ~= nil then
                -- 使用缓存
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if iso_map[bone_str] == "target" then
                        mesh_comp:SetBoneScaleByName(bone_fname, scale_target, bone_space)
                    end
                end
            else
                -- 无缓存时退化为直接匹配
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if bone_str == bone_name then
                        mesh_comp:SetBoneScaleByName(bone_fname, scale_target, bone_space)
                    end
                end
            end
        end
        -- HideBoneByName：对非目标/非祖先骨骼
        if mesh_comp.HideBoneByName ~= nil then
            if iso_map ~= nil then
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    local role = iso_map[bone_str]
                    if role == "sibling" or role == "descendant" then
                        mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                    end
                end
            else
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if bone_str ~= bone_name then
                        mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                    end
                end
            end
        end
    end)

    -- 验证关键骨 scale
    local s_holder = read_bone_scale(mesh_comp, "Holder", bone_space)
    local s_root = read_bone_scale(mesh_comp, "bone_root", bone_space)
    local s_forearm = read_bone_scale(mesh_comp, bone_name, bone_space)
    return ok
end

-- 对齐 PoseableMesh 护木到原 mesh — 已下沉到 reload_tools.align_poseable_socket
local function align_poseable_pump_bone(poseable, weapon_mesh, bone_name)
    return reload_tools.align_poseable_socket(poseable, weapon_mesh, bone_name)
end

local prepare_spawned_actor_visible = reload_tools.prepare_spawned_actor_visible

-- 隐藏/恢复装弹口骨骼（参照 pistol_reload hide_magazine_bone / show_magazine_bone）
local function hide_loading_gate(mesh)
    if LOADING_GATE_BONE == nil or LOADING_GATE_BONE == "" then
        return false
    end
    if mesh == nil then
        mesh = select(1, get_shotgun_chain())
    end
    if mesh == nil then
        return false
    end
    local ok, err = pcall(function()
        if mesh.HideBoneByName == nil then
            error("HideBoneByName missing")
        end
        mesh:HideBoneByName(uevrUtils.fname_from_string(LOADING_GATE_BONE), HIDE_BONE_PHYS_BODY)
    end)
    if ok then
        state.loading_gate_hidden = true
        print("[SHOTGUN_RELOAD] loading_gate HideBoneByName(" .. LOADING_GATE_BONE .. ")")
        return true
    end
    print("[SHOTGUN_RELOAD] loading_gate HideBoneByName failed: " .. tostring(err))
    return false
end

local function show_loading_gate(mesh)
    if not state.loading_gate_hidden then
        return false
    end
    if LOADING_GATE_BONE == nil or LOADING_GATE_BONE == "" then
        state.loading_gate_hidden = false
        return false
    end
    if mesh == nil then
        mesh = select(1, get_shotgun_chain())
    end
    if mesh == nil then
        state.loading_gate_hidden = false
        return false
    end
    local ok, err = pcall(function()
        if mesh.UnHideBoneByName == nil then
            error("UnHideBoneByName missing")
        end
        mesh:UnHideBoneByName(uevrUtils.fname_from_string(LOADING_GATE_BONE))
    end)
    if ok then
        state.loading_gate_hidden = false
        print("[SHOTGUN_RELOAD] loading_gate UnHideBoneByName(" .. LOADING_GATE_BONE .. ")")
        return true
    end
    state.loading_gate_hidden = false
    print("[SHOTGUN_RELOAD] loading_gate UnHideBoneByName failed: " .. tostring(err))
    return false
end

-- 隐藏真枪的 bone_forearm（避免与 PoseableMesh 重叠）
local function hide_pump_bone(mesh)
    if mesh == nil or mesh.HideBoneByName == nil then
        return false
    end
    pcall(function()
        mesh:HideBoneByName(uevrUtils.fname_from_string(PUMP_BONE_NAME), 0)
    end)
    state.pump_bone_hidden = true
    return true
end

-- 恢复真枪 bone_forearm 显示
local function show_pump_bone(mesh)
    if mesh == nil or mesh.UnHideBoneByName == nil then
        return false
    end
    pcall(function()
        mesh:UnHideBoneByName(uevrUtils.fname_from_string(PUMP_BONE_NAME))
    end)
    state.pump_bone_hidden = false
    return true
end

-- 同步真枪世界变换到 PoseableMesh（参照 pistol copy_component_world_transform）
-- 统一命名：原 copy_weapon_world_transform 已下沉到 reload_tools.copy_component_world_transform
local copy_weapon_world_transform = reload_tools.copy_component_world_transform

-- 设置 PoseableMesh 渲染标志 — 已下沉到 reload_tools.apply_poseable_render_flags
local apply_poseable_render_flags = reload_tools.apply_poseable_render_flags

-- 临时：表演护木只作手部挂点/位移载体，整件隐藏（避免骨骼隔离放大成巨木）——已弃用，不再隐藏
--[[
local function hide_pump_poseable_visual(poseable, actor)
    pcall(function()
        if poseable ~= nil then
            if poseable.SetVisibility ~= nil then
                poseable:SetVisibility(false, true)
            end
            if poseable.SetHiddenInGame ~= nil then
                poseable:SetHiddenInGame(true, true)
            end
        end
    end)
    pcall(function()
        if actor ~= nil then
            if actor.SetActorHiddenInGame ~= nil then
                actor:SetActorHiddenInGame(true)
            end
            local root = actor.RootComponent
            if root ~= nil then
                if root.SetVisibility ~= nil then
                    root:SetVisibility(false, true)
                end
                if root.SetHiddenInGame ~= nil then
                    root:SetHiddenInGame(true, true)
                end
            end
        end
    end)
end
--]]

local function pump_poseable_is_valid()
    return uevrUtils.getValid(pump_visual.poseable_mesh) ~= nil
        and uevrUtils.getValid(pump_visual.poseable_actor) ~= nil
end

local function clear_stale_pump_poseable_refs()
    local mesh_dead = pump_visual.poseable_mesh ~= nil and uevrUtils.getValid(pump_visual.poseable_mesh) == nil
    local actor_dead = pump_visual.poseable_actor ~= nil and uevrUtils.getValid(pump_visual.poseable_actor) == nil
    if mesh_dead or actor_dead then
        pump_visual.poseable_mesh = nil
        pump_visual.poseable_actor = nil
        state.pump_poseable = nil
        state.pump_poseable_actor = nil
        rawset(_G, "__sh2_pump_hand_parent", nil)
    end
end

local function set_pump_hand_parent(poseable)
    rawset(_G, "__sh2_pump_hand_parent", poseable)
end

local function clear_pump_hand_parent()
    rawset(_G, "__sh2_pump_hand_parent", nil)
end

-- attachHandToAccessory 会同步回调 on_accessory_animation→begin_pump→spawn，必须防重入
-- 卡顿根因：hide_pump_bone → detach → attach → animation → begin → spawn → hide… 同帧循环
local pump_attach_busy = false
local pump_begin_busy = false
local pump_spawn_busy = false

local function pump_callback_locked()
    return pump_attach_busy or pump_begin_busy or pump_spawn_busy
end

--- 藏真枪护木后左手改挂表演件（对齐 pistol attach_left_hand_to_performance_slide）
--- do_reattach=false 时只设挂点；true 时最多调用一次 attachHandToAccessory
local function attach_left_hand_to_performance_pump(do_reattach)
    local poseable = uevrUtils.getValid(pump_visual.poseable_mesh)
    if poseable == nil then
        return false
    end
    set_pump_hand_parent(poseable)
    -- 表演护木优先使用 pump_perf_marker_uuid，不存在时降级用本体 UUID
    local attach_uuid = pump_perf_marker_uuid or pump_marker_uuid
    if do_reattach ~= true or pump_attach_busy or attach_uuid == nil then
        return true
    end
    -- 已握护木或 grip 按下时改挂（leftGrip 为 float，勿用 == true）
    local should_attach = state.pump_offhand_gripping == true
    if not should_attach then
        local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
        should_attach = left_grip == true or (type(left_grip) == "number" and left_grip > 0.5)
    end
    if not should_attach then
        return true
    end
    pump_attach_busy = true
    state.pump_offhand_gripping = true
    local ok, err = pcall(function()
        accessories.attachHandToAccessory(Handed.Left, attach_uuid, false)
    end)
    pump_attach_busy = false
    return true
end

-- 左手改挂回真枪 bone_forearm（清 poseable 覆盖后 attach；useMontageProximity=false 避免原生动画拆挂）
local function reattach_left_hand_to_real_pump(reason)
    clear_pump_hand_parent()
    if pump_marker_uuid == nil or pump_attach_busy then
        return false
    end
    local should_attach = state.pump_offhand_gripping == true
    if not should_attach then
        local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
        should_attach = left_grip == true or (type(left_grip) == "number" and left_grip > 0.5)
    end
    if not should_attach then
        return false
    end
    pump_attach_busy = true
    state.pump_offhand_gripping = true
    local ok, err = pcall(function()
        accessories.attachHandToAccessory(Handed.Left, pump_marker_uuid, false)
    end)
    pump_attach_busy = false
    return ok
end

local function sock_delta_cm(weapon_mesh, poseable)
    local w = reload_tools.get_socket_world_location(weapon_mesh, PUMP_BONE_NAME)
    local p = reload_tools.get_socket_world_location(poseable, PUMP_BONE_NAME)
    if w == nil or p == nil then
        return nil
    end
    local dx = (w.X or 0) - (p.X or 0)
    local dy = (w.Y or 0) - (p.Y or 0)
    local dz = (w.Z or 0) - (p.Z or 0)
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function poseable_visibility_snapshot(poseable, actor)
    local hidden = nil
    local vis = nil
    pcall(function()
        if actor ~= nil and actor.bHidden ~= nil then
            hidden = actor.bHidden
        end
    end)
    pcall(function()
        if poseable ~= nil and poseable.bVisible ~= nil then
            vis = poseable.bVisible
        elseif poseable ~= nil and poseable.IsVisible ~= nil then
            vis = poseable:IsVisible()
        end
    end)
    local addr_a, addr_m = nil, nil
    pcall(function()
        if actor ~= nil and actor.get_address ~= nil then
            addr_a = string.format("0x%X", actor:get_address())
        end
    end)
    pcall(function()
        if poseable ~= nil and poseable.get_address ~= nil then
            addr_m = string.format("0x%X", poseable:get_address())
        end
    end)
    return {
        actor_hidden = hidden,
        mesh_visible = vis,
        actor_addr = addr_a,
        mesh_addr = addr_m,
    }
end

-- 更新 PoseableMesh：对齐 pistol update_slide_poseable_position（根变换同步 + 世界偏移，不用 SetBoneLocation）
local function update_pump_poseable_position(weapon_mesh, progress)
    local poseable = uevrUtils.getValid(pump_visual.poseable_mesh)
    if weapon_mesh == nil or poseable == nil then
        return
    end
    copy_weapon_world_transform(weapon_mesh, poseable)

    -- BLOCKER-1: 表演护木生成时已冻结锚点，用冻结值重投影；不再读被原生动画驱动的实时 bone_forearm
    local weapon_rest_world, axis_world
    local frozen = state.pump_anchor_frozen
    if frozen ~= nil then
        -- 用当前枪根把冻结的局部锚点重新投影到世界空间
        local root_now = nil
        pcall(function()
            if weapon_mesh.K2_GetComponentToWorld ~= nil then
                root_now = weapon_mesh:K2_GetComponentToWorld()
            end
        end)
        if root_now ~= nil then
            -- baseWorld = RootNow * ForearmLocal0
            local base_tf = nil
            pcall(function()
                if kismet_math_library ~= nil and kismet_math_library.ComposeTransforms ~= nil then
                    base_tf = kismet_math_library:ComposeTransforms(frozen.forearm_local, root_now)
                end
            end)
            if base_tf ~= nil and base_tf.Translation ~= nil then
                weapon_rest_world = {
                    X = base_tf.Translation.X or 0,
                    Y = base_tf.Translation.Y or 0,
                    Z = base_tf.Translation.Z or 0,
                }
            end
            -- axisWorld = RootNow.TransformVector(AxisLocal0)（用 TransformVector 保留缩放，fallback TransformDirection）
            pcall(function()
                if kismet_math_library ~= nil then
                    if kismet_math_library.TransformVector ~= nil then
                        axis_world = kismet_math_library:TransformVector(root_now, frozen.axis_local)
                    elseif kismet_math_library.TransformDirection ~= nil then
                        axis_world = kismet_math_library:TransformDirection(root_now, frozen.axis_local)
                    end
                end
            end)
        end
        if weapon_rest_world == nil or axis_world == nil then
            -- kismet_math_library 不可用时 fallback 到旧逻辑
            weapon_rest_world = reload_tools.get_socket_world_location(weapon_mesh, PUMP_BONE_NAME)
            axis_world = get_pump_backward_axis(weapon_mesh)
        end
    else
        -- 正常泵动阶段（pull_done 之前）：读实时数据
        weapon_rest_world = reload_tools.get_socket_world_location(weapon_mesh, PUMP_BONE_NAME)
        axis_world = get_pump_backward_axis(weapon_mesh)
    end

    local poseable_bone_world = reload_tools.get_socket_world_location(poseable, PUMP_BONE_NAME)
    if weapon_rest_world == nil or poseable_bone_world == nil or axis_world == nil then
        return
    end

    local target_world = reload_tools.calc_slide_bone_offset(
        weapon_rest_world, axis_world, progress, PUMP_BONE_MAX_DISTANCE)

    local dx, dy, dz = 0, 0, 0
    if poseable.K2_AddWorldOffset ~= nil then
        dx = target_world.X - poseable_bone_world.X
        dy = target_world.Y - poseable_bone_world.Y
        dz = target_world.Z - poseable_bone_world.Z
        pcall(function()
            poseable:K2_AddWorldOffset(
                uevrUtils.vector(dx, dy, dz), false, reusable_hit_result, false)
        end)
    end
end

-- Spawn PoseableMesh（对齐 pistol spawn_slide_poseable）
-- 顺序：生成表演件 → show_only(恢复目标骨 scale=1) → align → 再藏本体
---@param weapon_mesh userdata
---@return boolean
local function spawn_pump_poseable(weapon_mesh)
    -- 重入：hide→detach→begin→spawn 同帧循环时直接返回已有结果
    if pump_spawn_busy then
        return pump_poseable_is_valid()
    end
    weapon_mesh = uevrUtils.getValid(weapon_mesh)
    if weapon_mesh == nil then
        return false
    end

    pump_spawn_busy = true
    local ok_body, result = pcall(function()
        clear_stale_pump_poseable_refs()
        if pump_poseable_is_valid() then
            local progress = 0
            if state.pump_active and state.pump_rack ~= nil then
                progress = state.pump_rack.pull_progress or 0
            end
            update_pump_poseable_position(weapon_mesh, progress)
            local dist = sock_delta_cm(weapon_mesh, pump_visual.poseable_mesh)
            if dist ~= nil and dist > 40.0 then
                pcall(function()
                    if pump_visual.poseable_actor ~= nil then
                        uevrUtils.destroy_actor(pump_visual.poseable_actor)
                    end
                end)
                pump_visual.poseable_actor = nil
                pump_visual.poseable_mesh = nil
                state.pump_poseable_actor = nil
                state.pump_poseable = nil
                clear_pump_hand_parent()
            else
                if not state.pump_bone_hidden then
                    hide_pump_bone(weapon_mesh)
                end
                --hide_pump_poseable_visual(pump_visual.poseable_mesh, pump_visual.poseable_actor)
                -- spawn_busy 期间回调不会再进 begin/spawn；此处只挂一次手
                attach_left_hand_to_performance_pump(true)
                local snap = poseable_visibility_snapshot(pump_visual.poseable_mesh, pump_visual.poseable_actor)
                return true
            end
        end

        local sk_asset = nil
        pcall(function() sk_asset = weapon_mesh.SkeletalMesh end)
        if sk_asset == nil or uevrUtils.getValid(sk_asset) == nil then
            print_log("spawn_pump_poseable: SkeletalMesh asset nil", LogLevel.Warn)
            return false
        end

        local socket_loc = reload_tools.get_socket_world_location(weapon_mesh, PUMP_BONE_NAME)
        if socket_loc == nil then
            print_log("spawn_pump_poseable: no bone_forearm socket location", LogLevel.Warn)
            return false
        end
        local socket_rot = nil
        pcall(function()
            socket_rot = weapon_mesh:GetSocketRotation(uevrUtils.fname_from_string(PUMP_BONE_NAME))
        end)
        if socket_rot == nil then
            socket_rot = reload_tools.get_component_world_rotation(weapon_mesh)
        end

        local w_before = read_component_world_snapshot(weapon_mesh)

        local actor = uevrUtils.spawn_actor(
            reload_tools.make_spawn_transform(socket_loc, socket_rot), 1, nil)
        if actor == nil then
            print_log("spawn_pump_poseable: spawn_actor failed", LogLevel.Warn)
            return false
        end

        local poseable = nil
        local ok_create = pcall(function()
            poseable = uevrUtils.createPoseableMeshFromSkeletalMesh(weapon_mesh, {
                manualAttachment = true,
                relativeTransform = reload_tools.make_spawn_transform(socket_loc, socket_rot),
                deferredFinish = false,
                parent = actor,
            })
        end)
        if not ok_create or poseable == nil or uevrUtils.getValid(poseable) == nil then
            uevrUtils.destroy_actor(actor)
            print_log("spawn_pump_poseable: createPoseableMesh failed", LogLevel.Warn)
            return false
        end

        pcall(function()
            if poseable.SetMobility ~= nil then
                poseable:SetMobility(2)
            end
            if actor.K2_SetRootComponent ~= nil then
                actor:K2_SetRootComponent(poseable)
            end
        end)
        local copy_ok = copy_weapon_world_transform(weapon_mesh, poseable)

        -- 骨骼隔离：show_only_bone 缩放+HideBone，然后对齐修正位置
        pcall(function()
            uevrUtils.copyMaterials(weapon_mesh, poseable)
        end)
        align_poseable_pump_bone(poseable, weapon_mesh, PUMP_BONE_NAME)
        show_only_bone(poseable, PUMP_BONE_NAME)
        --hide_pump_poseable_visual(poseable, actor)
        prepare_spawned_actor_visible(actor)
        apply_poseable_render_flags(poseable)

        pump_visual.poseable_actor = actor
        pump_visual.poseable_mesh = poseable
        state.pump_poseable_actor = actor
        state.pump_poseable = poseable
        -- 先只设挂点；hide 真骨可能同步触发 detach，spawn_busy 会挡住回调里的 begin/spawn
        set_pump_hand_parent(poseable)
        local hide_ok = hide_pump_bone(weapon_mesh)
        -- hide 回调结束后再挂一次手（整段仍在 spawn_busy 内，animation 不会再 begin）
        attach_left_hand_to_performance_pump(true)
        local snap = poseable_visibility_snapshot(poseable, actor)
        print_log("spawn_pump_poseable: hidden poseable ready (hand attach), hid real bone_forearm", LogLevel.Info)
        return true
    end)
    pump_spawn_busy = false
    if not ok_body then
        return false
    end
    return result == true
end

-- BLOCKER-1: 表演护木生成时冻结锚点（提前到生成帧，整轮泵动统一使用）
-- 在 ensure_pump_poseable_ready / begin_pump 中 spawn 后调用
local function freeze_pump_anchor(mesh)
    if state.pump_anchor_frozen ~= nil then
        return  -- 已冻结，不重复拍
    end
    if mesh == nil then
        return
    end
    local root_tf = nil
    pcall(function()
        if mesh.K2_GetComponentToWorld ~= nil then
            root_tf = mesh:K2_GetComponentToWorld()
        end
    end)
    local forearm_world = reload_tools.get_socket_world_location(mesh, PUMP_BONE_NAME)
    local axis_world = get_pump_backward_axis(mesh)
    if root_tf == nil or forearm_world == nil or axis_world == nil then
        return
    end
    local inv_root = nil
    pcall(function()
        if kismet_math_library ~= nil and kismet_math_library.InvertTransform ~= nil then
            inv_root = kismet_math_library:InvertTransform(root_tf)
        end
    end)
    if inv_root == nil then
        return
    end
    -- ForearmWorld0 → 根空间局部坐标
    local forearm_tf_world = nil
    pcall(function()
        local forearm_ftrans = nil
        pcall(function()
            if kismet_math_library.MakeTransform ~= nil then
                forearm_ftrans = kismet_math_library:MakeTransform(
                    uevrUtils.vector(forearm_world.X, forearm_world.Y, forearm_world.Z),
                    uevrUtils.rotator(0, 0, 0),
                    uevrUtils.vector(1, 1, 1))
            end
        end)
        if forearm_ftrans ~= nil then
            forearm_tf_world = kismet_math_library:ComposeTransforms(forearm_ftrans, inv_root)
        end
    end)
    -- axis_world → 根空间局部向量（用 InverseTransformVector 保留缩放，fallback InverseTransformDirection）
    local axis_local = nil
    pcall(function()
        if kismet_math_library.InverseTransformVector ~= nil then
            axis_local = kismet_math_library:InverseTransformVector(root_tf,
                uevrUtils.vector(axis_world.X, axis_world.Y, axis_world.Z))
        elseif kismet_math_library.InverseTransformDirection ~= nil then
            axis_local = kismet_math_library:InverseTransformDirection(root_tf,
                uevrUtils.vector(axis_world.X, axis_world.Y, axis_world.Z))
        end
    end)
    if forearm_tf_world == nil or axis_local == nil then
        return
    end
    state.pump_anchor_frozen = {
        forearm_local = forearm_tf_world,
        axis_local = axis_local,
    }
end

-- needs_pump 期间预生成表演护木（grip 之前完成）；存在则每帧跟枪同步
local last_poseable_ensure_log = 0
local function ensure_pump_poseable_ready()
    if not state.needs_pump then
        return false
    end
    -- 策略E：空仓装弹后不预生成护木（引擎可能已移动护木位置导致锚点错误）
    -- 等用户真正握住护木开始拉栓时再生成（begin_pump 中会调用）
    if state.was_empty and not state.pump_active then
        return false
    end
    if state.reload_active or state.shells_in_hand then
        return false
    end
    local mesh = select(1, get_shotgun_chain())
    if mesh == nil then
        local now = os.clock()
        if now - last_poseable_ensure_log > 1.0 then
            last_poseable_ensure_log = now
        end
        return false
    end
    clear_stale_pump_poseable_refs()
    if not pump_poseable_is_valid() then
        if not spawn_pump_poseable(mesh) then
            return false
        end
    end
    if not state.pump_bone_hidden then
        hide_pump_bone(mesh)
    end
    -- BLOCKER-1: 表演护木生成后立即冻结锚点（整轮泵动统一参考系）
    freeze_pump_anchor(mesh)
    -- 未 begin_pump 也必须跟枪，否则护木钉在世界坐标
    if not state.pump_active then
        update_pump_poseable_position(mesh, 0)
    end
    return pump_poseable_is_valid()
end

-- 清理 PoseableMesh + 恢复真枪 bone_forearm 显示（参照 pistol cleanup_slide_visual）
-- opts.keep_left_grip：销毁前把手改挂回真枪，避免左手挂在即将销毁的 poseable 上消失
-- opts.skip_reattach：调用方已改挂过，此处只毁表演件
local function cleanup_pump_visual(opts)
    opts = opts or {}
    local snap = poseable_visibility_snapshot(pump_visual.poseable_mesh, pump_visual.poseable_actor)
    clear_pump_hand_parent()

    local mesh, _ = get_shotgun_chain()
    if mesh ~= nil and state.pump_bone_hidden then
        show_pump_bone(mesh)
    elseif state.pump_bone_hidden then
        state.pump_bone_hidden = false
    end

    -- 必须先改挂真枪再 destroy：否则左手父组件被毁 → 短暂消失
    if opts.skip_reattach ~= true then
        local want_left = opts.keep_left_grip == true
        if not want_left then
            local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
            want_left = state.pump_offhand_gripping == true
                or left_grip == true
                or (type(left_grip) == "number" and left_grip > 0.5)
        end
        if want_left then
            reattach_left_hand_to_real_pump("cleanup_before_destroy")
        end
    end

    if pump_visual.poseable_actor ~= nil then
        pcall(function()
            pump_visual.poseable_actor:SetHiddenInGame(true, true)
        end)
        local ok, err = pcall(function()
            uevrUtils.destroy_actor(pump_visual.poseable_actor)
        end)
    end
    pump_visual.poseable_actor = nil
    pump_visual.poseable_mesh = nil
    state.pump_poseable_actor = nil
    state.pump_poseable = nil

    if opts.skip_reattach ~= true then
        local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
        local want_left = opts.keep_left_grip == true
            or state.pump_offhand_gripping == true
            or left_grip == true
            or (type(left_grip) == "number" and left_grip > 0.5)
        if want_left then
            reattach_left_hand_to_real_pump("cleanup_after_destroy")
        end
    end
end

-- =============================================================================
-- Phase 3: 泵动上膛
-- =============================================================================


-- 左手 grip 是否按下（VREnvironment.leftGrip 是 0.0/1.0，不是 boolean）
local function is_left_grip_pressed()
    local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
    if left_grip == true then
        return true
    end
    return type(left_grip) == "number" and left_grip > 0.5
end

-- 获取左手世界坐标：弹药/泵动跟 MotionController（与 shell spawn 同源）
local function get_left_hand_location()
    local loc = select(1, get_shell_hand_world_transform())
    if loc ~= nil then
        return loc
    end
    return reload_tools.get_left_hand_world_location()
end

-- 开始泵动手势（由 accessory hook 触发）
local function begin_pump()
    if pump_callback_locked() then
        return
    end
    local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
    if state.pump_active then
        return
    end
    if not state.needs_pump then
        return
    end
    local mesh, _ = get_shotgun_chain()
    if mesh == nil then
        print_log("begin_pump: no shotgun mesh", LogLevel.Warn)
        return
    end
    pump_begin_busy = true
    local ok_run, err_run = pcall(function()
        if not spawn_pump_poseable(mesh) then
            print_log("begin_pump: spawn_pump_poseable failed, continue without visual isolation", LogLevel.Warn)
        end
        -- BLOCKER-1: 表演护木生成后立即冻结锚点（整轮泵动统一参考系；ensure 可能已拍，freeze 内判重）
        freeze_pump_anchor(mesh)
        local lh_pos = get_left_hand_location()
        if lh_pos == nil then
            print_log("begin_pump: no left hand position", LogLevel.Warn)
            return
        end
        local rack = state.pump_rack
        rack.active = true
        rack.start_pos = { X = lh_pos.X, Y = lh_pos.Y, Z = lh_pos.Z }
        rack.backward_axis = get_pump_backward_axis(mesh)
        rack.signed_pull = 0
        rack.pull_max = 0
        rack.pull_done = false
        rack.pull_progress = 0
        rack.returning = false
        state.pump_active = true

        -- 移动补偿：以枪体 bone_forearm socket 为锚点，捕获 begin 时刻 (lh - socket) · backward_axis 标量。
        -- tick 时再算 (lh - socket) · backward_axis 之差，玩家走动/转身时该差值保持不变
        -- （正交变换保内积），signed_pull 只反映手相对枪的真实后拉量。
        -- start_anchor_dist 为 nil 时 calc_slide_pull_anchored 走旧 world-space fallback。
        local socket_loc_begin = reload_tools.get_socket_world_location(mesh, PUMP_BONE_NAME)
        rack.start_anchor_dist = reload_tools.capture_slide_anchor(
            lh_pos, socket_loc_begin, rack.backward_axis
        )
        print_log("pump begin (left hand grip on forearm, poseable="
            .. tostring(pump_poseable_is_valid()) .. ")", LogLevel.Info)
    end)
    pump_begin_busy = false
end

-- 完成泵动：needs_pump=false + 引擎同步 + 音效/触觉
-- PrepareAnimData 已在 pull_done 时还原（触发原生抛壳动画），此处不再重复还原
local function complete_pump()
    local rack = state.pump_rack
    rack.active = false
    state.pump_active = false
    state.needs_pump = false
    state.pump_completed_this_cycle = true
    state.pump_anchor_frozen = nil  -- BLOCKER-1: 清理冻结锚点
    state.was_empty = false  -- 策略E：手动泵动完成，清除空仓标记
    -- 原生动画窗口内 montage proximity 可能拆左手：粘住 marker ~0.33s
    state.post_pump_keep_left_frames = 20

    -- PrepareAnimData 已在 pull_done 时还原，此处仅检查状态一致性
    local restored = not state.prepare_anim_data_nulled

    -- 先把手挂回真枪护木，再触发原生动画（手跟 bone_forearm 走，不会因毁 poseable 消失）
    clear_pump_hand_parent()
    local mesh_pre, _ = get_shotgun_chain()
    if mesh_pre ~= nil and state.pump_bone_hidden then
        show_pump_bone(mesh_pre)
    end
    reattach_left_hand_to_real_pump("complete_before_native")

    -- 引擎同步（方案 A）：对齐 SingleActionWeaponReadySaves
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    local chain = reload_tools.resolve_combat_chain(pawn)
    local subcomp = chain and chain.ranged or nil
    if subcomp ~= nil and reload_tools.SHRangedCmbSubcomp_c ~= nil then
        local ok, err = pcall(function()
            local fn = reload_tools.SHRangedCmbSubcomp_c:find_function("OnRangedSingleActionPrepareEnd")
            if fn ~= nil then
                subcomp:call_function(fn, nil, 0)
            end
        end)
        if not ok then
            print_log("complete_pump: OnRangedSingleActionPrepareEnd call failed: " .. tostring(err), LogLevel.Warn)
        end
    end

    -- 策略 D：前推完成时写入 idle 固定值，覆盖 post-fire 值
    -- 防止空仓装弹后引擎自动泵动（护木自己动一下）
    write_idle_prepare_anim_data("complete_pump")

    -- 音效：pump_fwd（前推到位）
    local seg = M.get_audio_segment("pump_fwd")
    audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)

    -- 触觉
    trigger_reload_haptic("pump_fwd")

    -- 销毁表演件（手已挂真枪；skip 避免重复逻辑乱序）
    cleanup_pump_visual({ keep_left_grip = true, skip_reattach = true })
    reattach_left_hand_to_real_pump("complete_after_cleanup")

    print_log("pump complete → needs_pump=false PrepareAnimData.restored="
        .. tostring(restored) .. " IsFireReady=allow", LogLevel.Info)
end

-- 取消泵动（武器切换/mesh丢失/装弹冲突等异常场景）
-- 注意：松手/左手位置丢失场景已改用 pause_pump（保持 pump_active=true，护木冻结）
-- cancel_pump 彻底清理 pump_active/needs_pump/表演护木
local function cancel_pump(reason)
    local rack = state.pump_rack
    -- 断言：accessory_detach/no_left_pos 应走 pause_pump 而非 cancel_pump
    -- 若意外走到此路径，说明有遗漏的调用点，记 Warn 日志
    if reason == "accessory_detach" or reason == "no_left_pos" then
        print_log("cancel_pump WARNING: reason=" .. tostring(reason)
            .. " should use pause_pump, not cancel_pump. This indicates a code path issue.",
            LogLevel.Warn)
    end
    rack.active = false
    state.pump_active = false
    state.pump_anchor_frozen = nil  -- BLOCKER-1: 清理冻结锚点
    rack.start_anchor_dist = nil     -- 移动补偿：清理锚定标量
    cleanup_pump_visual()
    print_log("pump cancelled: " .. tostring(reason), LogLevel.Info)
end

--- 暂停泵动（松手/左手位置丢失）：保持 pump_active=true，护木冻结在当前位置
--- 与 cancel_pump 不同：cancel 彻底清理，pause 只是停止驱动
--- needs_pump=true 时泵动只有"暂停"和"完成"，没有"取消"
local function pause_pump(reason)
    -- 只清握持标志，不修改 pump_active/needs_pump/pump_rack
    state.pump_offhand_gripping = false
    -- tick_pump 中 pump_offhand_gripping=false 时将以 rack.pull_progress 冻结护木
    print_log("pump paused (" .. tostring(reason) .. "), forearm frozen at progress="
        .. string.format("%.2f", state.pump_rack.pull_progress), LogLevel.Info)
end

-- 每帧驱动泵动逻辑（由 on_tick 调用）
local function tick_post_pump_keep_left()
    local frames = state.post_pump_keep_left_frames or 0
    if frames <= 0 then
        return
    end
    state.post_pump_keep_left_frames = frames - 1
    -- 原生动画期间 montage 可能反复拆挂：每隔几帧强制挂回真枪
    if frames % 4 == 0 then
        local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
        local gripping = state.pump_offhand_gripping == true
            or left_grip == true
            or (type(left_grip) == "number" and left_grip > 0.5)
        if gripping then
            reattach_left_hand_to_real_pump("post_complete_tick")
        end
    end
end

local function tick_pump(cached_mesh)
    tick_post_pump_keep_left()
    if not state.needs_pump then
        if state.pump_active then
            cancel_pump("not_needed")
        end
        -- 不需要泵时若残留表演件则清掉（仍握着则改挂真枪，避免左手消失）
        if pump_visual.poseable_actor ~= nil then
            cleanup_pump_visual({ keep_left_grip = true })
        end
        return
    end

    -- 装弹中不泵动，但护木仍需跟枪同步（否则脱离枪体）
    if state.reload_active or state.shells_in_hand then
        if state.pump_active then
            cancel_pump("reload_active")
        end
        -- 装弹时护木跟枪同步
        if pump_poseable_is_valid() then
            local mesh_sync = cached_mesh or select(1, get_shotgun_chain())
            if mesh_sync ~= nil then
                update_pump_poseable_position(mesh_sync, state.pump_rack and state.pump_rack.pull_progress or 0)
            end
        end
        return
    end

    -- grip 前预生成 + 跟枪同步
    ensure_pump_poseable_ready()

    if not state.pump_active then
        -- 开火时若已握着护木：无需松手再握，直接 begin（以 accessory offhand 为准）
        if state.pump_offhand_gripping then
            begin_pump()
        end
        return
    end

    local rack = state.pump_rack
    local mesh = cached_mesh or select(1, get_shotgun_chain())
    if mesh == nil then
        cancel_pump("no_mesh")
        return
    end

    -- 左手未握护木时：跳过位置更新，护木冻结在最后位置
    -- 仍需跟枪同步（枪身旋转时护木跟随），但不更新 pump_rack 进度
    if not state.pump_offhand_gripping then
        if pump_poseable_is_valid() then
            update_pump_poseable_position(mesh, rack.pull_progress)
        end
        return
    end

    local lh_pos = get_left_hand_location()
    if lh_pos == nil then
        -- 左手位置丢失：暂停而非取消
        pause_pump("no_left_pos")
        return
    end

    -- 后拉轴每帧随枪更新（BLOCKER-1: 冻结锚点已在表演护木生成时拍好，整轮泵动用冻结轴重投影）
    if state.pump_anchor_frozen ~= nil then
        local frozen_axis = nil
        local root_now = nil
        pcall(function()
            if mesh.K2_GetComponentToWorld ~= nil then
                root_now = mesh:K2_GetComponentToWorld()
            end
        end)
        if root_now ~= nil then
            pcall(function()
                if kismet_math_library ~= nil then
                    if kismet_math_library.TransformVector ~= nil then
                        frozen_axis = kismet_math_library:TransformVector(root_now, state.pump_anchor_frozen.axis_local)
                    elseif kismet_math_library.TransformDirection ~= nil then
                        frozen_axis = kismet_math_library:TransformDirection(root_now, state.pump_anchor_frozen.axis_local)
                    end
                end
            end)
        end
        if frozen_axis ~= nil then
            rack.backward_axis = { X = frozen_axis.X or 0, Y = frozen_axis.Y or 0, Z = frozen_axis.Z or 0 }
        else
            rack.backward_axis = get_pump_backward_axis(mesh)
        end
    else
        rack.backward_axis = get_pump_backward_axis(mesh)
    end

    -- 移动补偿：优先用「锚定到枪 socket」的算法（与 pistol_reload 同策略）。
    -- signed_pull = (lh - socket) · backward_axis 的当前值 - begin 时刻值
    -- 玩家走动/转身时 (lh-socket) 与 backward_axis 同步变换，内积不变 → signed_pull 不受影响。
    -- start_anchor_dist/socket_loc 为 nil 时 calc_slide_pull_anchored 内部走旧 world-space fallback。
    local socket_loc = reload_tools.get_socket_world_location(mesh, PUMP_BONE_NAME)
    local signed_pull, pull_progress = reload_tools.calc_slide_pull_anchored(
        lh_pos, socket_loc, rack.backward_axis,
        rack.start_anchor_dist, PUMP_PULL_THRESHOLD, rack.start_pos
    )

    -- 钳制
    if pull_progress > 1.0 then pull_progress = 1.0 end
    if signed_pull > PUMP_PULL_THRESHOLD then signed_pull = PUMP_PULL_THRESHOLD end
    if pull_progress < 0 then pull_progress = 0 end

    -- 方向锁定（参照 pistol_reload slide_rack_state L2588-2602 逻辑，但霰弹枪需要前推完成）
    if not rack.pull_done then
        -- 后拉未到位：signed_pull/pull_progress 只增不减，防止抖动或松手前泵回弹
        if signed_pull > rack.signed_pull then
            rack.signed_pull = signed_pull
        end
        if pull_progress > rack.pull_progress then
            rack.pull_progress = pull_progress
        end
        if signed_pull > rack.pull_max then
            rack.pull_max = signed_pull
        end
    else
        -- 后拉到位后：signed_pull/pull_progress 只减不增（只允许前推，不允许后拉）
        if signed_pull < rack.signed_pull then
            rack.signed_pull = signed_pull
        end
        if pull_progress < rack.pull_progress then
            rack.pull_progress = pull_progress
        end
    end

    -- 使用方向锁定后的值
    local locked_signed_pull = rack.signed_pull
    local locked_progress = rack.pull_progress

    -- 更新 PoseableMesh 护木位置（浮点跟随）
    update_pump_poseable_position(mesh, locked_progress)

    -- 表演件存在时隐藏真枪护木
    if pump_visual.poseable_mesh ~= nil and not state.pump_bone_hidden then
        hide_pump_bone(mesh)
    end

    -- 后拉到位判定（仅首次）
    if not rack.pull_done and reload_tools.is_pull_done(locked_signed_pull, PUMP_PULL_THRESHOLD) then
        rack.pull_done = true
        -- BLOCKER-1: pump_anchor_frozen 已在表演护木生成时拍好，此处不再重复快照
        -- 还原 PrepareAnimData → 触发原生动画（含抛壳，由引擎自动触发）
        restore_prepare_anim_data("pull_done_eject", false)
        -- 音效：pump_back
        local seg = M.get_audio_segment("pump_back")
        audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
        -- 触觉
        trigger_reload_haptic("pump_back")
        print_log("pump pull done (max=" .. string.format("%.1f", rack.pull_max) .. "cm)", LogLevel.Info)
    end

    -- 前推到位判定（后拉到位后，前推回原位算完成）
    -- 方向锁定后 locked_signed_pull 只减不增，检测它降到 ≤ PUMP_PUSH_DONE_DIST 即完成
    if rack.pull_done then
        if reload_tools.is_push_done(PUMP_PULL_THRESHOLD, locked_signed_pull, PUMP_PUSH_DONE_DIST) then
            complete_pump()
            return
        end
    end
end

-- =============================================================================
-- Phase 2: 双弹装填
-- =============================================================================

-- 生成双霰弹模型到左手（左胯取弹）
-- StaticMesh 比 pistol 的 PoseableMesh 简单：find → spawn actor → create component → attach 左手
-- Phase 2.1：双弹装填，spawn_single_shell 复用于 shell_1 / shell_2（两个独立 actor）
-- shell_index: 1 = shell_1（走 shotgun_shell_1 偏移），2 = shell_2（走 shotgun_shell_2 偏移）
-- 返回 actor, comp 或 nil, nil（失败时内部已 set_spawn_fail）
local function spawn_single_shell(mesh_obj, spawn_loc, spawn_rot, identity_xf, shell_index)
    local actor = uevrUtils.spawn_actor(
        reload_tools.make_spawn_transform(spawn_loc, spawn_rot), 1, nil)
    if actor == nil then
        set_spawn_fail("spawn_actor_" .. tostring(shell_index), "uevrUtils.spawn_actor returned nil")
        return nil, nil
    end

    local comp = uevrUtils.createStaticMeshComponent(mesh_obj, {
        manualAttachment = true,
        relativeTransform = identity_xf,
        deferredFinish = false,
        parent = actor,
    })
    if comp == nil then
        uevrUtils.destroy_actor(actor)
        set_spawn_fail("comp" .. tostring(shell_index), "createStaticMeshComponent shell failed")
        return nil, nil
    end
    pcall(function()
        if comp.SetMobility ~= nil then
            comp:SetMobility(2)
        end
        if actor.K2_SetRootComponent ~= nil then
            actor:K2_SetRootComponent(comp)
        end
    end)

    -- shell_2 走独立的 json 偏移条目（shotgun_shell_2），shell_1 走默认（shotgun_shell_1）
    local function apply_offset()
        if shell_index == 2 then
            apply_shotgun_shell_transform(comp, SHELL_LEFT_HAND_ATTACHMENT_ID_2, SHELL_CONFIG_PREFIX_2)
        else
            apply_shotgun_shell_transform(comp)
        end
    end

    -- Phase 2.1：shell_2 完全照抄 shell_1 的 spawn 路径（用户要求"照着抄"）
    -- 走 attachToController 注册到 meshAttachmentList，与 shell_1 同源
    -- 关键差异：on_grip_update_merge 只能返回一个 leftAttachment（API 限制），
    -- grip update 的 detachGripAttachments(Left) 会无差别 detach shell_1 + shell_2，
    -- 但只 reattach shell_1。shell_2 被 detach 后由 on_tick 每帧 reattach 维护
    -- （见 on_tick 中的 shell_2 attach 关系维护逻辑）
    local attach_ok, attach_err = pcall(function()
        -- 与 shell_1 / pistol Phase2 成功路径一致：挂 MotionController，不挂 IK hand_l_bn
        attachments.attachToController(comp, Handed.Left, shellAttachOptions)
    end)

    apply_offset()
    -- attach 后强制 Snap 到控制器（KeepRelative 在部分情况下会保留错误相对偏移）
    pcall(function()
        local mc = resolve_shell_hand_parent()
        if mc ~= nil and comp.K2_AttachTo ~= nil then
            -- EAttachLocation::SnapToTarget = 2
            comp:K2_AttachTo(mc, uevrUtils.fname_from_string(""), 2, false)
            apply_offset()
        end
    end)

    local after_loc = reload_tools.get_component_world_location(comp)

    return actor, comp
end

local function spawn_shells_in_hand()
    state.spawn_attempt_count = (state.spawn_attempt_count or 0) + 1
    state.last_grab_skip = nil
    state.last_spawn_fail = nil
    state.last_spawn_step = "begin"

    if state.shells_in_hand then
        set_grab_skip("already_holding")
        return false
    end

    -- 备弹门禁：与手枪/诊断面板同源 — 读 st.reserveAmmo（SH2.dll 回调缓存）
    local reserve = reload_tools.sh2_state().reserveAmmo
    if reserve == nil or reserve <= 0 then
        set_spawn_fail("reserve", "no reserve ammo (" .. tostring(reserve) .. ")")
        return false
    end

    -- 弹药跟 VR 左手控制器（attachToController 同源），不用 IK mesh / hand_l_bn
    local spawn_loc, spawn_rot, left_comp, hand_err, loc_source = get_shell_hand_world_transform()
    if left_comp == nil or spawn_loc == nil then
        set_spawn_fail("left_hand_comp", "no left motion controller (" .. tostring(hand_err) .. ")")
        return false
    end
    -- 诊断：对比 IK mesh hand_l_bn，便于确认是否仍偏移
    local ik_comp = resolve_left_hand_component()
    local ik_sock = ik_comp and reload_tools.get_socket_world_location(ik_comp, SHELL_ATTACH_SOCKET) or nil
    local ik_root = ik_comp and reload_tools.get_component_world_location(ik_comp) or nil

    -- 加载 ShotgunShell_01_A StaticMesh
    local mesh_obj = nil
    local mesh_err = nil
    local ok_mesh, mesh_or_err = pcall(function()
        return uevr.api:find_uobject("StaticMesh " .. SHELL_MESH_PATH)
    end)
    if ok_mesh then
        mesh_obj = mesh_or_err
    else
        mesh_err = tostring(mesh_or_err)
    end
    if mesh_obj == nil then
        set_spawn_fail("mesh_find", "ShotgunShell_01_A not found at " .. SHELL_MESH_PATH
            .. (mesh_err and (" err=" .. mesh_err) or ""))
        return false
    end

    local identity_xf = uevrUtils.get_transform()

    -- Phase 2.1：先 spawn shell_1（始终 spawn，reserve >= 1 已检查）
    local actor1, comp1 = spawn_single_shell(mesh_obj, spawn_loc, spawn_rot, identity_xf, 1)
    if actor1 == nil or comp1 == nil then
        return false  -- spawn_single_shell 内部已 set_spawn_fail
    end

    state.shells_in_hand = true
    state.shells_actor = actor1
    state.shells_component = comp1
    state.reload_active = true
    -- Phase 2.1: shell_2 状态初始化（无 shell_2 时为 nil/false）
    state.shells_actor2 = nil
    state.shells_component2 = nil
    state.shell2_proximity_enabled = false
    state.shell2_doomed = false
    state.shell2_lerp = nil

    -- Phase 2.1：reserve >= 2 才 spawn shell_2（用户决策）
    -- reserve == 1 时只生成 shell_1，shell_1 入仓后整个流程结束
    local spawned_two = false
    if reserve >= 2 then
        local actor2, comp2 = spawn_single_shell(mesh_obj, spawn_loc, spawn_rot, identity_xf, 2)
        if actor2 ~= nil and comp2 ~= nil then
            state.shells_actor2 = actor2
            state.shells_component2 = comp2
            spawned_two = true
        else
            -- shell_2 spawn 失败：不影响 shell_1，继续单弹流程
        end
    end

    apply_left_hand_shell_pose()

    publish_globals()
    set_spawn_ok("shell in left hand reserve=" .. tostring(reserve) .. " shells=" .. (spawned_two and "2" or "1"))
    return true
end

-- 取消松手掉落（不碰当前仍在手上的 shells）
-- drop_state: state.shell_drop 或 state.shell_drop2；nil 时默认 shell_drop
local function cancel_shell_drop(drop_state)
    drop_state = drop_state or state.shell_drop
    if drop_state == nil then
        return
    end
    if drop_state.actor ~= nil
       and drop_state.actor ~= state.shells_actor
       and drop_state.actor ~= state.shells_actor2 then
        pcall(function()
            uevrUtils.destroy_actor(drop_state.actor)
        end)
    end
    reload_tools.cancel(drop_state)
    drop_state.actor = nil
    drop_state.root = nil
end

-- 销毁左手所有霰弹模型（shell_1 + shell_2，直接 K2_DestroyActor，不走掉落效果）
local function despawn_left_hand_shells()
    -- 取消两个 drop（如果有），自动跳过仍在左手上的 actor
    cancel_shell_drop(state.shell_drop)
    cancel_shell_drop(state.shell_drop2)
    pcall(function()
        attachments.detachGripAttachments(Handed.Left)
    end)
    if state.shells_actor ~= nil then
        pcall(function()
            state.shells_actor:K2_DestroyActor()
        end)
        state.shells_actor = nil
    end
    if state.shells_actor2 ~= nil then
        pcall(function()
            state.shells_actor2:K2_DestroyActor()
        end)
        state.shells_actor2 = nil
    end
    state.shells_component = nil
    state.shells_component2 = nil
    state.shells_in_hand = false
    state.reload_active = false
    state.shell2_proximity_enabled = false
    state.shell2_doomed = false
    state.shell2_lerp = nil
    show_loading_gate(nil)
    clear_left_hand_shell_pose()
    publish_globals()
end

-- 从左手 detach 单发霰弹但保留 actor 供掉落动画
-- shell_index: 1 = shell_1，2 = shell_2
-- 返回 actor, root, loc（root 用于后续 start_fall 驱动 K2_SetWorldLocation）
-- Phase 2.1：用 detachSingleAttachment 只分离当前 shell，不影响另一发
local function detach_shell_for_animation(shell_index)
    local is_shell2 = (shell_index == 2)
    local actor = is_shell2 and state.shells_actor2 or state.shells_actor
    local comp = is_shell2 and state.shells_component2 or state.shells_component
    if actor == nil or comp == nil then
        return nil, nil, nil
    end
    local root = uevrUtils.getValid(comp)
    local loc = nil
    if root ~= nil then
        loc = reload_tools.get_component_world_location(root)
    end
    if is_shell2 then
        state.shells_actor2 = nil
        state.shells_component2 = nil
        state.shell2_proximity_enabled = false
        state.shell2_doomed = false
        state.shell2_lerp = nil
    else
        state.shells_actor = nil
        state.shells_component = nil
    end
    -- 两个 actor 都没了 → 整个 reload 流程结束
    if state.shells_actor == nil and state.shells_actor2 == nil then
        state.shells_in_hand = false
        state.reload_active = false
        show_loading_gate(nil)
        clear_left_hand_shell_pose()
    end
    -- Phase 2.1：只 detach 当前 shell，保留另一发在左手上
    -- shell_1 和 shell_2 都走 attachToController（注册到 meshAttachmentList），
    -- 用 detachSingleAttachment 只分离当前 shell，不影响另一发
    pcall(function()
        if attachments.detachSingleAttachment ~= nil then
            attachments.detachSingleAttachment(comp)
        else
            attachments.detachGripAttachments(Handed.Left)
        end
    end)
    publish_globals()
    if root ~= nil and loc ~= nil then
        pcall(function()
            root:K2_SetWorldLocation(
                uevrUtils.vector(loc.X, loc.Y, loc.Z),
                false,
                reusable_hit_result,
                false
            )
        end)
    end
    return actor, root, loc
end

-- 入膛滑入动画的 follow_provider：每帧从枪体 bone_magazine socket 刷新起点/终点/旋转
-- 使弹壳在滑入阶段跟随枪体移动（走动/转身时弹壳不会脱离入弹口）
-- 同时也被 shell drop（start_single_shell_drop）复用作为 fall 阶段水平跟随的参照点
local function make_shell_slide_follow_provider()
    return function()
        local mesh, _ = get_shotgun_chain()
        if mesh == nil then
            return nil
        end
        local _, start_pos = get_shell_slide_start_world_location(mesh)
        local _, end_pos = resolve_shell_insert_socket(mesh)
        if start_pos == nil or end_pos == nil then
            return nil
        end
        local start_rot, end_rot = build_shell_slide_rotations(mesh)
        return {
            sx = start_pos.X, sy = start_pos.Y, sz = start_pos.Z,
            ex = end_pos.X, ey = end_pos.Y, ez = end_pos.Z,
            start_rot = start_rot, end_rot = end_rot,
        }
    end
end

-- 启动单发霰弹的垂直掉落（reload_tools.start_fall）
-- shell_index: 1 = shell_1，2 = shell_2
-- 返回 true/false
local function start_single_shell_drop(shell_index)
    local actor, root, start_loc = detach_shell_for_animation(shell_index)
    if actor == nil or root == nil or start_loc == nil then
        if actor ~= nil then
            pcall(function() uevrUtils.destroy_actor(actor) end)
        end
        return false
    end
    local drop = (shell_index == 2) and state.shell_drop2 or state.shell_drop
    if drop == nil then
        drop = reload_tools.new_drop_state()
        drop.duration = SHELL_DROP_DURATION
        drop.distance = SHELL_DROP_DISTANCE
        if shell_index == 2 then
            state.shell_drop2 = drop
        else
            state.shell_drop = drop
        end
    end
    drop.actor = actor
    drop.root = root
    local on_finish = function()
        if drop.actor ~= nil then
            pcall(function() drop.actor:SetHiddenInGame(true, true) end)
            pcall(function() uevrUtils.destroy_actor(drop.actor) end)
        end
        drop.actor = nil
        drop.root = nil
        print_log("shell_" .. shell_index .. " grip_release drop finished", LogLevel.Info)
    end
    reload_tools.start_fall(drop, {
        sx = start_loc.X, sy = start_loc.Y, sz = start_loc.Z,
        duration = SHELL_DROP_DURATION,
        distance = SHELL_DROP_DISTANCE,
        on_finish = on_finish,
        -- fall 阶段水平跟随枪体：走动/转身时弹壳不会原地下坠脱离枪体
        -- 复用 shell slide 的 follow_provider（返回枪体 socket 位置作为参照点）
        -- tick_fall 会记录初始位置，计算相对运动，使弹壳跟着枪水平移动
        follow_provider = make_shell_slide_follow_provider(),
    })
    return true
end

-- 松手：垂直掉落（shell_1 + shell_2 同时掉落）
-- Phase 2.1：如果有 shell_2，也走掉落动画（lerp 期间松手同样走此路径）
local function start_shell_grip_release_drop()
    local ok1 = start_single_shell_drop(1)
    -- shell_2 存在时也掉落（无论是否在 lerp 中）
    local ok2 = false
    if state.shells_actor2 ~= nil or state.shells_component2 ~= nil then
        ok2 = start_single_shell_drop(2)
    end
    return ok1 or ok2
end

-- 每帧驱动单发掉落动画（参数化支持 shell_1 / shell_2）
local function tick_single_shell_drop(drop)
    if drop == nil or not drop.active or drop.root == nil or drop.phase ~= "fall" then
        return
    end
    local result = reload_tools.tick_fall(drop)
    if result == nil then
        return
    end
    pcall(function()
        drop.root:K2_SetWorldLocation(
            uevrUtils.vector(result.x, result.y, result.z),
            false, reusable_hit_result, false
        )
    end)
end

local function tick_shell_drop()
    tick_single_shell_drop(state.shell_drop)
    tick_single_shell_drop(state.shell_drop2)
end

-- =============================================================================
-- Phase 2.1: shell_2 lerp 过渡（shell_1 despawn 后触发）
-- =============================================================================

-- 启动 shell_2 lerp：从 shell_2 当前 relative location 滑到 shell_1 的 json 偏移位置
-- ease-in 曲线（t^2），时长 SHELL_LERP_DURATION（0.2s）
-- lerp 完成后：若未 doomed 则启用 shell_2 proximity；doomed 则等玩家松手掉落
local function start_shell2_lerp()
    if state.shells_component2 == nil then
        return false
    end
    local comp2 = uevrUtils.getValid(state.shells_component2)
    if comp2 == nil then
        return false
    end
    -- lerp 起点：shell_2 当前的 relative location
    local start_loc = nil
    pcall(function()
        start_loc = {
            X = comp2.RelativeLocation.X or 0,
            Y = comp2.RelativeLocation.Y or 0,
            Z = comp2.RelativeLocation.Z or 0,
        }
    end)
    if start_loc == nil then
        return false
    end
    -- lerp 终点：shell_1 的 json 偏移（用户决策：lerp 到 shell_1 初始位置）
    local shell1_params = load_shotgun_shell_params(SHELL_LEFT_HAND_ATTACHMENT_ID, SHELL_CONFIG_PREFIX)
    local end_loc = shell1_params.location or { 0, 0, 0 }
    local end_vec = uevrUtils.vector(end_loc)

    state.shell2_lerp = {
        active = true,
        start_t = os.clock(),
        duration = SHELL_LERP_DURATION,
        comp = comp2,
        start_loc = start_loc,
        end_loc = { X = end_vec.X, Y = end_vec.Y, Z = end_vec.Z },
    }
    -- lerp 期间禁用 proximity（防止 lerp 中途触发入仓）
    state.shell2_proximity_enabled = false
    return true
end

-- 每帧驱动 shell_2 lerp（ease-in t^2）
local function tick_shell2_lerp()
    if state.shell2_lerp == nil or not state.shell2_lerp.active then
        return
    end
    local lerp = state.shell2_lerp
    local comp = lerp.comp
    if comp == nil or uevrUtils.getValid(comp) == nil then
        state.shell2_lerp = nil
        return
    end
    local elapsed = os.clock() - lerp.start_t
    local t = elapsed / math.max(lerp.duration, 0.001)
    if t >= 1.0 then
        -- lerp 完成：写终点位置
        pcall(function()
            uevrUtils.set_component_relative_location(comp, lerp.end_loc)
        end)
        state.shell2_lerp = nil
        -- 启用 shell_2 proximity（如果未 doomed）
        if not state.shell2_doomed then
            state.shell2_proximity_enabled = true
        end
        return
    end
    -- ease-in: t^2
    local eased = t * t
    local x = lerp.start_loc.X + (lerp.end_loc.X - lerp.start_loc.X) * eased
    local y = lerp.start_loc.Y + (lerp.end_loc.Y - lerp.start_loc.Y) * eased
    local z = lerp.start_loc.Z + (lerp.end_loc.Z - lerp.start_loc.Z) * eased
    pcall(function()
        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(x, y, z))
    end)
end

-- 入膛滑入动画：斜向滑入装弹 socket，被枪体遮挡后 despawn（非垂直掉落）
-- Phase 2.1：参数化 shell_index（1=shell_1, 2=shell_2）
-- shell_1 入膛：detachSingleAttachment 保留 shell_2 attachment；on_finish 触发 shell_2 lerp 或 doomed
-- shell_2 入膛：on_finish 结束整个 reload 流程
local function slide_shells_into_chamber(shell_index, prefer_socket_name, prefer_pos)
    if shell_index == nil then shell_index = 1 end
    local is_shell2 = (shell_index == 2)

    local actor = is_shell2 and state.shells_actor2 or state.shells_actor
    local comp = is_shell2 and state.shells_component2 or state.shells_component
    local slide_state_ref = is_shell2 and state.shell_slide2 or state.shell_slide

    if actor == nil then
        return false
    end
    -- 已在滑入中则跳过
    if slide_state_ref ~= nil and slide_state_ref.active then
        return false
    end

    -- shell_2 入仓：清除 lerp 状态（防止 lerp 中途触发入仓时干扰 slide 动画）
    if is_shell2 and state.shell2_lerp ~= nil then
        state.shell2_lerp = nil
    end

    local mesh, _ = get_shotgun_chain()
    if mesh == nil then
        if is_shell2 then
            -- shell_2 失败：销毁 shell_2，不影响 shell_1（shell_1 已入膛）
            pcall(function() state.shells_actor2:K2_DestroyActor() end)
            state.shells_actor2 = nil
            state.shells_component2 = nil
            state.shell2_lerp = nil
            state.shell2_proximity_enabled = false
            state.shell2_doomed = false
            if state.shells_actor == nil then
                state.shells_in_hand = false
                state.reload_active = false
                clear_left_hand_shell_pose()
            end
            publish_globals()
        else
            despawn_left_hand_shells()
        end
        return false
    end

    local socket_name = prefer_socket_name
    local chamber_pos = prefer_pos
    if chamber_pos == nil then
        socket_name, chamber_pos = resolve_shell_insert_socket(mesh)
    end
    if chamber_pos == nil then
        print("[SHOTGUN_RELOAD] slide: no insert socket " .. tostring(SHELL_INSERT_SOCKET))
        if is_shell2 then
            pcall(function() state.shells_actor2:K2_DestroyActor() end)
            state.shells_actor2 = nil
            state.shells_component2 = nil
            state.shell2_lerp = nil
            state.shell2_proximity_enabled = false
            state.shell2_doomed = false
            if state.shells_actor == nil then
                state.shells_in_hand = false
                state.reload_active = false
                clear_left_hand_shell_pose()
            end
            publish_globals()
        else
            despawn_left_hand_shells()
        end
        return false
    end

    local root = uevrUtils.getValid(comp)
    if root == nil then
        root = actor
    end

    -- 滑入起点：固定在终点正下方（同 forward/right），绝不跟手——跟手会从侧面割枪身
    local start_pos = select(2, get_shell_slide_start_world_location(mesh))
    if start_pos == nil then
        print("[SHOTGUN_RELOAD] slide: fixed start failed, abort (no hand fallback)")
        if is_shell2 then
            pcall(function() state.shells_actor2:K2_DestroyActor() end)
            state.shells_actor2 = nil
            state.shells_component2 = nil
            state.shell2_lerp = nil
            state.shell2_proximity_enabled = false
            state.shell2_doomed = false
            if state.shells_actor == nil then
                state.shells_in_hand = false
                state.reload_active = false
                clear_left_hand_shell_pose()
            end
            publish_globals()
        else
            despawn_left_hand_shells()
        end
        return false
    end

    -- 统一起止旋转（跟枪管，不跟手）；失败则仍只做位移滑入
    local start_rot, end_rot = build_shell_slide_rotations(mesh)
    local use_rot = start_rot ~= nil and end_rot ~= nil
    -- 起止相同 → 只锁朝向，不做旋转插值
    local interpolate_rot = use_rot and not shell_slide_rots_equal(start_rot, end_rot)

    print(string.format(
        "[SHOTGUN_RELOAD] slide_%d → socket=%s start=(%.1f,%.1f,%.1f) end=(%.1f,%.1f,%.1f) rot=%s",
        shell_index,
        tostring(socket_name),
        start_pos.X or 0, start_pos.Y or 0, start_pos.Z or 0,
        chamber_pos.X or 0, chamber_pos.Y or 0, chamber_pos.Z or 0,
        interpolate_rot and "lerp" or (use_rot and "lock" or "off")
    ))

    -- 滑入开始时隐藏真枪入弹口（HideBoneByName），结束/取消时 UnHide
    hide_loading_gate(mesh)

    -- Phase 2.1：只 detach 当前 shell 的 attachment，不影响另一发
    -- shell_1 case: detachSingleAttachment(comp) 保留 shell_2 的 attachment
    -- shell_2 case: shell_1 已没了，detachSingleAttachment 也行
    pcall(function()
        if attachments.detachSingleAttachment ~= nil then
            attachments.detachSingleAttachment(comp)
        else
            attachments.detachGripAttachments(Handed.Left)
        end
    end)

    -- shells_in_hand 保持 true 如果另一发还在手上（用户决策）
    if is_shell2 then
        -- shell_2 入膛：shell_1 已没了，整个流程即将结束
        state.shells_in_hand = false
        clear_left_hand_shell_pose()
    else
        -- shell_1 入膛：shell_2 可能还在手上
        if state.shells_actor2 == nil then
            state.shells_in_hand = false
            clear_left_hand_shell_pose()
        end
        -- else: shells_in_hand 保持 true，shell_2 继续持弹，保持持弹姿势
    end
    publish_globals()

    -- detach 后：清掉持弹 RelativeLocation/Rotation，再一次性写回世界位姿
    if root ~= nil then
        pcall(function()
            uevrUtils.set_component_relative_location(root, uevrUtils.vector(0, 0, 0))
            uevrUtils.set_component_relative_rotation(root, uevrUtils.rotator(0, 0, 0))
        end)
        pcall(function()
            if root.K2_SetWorldLocation ~= nil then
                root:K2_SetWorldLocation(
                    uevrUtils.vector(start_pos.X, start_pos.Y, start_pos.Z),
                    false, reusable_hit_result, false)
            end
            if use_rot and root.K2_SetWorldRotation ~= nil then
                root:K2_SetWorldRotation(
                    uevrUtils.rotator({ start_rot.Pitch, start_rot.Yaw, start_rot.Roll }),
                    false, reusable_hit_result, false)
            end
        end)
    end

    -- 创建独立的 slide_state（shell_1 → state.shell_slide, shell_2 → state.shell_slide2）
    local new_slide = {}
    if is_shell2 then
        state.shell_slide2 = new_slide
    else
        state.shell_slide = new_slide
    end

    reload_tools.start_slide(new_slide, {
        sx = start_pos.X, sy = start_pos.Y, sz = start_pos.Z,
        ex = chamber_pos.X, ey = chamber_pos.Y, ez = chamber_pos.Z,
        duration = SHELL_SLIDE_DURATION,
        skip_fall = true,
        interpolate_rot = interpolate_rot,
        start_rot = start_rot,
        end_rot = end_rot,
        rot_delay = SHELL_SLIDE_ROT_DELAY,
        -- 移动补偿：每帧从枪体 socket 刷新起点/终点/旋转，
        -- 使弹壳在滑入阶段跟随枪体移动（走动/转身时不脱离入弹口）
        follow_provider = make_shell_slide_follow_provider(),
        on_finish = function()
            -- 销毁当前 shell actor
            if is_shell2 then
                if state.shells_actor2 ~= nil then
                    pcall(function() state.shells_actor2:K2_DestroyActor() end)
                    state.shells_actor2 = nil
                end
                state.shells_component2 = nil
                state.shell_slide2 = nil
                -- shell_2 完成 → 整个 reload 流程结束
                state.shells_in_hand = false
                state.reload_active = false
                state.shell2_proximity_enabled = false
                state.shell2_doomed = false
                state.shell2_lerp = nil
                show_loading_gate(nil)
                clear_left_hand_shell_pose()
                publish_globals()
                print_log("shell_2 slid into chamber and despawned → reload flow end", LogLevel.Info)
            else
                -- shell_1 完成
                if state.shells_actor ~= nil then
                    pcall(function() state.shells_actor:K2_DestroyActor() end)
                    state.shells_actor = nil
                end
                state.shells_component = nil
                state.shell_slide = nil
                -- 判断 shell_2 的命运
                if state.shells_actor2 ~= nil then
                    -- shell_2 存在：检查是否可入仓
                    local weapon = rawget(_G, KEYS.equipped_weapon)
                    local offsets = reload_tools.WEAPON_PROFILES.shotgun
                    local clip = reload_tools.read_clip_ammo(weapon, offsets)
                    local clip_size = reload_tools.read_clip_size(weapon, offsets)
                    local reserve = reload_tools.sh2_state().reserveAmmo
                    if clip ~= nil and clip_size ~= nil and clip < clip_size
                       and (reserve == nil or reserve > 0) then
                        -- 弹仓未满 + 有备弹 → 启动 shell_2 lerp（lerp 完成后启用 proximity）
                        state.shell2_doomed = false
                        start_shell2_lerp()
                        print_log("shell_1 done → shell_2 lerp started (clip not full)", LogLevel.Info)
                    else
                        -- 弹仓已满 或 无备弹 → shell_2 doomed（仍 lerp 到 shell_1 位置，等玩家松手掉落）
                        state.shell2_doomed = true
                        start_shell2_lerp()
                        print_log(string.format(
                            "shell_1 done → shell_2 doomed (clip=%s/%s reserve=%s), lerp then wait drop",
                            tostring(clip), tostring(clip_size), tostring(reserve)), LogLevel.Info)
                    end
                    -- shells_in_hand 保持 true（shell_2 仍在手）
                    -- reload_active 保持 true（shell_2 还没入仓）
                    -- 持弹姿势保持（shell_2 仍需 shotgun_shell_insert）
                else
                    -- 没有 shell_2 → 整个流程结束
                    state.shells_in_hand = false
                    state.reload_active = false
                    show_loading_gate(nil)
                    clear_left_hand_shell_pose()
                    print_log("shell_1 done → no shell_2, reload flow end", LogLevel.Info)
                end
                publish_globals()
            end
        end,
    })

    new_slide.root = root
    return true
end

-- 每帧驱动单个 slide（参数化支持 shell_1 / shell_2）
-- slide_state: state.shell_slide 或 state.shell_slide2
local function tick_single_shell_slide(slide_state)
    if slide_state == nil or not slide_state.active then
        return
    end
    local slide = slide_state
    local root = slide.root
    if root == nil then
        return
    end

    local result = reload_tools.tick_slide(slide)
    if result == nil then
        return
    end

    -- tick_slide 在 slide 完成时同步触发 on_finish（销毁 actor + 清 slide_state）
    -- 此处检查避免对已销毁对象调用 K2_SetWorldLocation
    if result.all_done or slide_state == nil then
        return
    end

    pcall(function()
        if root.K2_SetWorldLocation ~= nil then
            root:K2_SetWorldLocation(
                uevrUtils.vector(result.x, result.y, result.z),
                false, reusable_hit_result, false)
        end
        -- 与 pistol tick_mag_release_drop 相同：interpolate_rot 时写世界旋转
        if result.pitch ~= nil and root.K2_SetWorldRotation ~= nil then
            root:K2_SetWorldRotation(
                uevrUtils.rotator({ result.pitch, result.yaw, result.roll }),
                false, reusable_hit_result, false)
        end
    end)
end

-- 每帧驱动入膛滑入动画（shell_1 + shell_2）
local function tick_shell_slide()
    tick_single_shell_slide(state.shell_slide)
    tick_single_shell_slide(state.shell_slide2)
end

-- 插弹：proximity 每次入舱写 +1，并播滑入
-- Phase 2.1：参数化 shell_index（1=shell_1, 2=shell_2）
local function insert_shells(shell_index, socket_name, socket_pos)
    if shell_index == nil then shell_index = 1 end
    local weapon = rawget(_G, KEYS.equipped_weapon)
    if weapon == nil then
        return false
    end

    local offsets = reload_tools.WEAPON_PROFILES.shotgun
    local clip = reload_tools.read_clip_ammo(weapon, offsets)
    local clip_size = reload_tools.read_clip_size(weapon, offsets)
    -- 备弹与诊断面板同源（DLL 缓存）。入仓结算：先扣备弹再 SetClipAmmo（HUD 同步）；抓取 spawn 不扣。
    local reserve = reload_tools.sh2_state().reserveAmmo

    local wrote_ammo = false
    -- 满仓由 check_shell_proximity 拦截；此处再兜底
    print(string.format(
        "[SHOTGUN_RELOAD] insert_shells DIAG clip=%s size=%s reserve=%s condition=%s",
        tostring(clip), tostring(clip_size), tostring(reserve),
        tostring(clip ~= nil and clip_size ~= nil and clip < clip_size)))
    if clip ~= nil and clip_size ~= nil and clip < clip_size then
        -- apply_shell_insert：reserve-1 → 再 clip+1（与手枪 mag_insert 同序；不改 DLL）
        wrote_ammo = reload_tools.apply_shell_insert(offsets) == true
        print(string.format(
            "[SHOTGUN_RELOAD] shell_%d insert ammo queued=%s clip=%s/%s reserve_cache=%s",
            shell_index, tostring(wrote_ammo), tostring(clip), tostring(clip_size), tostring(reserve)))
    else
        print(string.format(
            "[SHOTGUN_RELOAD] insert ammo write SKIPPED shell_%d clip=%s size=%s reserve=%s",
            shell_index, tostring(clip), tostring(clip_size), tostring(reserve)
        ))
    end

    slide_shells_into_chamber(shell_index, socket_name, socket_pos)

    local seg = M.get_audio_segment("shell_insert")
    audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
    trigger_reload_haptic("shell_insert")

    print(string.format(
        "[SHOTGUN_RELOAD] insert ok shell_%d socket=%s wrote_ammo=%s",
        shell_index, tostring(socket_name), tostring(wrote_ammo)
    ))
    return true
end

-- 每帧检测霰弹与装弹口的距离（bone_magazine + 沿枪体前移偏移）
-- Phase 2.1：shell_1 优先检测；shell_1 不存在时检测 shell_2
-- 用户决策（2026-07-19）：移除 shell2_proximity_enabled 门控——shell_2 不滑到 shell_1 位置
-- 也不可能进入距离阈值，没必要阻止；lerp 中途触发入仓时 slide 开始会清除 lerp
local function check_shell_proximity(cached_mesh)
    if not state.shells_in_hand then
        return
    end

    -- 判断当前应检测哪一发
    -- shell_1 存在且未在滑入中 → 检测 shell_1
    -- shell_1 不存在 + shell_2 存在 + shell_2 未在滑入中 → 检测 shell_2
    local shell_index = nil
    local ref_comp = nil
    if state.shells_component ~= nil
       and (state.shell_slide == nil or not state.shell_slide.active) then
        shell_index = 1
        ref_comp = state.shells_component
    elseif state.shells_component2 ~= nil
           and state.shells_component == nil
           and (state.shell_slide2 == nil or not state.shell_slide2.active)
           and state.shell2_proximity_enabled == true then
        -- 2026-07-27 门控：shell_1 入仓销毁后 + shell_2 lerp 完成后才允许 shell_2 proximity
        -- 防御性修复：霰弹枪 5cm 阈值下不易触发，但门控本意如此（shell2_proximity_enabled 字段本就为此设计）
        -- 原 2026-07-19 注释"移除门控"假设 shell_2 不会进入距离阈值，但该假设依赖参数，不够稳健
        shell_index = 2
        ref_comp = state.shells_component2
    end
    if shell_index == nil then
        -- 诊断：低频打印为什么没检测（帮助定位"第一发不检测"问题）
        local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
        if state._last_no_prox_log == nil or (now - state._last_no_prox_log) >= 1.5 then
            state._last_no_prox_log = now
            print(string.format(
                "[SHOTGUN_RELOAD] insert_prox SKIP shells_in_hand=true comp1=%s slide1=%s comp2=%s slide2=%s",
                tostring(state.shells_component ~= nil),
                tostring(state.shell_slide ~= nil and state.shell_slide.active or false),
                tostring(state.shells_component2 ~= nil),
                tostring(state.shell_slide2 ~= nil and state.shell_slide2.active or false)
            ))
        end
        return
    end

    -- 弹仓已满：关闭距离检测，不触发滑入
    local weapon = rawget(_G, KEYS.equipped_weapon)
    if weapon ~= nil then
        local offsets = reload_tools.WEAPON_PROFILES.shotgun
        local clip = reload_tools.read_clip_ammo(weapon, offsets)
        local clip_size = reload_tools.read_clip_size(weapon, offsets)
        if clip ~= nil and clip_size ~= nil and clip >= clip_size then
            return
        end
    end

    local mesh = cached_mesh or select(1, get_shotgun_chain())
    if mesh == nil then
        return
    end

    -- 优先用弹壳组件世界坐标（比控制器更贴近可见模型）
    local ref_pos = nil
    if ref_comp ~= nil then
        ref_pos = reload_tools.get_component_world_location(ref_comp)
    end
    if ref_pos == nil then
        ref_pos = get_left_hand_location()
    end
    if ref_pos == nil then
        return
    end

    local socket_name, socket_pos = get_shell_insert_world_location(mesh)
    if socket_name == nil or socket_pos == nil then
        return
    end

    local dist = reload_tools.vector_distance(
        { X = ref_pos.X, Y = ref_pos.Y, Z = ref_pos.Z },
        { X = socket_pos.X, Y = socket_pos.Y, Z = socket_pos.Z }
    )

    -- 持弹时每 ~0.8s 打一次距离，方便对齐枪底洞口
    local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
    if state._last_insert_prox_log == nil or (now - state._last_insert_prox_log) >= 0.8 then
        state._last_insert_prox_log = now
        print(string.format(
            "[SHOTGUN_RELOAD] insert_prox shell_%d socket=%s fwd=%.0f down=%.0f right=%.0f dist=%.1fcm thresh=%.1fcm",
            shell_index,
            socket_name,
            SHELL_INSERT_OFFSET.forward or 0,
            SHELL_INSERT_OFFSET.down or 0,
            SHELL_INSERT_OFFSET.right or 0,
            dist,
            SHELL_INSERT_DISTANCE
        ))
    end

    if dist < SHELL_INSERT_DISTANCE then
        insert_shells(shell_index, socket_name, socket_pos)
    end
end

-- 取消手动装弹（武器切换/过场等；松手走 start_shell_grip_release_drop，不走这里）
-- Phase 2.1：同时清理 shell_2 状态（lerp/slide2/doomed/proximity）
local function cancel_manual_reload(reason)
    reload_block_guard.cancelling = true
    -- 取消两个掉落动画（参数化版本，nil 时默认 shell_drop）
    cancel_shell_drop(state.shell_drop)
    cancel_shell_drop(state.shell_drop2)
    -- 清 shell_2 lerp 状态
    state.shell2_lerp = nil
    state.shell2_proximity_enabled = false
    state.shell2_doomed = false
    -- 取消入膛滑入动画（shell_1 或 shell_2 任一活跃）
    if state.shell_slide ~= nil or state.shell_slide2 ~= nil then
        if state.shells_actor ~= nil then
            pcall(function()
                state.shells_actor:K2_DestroyActor()
            end)
            state.shells_actor = nil
        end
        if state.shells_actor2 ~= nil then
            pcall(function()
                state.shells_actor2:K2_DestroyActor()
            end)
            state.shells_actor2 = nil
        end
        state.shells_component = nil
        state.shells_component2 = nil
        state.shells_in_hand = false
        state.reload_active = false
        state.shell_slide = nil
        state.shell_slide2 = nil
        clear_left_hand_shell_pose()
        publish_globals()
    else
        despawn_left_hand_shells()
    end
    -- 武器切换/关卡变更时清理泵动视觉
    if state.pump_active or pump_visual.poseable_actor ~= nil then
        cancel_pump(reason)
    end
    reload_block_guard.cancelling = false
    print_log("manual reload cancelled: " .. tostring(reason), LogLevel.Info)
end

-- =============================================================================
-- C 类 accessory hooks（泵动 grip+proximity）— 自注册
-- =============================================================================

local pump_hooks_installed = false
local pump_reattach_guard = false

local function install_pump_accessory_hooks()
    -- 每次 init 刷新 _G 派发，避免热重载后旧闭包读写陈旧 pump_visual
    _G.__sh2_shotgun_on_accessory_animation = function(handed, anim)
        if handed ~= Handed.Left then
            return
        end
        if anim == "rifle_offhand" then
            state.pump_offhand_gripping = true
        elseif anim == nil then
            -- spawn/hide 过程中的瞬时 nil 不掉握持标志
            if not pump_callback_locked() then
                state.pump_offhand_gripping = false
            end
        end
        -- 热路径：重入时不刷盘，避免卡顿叠加
        -- 守护逻辑：表演护木存在期间，左手附着本体护木UUID时强制改挂表演护木UUID
        -- 防止 proximity/原生 montage 系统将左手"偷"回本体护木
        if anim == "rifle_offhand" and pump_poseable_is_valid() and pump_perf_marker_uuid ~= nil then
            if not pump_reattach_guard and not pump_attach_busy then
                pump_reattach_guard = true
                attach_left_hand_to_performance_pump(true)
                pump_reattach_guard = false
            end
        end
        if anim ~= "rifle_offhand" then
            return
        end
        -- spawn/attach/begin 回调栈内禁止再进 begin_pump
        if pump_callback_locked() or pump_reattach_guard then
            return
        end
        -- pump_active=true 时：已在泵动中（暂停状态），仅恢复握持 + 重新挂到表演护木
        -- pump_active=false 时：首次握住，正常 begin_pump
        if state.pump_active then
            state.pump_offhand_gripping = true
            attach_left_hand_to_performance_pump(true)
        else
            begin_pump()
        end
    end
    _G.__sh2_shotgun_on_accessory_detach = function(handed)
        if handed ~= Handed.Left then
            return
        end
        -- hide_pump_bone 同步触发 detach：spawn/begin 进行中只记握持，不改挂、不 begin
        if pump_callback_locked() then
            if state.needs_pump then
                state.pump_offhand_gripping = true
            end
            return
        end
        -- 拉完栓原生动画窗口：montage 拆挂时立刻挂回真枪，左手不消失
        if (state.post_pump_keep_left_frames or 0) > 0 and is_left_grip_pressed() then
            state.pump_offhand_gripping = true
            reattach_left_hand_to_real_pump("detach_during_post_complete")
            return
        end
        -- 藏骨瞬间/原生动画拆挂可能误发 detach：握键仍按下且表演件在 → 改挂表演件，不取消泵动
        -- 仅 pump_active 时守护（泵动进行中防 montage 偷手）
        -- needs_pump 但 pump_active=false 时允许脱离（左手可自由去取弹）
        if state.pump_active and is_left_grip_pressed() and pump_poseable_is_valid() then
            if pump_reattach_guard then
                return
            end
            pump_reattach_guard = true
            state.pump_offhand_gripping = true
            attach_left_hand_to_performance_pump(true)
            -- 未在泵动中时交给 tick AUTO begin，避免 detach→begin→spawn 同步嵌套
            pump_reattach_guard = false
            return
        end
        state.pump_offhand_gripping = false
        if not state.pump_active then
            return
        end
        -- needs_pump=true 时：松手 = 暂停（护木冻结），不是取消
        -- needs_pump=false 时：pump_active 但不需要泵（异常路径），取消
        if state.needs_pump then
            pause_pump("accessory_detach")
        else
            cancel_pump("accessory_detach")
        end
    end
    _G.__sh2_shotgun_active_left_accessory = function()
        local sticky = (state.post_pump_keep_left_frames or 0) > 0
        if not state.pump_active and not state.needs_pump and not sticky then
            return
        end
        -- 泵动/暂停/粘住窗口：仅在左手握着且 grip 按下时返回高 priority UUID（对齐手枪 slide_rack 做法）
        -- 松 grip → 返回 nil → checkAccessories 触发 detach → on_accessory_detach → pause_pump
        -- grip 按下 + offhand=true → 返回 UUID + priority 30 → 压过 proximity → 维持长拉行程吸附
        -- 暂停状态下 offhand=false 或 grip 松开 → 不返回 UUID → proximity 路径接管（需 grip + 距离内）→ 用户主动重新握住
        if not state.pump_offhand_gripping or not is_left_grip_pressed() then
            return
        end
        if pump_poseable_is_valid() and pump_perf_marker_uuid ~= nil then
            return pump_perf_marker_uuid, 30
        end
        return pump_marker_uuid, 25
    end

    if pump_hooks_installed or rawget(_G, "__sh2_shotgun_pump_hooks_installed") then
        pump_hooks_installed = true
        return
    end

    uevrUtils.registerUEVRCallback("on_accessory_animation", function(handed, anim)
        local fn = rawget(_G, "__sh2_shotgun_on_accessory_animation")
        if type(fn) == "function" then
            fn(handed, anim)
        end
    end)
    uevrUtils.registerUEVRCallback("on_accessory_detach", function(handed)
        local fn = rawget(_G, "__sh2_shotgun_on_accessory_detach")
        if type(fn) == "function" then
            fn(handed)
        end
    end)
    uevrUtils.registerUEVRCallback("active_left_accessory", function()
        local fn = rawget(_G, "__sh2_shotgun_active_left_accessory")
        if type(fn) == "function" then
            return fn()
        end
    end)

    pump_hooks_installed = true
    _G.__sh2_shotgun_pump_hooks_installed = true
end

-- =============================================================================
-- 武器切换检测
-- =============================================================================

local function tick_weapon_change_watch()
    local key = reload_tools.get_current_weapon_key()
    if key == state.last_weapon_key then
        return
    end
    -- 武器地址变化：清理状态
    if state.last_weapon_key ~= nil then
        print_log("weapon changed (key " .. tostring(state.last_weapon_key) .. " → " .. tostring(key) .. ")", LogLevel.Info)
        restore_prepare_anim_data("weapon_change", true)
        cancel_manual_reload("weapon_change")
        if state.pump_active or pump_visual.poseable_actor ~= nil then
            cleanup_pump_visual()
            state.pump_active = false
            if state.pump_rack ~= nil then
                state.pump_rack.active = false
            end
        end
        state.needs_pump = false
        state.pump_completed_this_cycle = false
        state.last_clip_ammo = nil
    end
    state.last_weapon_key = key
end

-- =============================================================================
-- 全局状态发布
-- =============================================================================

publish_globals = function()
    -- 霰弹枪复用手枪的全局变量（不做武器区分，同一时刻只有一种武器激活）
    _G[KEYS.manual_reload_active] = state.reload_active == true
    _G[KEYS.mag_in_left_hand] = state.shells_in_hand == true
    _G[KEYS.block_closed_hands_dock] = state.reload_active == true
    -- slide_locked：借用 00/09 已建好的通用禁瞄准 + dry fire 链路
    -- 由 on_tick 读 weapon:IsFireReady() 写入，与手枪同一全局
    _G[KEYS.slide_locked] = state.slide_locked == true
    -- needs_pump 不发布全局（仅本地）
    -- vr_block_fire_when_empty 不发布（策略 B 下引擎自身处理 IsFireReady）
end

-- =============================================================================
-- D 类生命周期回调
-- =============================================================================

local function on_tick()
    -- 底层音频计时器：每帧检查播放是否到期（切枪/过场时也能正常停止）
    audio.tick()

    -- 入口守卫：非霰弹枪时 no-op，仅发布全局状态 + 降沿清理
    local was_shotgun = state._was_shotgun
    state._was_shotgun = is_shotgun_equipped()
    if not state._was_shotgun then
        -- 左胯 edge 到达但本模块不消费：打一次诊断，避免误判为 spawn 内部失败
        if rawget(_G, KEYS.mag_grab_edge) == true then
            local wt = tostring(rawget(_G, KEYS.current_weapon_type) or "none")
            if state._last_non_sg_grab_log_wt ~= wt then
                state._last_non_sg_grab_log_wt = wt
            end
        else
            state._last_non_sg_grab_log_wt = nil
        end
        if was_shotgun then
            print_log("weapon swap: shotgun → non-shotgun, cancel all", LogLevel.Info)
            restore_prepare_anim_data("weapon_swap", true)
            if state.reload_active or state.shells_in_hand or state.pump_active
                or pump_visual.poseable_actor ~= nil then
                cancel_manual_reload("weapon_swap")
            end
            cleanup_pump_visual()
            state.pump_active = false
            state.needs_pump = false
            state.was_empty = false  -- 策略E：换枪时清除空仓标记
            state.last_clip_ammo = nil
            -- 清理 slide_locked：避免切到手枪/其它武器后残留 true 误禁瞄准
            state.slide_locked = false
            _G[KEYS.slide_locked] = false
            publish_globals()
        end
        return
    end
    state._last_non_sg_grab_log_wt = nil

    -- 缓存 weapon 和 clip（每帧只查一次，避免重复调用昂贵的 resolve_combat_chain）
    local weapon = resolve_shotgun_weapon()
    local clip = nil
    if weapon ~= nil then
        local offsets = reload_tools.WEAPON_PROFILES.shotgun
        clip = reload_tools.read_clip_ammo(weapon, offsets)
    end

    -- 换枪清理（可能 discard 写回旧枪备份）
    pcall(tick_weapon_change_watch)
    -- 弹匣变化 → 开火后 block PrepareAnimData / 上弹写回
    pcall(tick_clip_fire_watch, weapon, clip)

    -- slide_locked 同步：借用手枪空仓挂机机制驱动 00/09 禁瞄准 + dry fire
    -- 直接读弹夹弹药 + needs_pump 判断空仓，不调用 weapon:IsFireReady()（会触发 hook 死锁）
    -- slide_locked=true 条件：needs_pump==true（泵动未完成）或 clip_ammo==0（弹仓空）
    -- slide_locked=false 条件：needs_pump==false 且 clip_ammo>0
    do
        if weapon ~= nil then
            local should_lock = (state.needs_pump == true) or (type(clip) == "number" and clip <= 0)
            if should_lock then
                if not state.slide_locked then
                    state.slide_locked = true
                    _G[KEYS.slide_locked] = true
                    publish_globals()
                    force_release_vr_aim("slide_locked")
                end
            else
                if state.slide_locked then
                    state.slide_locked = false
                    _G[KEYS.slide_locked] = false
                    publish_globals()
                end
            end
        end
    end

    -- 消费 UEVR_09 发布的左胯取弹 edge
    if rawget(_G, KEYS.mag_grab_edge) == true then
        _G[KEYS.mag_grab_edge] = false
    print("[SHOTGUN_RELOAD] grab_edge consumed")
    if state.shells_in_hand then
        set_grab_skip("already_holding")
    else
        spawn_shells_in_hand()
    end
end

-- 消费左手 grip 松开 edge：垂直掉落（与 pistol start_grip_release_drop 对齐）
if rawget(_G, KEYS.mag_grab_release) == true then
    _G[KEYS.mag_grab_release] = false
    if state.shells_in_hand then
        print("[SHOTGUN_RELOAD] grab_release → vertical fall")
        trigger_reload_haptic("mag_release")
        local seg_mr = M.get_audio_segment("mag_release")
        audio.play_segment(seg_mr.audio_key, seg_mr.start_sec, seg_mr.duration)
        if not start_shell_grip_release_drop() then
            despawn_left_hand_shells()
        end
    end
end

    -- 消费 dry fire edge：slide_locked 时扣扳机播放空仓音效
    if rawget(_G, KEYS.dry_fire_edge) == true then
        _G[KEYS.dry_fire_edge] = false
        if state.slide_locked then
            play_dry_fire_sound()
        end
    end

    -- M1 优化：缓存一次 chain，避免子函数重复解析 UObject 链
    local cached_mesh = select(1, get_shotgun_chain())

    -- Phase 2: 双弹 proximity 检测
    check_shell_proximity(cached_mesh)

    -- 持弹时持续应用偏移（与 pistol 持弹 tick 对齐，防止 grip update 重置 relative location）
    -- shell_1：始终应用 shell_1 的 json 偏移
    if state.shells_in_hand and state.shells_component ~= nil then
        apply_shotgun_shell_transform(state.shells_component)
    end
    -- Phase 2.1: shell_2 attach 关系维护（关键修复）
    -- shell_2 走 attachToController 注册到 meshAttachmentList，但 on_grip_update_merge
    -- 只能返回 shell_1（API 限制），grip update 的 detachGripAttachments(Left) 会无差别
    -- detach shell_1 + shell_2，只 reattach shell_1。shell_2 被 detach 后位置丢失到 (0,0,0)。
    -- 修复：每帧检查 shell_2 的 AttachParent，如果不是 motion controller，立即 K2_AttachTo 重新 attach。
    -- 用 KeepRelative (0) 而不是 SnapToTarget (2)，保留当前 relative location，
    -- 这样 lerp 期间 reattach 也不会破坏 lerp 位置。
    if state.shells_in_hand and state.shells_component2 ~= nil then
        local comp2 = uevrUtils.getValid(state.shells_component2)
        local mc = resolve_shell_hand_parent()
        if comp2 ~= nil and mc ~= nil then
            local parent = nil
            pcall(function() parent = comp2.AttachParent end)
            if parent ~= mc then
                -- attach 关系丢失，重新 attach（EAttachLocation::KeepRelative = 0）
                pcall(function()
                    comp2:K2_AttachTo(mc, uevrUtils.fname_from_string(""), 0, false)
                end)
            end
        end
    end
    -- shell_2：根据状态应用不同偏移
    -- - lerping：跳过（tick_shell2_lerp 驱动位置）
    -- - post-lerp（proximity_enabled 或 doomed）：应用 shell_1 的偏移（lerp 终点位置）
    -- - pre-lerp（shell_1 仍在手）：应用 shell_2 自己的 json 偏移
    if state.shells_in_hand and state.shells_component2 ~= nil then
        if state.shell2_lerp == nil then
            if state.shell2_proximity_enabled or state.shell2_doomed then
                -- post-lerp：应用 shell_1 的偏移（保持 lerp 终点位置）
                apply_shotgun_shell_transform(state.shells_component2,
                    SHELL_LEFT_HAND_ATTACHMENT_ID, SHELL_CONFIG_PREFIX)
            else
                -- pre-lerp：应用 shell_2 自己的偏移
                apply_shotgun_shell_transform(state.shells_component2,
                    SHELL_LEFT_HAND_ATTACHMENT_ID_2, SHELL_CONFIG_PREFIX_2)
            end
        end
    end

    -- Phase 2.1: shell_2 lerp 驱动
    tick_shell2_lerp()

    -- Phase 2.5: 入膛滑入 + 松手掉落 + 泵动驱动已移至 PostCalculateStereoViewOffset（VR 变换更新后），
    -- 消除枪移动时弹壳/护木跟随的 1 帧滞后（与 pistol tick_slide_rack 同策略）
    -- shell_drop 现在也有 follow_provider（水平跟随枪体），必须与 slide 同步在 stereo view 后执行
    -- pump 也在 stereo view 后执行：copy_weapon_world_transform 读取的是当帧 VR 变换

    publish_globals()
end

local function on_level_change()
    restore_prepare_anim_data("level_change", true)
    cancel_manual_reload("level_change")
    cleanup_pump_visual()
    state.pump_active = false
    state.needs_pump = false
    state.pump_completed_this_cycle = false
    state.last_clip_ammo = nil
    -- 读档/切关后清空 Wwise 事件缓存（audio.lua 自身也会挂 lifecycle；此处双保险）
    pcall(function()
        audio.invalidate_cache()
    end)
    publish_globals()
end

-- =============================================================================
-- 初始化
-- =============================================================================

function M.init()
    -- 代码世代：热重载后控制台必须出现这行，否则新代码没加载
    local CODE_REV = 26
    print("[SHOTGUN_RELOAD] init CODE_REV=" .. tostring(CODE_REV))

    -- 世代变化时强制允许重新注册「经 _G 间接调用」的 tick（旧闭包在完整 Reset 前仍可能残留）
    if rawget(_G, "__sh2_shotgun_code_rev") ~= CODE_REV then
        _G.__sh2_shotgun_code_rev = CODE_REV
        _G.__sh2_shotgun_reload_initialized = nil
        print("[SHOTGUN_RELOAD] CODE_REV changed → will (re)register indirection tick")
    end

    -- 本模块实例 token：完整 Reset 后只跑最新 on_tick；旧闭包若已带 token 检查会自行 no-op
    local MODULE_TOKEN = {}
    _G.__sh2_shotgun_live_token = MODULE_TOKEN
    -- 包装 on_tick：过期模块实例直接 return
    local real_on_tick = on_tick
    local function guarded_on_tick()
        if rawget(_G, "__sh2_shotgun_live_token") ~= MODULE_TOKEN then
            return
        end
        real_on_tick()
    end
    local real_on_level = on_level_change
    local function guarded_on_level()
        if rawget(_G, "__sh2_shotgun_live_token") ~= MODULE_TOKEN then
            return
        end
        real_on_level()
    end
    -- 入膛滑入 + 松手掉落 + 泵动驱动视觉 tick：在 PostCalculateStereoViewOffset（VR 变换更新后）执行，
    -- 消除枪移动时弹壳/护木跟随的 1 帧滞后（与 pistol tick_slide_rack 同策略）
    -- 仅霰弹枪装备 + 非过场时执行；tick_shell_slide / tick_shell_drop / tick_pump 内部对 active 自检
    -- shell_drop 现在也有 follow_provider（水平跟随枪体），必须与 slide 同步在 stereo view 后执行
    -- pump 也在 stereo view 后执行：copy_weapon_world_transform 读取的是当帧 VR 变换
    -- 对齐 pistol_reload.lua:3129 guarded_mag_drop_visual_tick（含 tick_slide_rack 状态逻辑）
    local function guarded_shell_slide_visual_tick()
        if rawget(_G, "__sh2_shotgun_live_token") ~= MODULE_TOKEN then
            return
        end
        if not state._was_shotgun then
            return
        end
        if uevrUtils.isInCutscene and uevrUtils.isInCutscene() then
            return
        end
        -- M1 优化：缓存一次 chain，传给子函数
        local cached_mesh = select(1, get_shotgun_chain())
        pcall(tick_shell_slide)
        pcall(tick_shell_drop)
        pcall(tick_pump, cached_mesh)
    end

    -- 注册霰弹枪音频事件（底层 audio.lua 缓存 UAkAudioEvent 对象）
    audio.register_event(
        "shotgun_reload",
        "Play_Wpn_Shotgun_Reload",
        SHOTGUN_RELOAD_EVENT_PATH
    )
    audio.register_event(
        "shotgun_pump",
        "Play_Wpn_Shotgun_Pump_Action",
        SHOTGUN_PUMP_EVENT_PATH
    )
    audio.register_event(
        SHOTGUN_DRY_FIRE_KEY,
        DRY_FIRE_AUDIO_EVENT,
        SHOTGUN_DRY_FIRE_EVENT_PATH
    )

    if pump_marker_uuid == nil then
        pcall(function()
            local params = json.load_file("accessories_parameters.json")
            if params and params.accessories then
                local shotgun_entry = params.accessories["WeaponShotgun_Alt_D_BP_C_shotgun_05_A_rig"]
                if type(shotgun_entry) == "table" then
                    for uuid, entry in pairs(shotgun_entry) do
                        if type(entry) == "table" and type(entry.label) == "string" then
                            if entry.label == "performance foregrip (pump)" then
                                pump_perf_marker_uuid = uuid
                            else
                                pump_marker_uuid = uuid
                            end
                        end
                    end
                end
            end
        end)
        if pump_marker_uuid ~= nil then
            print_log("pump marker UUID loaded: " .. tostring(pump_marker_uuid), LogLevel.Info)
        else
            print_log("WARNING: pump marker UUID not found in accessories_parameters.json", LogLevel.Warn)
        end
        if pump_perf_marker_uuid ~= nil then
            print_log("pump perf marker UUID loaded: " .. tostring(pump_perf_marker_uuid), LogLevel.Info)
        else
            print_log("WARNING: pump perf marker UUID not found in accessories_parameters.json", LogLevel.Warn)
        end
    end

    reload_hooks.register_weapon_module("shotgun", M)
    install_pump_accessory_hooks()

    -- 注册 grip_block：左手持弹时阻断护木 proximity attach（对齐 rifle_reload.lua:4518）
    -- KEYS.mag_in_left_hand 由 publish_globals 每帧发布（= state.shells_in_hand）
    -- 护木两个 marker（真枪 foregrip + 表演护木）的 grip_animation 均为 rifle_offhand（accessories_parameters.json 确认）
    -- 持弹动画为 shotgun_shell_insert，互不干扰；弹入仓/掉落后 shells_in_hand 清零，吸附自动恢复
    -- 作用域：仅 proximity 主路径；泵动期间 active_left_accessory 主动吸附走另一条路，不受影响
    pcall(function()
        accessories.registerGripBlock(KEYS.mag_in_left_hand, "rifle_offhand")
    end)

    -- 热重载关键：tick 必须经 _G 间接调用
    _G.__sh2_shotgun_on_tick = guarded_on_tick
    _G.__sh2_shotgun_on_level_change = guarded_on_level
    _G.__sh2_shotgun_shell_slide_visual_tick = guarded_shell_slide_visual_tick

    publish_globals()

    if rawget(_G, "__sh2_shotgun_reload_initialized") then
        print("[SHOTGUN_RELOAD] hot-reload: rebound tick via _G (CODE_REV=" .. tostring(CODE_REV) .. ")")
        print("[SHOTGUN_RELOAD] 若行为仍旧：请做一次完整 Reset Scripts / 重启，清掉旧闭包")
        return M
    end

    uevrUtils.registerPostEngineTickCallback(function()
        local fn = rawget(_G, "__sh2_shotgun_on_tick")
        if type(fn) == "function" then
            fn()
        end
    end)

    -- 入膛滑入视觉位置在 PostCalculateStereoViewOffset 更新（VR 控制器变换已更新），
    -- 消除枪移动时弹壳跟随的 1 帧滞后；仅 view_index==0 时执行（每帧只更新一次）
    uevrUtils.registerPostCalculateStereoViewCallback(function(device, view_index)
        if view_index ~= 0 then return end
        local fn = rawget(_G, "__sh2_shotgun_shell_slide_visual_tick")
        if type(fn) == "function" then
            fn()
        end
    end)

    uevrUtils.registerPreLevelChangeCallback(function()
        local fn = rawget(_G, "__sh2_shotgun_on_level_change")
        if type(fn) == "function" then
            fn()
        end
    end)

    -- 读档常见走 ClientRestart；与 pistol_reload 对齐清理
    uevrUtils.registerUEVRCallback("on_client_restart", function()
        local fn = rawget(_G, "__sh2_shotgun_on_level_change")
        if type(fn) == "function" then
            fn()
        end
    end)

    vr_globals.compat.on_script_reset(function()
        pcall(restore_prepare_anim_data, "script_reset", true)
        local fn = rawget(_G, "__sh2_shotgun_on_level_change")
        if type(fn) == "function" then
            fn()
        end
        _G.__sh2_shotgun_reload_initialized = nil
        _G.__sh2_shotgun_code_rev = nil
    end)

    _G.__sh2_shotgun_reload_initialized = true
    print("[SHOTGUN_RELOAD] indirection tick registered (CODE_REV=" .. tostring(CODE_REV) .. ")")
    print_log("shotgun_reload loaded (CODE_REV=26: shell slide + drop + pump all in PostCalculateStereoViewOffset, follow_provider for movement compensation)", LogLevel.Info)

    return M
end

-- 单独热重载本文件时 main 不会再调 init：文件末尾自调
M.init()

return M
