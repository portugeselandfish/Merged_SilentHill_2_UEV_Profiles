--[[修改说明：
1. Mixed 模式下原 aim gun 段（rightGripPressed → bLeftTrigger/LT）已注释；
   右抓握 → 瞄准(LT) 改由 UEVR_09 的 gripRight 经 gamepad.Press(LeftTrigger) 统一管理。
2. 加载 pistol_reload（Phase 1：B 键退弹 + 表演弹匣下落）。
4. getWeaponMesh() 中发布 _G.__sh2_current_weapon_type（"pistol"/"shotgun"/"rifle"/"none"）
   和 _G.__sh2_equipped_weapon（当前装备的武器对象），供其他模块直接读取，
   避免各自重复做 EquippedWeapon 链式查询。
   空手 ItemContext：跳过 ShotgunAmmo/SniperRifleAmmo（不挂右手；不碰手枪/药水）。
   2026-08-08：上述步枪/霰弹弹药跳过保留，避免左远程拾取后误挂右手。
5. 在 pistol_reload.init 之前加载 libs/reload_hooks 并调用其 init：
   集中注册 A 类 UFunction hooks（IsFireReady/CanBeReloaded/PlayRequest/OnRangedReload 等）
   和 B 类附件 hooks（grip update / initAttachment），按 _G.__sh2_current_weapon_type
   dispatch 到各武器业务模块导出的 M.on_xxx 回调入口，避免多武器重复 hook 互相覆盖。
6. 加载 heal（治疗系统 VR 改造：spawn/despawn 表演道具，消费 4 个 edge 信号）。
7. 2026-07-28：右手针剂占用时跳过武器 Root 瞄准同步（g_heal_right_prop_active），
   避免枪被拽到针剂变换上造成“枪还在且歪”。
8. 2026-08-03：加载 recoil（运动后座力，无震动）
   - 在 rifleReload.init() 之后 require('recoil'); recoil.init()
   - Seed：UEVR_09 trigger_right_fire_action enter → recoil.on_fire_success
   - post_engine_tick 武器瞄准分支：attachment 基准变换算出后调用
     recoil.apply_to_aim_transform(location, rotation) 合成后再写 K2_SetWorldLocation/Rotation
   - main 写 Root（瞄准）+ 右手 hand_r_bn 可视后座；recoil 只变换局部变量 / 手骨姿态
   - recoil.lua 内嵌 M.init_config_ui()：使用 configui 创建滑块面板，
     管理 recoil 全部主要参数，持久化到 recoil_intensity.json。
     init_config_ui() 不受开发者模式门控，始终注册面板。
9. 2026-08-04：加载 weapon_two_hand（双手长枪 WeaponDriver）
   - pre_tick：清洁双手求解 → 长枪 Mesh 后坐（pitch→roll）→ 写可见枪
   - 右手仍走 compose_visual_rotation；Root 读已含后坐的 Mesh，勿二次叠加
10. 2026-09-04：统一 pawn 检测（方案A）——新增 check_pawn_globally（1s）集中检测 pawn 指针变化，
   向 remote_grab/unlock_door/unlock_item_door 广播 on_pawn_changed，消除三处重复 get_local_pawn；
   on_level_change 补转发 remoteGrab（原自注册回调已删）。
11. 2026-09-04 补修（code-review）：on_level_change 进入时置空 _G.__sh2_global_pawn_ref，强制下 1s tick
   重广播当前 pawn 状态——pawn 仍 nil 则清 pending 防过渡期全图重建，pawn 有效则重 schedule（pending 去重）。
]]--

--[[
================================================================================
Silent Hill 2 第一人称 VR Mod — 主入口脚本 (main.lua)
================================================================================

【总体职责】
  UEVR 用户脚本的启动与调度中心：加载各 libs 子模块，注册配置 UI、输入重映射、
  引擎 Tick 回调，以及 SH2 游戏专属的逻辑补丁。

【模块初始化】（脚本加载时执行）
  - ui / montage / interaction / attachments / reticule / pawn / remap / input / ik 等
  - gunstock 配置面板；IK 与 forearms 的 gunstock 偏移开关
  - 详见下方 require 与 xxx.init() 调用

【配置 UI — configDefinition → configui.create】
  - 主面板 "Silent Hill 2 Config"（持久化 sh2_config.json）
  - 移动：前进方向（游戏/跟头）、Snap Turn、隐藏头部、副手抓武器、光追等
  - 交互：Vanilla / Mixed 控制方案、冲刺模式说明
  - 嵌入 ui / reticule 子模块的配置控件

【VR 身体与手部 — 假全身方案】
  - hands_type：None / Forearms / IK Arms，切换时 regenerateHands
  - hide_head：HideBone 隐藏 neck_02_bn，避免第一人称看到头部
  - ik + pawn：IK 手臂驱动手柄；pawn 隐藏原 mesh 上臂；躯干/腿仍靠游戏动画
  - input.lua（本脚本未展开）：mesh 偏移、room-scale、头身 Yaw 对齐
  - on_cutscene_change：过场时隐藏手臂骨骼、藏头、禁用 melee

【武器与附件 — attachments 回调】
  - onGripUpdate：将武器挂到右手（或 IK mesh / 控制器），手电筒挂左手
  - post_tick：同步已装备武器 RootComponent 的世界位置/旋转到附件变换（瞄准）
  - reticule 自定义瞄准原点：RegisteredFirePoint + 武器 Root 位置
  - 手电筒：attachLightToController（头/副手/主手三种模式）

【输入重映射 — on_pre_input_get_state】
  - Mixed 模式：左摇杆冲刺、双击后转 180°、头部手势换电筒位置、左扳机切手电等
  - Vanilla 模式：防止右肩键连续 180° 转向
  - Snap Turn / 平滑转向：右摇杆 X 轴
  - 右摇杆下 + B：Mixed 下映射确认键
  - 瞄准(LT) 注入见文件最上方「修改说明」

【相机与视角】
  - post_engine_tick：HMD 姿态 → OverrideControlRotation；recenter_view
  - pre_engine_tick：applyFaceAwayFromCamera（移动朝向对齐相机 Yaw）
  - 禁用 CameraOverlapHandler  tick / OwnerCharacterPlay（防止瞄准隐身）
  - centerOrbitCamera：可选修复轨道相机横向偏移（fix_orbit_camera_offset）
  - Hook LegacyCameraShake：ShakeScale = 0，关闭相机抖动

【游戏状态与补丁 — pre_engine_tick】
  - 过场检测：SHCharacterStatics / GetGameplayInputMode → setIsInCutsceneOverride
  - 推物动画：临时关闭 room-scale 移动
  - 攀爬/翻越：isPawnTraversing → 过场式输入锁定
  - SpringArm lag 开关；地图打开时禁用 remap

【关卡与生命周期】
  - on_level_change：清理 status、重建手部/IK、藏头、光追 glitch 修复、轨道相机
  - applySaveSlotLimit：手动存档槽扩至 200
  - on_script_reset：卸载相机抖动 Hook

【图形】
  - enable_raytracing / fix_no_raytracing_visual_glitches：开关光追与周期性 renderer 重置

【调试】
  - F2：pawn 本地偏移测试（register_key_bind）
  - 注释掉的 setDeveloperMode / enableConfigurationTool / profiler

================================================================================
]]--
local uevrUtils = require('libs/uevr_utils')
local controllers = require('libs/controllers')
local configui = require("libs/configui")
local reticule = require("libs/reticule")
local hands = require('libs/hands')
local attachments = require('libs/attachments')
local input = require('libs/input')
local pawnModule = require('libs/pawn')
local montage = require('libs/montage')
local interaction = require('libs/interaction')
local ui = require('libs/ui')
local remap = require('libs/remap')
local gestures = require('libs/gestures')
local gunstock = require('libs/gunstock')
local ik = require('libs/ik')
local accessories = require('libs/accessories')
local mathLib = require('libs/core/math_lib')
local vr_globals = require('UEVR_00_init_globals')
local melee = require('melee')
-- 1.0.2 推门功能：手部碰撞体模块，配合 registerContactCallback 实现 VR 手推门
local collision = require('libs/collision')
-- 公共 hook 入口必须先 init，集中注册 A+B 类 hooks 并建立武器类型 dispatch
-- 各武器业务模块（pistol/shotgun/rifle）在自身 init 中通过 register_weapon_module 注册
local reload_hooks = require('libs/reload_hooks')
reload_hooks.init()
local manualReload = require('pistol_reload')
manualReload.init()
-- 霰弹枪手动换弹：依赖 reload_hooks 已 init，通过 register_weapon_module 注册到 dispatch
local shotgunReload = require('shotgun_reload')
shotgunReload.init()
-- 步枪手动换弹：同霰弹枪架构，依赖 reload_hooks 已 init
local rifleReload = require('rifle_reload')
rifleReload.init()

-- 加载 recoil（运动后座力，无震动）：
--   - Seed：UEVR_09 trigger_right_fire_action enter → recoil.on_fire_success
--   - 弹簧在高优先级 pre-tick 更新
--   - IK Arms：可视旋转在 ik.rotateHandAndWrist 写 hand_r_bn 前 compose
--   - Forearms：post-tick 写 hand_r_bn；Root 仍走 apply_to_aim_transform
--   - Root：瞄准 / FirePoint；IK 已合成旋转时只补位置 kick
local recoil = require('recoil')
recoil.init()

-- 双手长枪 WeaponDriver：左右控制器 → 唯一武器世界姿态 → 驱动可见 Mesh；
-- Root 仍由下方 post_engine_tick 读 Mesh+recoil 同步（与可见枪一致）。
local weaponTwoHand = require('weapon_two_hand')
weaponTwoHand.init()

local heal = require('heal')
pcall(function() heal.init() end)

local remoteGrab = require('remote_grab')

--uevrUtils.setLogLevel(LogLevel.Debug)
-- 开发者模式：注释掉下一行后，two_hand配置面板不会注册/显示。
--uevrUtils.setDeveloperMode(true)
--hands.enableConfigurationTool()
recoil.init_config_ui()
if uevrUtils.getDeveloperMode() == true then
	pcall(function() weaponTwoHand.init_config_ui() end)
end
--uevrUtils.profiler:toggle(true)

ui.init()
--ui.setRequireWidgetOpenState(true)
ui.setRequireWidgetVisibility(true)
montage.init()
interaction.init()
attachments.init()
reticule.init()
reticule.setHiddenWhenScopeActive(true)
pawnModule.init()
remap.init()
input.init()
gunstock.showConfiguration()
ik.init()
-- 1.0.2 推门功能：初始化手部碰撞体（读取 collision_parameters.json 创建左右手 collider）
collision.init()

-- 左手激光白名单拾取：依赖 interaction 已 init
pcall(function() remoteGrab.init() end)

-- 门栓拉取：Phase 0 枚举器（在 remote_grab 之后加载）
local openLatch = require('unlock_door')
pcall(function() openLatch.init() end)

-- 道具门业务模块（unlock_item_door）：自轮询驱动 L1/L2 缓存 + 钥匙生成
-- 此处 init 注册唯一 interval；main 的 on_level_change/on_cutscene_change 转发作为兜底重建信号。
local itemDoor = require('unlock_item_door')
pcall(function() itemDoor.init() end)
-- 钥匙偏移配置面板（main 脚本自绘，受开发者模式门控）：
-- 注释掉上方 setDeveloperMode(true) 后，此面板不再注册/显示。
if uevrUtils.getDeveloperMode() == true then
	pcall(function() itemDoor.init_config_ui() end)
end

attachments.setGunstockOffsetsEnabled(false)
hands.setGunstockOffsetsEnabled(true)
ik.setGunstockOffsetsEnabled(true)

-- hands.setAutoCreateHands(false)
-- ik.setAutoCreateArms(false)

local settings = {}
local status = {}
local desiredManualSaveSlots = 200
local RaytracingMode = {
	Off = 0,
	On = 1,
	ForceOn = 2,
}
local HandsType = {
	None = 1,
	Forearms = 2,
	IKArms = 3,
}

local TraversalType = {
	Undefined = 0,
	Crawl = 1,
	Squeeze = 2,
	Vault = 3,
	Climb = 4,
}


local versionTxt = "v1.0.0"
local title = "Silent Hill 2 First Person Mod " .. versionTxt
local configDefinition = {
	{
		panelLabel = "Silent Hill 2 Config",
		saveFile = "sh2_config",
		layout = spliceableInlineArray
		{
			{ widgetType = "text", id = "title", label = title },
			{ widgetType = "indent", width = 20 }, { widgetType = "text", label = "Control" }, { widgetType = "begin_rect", },
                {
                    widgetType = "combo",
                    id = "movement_type",
                    label = "Forward Movement Direction",
                    selections = {"Game (no roomscale)", "Follows Head"},
                    initialValue = 2,
                },
                {
                    widgetType = "combo",
                    id = "handedness_type",
                    label = "Handedness",
                    selections = {"Left", "Right"},
                    initialValue = 2,
					isHidden = true,
                },
                {
                    widgetType = "combo",
                    id = "hands_type",
                    label = "Hands Type",
                    selections = {"None", "Forearms", "IK Arms"},
                    initialValue = 1,
                },
                {
                    widgetType = "combo",
                    id = "light_type",
                    label = "Light Location",
                    selections = {"Head", "OffHand", "Weapon"},
                    initialValue = 1,
                },
                {
					widgetType = "checkbox",
					id = "use_snap_turn",
					label = "Use Snap Turn",
					initialValue = false
				},
				{ widgetType = "indent", width = 20 }, 
					{
						widgetType = "drag_int",
						id = "snap_turn_angle",
						label = "Angle",
						speed = 1,
						range = {1, 360},
						initialValue = 30,
					},
				{ widgetType = "unindent", width = 20 },
                {
					widgetType = "checkbox",
					id = "hide_head",
					label = "Hide Head",
					initialValue = false
				},
                {
					widgetType = "checkbox",
					id = "offhand_grip_weapon",
					label = "Offhand Can Grip Weapon",
					initialValue = true
				},
                {
					widgetType = "checkbox",
					id = "enable_raytracing",
					label = "Enable Raytracing",
					initialValue = false
				},
				{ widgetType = "indent", width = 20 }, { widgetType = "begin_group", id = "fix_no_raytracing_visual_glitches_group" },
					{
						widgetType = "checkbox",
						id = "fix_no_raytracing_visual_glitches",
						label = "Fix Visual Glitches",
						initialValue = true
					},
					{ widgetType = "same_line" },
					{
						widgetType = "drag_int",
						id = "fix_visual_glitch_seconds",
						label = "Interval (secs)",
						speed = 1,
						range = {1, 100},
						initialValue = 20,
						width = 50
					},
				{ widgetType = "end_group" }, { widgetType = "unindent", width = 20 },
                {
					widgetType = "checkbox",
					id = "fix_orbit_camera_offset",
					label = "Fix Orbit Camera Offset",
					initialValue = false,
					isHidden = true,
				},
                {
                    widgetType = "drag_float",
                    id = "camera_relative_rotation",
                    label = "Camera Relative Rotation",
                    speed = 1,
                    range = {-180, 180},
                    initialValue = 0,
                    isHidden = true,
                },
			{ widgetType = "end_rect", additionalSize = 12, rounding = 5 }, { widgetType = "unindent", width = 20 },
			{ widgetType = "new_line" },
			{ widgetType = "indent", width = 20 }, { widgetType = "text", label = "Interaction" }, { widgetType = "begin_rect", },
				{
					widgetType = "combo",
					id = "interaction_control_mode",
					label = "Interaction Controls",
					selections = {"Vanilla", "Mixed"}, --, "Full Immersion"},
					initialValue = 1,
				},
				{
					widgetType = "combo",
					id = "interaction_sprint_mode",
					label = "Sprint",
					selections = {"Left Thumbstick Press", "Left Thumbstick Press Toggled", "Left Thumbstick Double Tap Forward"},
					initialValue = 2,
				},
				{ widgetType = "begin_group", id = "interaction_desc_advanced_group" },
					{
						widgetType = "text",
						label = "    Turn around - double tap left stick down"
					},
					{
						widgetType = "text",
						label = "    Dodge - right stick down + left stick direction"
					},
					{
						widgetType = "text",
						label = "    Toggle Flashlight - left trigger"
					},
					{
						widgetType = "text",
						label = "    Put Flashlight on Head/Retrieve Flashlight - left grip head just above HMD"
					},
				{ widgetType = "end_group"},
			{ widgetType = "end_rect", additionalSize = 12, rounding = 5 }, { widgetType = "unindent", width = 20 },
			{ widgetType = "new_line" },
			{ widgetType = "indent", width = 20 }, { widgetType = "text", label = "UI" }, { widgetType = "begin_rect", },
				expandArray(ui.getConfigurationWidgets),
			{ widgetType = "end_rect", additionalSize = 12, rounding = 5 }, { widgetType = "unindent", width = 20 },
			{ widgetType = "new_line" },
			{ widgetType = "indent", width = 20 }, { widgetType = "text", label = "Reticule" }, { widgetType = "begin_rect", },
				expandArray(reticule.getConfigurationWidgets,{{id="uevr_reticule_update_distance", initialValue=200}, {id="uevr_reticule_eye_dominance_offset", initialValue=63.0, isHidden=false}}),
			{ widgetType = "end_rect", additionalSize = 12, rounding = 5 }, { widgetType = "unindent", width = 20 },
			{ widgetType = "new_line" },
		}
	}
}

--increase the number of save game slots
local function applySaveSlotLimit()
	local saveGameSettings = uevrUtils.find_default_instance("Class /Script/GameBase.SaveGameSettings")
	if saveGameSettings == nil then
		return
	end

	print("Current max save slots", saveGameSettings.MaxSaveSlotsNumber)

	local autoSaveSlots = saveGameSettings.AutoSaveSlotsNumber or 0
	local targetMaxSlots = desiredManualSaveSlots + autoSaveSlots
	if saveGameSettings.MaxSaveSlotsNumber ~= targetMaxSlots then
		saveGameSettings.MaxSaveSlotsNumber = targetMaxSlots
		print("Updated manual save slots to", desiredManualSaveSlots, "total slots", targetMaxSlots)
	end
end

applySaveSlotLimit()

local function getGameUserSettings()
	if status.gameUserSettings ~= nil and uevrUtils.getValid(status.gameUserSettings) ~= nil then
		return status.gameUserSettings
	end

	local gameUserSettingsClass = uevrUtils.find_default_instance("Class /Script/Engine.GameUserSettings")
	if gameUserSettingsClass ~= nil and gameUserSettingsClass.GetGameUserSettings ~= nil then
		status.gameUserSettings = gameUserSettingsClass:GetGameUserSettings()
	end

	if status.gameUserSettings == nil then
		status.gameUserSettings = (uevrUtils.find_all_of("Class /Script/GameBase.BGameUserSettings", false) or {})[1]
	end

	return uevrUtils.getValid(status.gameUserSettings)
end

local function getPlayerProfile()
	if status.playerProfile ~= nil and uevrUtils.getValid(status.playerProfile) ~= nil then
		return status.playerProfile
	end

	local world = uevrUtils.getWorld()
	if world == nil then
		return nil
	end

	status.gameBaseStatics = status.gameBaseStatics or uevrUtils.find_default_instance("Class /Script/GameBase.GameBaseStatics")
	if status.gameBaseStatics ~= nil and status.gameBaseStatics.GetPlayerProfile ~= nil then
		status.playerProfile = status.gameBaseStatics:GetPlayerProfile(world)
	end

	return uevrUtils.getValid(status.playerProfile)
end

local function savePlayerProfile()
	local world = uevrUtils.getWorld()
	if world == nil then
		return false
	end

	status.gameBaseStatics = status.gameBaseStatics or uevrUtils.find_default_instance("Class /Script/GameBase.GameBaseStatics")
	if status.gameBaseStatics == nil or status.gameBaseStatics.SaveUserProfile == nil then
		return false
	end

	status.gameBaseStatics:SaveUserProfile(world)
	return true
end

local function setSprintToggleEnabled(enabled, saveProfile)
	local playerProfile = getPlayerProfile()
	if playerProfile == nil then
		return false
	end

	playerProfile.SprintToggleable = enabled == true

	if saveProfile ~= false then
		savePlayerProfile()
	end

	return true
end

local function applyRaytracingMode(mode, updateSettings)
	local raytracingMode = mode
	if raytracingMode == nil then raytracingMode = RaytracingMode.Off end

	local enabled = raytracingMode ~= RaytracingMode.Off

	if updateSettings == true then
		local playerProfile = getPlayerProfile()
		if playerProfile ~= nil and playerProfile.GFXSettings ~= nil then
			local profileSettings = playerProfile.GFXSettings
			profileSettings.Raytracing = raytracingMode
			playerProfile.GFXSettings = profileSettings
		end

		local gameUserSettings = getGameUserSettings()
		if gameUserSettings ~= nil and gameUserSettings.GFXSettings ~= nil then
			local gfxSettings = gameUserSettings.GFXSettings
			gfxSettings.Raytracing = raytracingMode
			gameUserSettings.GFXSettings = gfxSettings
			if gameUserSettings.ApplyNonResolutionSettings ~= nil then
				gameUserSettings:ApplyNonResolutionSettings()
			end
			if gameUserSettings.SaveSettings ~= nil then
				gameUserSettings:SaveSettings()
			end
		end

		status.rendererSettings = status.rendererSettings or uevrUtils.find_default_instance("Class /Script/Engine.RendererSettings")
		if status.rendererSettings ~= nil then
			status.rendererSettings.bEnableRayTracing = enabled
			status.rendererSettings.bUseHardwareRayTracingForLumen = enabled
		end
	end

	uevrUtils.set_cvar_int("r.RayTracing", enabled and 1 or 0)
	uevrUtils.set_cvar_int("r.Lumen.HardwareRayTracing", enabled and 1 or 0)
	uevrUtils.set_cvar_int("r.Lumen.Reflections.HardwareRayTracing", enabled and 1 or 0)
	uevrUtils.set_cvar_int("r.LumenScene.Radiosity.HardwareRayTracing", enabled and 1 or 0)
	uevrUtils.set_cvar_int("r.Lumen.RadianceCache.HardwareRayTracing", enabled and 1 or 0)

	return raytracingMode
end

local function cleanup()
    status = {}
end

local function regenerateHands(value)
    hands.setAutoCreateHands(value == HandsType.Forearms)
    ik.setAutoCreateArms(value == HandsType.IKArms)

    hands.destroyHands()
    ik.destroyAll()
end

ik.registerOnMeshCreatedCallback(function(meshComponentList, ikInstance)
     for i, meshComponent in ipairs(meshComponentList or {}) do
		--These hide the arms but not the shadows and flashlight is still blocked even with arms hidden
		-- meshComponent:SetRenderInMainPass(false)
		-- meshComponent:SetRenderInDepthPass(false)
		-- meshComponent:SetVisibility(false)

		--uncomment this to have the arms not cast shadows (and not block the flashlight)
		--meshComponent.bCastDynamicShadow = false
     end
end)
ik.registerOnDestroyCallback(function(ikInstance)
	--detach attachments first so they dont get "lost" when hands are destroyed
	attachments.detachGripAttachments(Handed.Right)
	attachments.detachGripAttachments(Handed.Left)
end)

hands.registerOnDestroyCallback(function()
	--detach attachments first so they dont get "lost" when hands are destroyed
	attachments.detachGripAttachments(Handed.Right)
	attachments.detachGripAttachments(Handed.Left)
end)

local function hideHead(val)
	if uevrUtils.getValid(pawn,{"Mesh"}) ~= nil then
		if val and configui.getValue("hide_head") == true then
			pawn.Mesh:HideBoneByName(uevrUtils.fname_from_string("neck_02_bn"), 0)
		else
			pawn.Mesh:UnHideBoneByName(uevrUtils.fname_from_string("neck_02_bn"))
		end
	else
		delay(2000, function() hideHead(val) end)
	end
end
configui.onCreateOrUpdate("hide_head", function(value)
    hideHead(value)
end)

configui.onCreateOrUpdate("hands_type", function(value)
    regenerateHands(value)
end)

function on_cutscene_change(isInCutscene)
    pawnModule.hideArmsBones(not isInCutscene)
    hideHead(not isInCutscene)
	melee.disable(isInCutscene)
    openLatch.on_cutscene_change(isInCutscene)
    remoteGrab.on_cutscene_change(isInCutscene)
    pcall(function() itemDoor.on_cutscene_change(isInCutscene) end)
end

local function getHandedNess()
	local handednessType = configui.getValue("handedness_type")
	if handednessType == 1 then
		return Handed.Left
	elseif handednessType == 2 then
		return Handed.Right
	end
	return Handed.Right
end

local function resetAttachment()
	local attachmentData = attachments.getCurrentGrippedAttachmentData(getHandedNess())
	if attachmentData ~= nil and attachmentData.attachment ~= nil and attachmentData.attachment.RelativeLocation ~= nil and attachmentData.attachment.RelativeLocation.X == 0 and attachmentData.attachment.RelativeLocation.Y == 0 and attachmentData.attachment.RelativeLocation.Z == 0 then
		local loc, rot, scale = attachments.getAttachmentOffset(attachmentData.attachment)
		local attachmentID = attachments.getAttachmentIDFromAttachment(attachmentData.attachment)
		attachments.updateAttachmentTransform(loc, rot, scale, attachmentID)
	end
end

local function attachLightToController(light)
	if uevrUtils.getValid(light) ~= nil then
		if configui.getValue("light_type") == 1 then
			local lightState = UEVR_UObjectHook.get_or_add_motion_controller_state(light)
			lightState:set_hand(2) -- head
			lightState:set_permanent(false)
			lightState:set_rotation_offset(temp_vec3f:set(0.0, 0.0, 0.0))
			lightState:set_location_offset(temp_vec3f:set(0.0, 0.0, 0.0))
		elseif configui.getValue("light_type") == 2 then
			UEVR_UObjectHook.remove_motion_controller_state(light)
			local lightState = UEVR_UObjectHook.get_or_add_motion_controller_state(light)
			lightState:set_hand(1-getHandedNess()) -- off hand
			lightState:set_permanent(false)
			lightState:set_rotation_offset(temp_vec3f:set(0.38, -0.59, 0.0))
			lightState:set_location_offset(temp_vec3f:set(-2.4, -6.8, -0.8))
			status.lightState = lightState
		elseif configui.getValue("light_type") == 3 then
			UEVR_UObjectHook.remove_motion_controller_state(light)
			local lightState = UEVR_UObjectHook.get_or_add_motion_controller_state(light)
			lightState:set_hand(getHandedNess()) -- off hand
			lightState:set_permanent(false)
			lightState:set_rotation_offset(temp_vec3f:set(0.13, 0.265, 0.0))
			lightState:set_location_offset(temp_vec3f:set(-2.4, -8.9, -0.8))
			status.lightState = lightState
		end
	end
end

local function getFlashlightMesh()
    if pawn == nil then return nil end

	if status.flashlight ~= nil and status.flashlight.flashlightMesh ~= nil and uevrUtils.getValid(status.flashlight.flashlightMesh) ~= nil then
		return status.flashlight.flashlightMesh
	end

	local equipmentActors = uevrUtils.getValid(pawn, {"Items", "EquipmentActors"})
	if equipmentActors ~= nil then
		for _, actor in ipairs(equipmentActors) do
			if actor:is_a(uevrUtils.get_class("Class /Script/SHProto.SHFlashlight")) then
				status.flashlight = {}
				status.flashlight.flashlightMesh = actor.Mesh

				local light = actor.LightMain
				if light ~= nil then
					attachLightToController(light)
				end
				status.flashlight.lightMesh = light

				local lightShaft = actor.Lightshaft
				if lightShaft ~= nil then
					lightShaft:SetRenderInMainPass(false)
					-- lightShaft:K2_AttachTo(status.flashlight.flashlightMesh, uevrUtils.fname_from_string(""), 0, false)
					-- uevrUtils.set_component_relative_transform(lightShaft, uevrUtils.vector(configui.getValue("light_shaft_location")), uevrUtils.rotator(configui.getValue("light_shaft_rotation")))
				end
				status.flashlight.lightShaftMesh = lightShaft

				return status.flashlight.flashlightMesh
			end
		end
	end
    return nil
end

local function getWeaponMesh()
    local equippedWeapon = uevrUtils.getValid(pawn, {"Mesh", "AnimScriptInstance", "WeaponManageCmbSubcomp", "EquippedWeapon"})
	local weaponType = "none"
	if equippedWeapon ~= nil then
		if equippedWeapon.AutoAimMaxRange ~= nil then
			equippedWeapon.AutoAimMaxRange = 1.0
		end
		local weaponName = equippedWeapon:get_full_name()
		if uevrUtils.startsWith(weaponName, "WeaponPistol") then
			status.currentReticuleOffset = 3
			weaponType = "pistol"
		elseif uevrUtils.startsWith(weaponName, "WeaponShotgun") then
			status.currentReticuleOffset = 5
			weaponType = "shotgun"
		elseif uevrUtils.startsWith(weaponName, "WeaponRifle") then
			status.currentReticuleOffset = 6
			weaponType = "rifle"
		end
		--print("Equipped weapon", equippedWeapon:get_full_name())
	end

	-- 发布武器类型与武器对象到全局，供其他模块读取（避免各自重复链式查询）
	_G[vr_globals.KEYS.current_weapon_type] = weaponType
	_G[vr_globals.KEYS.equipped_weapon] = equippedWeapon

	local weaponMesh = uevrUtils.getValid(equippedWeapon, {"Mesh"})

	status.currentEquippedWeapon = equippedWeapon


    if weaponMesh == nil then
        --try to get investigation items
        -- 步枪/霰弹弹药 E 后会进 ItemContext（手枪是 TakeItem 不进）；跳过以免挂右手
        local contextMesh = uevrUtils.getValid(pawn, {"Items", "ItemExecutive", "ItemContext", "Mesh"})
		if contextMesh ~= nil then
			local skip = false
			pcall(function()
				local n = ""
				if contextMesh.StaticMesh ~= nil then
					n = contextMesh.StaticMesh:get_full_name() or ""
				end
				if n == "" then
					n = contextMesh:get_full_name() or ""
				end
				n = string.lower(n)
				skip = string.find(n, "shotgunammo", 1, true) ~= nil
					or string.find(n, "sniperrifleammo", 1, true) ~= nil
			end)
			if skip then
				contextMesh = nil
			end
		end
		weaponMesh = contextMesh
		if weaponMesh ~= status.currentWeaponMesh then
			-- if weaponMesh ~= nil then
			-- 	print("New Weapon mesh found", weaponMesh:get_full_name(), weaponMesh.StaticMesh and weaponMesh.StaticMesh:get_full_name() or "no static mesh", weaponMesh.SkeletalMesh and weaponMesh.SkeletalMesh:get_full_name() or "no skeletal mesh")
			-- end
			status.currentWeaponMesh = weaponMesh
			status.updateAttachmentTransform = true
			delay(1000, function()
				status.updateAttachmentTransform = false
			end)
		end
    end
    return weaponMesh
end

local function getEquippedWeapon(currentPawn)
	return uevrUtils.getValid(currentPawn, {"Mesh", "AnimScriptInstance", "WeaponManageCmbSubcomp", "EquippedWeapon"})
end

local defaultAttachOptions = {
	detachFromOriginOnGrip = true,
	maintainWorldPositionOnDetachFromOrigin = false,
	detachFromParentOnRelease = true,
	maintainWorldPositionOnDetachFromParent = false,
	reattachToOriginOnRelease = true,
	restoreTransformToOriginOnReattach = true,
	useZeroTransformOnReattach = false,
	allowChildVisibilityHandling = false,
	allowChildHiddenInGameHandling = false,
	allowRenderInMainPassHandling = false,
}

attachments.registerOnGripUpdateCallback(function()
	if uevrUtils.isInCutscene() then return nil end

    local weaponMesh = getWeaponMesh()
	local flashlightMesh = getFlashlightMesh()
	if configui.getValue("light_type") == 1 or configui.getValue("light_type") == 3 then
		flashlightMesh = nil
	end
	accessories.setDisabled(not configui.getValue("offhand_grip_weapon") or flashlightMesh ~= nil)

    local rightHandComponent = nil
   	local leftHandComponent = nil
    if configui.getValue("hands_type") == HandsType.None then
        rightHandComponent = controllers.getController(Handed.Right)
        leftHandComponent = controllers.getController(Handed.Left)
    elseif configui.getValue("hands_type") == HandsType.Forearms then
        rightHandComponent = hands.getHandComponent(Handed.Right)
        leftHandComponent = hands.getHandComponent(Handed.Left)
    elseif configui.getValue("hands_type") == HandsType.IKArms then
        rightHandComponent = ik.getCurrentMesh()
		leftHandComponent = ik.getCurrentMesh()
    end

    local weaponAttachSocket = "hand_r_bn" 
	local flashlightAttachSocket = "hand_l_bn"
    --print( weaponMesh, rightHandComponent, weaponAttachSocket, flashlightMesh, leftHandComponent, flashlightAttachSocket)
    return rightHandComponent and weaponMesh, rightHandComponent, weaponAttachSocket, leftHandComponent and flashlightMesh, flashlightMesh and leftHandComponent, flashlightAttachSocket, defaultAttachOptions --, controllers.getController(Handed.Right)
end)

local snapTurnState = {
	rxState = 0,
	deadZone = 20000,
}

local smoothTurnState = {
	deadZone = 4000,
	degreesPerSecond = 180,
}

local leftStickDoubleTapState = {
	forward = {
		isPressed = false,
		lastTapTime = nil,
		pressThreshold = 24000,
		releaseThreshold = 18000,
	},
	backward = {
		isPressed = false,
		lastTapTime = nil,
		pressThreshold = -20000,
		releaseThreshold = -12000,
	},
	doubleTapWindow = 0.35,
}

local fixedOrbitCameraPitch = -20.0

local function getLocalPawn()
	local currentPawn = uevrUtils.get_local_pawn()
	if uevrUtils.getValid(currentPawn) == nil then
		return nil
	end
	return currentPawn
end

local function isPawnTraversing(currentPawn)
	if currentPawn == nil then
		return false
	end

	local activeTraversal = uevrUtils.getValid(currentPawn, {"Traversal", "CurrentlyPlayingTraversal"})
	if activeTraversal == nil then
		return false
	end
	print("Active traversal type", activeTraversal.Type)
	return activeTraversal.Type == TraversalType.Vault or activeTraversal.Type == TraversalType.Climb
end

local function applyFaceAwayFromCamera(currentPawn)
	if currentPawn == nil or currentPawn.View == nil or currentPawn.Movement == nil then
		return
	end

	local viewRotation = currentPawn.View:GetViewRotation()
	if viewRotation == nil then
		return
	end

	local yawOffset = configui.getValue("camera_relative_rotation") or 0
	local targetRotation = uevrUtils.rotator(0, viewRotation.Yaw + yawOffset, 0)
	currentPawn.Movement:RotationSnapAbsoluteStatic(targetRotation, 0.0, currentPawn, nil)
end

local function handleSnapTurnInput(state)
	if configui.getValue("use_snap_turn") ~= true then
		snapTurnState.rxState = 0
		return
	end

	if state == nil or state.Gamepad == nil then
		snapTurnState.rxState = 0
		return
	end

	local currentPawn = getLocalPawn()
	if currentPawn == nil or currentPawn.View == nil then
		snapTurnState.rxState = 0
		return
	end

	local thumbRX = state.Gamepad.sThumbRX or 0
	local turnStep = nil
	if thumbRX >= snapTurnState.deadZone then
		state.Gamepad.sThumbRX = 0
		if snapTurnState.rxState == 0 then
			turnStep = configui.getValue("snap_turn_angle") or 30
			snapTurnState.rxState = 1
		end
	elseif thumbRX <= -snapTurnState.deadZone then
		state.Gamepad.sThumbRX = 0
		if snapTurnState.rxState == 0 then
			turnStep = -(configui.getValue("snap_turn_angle") or 30)
			snapTurnState.rxState = -1
		end
	else
		snapTurnState.rxState = 0
	end

	if turnStep == nil or currentPawn.View.GetViewRotation == nil or currentPawn.View.OverrideControlRotation == nil then
		return
	end

	local viewRotation = currentPawn.View:GetViewRotation()
	if viewRotation == nil then
		return
	end

	if status.turnStep == nil then status.turnStep = 0 end
	status.turnStep = status.turnStep + turnStep
end

local function handleSmoothTurnInput(state)
	if configui.getValue("use_snap_turn") == true then
		status.turnAxisX = 0
		return
	end

	if state == nil or state.Gamepad == nil then
		status.turnAxisX = 0
		return
	end

	local thumbRX = state.Gamepad.sThumbRX or 0
	if math.abs(thumbRX) < smoothTurnState.deadZone then
		status.turnAxisX = 0
		return
	end

	status.turnAxisX = thumbRX / 32767.0
	state.Gamepad.sThumbRX = 0
end

local function getLeftStickDoubleTapDirection(state)
	if state == nil or state.Gamepad == nil then
		leftStickDoubleTapState.forward.isPressed = false
		leftStickDoubleTapState.backward.isPressed = false
		return false, false
	end

	local thumbLY = state.Gamepad.sThumbLY or 0
	local currentTime = os.clock()
	local wasTappedForward = false
	local wasTappedBackward = false

	local isPressedForward = thumbLY >= leftStickDoubleTapState.forward.pressThreshold
	local isReleasedForward = thumbLY <= leftStickDoubleTapState.forward.releaseThreshold
	if isPressedForward and not leftStickDoubleTapState.forward.isPressed then
		leftStickDoubleTapState.forward.isPressed = true
		if leftStickDoubleTapState.forward.lastTapTime ~= nil and currentTime - leftStickDoubleTapState.forward.lastTapTime <= leftStickDoubleTapState.doubleTapWindow then
			leftStickDoubleTapState.forward.lastTapTime = nil
			wasTappedForward = true
		else
			leftStickDoubleTapState.forward.lastTapTime = currentTime
		end
	elseif isReleasedForward then
		leftStickDoubleTapState.forward.isPressed = false
	end

	local isPressedBackward = thumbLY <= leftStickDoubleTapState.backward.pressThreshold
	local isReleasedBackward = thumbLY >= leftStickDoubleTapState.backward.releaseThreshold
	if isPressedBackward and not leftStickDoubleTapState.backward.isPressed then
		leftStickDoubleTapState.backward.isPressed = true
		if leftStickDoubleTapState.backward.lastTapTime ~= nil and currentTime - leftStickDoubleTapState.backward.lastTapTime <= leftStickDoubleTapState.doubleTapWindow then
			leftStickDoubleTapState.backward.lastTapTime = nil
			wasTappedBackward = true
		else
			leftStickDoubleTapState.backward.lastTapTime = currentTime
		end
	elseif isReleasedBackward then
		leftStickDoubleTapState.backward.isPressed = false
	end

	return wasTappedForward, wasTappedBackward
end

--wont callback unless an uevrUtils.updateDeferral("is_gripping_light") hasnt been called in the last 300ms
uevrUtils.createDeferral("is_gripping_light", 300, function()
    status["isGrippingLight"] = false
end)

uevrUtils.registerOnPreInputGetStateCallback(function(retval, user_index, state)
    if not ui.isRemapDisabled() then
        if state.Gamepad.sThumbRY < -20000 then
            uevrUtils.pressButton(state, XINPUT_GAMEPAD_B)
        end
        state.Gamepad.sThumbRY = 0 --disable pitching the orbiting camera

	    handleSnapTurnInput(state)
		handleSmoothTurnInput(state)

		if configui.getValue("interaction_control_mode") == 2 then
			local handed = getHandedNess()
			local isEating, isGrabbingGlasses, gripHead, isGrabbingEar, triggerMouth, isScratchingEyes, triggerHead, isScratchingEar = gestures.getHeadGestures(state, 1-handed, false)
			local isEatingRight, isGrabbingGlassesRight, gripHeadRight, isGrabbingEarRight, triggerMouthRight, isScratchingEyesRight, triggerHeadRight, isScratchingEarRight = gestures.getHeadGestures(state, handed, false)

			local sprintMode = configui.getValue("interaction_sprint_mode")
			local wasTappedForward, wasTappedBackward = getLeftStickDoubleTapDirection(state)
			local leftGripPressed = uevrUtils.isButtonPressed(state, XINPUT_GAMEPAD_LEFT_SHOULDER)
			local rightGripPressed = uevrUtils.isButtonPressed(state, XINPUT_GAMEPAD_RIGHT_SHOULDER)
			local leftStickPressed = uevrUtils.isButtonPressed(state, XINPUT_GAMEPAD_LEFT_THUMB)
			local rightStickPressed = uevrUtils.isButtonPressed(state, XINPUT_GAMEPAD_RIGHT_THUMB)
			local leftTriggerPressed = state.Gamepad.bLeftTrigger >= 128
			if (sprintMode == 3 and wasTappedForward) or ((sprintMode == 1 or sprintMode == 2) and leftStickPressed) then --leftStickPressed then
				uevrUtils.pressButton(state, XINPUT_GAMEPAD_LEFT_SHOULDER)
			else
				uevrUtils.unpressButton(state, XINPUT_GAMEPAD_LEFT_SHOULDER)
			end

			if wasTappedBackward then
				uevrUtils.pressButton(state, XINPUT_GAMEPAD_RIGHT_SHOULDER)
			else
				uevrUtils.unpressButton(state, XINPUT_GAMEPAD_RIGHT_SHOULDER)
    		end

			--flashlight
			if gripHead and status["isGrippingLight"] ~= true then
				configui.setValue("light_type", configui.getValue("light_type") == 1 and 2 or 1)
				status["isGrippingLight"] = true
			elseif gripHeadRight and status["isGrippingLight"] ~= true then
				configui.setValue("light_type", configui.getValue("light_type") == 1 and 3 or 1)
				status["isGrippingLight"] = true
			else
				if leftTriggerPressed then
					uevrUtils.pressButton(state, XINPUT_GAMEPAD_RIGHT_THUMB)
				else
					uevrUtils.unpressButton(state, XINPUT_GAMEPAD_RIGHT_THUMB)
				end
			end
			--prevent flapping between light states by only allowing grip to trigger light state change once every 300ms, the deferral will reset the "isGrippingLight" status after 300ms allowing it to be triggered again
			if gripHead or gripHeadRight then
				uevrUtils.updateDeferral("is_gripping_light")
			end
			-- end flashlight

			
			-- aim gun（空仓挂机 g_slide_locked 时不注入 LT，避免 AnimBP 空弹+瞄准换弹混合）
			if rightGripPressed and rawget(_G, "g_slide_locked") ~= true then
				state.Gamepad.bLeftTrigger = 255
			else
				state.Gamepad.bLeftTrigger = 0
			end
			--end aim
			

			if uevrUtils.isButtonPressed(state, XINPUT_GAMEPAD_RIGHT_SHOULDER) then
				status.turnStep = (status.turnStep or 0) + 180
			end

		elseif configui.getValue("interaction_control_mode") == 1 then
			--prevent continuous 180 turn in vanilla mode
			if uevrUtils.isButtonPressed(state, XINPUT_GAMEPAD_RIGHT_SHOULDER) then
				if status.lock180Turn ~= true then
					status.lock180Turn = true
					status.turnStep = (status.turnStep or 0) + 180
				end
			else
				status.lock180Turn = false
			end

		end

	end
end, 5)

configui.onCreateOrUpdate("use_snap_turn", function(enabled)
	snapTurnState.rxState = 0
	status.turnAxisX = 0
	status.lastViewRotationYaw = nil
	if enabled == true then
		uevrUtils.enableSnapTurn(false)
	end
	configui.setHidden("snap_turn_angle", enabled ~= true)
end)

--The normal handler for this is being overridden somehow
ui.registerWidgetChangeCallback("GameplayEndGame_WidgetBP_C", function(active)
	if active then
		delay(200, function()
			uevrUtils.fadeCamera(0.1, true)
		end)
	else
		uevrUtils.stopFadeCamera()
	end
end)

uevr.sdk.callbacks.on_pre_engine_tick(function(engine, delta)
	local currentPawn = getLocalPawn()
	if currentPawn == nil then
		return
	end

	if not ui.isInputDisabled() then
		applyFaceAwayFromCamera(currentPawn)
	end

	local camera_overlap = currentPawn.CameraOverlapHandler
    if camera_overlap ~= nil then
        if camera_overlap:IsComponentTickEnabled() then
            camera_overlap:SetComponentTickEnabled(false) -- Stops camera from making pawn and other things near it invisible
            --print("Disabled camera overlap handler")
        end

        camera_overlap.OwnerCharacterPlay = nil -- Nulls out the owner actor, this stops some logic from functioning when we start aiming which hides the pawn
    end

	-- This is what the game uses to signify a cutscene is in progress
	if status.characterStatics == nil then
		status.characterStatics = uevrUtils.find_default_instance("Class /Script/SHProto.SHCharacterStatics")
	end
	if status.characterStatics ~= nil then
		local isInCutscene = status.characterStatics:IsCharacterInCutscene(currentPawn)
		if status.isInCutscene ~= isInCutscene then
			local skipNotify = status.isInCutscene == nil and isInCutscene == false --dont trigger cutscene state change on first tick if not in cutscene, in case another system thinks we are in a cutscene
			status.isInCutscene = isInCutscene
			if skipNotify == false then
				--print("Cutscene state changed from characterStatics", status.isInCutscene)
				uevrUtils.setIsInCutsceneOverride(status.isInCutscene)
				if status.isInCutscene == false then
					status.currentGameplayInputMode = 0
					if not ui.isFadeCameraEnabled() then
						uevrUtils.stopFadeCamera()
					end
				end
			end
		end
	else
		print("Could not find character statics for cutscene detection")
	end

	if currentPawn.GetGameplayInputMode ~= nil then
		local currentGameplayInputMode = currentPawn:GetGameplayInputMode()
		if status.currentGameplayInputMode ~= currentGameplayInputMode then
			status.currentGameplayInputMode = currentGameplayInputMode
			if uevrUtils.getValid(currentPawn, {"Items", "ItemExecutive"}) == nil and status.isPushing ~= true and status.isTraversing ~= true then
				--print("Cutscene state changed from GetGameplayInputMode", currentGameplayInputMode == 1, currentGameplayInputMode)
				uevrUtils.setIsInCutsceneOverride(currentGameplayInputMode == 1)
			end
		end
	end

	-- We have to disable roomscale movement during the "Pushing" animations or the game will prevent the task from ever being completed
	if currentPawn.Movement ~= nil then
		if status.isPushing ~= (currentPawn.Movement.PushableComponent ~= nil) then
			status.isPushing = (currentPawn.Movement.PushableComponent ~= nil)
			uevrUtils.setIsInCutsceneOverride(status.isPushing)
			if status.isPushing then
				status.isRoomscale = uevrUtils.getUEVRParam_bool("VR_RoomscaleMovement")
				uevrUtils.setUEVRParam("VR_RoomscaleMovement", "false")
			elseif status.isRoomscale ~= nil then
				uevrUtils.setUEVRParam("VR_RoomscaleMovement", status.isRoomscale == true and "true" or "false")
				status.isRoomscale = nil
			end
		end
	end

	--invincibility
	-- local health = uevrUtils.getValid(currentPawn, {"Health"})
	-- if health ~= nil then
	-- 	health.HealthValue = 100
	-- end

end)

--This gets the source location and rotation for the reticle. The game must internally handle the RegisteredFirePoint yaw offset when firing
--because just using the raw rotation doesn't work for reticule aiming and must be offset manually
reticule.registerCustomTargetCallback(function()
	if uevrUtils.getValid(status.currentEquippedWeapon) ~= nil and status.currentEquippedWeapon.RootComponent ~= nil and status.currentEquippedWeapon.RootComponent.K2_GetComponentLocation ~= nil and status.currentEquippedWeapon.RegisteredFirePoint ~= nil then
		local loc = status.currentEquippedWeapon.RootComponent:K2_GetComponentLocation()
		local rot = status.currentEquippedWeapon.RootComponent:K2_GetComponentRotation()
		local offsetYaw = status.currentEquippedWeapon.RegisteredFirePoint.RelativeRotation
		rot = mathLib.composeRotators(uevrUtils.rotator(offsetYaw.Pitch, offsetYaw.Yaw + 90, offsetYaw.Roll), rot)

		local vector = uevrUtils.rotateVector(uevrUtils.vector(0,0,status.currentReticuleOffset or 0), rot)
		loc = loc + vector

		return loc, rot
	end
	return uevrUtils.vector(0,0,0), uevrUtils.rotator(0,0,0)
end)

uevr.sdk.callbacks.on_post_engine_tick(function(engine, delta)
	local currentPawn = getLocalPawn()
	if currentPawn == nil then
		return
	end

	-- The game tries to change the relative offset of attachments for a short period during activation so this overrides that
	if status.updateAttachmentTransform == true then
		resetAttachment()
	end

	--This is what aims the ranged weapons
	-- 右手针剂占用附着位时不要同步：否则武器 Root 会被拽到针剂变换上（可见+歪）
	-- Root 读 Mesh 世界姿态（双手激活时 Mesh 已由 WeaponDriver 驱动）+ recoil。
	if rawget(_G, vr_globals.KEYS.heal_right_prop_active) ~= true
		and uevrUtils.getValid(status.currentEquippedWeapon) ~= nil
		and status.currentEquippedWeapon.RootComponent ~= nil
		and status.currentEquippedWeapon.RootComponent.K2_SetWorldLocation ~= nil then
		local weapon = status.currentEquippedWeapon
		local root = weapon.RootComponent

		local recoil_active = false
		pcall(function() recoil_active = recoil.is_active() == true end)

		local hands_type = configui.getValue("hands_type") or HandsType.None
		local use_forearms_bone = (hands_type == HandsType.Forearms)

		local hand_comp = nil
		if use_forearms_bone then
			pcall(function()
				if type(recoil.resolve_right_hand_component) == "function" then
					hand_comp = recoil.resolve_right_hand_component()
				end
			end)
			-- Forearms：写骨前还原，保证 attachment 基准干净
			if recoil_active then
				pcall(function()
					recoil.cache_hand_bone_base(hand_comp)
					recoil.restore_hand_bone_base(hand_comp)
				end)
			elseif recoil.hand_needs_restore and recoil.hand_needs_restore() then
				pcall(function() recoil.finish_hand_recoil(hand_comp) end)
			end
		elseif recoil.hand_needs_restore and recoil.hand_needs_restore() then
			-- 切离 Forearms 时清掉残留骨偏移
			pcall(function() recoil.finish_hand_recoil(nil) end)
		end

		local location, rotation = attachments.getActiveAttachmentTransforms(getHandedNess())

		-- 双手 WeaponDriver：可见 Mesh 已含完整后坐 → Root 只跟 Mesh+offsets，勿二次叠加。
		-- IK Arms：可视旋转已在求解器 compose_visual_rotation 写入 hand_r_bn，
		-- Root 只补位置 kick，避免旋转双重叠加。
		-- Forearms / 无 IK 合成：走完整 apply_to_aim_transform。
		local mesh_owns_recoil = false
		pcall(function()
			mesh_owns_recoil = recoil.two_hand_mesh_owns_recoil and recoil.two_hand_mesh_owns_recoil() == true
		end)
		if mesh_owns_recoil then
			pcall(function()
				if recoil.clear_visual_rotation_flag then recoil.clear_visual_rotation_flag() end
			end)
		else
			local visual_rot_done = false
			pcall(function()
				visual_rot_done = recoil.was_visual_rotation_applied and recoil.was_visual_rotation_applied() == true
			end)
			if visual_rot_done and type(recoil.apply_position_kick_only) == "function" then
				location, rotation = recoil.apply_position_kick_only(location, rotation)
				pcall(function() recoil.clear_visual_rotation_flag() end)
			else
				location, rotation = recoil.apply_to_aim_transform(location, rotation)
				pcall(function()
					if recoil.clear_visual_rotation_flag then recoil.clear_visual_rotation_flag() end
				end)
			end
		end

		-- Root：瞄准 / FirePoint（世界变换）；写入全程 pcall，避免坏 UObject 闪退
		local write_ok = pcall(function()
			local lx = location.X
			local ly = location.Y
			local lz = location.Z
			local rp = rotation.Pitch
			local ry = rotation.Yaw
			local rr = rotation.Roll
			if type(lx) ~= "number" or lx ~= lx
				or type(ly) ~= "number" or ly ~= ly
				or type(lz) ~= "number" or lz ~= lz
				or type(rp) ~= "number" or rp ~= rp
				or type(ry) ~= "number" or ry ~= ry
				or type(rr) ~= "number" or rr ~= rr
				or math.abs(lx) >= 1e8 or math.abs(ly) >= 1e8 or math.abs(lz) >= 1e8 then
				error("non_finite_transform")
			end
			root:K2_SetWorldLocation(location, false, reusable_hit_result, false)
			root:K2_SetWorldRotation(rotation, false, reusable_hit_result, false)
		end)
		-- Forearms 可视后座：hand_r_bn ComponentSpace（IK Arms 走 compose；双手 Mesh 仍可震右手）
		if use_forearms_bone and recoil_active and write_ok then
			pcall(function()
				if type(recoil.apply_hand_bone_recoil) == "function" then
					recoil.apply_hand_bone_recoil(hand_comp)
				end
			end)
		end
	else
		pcall(function() weaponTwoHand.on_inactive_frame() end)
	end

    if currentPawn.View ~= nil and not ui.isViewLocked() then
		uevr.params.vr.get_pose(uevr.params.vr.get_hmd_index(), temp_vec3f, temp_quatf)
		local poseQuat = uevrUtils.quat(temp_quatf.Z, temp_quatf.X, -temp_quatf.Y, -temp_quatf.W)  --reordered terms to convert UEVR to unreal coord system
		local hmdRotation = kismet_math_library:Quat_Rotator(poseQuat)

		status.currentHMDYaw = hmdRotation.Yaw
		uevr.params.vr.recenter_view()

		if configui.getValue("movement_type") == 1 then
			status.currentHMDYaw = 0
		end

		local turnDelta = 0
		if configui.getValue("use_snap_turn") then
			turnDelta = (status.turnStep or 0)
		else
			if status.turnStep == nil then
				status.turnStep = 0
			end
			status.turnStep = status.turnStep + ((status.turnAxisX or 0) * smoothTurnState.degreesPerSecond * (delta or 0))
			turnDelta = status.turnStep or 0
		end

		local deltaRotation = turnDelta - (status.currentHMDYaw or 0)
		currentPawn.View:OverrideControlRotation(
			uevrUtils.rotator(hmdRotation.Pitch, deltaRotation, hmdRotation.Roll), -- Pitch required for item indicators
			currentPawn
		)
	end

end)

setInterval(200, function()
    local springArm = uevrUtils.getValid(pawn, {"SpringArm"})
    if springArm ~= nil then
        springArm.bEnableCameraLag = configui.getValue("enable_spring_arm_lag")
        springArm.bEnableCameraRotationLag = configui.getValue("enable_spring_arm_rotationlag")
    end

	-- currently vaulting and climbing (not ladder)
	local isTraversing = isPawnTraversing(pawn)
	if status.isTraversing ~= isTraversing then
		local skipNotify = status.isTraversing == nil and isTraversing == false
		status.isTraversing = isTraversing
		if skipNotify == false then
			--print("Cutscene state changed from isTraversing", status.isInCutscene)
			uevrUtils.setIsInCutsceneOverride(status.isTraversing)
			if status.isTraversing == false then status.currentGameplayInputMode = 0 end
		end
	end

	--When map is showing use default button mappings
	local map = uevrUtils.getValid(pawn, {"Items", "ItemExecutive"})
	if map ~= nil and string.sub(map:get_full_name(), 1, 3) == "Map"  then
		ui.setCustomState("remapEnabled", false, 2)
	else
		ui.setCustomState("remapEnabled", nil)
	end

end)


local function getBlendDataOverride()
	local blendData = uevrUtils.get_struct_object("ScriptStruct /Script/SHProto.SHBlendData")
	if blendData == nil then
		return nil
	end

	blendData.BlendInTime = 0.0
	blendData.BlendInAlphaCurve = nil
	blendData.BlendOutTime = 0.0
	blendData.BlendOutAlphaCurve = nil
	return blendData
end


local function buildCenteredCameraData(sourceData)
	if sourceData == nil or sourceData.BlendData == nil then
		return nil
	end

	local blendData = getBlendDataOverride()
	if blendData == nil then
		return nil
	end

	local cameraData = uevrUtils.get_struct_object("ScriptStruct /Script/SHProto.SHCameraDataStruct")
	if cameraData == nil then
		return nil
	end

	cameraData.BlendData = blendData
	cameraData.ArmLengthFromPitchCurve = sourceData.ArmLengthFromPitchCurve
	cameraData.SocketOffsetFromPitchCurve = nil
	cameraData.TargetOffset = uevrUtils.vector(0, -45, sourceData.TargetOffset and sourceData.TargetOffset.Z or 0)
	cameraData.TargetOffsetExtraHeightFromPitchScale = sourceData.TargetOffsetExtraHeightFromPitchScale or 1.0
	cameraData.MovementForwardCameraLag = sourceData.MovementForwardCameraLag or 0.0
	cameraData.MovementNonForwardCameraLag = sourceData.MovementNonForwardCameraLag or 0.0
	cameraData.RotationLag = sourceData.RotationLag or 0.0
	return cameraData
end

local function getActiveCameraBlender(currentPawn)
	if currentPawn == nil or currentPawn.SpringArm == nil or currentPawn.View == nil then
		return nil
	end

	local viewRotation = currentPawn.View:GetViewRotation()
	if viewRotation == nil then
		return nil
	end

	local targetArmLength = currentPawn.SpringArm.TargetArmLength
	if targetArmLength == nil then
		return nil
	end

	local candidates = {
		currentPawn.SpringArm.InteriorCameraBlender,
		currentPawn.SpringArm.ExteriorSprintCameraBlender,
		currentPawn.SpringArm.InteriorSprintCameraBlender,
	}

	local bestBlender = nil
	local bestDiff = nil
	for _, blender in ipairs(candidates) do
		if blender ~= nil and blender.CameraData ~= nil and blender.CameraData.ArmLengthFromPitchCurve ~= nil then
			local curveValue = blender.CameraData.ArmLengthFromPitchCurve:GetFloatValue(viewRotation.Pitch)
			--local curveValue = blender.CameraData.ArmLengthFromPitchCurve:GetFloatValue(fixedOrbitCameraPitch)
			if curveValue ~= nil then
				local diff = math.abs(curveValue - targetArmLength)
				if bestDiff == nil or diff < bestDiff then
					bestDiff = diff
					bestBlender = blender
				end
			end
		end
	end

	return bestBlender
end

local function centerOrbitCamera(currentPawn)
	if currentPawn == nil or currentPawn.SpringArm == nil then
		return
	end

	local activeBlender = getActiveCameraBlender(currentPawn)
	if activeBlender == nil or activeBlender.CameraData == nil or activeBlender.CollisionData == nil then
		return
	end

	local centeredCameraData = buildCenteredCameraData(activeBlender.CameraData)
	local centeredCollisionData = buildCenteredCameraData(activeBlender.CollisionData)
	if centeredCameraData == nil or centeredCollisionData == nil then
		return
	end

	currentPawn.SpringArm:SetCustomCameraData(currentPawn, "CopilotCenteredOrbit", centeredCameraData, centeredCollisionData)
	currentPawn.SpringArm:RequestRefreshState(currentPawn)
end

local function fixRaytrace()
	if configui.getValue("enable_raytracing") ~= true and configui.getValue("fix_no_raytracing_visual_glitches") == true then
		applyRaytracingMode(RaytracingMode.On)
		delay(500, function()
			applyRaytracingMode(RaytracingMode.Off)
		end)
	end
end

function on_level_change(level)
    cleanup()
	applySaveSlotLimit()
    regenerateHands(configui.getValue("hands_type") or 1)
    hideHead(true)
	delay(3000, fixRaytrace)
	if configui.getValue("fix_orbit_camera_offset") == true then
		centerOrbitCamera(pawn)
	end
	accessories.setDisabled(configui.getValue("offhand_grip_weapon") == false)
    -- 2026-09-04 补修：关卡切换时强制置空全局 pawn ref，使下一 1s tick 无条件重广播当前 pawn 状态。
    -- 若 pawn 仍为 nil → 广播 pawn_nil，清掉刚 schedule 的 pending，杜绝过渡期(半加载世界)执行全图重建；
    -- 若 pawn 有效 → 广播 pawn_changed 重 schedule（三模块 pending 守卫去重，无双重建）。
    _G.__sh2_global_pawn_ref = nil
    openLatch.on_level_change(level)
    remoteGrab.on_level_change(level)
    pcall(function() itemDoor.on_level_change(level) end)
end

-- 统一 Pawn 检测（2026-09-04，方案A）：只在 main 集中检测一次 pawn 指针变化，
-- 向 remote_grab/unlock_door/unlock_item_door 广播 on_pawn_changed，消除三处重复 get_local_pawn。
-- 各模块自身的 5s 延迟重建 + 2s 重试状态机保留；重复广播由各模块 l1_rebuild_pending 守卫去重。
-- 修改说明：新增本函数用于统一 pawn 变化检测；不新增诊断日志（复用现有模块日志通路）。
local function check_pawn_globally()
    local p = nil
    pcall(function() p = uevrUtils.get_local_pawn() end)
    local ref = tostring(p)
    if ref == (_G.__sh2_global_pawn_ref or "") then return end
    _G.__sh2_global_pawn_ref = ref
    local reason = (p == nil) and "pawn_nil" or "pawn_changed"
    pcall(function() remoteGrab.on_pawn_changed(reason) end)
    pcall(function() openLatch.on_pawn_changed(reason) end)
    pcall(function() itemDoor.on_pawn_changed(reason) end)
end
setInterval(1000, check_pawn_globally)


-- local currentOverride = false
-- register_key_bind("F1", function()
-- 	currentOverride = not currentOverride
-- 	uevrUtils.setIsInCutsceneOverride(currentOverride)
-- end)
register_key_bind("F2", function()
	print("F2 pressed")
	pawn:K2_AddActorLocalOffset(uevrUtils.vector(100,0,0), false, reusable_hit_result, true)
end)
-- local isPaused = false
-- register_key_bind("F3", function()
-- 	isPaused = not isPaused
-- 	uevrUtils.pauseGame(isPaused)
-- end)
-- register_key_bind("F4", function()
-- 	uevrUtils.profiler:report()
-- end)
-- register_key_bind("F1", function()
-- 	ending_selector.select("inwater") -- "leave" / "inwater" / "maria"
-- 	print("Set Ending to inwater")
-- end)

--When raytracing is off there can be mismatched lighting in both eyes. 
--This forces a renderer reset every 20 seconds to help mitigate that issue. 
--This is only needed when raytracing is disabled, so it will not run if the user has enabled raytracing in the settings.
--setInterval(20000,fixRaytrace)
--configui.getValue("fix_visual_glitch_seconds")
local function onRaytracingVisualGlitchTimer()
	local delaySeconds = configui.getValue("fix_visual_glitch_seconds") or 20
	if configui.getValue("fix_no_raytracing_visual_glitches") == true then
		fixRaytrace()
	else
		delaySeconds = 5
	end
	delay(delaySeconds * 1000, onRaytracingVisualGlitchTimer)
end
onRaytracingVisualGlitchTimer()

configui.onCreateOrUpdate("enable_raytracing", function(value)
	applyRaytracingMode(value == true and RaytracingMode.On or RaytracingMode.Off, true)
	configui.setHidden("fix_no_raytracing_visual_glitches_group", value)
	if value == false and configui.getValue("fix_no_raytracing_visual_glitches") == true then
		fixRaytrace()
	end
end)

configui.onCreateOrUpdate("fix_no_raytracing_visual_glitches", function(value)
	configui.setHidden("fix_visual_glitch_seconds", not value)
	if value == true then
		fixRaytrace()
	end
end)

configui.onCreateOrUpdate("interaction_sprint_mode", function(value)
	setSprintToggleEnabled(value == 2 or value == 3, true)
end)

configui.onCreateOrUpdate("interaction_control_mode", function(value)
	configui.setHidden("interaction_sprint_mode", value == 1)
	configui.setHidden("interaction_desc_advanced_group", value == 1)
end)

configui.onUpdate("light_type", function(value)
	--print("Light type changed, reattaching light")
	local light = uevrUtils.getValid(status.flashlight and status.flashlight.lightMesh)
	attachLightToController(light)
end)

configui.onCreateOrUpdate("offhand_grip_weapon", function(value)
	accessories.setDisabled(value == false)
end)

configui.create(configDefinition)

-- 1.0.2 推门功能：注册手部碰撞体接触回调，检测门并施加推力
-- SH2 门由 USHDoorMovementComponent:AddPhysicForce 驱动（角度驱动），非 Chaos 冲量
-- 推门震动由 UEVR_11_EventFeedback.lua 独立注册另一个 contact callback 处理
local DOOR_PHYSIC_FORCE_SCALE = 0.1

local function getDoorMovement(actor)
	if actor == nil then return nil end
	local candidates = { actor.DoorMovement, actor.LeftDoorMovement, actor.RightDoorMovement }
	for i = 1, #candidates do
		local dm = candidates[i]
		if dm ~= nil and dm.AddPhysicForce ~= nil then
			return dm
		end
	end
	return nil
end

collision.registerContactCallback(function(id, handVelocity, hitResult, collider, handed)
	if handVelocity == nil or hitResult == nil then return end
	local hit = uevrUtils.getCleanHitResult(hitResult)
	local hitComp = hit and uevrUtils.getValid(hit.Component) or nil
	if hit == nil or hitComp == nil or hit.ImpactPoint == nil then return end

	local doorMovement = getDoorMovement(hitComp.GetOwner and hitComp:GetOwner() or nil)
	if doorMovement == nil then return end

	local pivot = hitComp:K2_GetComponentLocation()
	local rx = hit.ImpactPoint.X - pivot.X
	local ry = hit.ImpactPoint.Y - pivot.Y
	local rz = hit.ImpactPoint.Z - pivot.Z
	local up = hitComp.GetUpVector and hitComp:GetUpVector() or nil
	if up == nil then return end

	-- 切向方向（up × radius），使力的符号匹配门的摆动方向
	local tx = up.Y * rz - up.Z * ry
	local ty = up.Z * rx - up.X * rz
	local tz = up.X * ry - up.Y * rx
	local tLen = math.sqrt(tx * tx + ty * ty + tz * tz)
	if tLen < 1.0 then return end
	tx, ty, tz = tx / tLen, ty / tLen, tz / tLen

	local moveForce = (handVelocity.X * tx + handVelocity.Y * ty + handVelocity.Z * tz) * DOOR_PHYSIC_FORCE_SCALE
	if math.abs(moveForce) > 0.001 then
		doorMovement:AddPhysicForce(moveForce)
	end
end)



--The following code courtesy of Praydog
local LegacyCameraShake_c = uevrUtils.find_required_object("Class /Script/GameplayCameras.LegacyCameraShake")

-- Disable camera shake 1
local BlueprintUpdateCameraShake = LegacyCameraShake_c and LegacyCameraShake_c:find_function("BlueprintUpdateCameraShake")

if BlueprintUpdateCameraShake ~= nil then
    BlueprintUpdateCameraShake:set_function_flags(BlueprintUpdateCameraShake:get_function_flags() | 0x400) -- Mark as native
    BlueprintUpdateCameraShake:hook_ptr(function(fn, obj, locals, result)
        obj.ShakeScale = 0.0
        return false
    end)
end

-- Disable camera shake 2
local ReceivePlayShake = LegacyCameraShake_c and LegacyCameraShake_c:find_function("ReceivePlayShake")

if ReceivePlayShake ~= nil then
    ReceivePlayShake:set_function_flags(ReceivePlayShake:get_function_flags() | 0x400) -- Mark as native
    ReceivePlayShake:hook_ptr(function(fn, obj, locals, result)
        obj.ShakeScale = 0.0
        return false
    end)
end

uevr.sdk.callbacks.on_script_reset(function()
    print("Resetting")

    if BlueprintUpdateCameraShake ~= nil then
        BlueprintUpdateCameraShake:set_function_flags(BlueprintUpdateCameraShake:get_function_flags() & ~0x400) -- Unmark as native
    end

    if ReceivePlayShake ~= nil then
        ReceivePlayShake:set_function_flags(ReceivePlayShake:get_function_flags() & ~0x400) -- Unmark as native
    end

end)