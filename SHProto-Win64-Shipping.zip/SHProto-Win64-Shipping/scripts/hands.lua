--[[修改说明：
1. 2026-07-29 修复：左手 drink_potion / 右手 inject_syringe 被空手握姿覆盖
   - 根因：本文件 on_xinput_get_state 每帧调用 handleInput(state, false, Right)
     1) 把 autoHandleInput 关掉
     2) 把左手当副手强制走 left_grip（空手抓握），右手同理
   - heal 生成的 Actor 道具（药水/针剂）靠 attachments grip animation 驱动手指；
     应交由 hands_animation 自动路径按 getCurrentGripAnimation 更新双手
]]--

local uevrUtils = require('libs/uevr_utils')
local hands = require('libs/hands')
local controllers = require('libs/controllers')

function on_level_change(level)
	controllers.createController(0)
	controllers.createController(1)
	hands.reset()

	local paramsFile = 'hands_parameters' -- found in the [game profile]/data directory
	local configName = 'Main' -- the name you gave your config
	local animationName = 'Shared' -- the name you gave your animation
	hands.createFromConfig(paramsFile, configName, animationName)
	-- 确保自动输入开启：按 attachments 当前 grip animation 驱动左右手指
	-- （含 drink_potion / inject_syringe 等动态 Actor 道具）
	hands.setAutoHandleInput(true)
end

-- 不再手动 handleInput(..., false, ...)：
-- hands_animation 已在 PreInput 回调里用 attachments.getCurrentGripAnimation
-- 更新双手；强制 false 会盖掉药水/针剂持物姿势。
