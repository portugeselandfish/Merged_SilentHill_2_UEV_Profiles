--[[修改说明：
1. 从 manual_reload.lua 更名为 pistol_reload.lua
2. 分离纯数学/动画逻辑至 libs/reload_tools.lua，本文件调用 reload_tools API 驱动动画
3. 入口守卫：检测角色是否 equip WeaponPistol_BP_C，非手枪则整个模块 no-op
4. 所有游戏 API 调用保留在本文件
5. Phase 4：B 键退弹/插弹时通过 reload_tools 正式改写弹夹与备弹；needs_rack 仅在弹夹=0 时触发
6. 武器类型检测改为读 main.lua 发布的全局变量 _G.__sh2_current_weapon_type /
   _G.__sh2_equipped_weapon，不再独立做链式查询；非手枪时 on_tick 直接 early return；
   tick_weapon_change_watch 改为比对全局武器对象地址，消除每帧两次冗余查询
7. A 类 UFunction hooks（IsFireReady/CanBeReloaded/PlayRequest/OnRangedReload/MontageChange 等）
   和 B 类附件 hooks（grip update / initAttachment）已挪到 libs/reload_hooks.lua 集中注册，
   按 _G.__sh2_current_weapon_type dispatch 到本模块导出的 M.on_xxx 回调入口；
   本文件保留 C 类 accessory hooks（pull_slide）和 D 类生命周期回调，
   以及武器专属的 hook 回调内部逻辑（is_player_pistol / should_block_native_reload 等）
8. 2026-07-21 删除诊断接口：pistol_reload 已完工，移除以下诊断专用函数：
   - M.get_status（状态快照，仅 shotgun_diagnose 调用）
   - M.is_slide_locked（仅 shotgun_diagnose 调用）
   - M.force_install_slide_lock_hooks（DEPRECATED，仅 shotgun_diagnose 调用）
   保留 M.unlock_slide（complete_slide_rack 内部调用）、M.engine_drop_mag（on_tick B 键调用）
9. PoseableMesh 对齐用 bone location（get_bone_world_location / align_poseable_mag_bone），
   不用 socket。将来移植到别的游戏时，应改用 reload_tools.align_poseable_socket
   （以及 get_socket_world_location），与步枪/霰弹枪一致。
10. 菜单/地图模式下 B 键不退弹：on_tick 消费 g_mag_drop_edge 前复用 main.lua:1156-1162
    的地图检测（pawn.Items.ItemExecutive 的 full_name 以 "Map" 开头），地图打开时清零 edge
    并跳过 engine_drop_mag，避免在地图菜单里误触退弹
11. 2026-07-30 迁移到新锚定 API：begin_slide_rack / tick_slide_rack / reset_slide_rack_state
    的内联 (lh-socket)·axis 算法 + 旧 calc_slide_pull fallback 替换为
    reload_tools.capture_slide_anchor + reload_tools.calc_slide_pull_anchored 单次调用；
    slide_rack_state.start_back_dist 字段重命名为 start_anchor_dist（与步枪一致）。
    旧 calc_slide_pull / calc_slide_rotate 已从 reload_tools.lua 删除。
12. 2026-07-30 修复面板手枪滑块分段预览无法播放的 bug：
    根因是手枪 RELOAD_SEGMENTS 无 key 字段且面板错误复用 shotgun 模块，
    导致按钮点击路径 reload_mod.play_audio_segment(seg.key) 因 seg.key=nil 不触发。
    本文件对齐 shotgun/rifle：PISTOL_RELOAD_SEGMENTS 每段加 audio_key 字段，
    暴露 M.get_audio_segment / M.play_audio_segment / M.set_audio_segment 三个接口，
    并在 init 末尾 publish_globals() 前注册 _G.__sh2_pistol_reload_module = M。
13. 2026-07-30 新增手枪 mag_release（释放卡扣）音效段：
    SDK 无独立 Play_Wpn_Pistol_Mag_Release 事件，按用户决策复用霰弹枪 mag_release 段
    （Play_Wpn_Shotgun_Pump_Action 事件 2.0-3.7s 片段，对齐 shotgun_reload.lua:225）。
    改动：(a) 新增 PISTOL_MAG_RELEASE_AUDIO_KEY="shotgun_pump" 常量；
    (b) PISTOL_RELOAD_SEGMENTS 加 mag_release 段（audio_key=shotgun_pump, start=2.00, dur=1.70）；
    (c) init 注册 "shotgun_pump" 事件（register_event 幂等，shotgun_reload 已注册也安全）；
    (d) start_grip_release_drop 内左手松开 grip 时触发 mag_release 音效 + haptic，
    对齐 shotgun_reload.lua L3669-3671 触发模式。
14. 2026-07-30 新增「地图/菜单检测」诊断接口（定位"菜单中 B 键仍触发退弹"的根因）：
    静态分析：on_tick 内 map 检查（参考 main.lua:1156-1162）逻辑等价于原版，
    但 get_full_name() 可能返回路径前缀的字符串导致 string.sub(_,1,3)=="Map" 永远 false，
    或者 UObject 调用抛错被 UEVR tick 吞掉。新增：
    (a) map_menu_debug 表（每 tick 刷新 + last_edge_* 持久保留到下次 edge 消费）；
    (b) update_map_menu_check(pawn) 函数：pcall 保护所有 UObject 调用，记录中间值
    （pawn_addr / has_item_executive / item_full_name / item_first_3 / in_map_menu / get_full_name_error）；
    (c) M.get_map_menu_debug_info() 接口供面板读取；
    (d) on_tick 内 edge 消费时记录 last_edge_in_map_menu / last_edge_dropped / last_edge_blocked_by_map / last_edge_clock。
15. 2026-07-30 修复菜单/暂停状态下 B 键仍触发退弹的 bug：
    面板诊断确认根因：原 map 检查只覆盖"地图菜单"（ItemExecutive="Map*"）这一种场景，
    在暂停菜单等其它菜单下 pawn.Items.ItemExecutive 是 nil，检测必然 false，导致 B 键错误触发 engine_drop_mag。
    修复方案：map_menu_debug 新增 is_game_paused / in_any_menu 字段；
    update_map_menu_check 调 uevrUtils.isGamePaused()（底层 Statics:IsGamePaused(world)，
    由 ui.lua:484 注册回调更新），in_any_menu = in_map_menu OR is_game_paused；
    on_tick edge 消费条件改为 not in_any_menu，并区分记录 last_edge_blocked_by_map / last_edge_blocked_by_pause。
16. 2026-08-31 插弹 slide-in 期间左手跟随弹夹（用户拍板，item door「手跟钥匙」同构）：
    - 动态捕获两步引擎换算，零偏移调校、不改底层 hands.lua：
      ① executeUEVRCallbacks("on_accessory_attach") 走标准通道保存手势快照（供脱附恢复）；
      ② 对 AttachParent==弹夹root 的左手组件 K2_AttachTo(root, "", 1, false) KeepWorld 重挂，
        引擎自动换算相对变换保持手当前世界位姿，绕过 attachHandToTarget 内部
        composeRotators(baseRotation, rot) 的固定叠加（无需预知手部 profile 组件数，自适应过滤）。
    - 挂附时机：弹夹瞬移到管子起点之前（手随弹夹一起瞬移+滑入，手势保持不变）；
    - 脱附路径（restoreHandSnapshot 恢复手部追踪，均幂等）：
      ① 插入完成 finish_mag_insert_state；② 滑入中松开左 Grip（guarded_mag_drop_visual_tick 轮询，
      因 mag_grab_release edge 仅在 mag_in_left_hand=true 时发布，slide-in 期间已清零收不到）；
      ③ 异常兜底 cancel_manual_reload / despawn_left_hand_mag / init 热重载强制脱附。
    - detach_left_hand_mag_for_animation 新增 keep_hand_pose 参数：插弹路径保留握弹手势，
      掉落（grip-release drop）路径行为不变。
]]--

local uevrUtils = require("libs/uevr_utils")
local attachments = require("libs/attachments")
local accessories = require("libs/accessories")
local configui = require("libs/configui")
local controllers = require("libs/controllers")
local hands = require("libs/hands")
local ik = require("libs/ik")
local vr_globals = require("UEVR_00_init_globals")
local reload_tools = require("libs/reload_tools")
local reload_hooks = require("libs/reload_hooks")
local audio = require("libs/audio")
local event_feedback = require("UEVR_11_EventFeedback")

local M = {}

-- 触发换弹手柄震动（防御性包装：11号模块未加载或热重载陈旧时不破坏换弹流程）
local function trigger_reload_haptic(action)
    if event_feedback and type(event_feedback.play_reload_haptic) == "function" then
        pcall(event_feedback.play_reload_haptic, action)
    end
end

local KEYS = vr_globals.KEYS

-- 前向声明：detach/slide-in 路径在定义点之前就会调用
local publish_globals

-- 空仓扣扳机（dry fire）音效
-- 走 audio.lua 的 SpawnAkComponentAtLocation 独立路径，绕开 reload_hooks 对 PostEventByName 的 hook
-- （从 Lua 主动调用 cdo:PostEventByName 会触发 UEVR hook_ptr 递归锁"resource deadlock would occur"）
local DRY_FIRE_AUDIO_EVENT = "Play_Wpn_Pistol_Shot_No_Ammo"
local PISTOL_DRY_FIRE_AUDIO_KEY = "pistol_dry_fire"
local PISTOL_DRY_FIRE_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Pistol/Play_Wpn_Pistol_Shot_No_Ammo.Play_Wpn_Pistol_Shot_No_Ammo"

-- 播放空仓扣扳机（dry fire）音效：走 audio.lua 的 SpawnAkComponentAtLocation 独立路径
-- （绕开 reload_hooks 对 PostEventByName 的 hook，规避 UEVR hook_ptr 递归锁）
local function play_dry_fire_sound()
    local ok, result = pcall(audio.play_segment, PISTOL_DRY_FIRE_AUDIO_KEY, 0, 1.0)
    return ok and result == true
end

local MAG_ATTACHMENT_ID = "ItemBase_BP_C_HandgunAmmoClosed_01_A"
local MAG_LEFT_HAND_ATTACHMENT_ID = "pistol_mag"
local MAG_BONE_NAME = "magazine_joint"
local MAG_SOCKET_NAME = "magazine_socket_joint"
local MAG_ATTACH_SOCKET = "hand_l_bn"
local HIDE_BONE_PHYS_BODY = 0

local HandsType = {
	None = 1,
	Forearms = 2,
	IKArms = 3,
}

local magAttachOptions = {
	detachFromOriginOnGrip = true,
	maintainWorldPositionOnDetachFromOrigin = false,
	detachFromParentOnRelease = true,
	maintainWorldPositionOnDetachFromParent = false,
	reattachToOriginOnRelease = false,
	restoreTransformToOriginOnReattach = false,
	useZeroTransformOnReattach = false,
	allowChildVisibilityHandling = false,
	allowChildHiddenInGameHandling = false,
	allowRenderInMainPassHandling = false,
}
local BONE_SCALE_HIDDEN = 0.001

local DROP_DURATION = 0.25
local DROP_DISTANCE = 120.0
-- 滑入/滑出动画时长（秒），仿照 re9_vr_reload_advanced.lua 的 duration_default
local SLIDE_DURATION = 0.25

-- 插弹 proximity 距离（cm）：左手持弹靠近 magazine_socket_joint 的阈值
-- 设为 15.0 与 slide-out 对称：触发即开始 15cm 滑入动画（而非贴到 1cm 才瞬间吸入）
local MAG_INSERT_DISTANCE = 12.0

-- 插弹口相对 magazine_socket_joint 的局部偏移（cm，与 MAG_DROP_LOCAL_* 同一套轴）
-- proximity 吸附点 + slide-in 终点共用；插入口偏前穿模时把 forward 调负（往后挪）
-- forward=socket 前(+往枪口) / right=右 / down=下（正=往下）
local MAG_INSERT_OFFSET = { forward = -1.0, right = 0.0, down = 0.0 }

-- 插弹 slide-in 旋转偏移（单位：度）
-- start_rot = socket旋转 + 此偏移，end_rot = socket旋转 + 此偏移（两者相同，无旋转插值）
-- 弹夹在左手吸附时的旋转与 socket 旋转差异约 90°，会导致滑入开始时瞬间大角度翻转+穿模
-- 设为 0 则弹夹始终以 socket 朝向滑入（与枪身平行）
-- 若需弹夹稍微倾斜插入，填 10 即偏转 10°，填 20 即偏转 20°，以此类推
local MAG_SLIDE_IN_ROT_PITCH = 10.0   -- 度；绕侧轴偏转（正值=抬头/尾沉）
local MAG_SLIDE_IN_ROT_YAW = 0.0      -- 度；绕竖轴偏转（正值=左偏）
local MAG_SLIDE_IN_ROT_ROLL = 0.0     -- 度；绕前轴偏转（正值=右倾）

-- 插弹 slide-in 起始偏移（cm）：沿 magazine_socket 局部坐标系，弹夹从枪口下方多远处开始滑入
-- 像枪身下方延伸出的一根管子：弹夹脱手后立即出现在此位置，沿管子滑入
-- down=15 即入弹口正下方 15cm（与 MAG_INSERT_DISTANCE 对称）
-- forward/right 一般留 0，确保弹夹从正下方直上滑入
local MAG_SLIDE_IN_START_FORWARD = 0.0
local MAG_SLIDE_IN_START_RIGHT = 0.0
local MAG_SLIDE_IN_START_DOWN = 15.0

-- 表演弹匣起点微调（改完重载脚本）
-- 推荐调 LOCAL_DOWN：沿 magazine_socket 的「下」方向（正值=往下挪，与握枪角度无关）
local MAG_DROP_LOCAL_FORWARD = 0.0
local MAG_DROP_LOCAL_RIGHT = 0.0
-- slide-out 滑出距离（cm）：原 3.0 太小几乎不可见，提升到 15.0（≈RE9 的 10.9cm 量级）
local MAG_DROP_LOCAL_DOWN = 20.0
-- 世界坐标附加偏移（一般留 0；之前改 Y/Z 常无效，因为没作用在 spawn 上）
-- 注意：这些偏移作用在 slide 终点，不是生成位置，改了会影响 slide-out 动画轨迹
local MAG_DROP_OFFSET_X = 0.0
local MAG_DROP_OFFSET_Y = 0.0
local MAG_DROP_OFFSET_Z = 0.0

-- 退弹 slide-out 旋转偏移（单位：度）：修正弹匣模型与 socket 的固有朝向偏差
-- start_rot = end_rot = socket旋转 + 此偏移（退弹期间弹夹旋转跟随枪体 + 此修正量）
-- 实测若弹夹相对枪身有轻微倾斜，调这三个值对齐（与 MAG_SLIDE_IN_ROT_* 同一套轴）
local MAG_DROP_ROT_PITCH = 10.0   -- 度；绕侧轴偏转（正值=抬头/尾沉）
local MAG_DROP_ROT_YAW   = 0.0   -- 度；绕竖轴偏转（正值=左偏）
local MAG_DROP_ROT_ROLL  = 0.0   -- 度；绕前轴偏转（正值=右倾）

-- 生成弹匣时的局部偏移（cm）：沿枪的 magazine_socket 局部坐标系偏移，跟随枪旋转
-- 正值 DOWN：沿 socket 的「下」方向往下挪（枪斜着也跟着歪，不会偏到枪外面）
local MAG_SPAWN_LOCAL_FORWARD = 0.0
local MAG_SPAWN_LOCAL_RIGHT = 0.0
local MAG_SPAWN_LOCAL_DOWN = 5.0

-- 手枪换弹音频分段配置（与 Play_Wpn_Pistol_Reload 的 MaximumDuration ≈ 2.8788s 对齐）
-- 4 段对应 4 个换弹动作：start_sec 为音频内起始位置，duration 为播放时长后自动停止
-- 上层"插入CD按下播放键"，底层 audio.lua 负责实际播放/Seek/计时停止
local PISTOL_RELOAD_AUDIO_KEY = "pistol_reload"
-- mag_release 段复用霰弹枪 Pump_Action 事件 2.0-3.7s 片段（SDK 无独立手枪 Mag_Release 事件）
local PISTOL_MAG_RELEASE_AUDIO_KEY = "shotgun_pump"
local PISTOL_RELOAD_SEGMENTS = {
    mag_drop   = { audio_key = PISTOL_RELOAD_AUDIO_KEY,      start_sec = 0.00, duration = 0.40 },  -- 退弹
    mag_insert = { audio_key = PISTOL_RELOAD_AUDIO_KEY,      start_sec = 0.40, duration = 0.40 },  -- 插入弹夹
    pull_slide = { audio_key = PISTOL_RELOAD_AUDIO_KEY,      start_sec = 1.50, duration = 0.50 },  -- 拉栓
    slide_snap = { audio_key = PISTOL_RELOAD_AUDIO_KEY,      start_sec = 1.90, duration = 0.40 },  -- 套筒复位
    mag_release = { audio_key = PISTOL_MAG_RELEASE_AUDIO_KEY, start_sec = 2.00, duration = 1.70 },  -- 释放卡扣（复用 shotgun pump 2.0-3.7s）
}

-- 获取指定音效段的参数（供本模块和面板共用，对齐 shotgun/rifle 同名接口）
function M.get_audio_segment(seg_name)
    return PISTOL_RELOAD_SEGMENTS[seg_name]
end

-- 播放指定音效段（供面板按钮调用）
function M.play_audio_segment(seg_name)
    local seg = PISTOL_RELOAD_SEGMENTS[seg_name]
    if seg == nil then
        return false
    end
    audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
    return true
end

-- 临时修改音效段参数（仅 diagnose 面板预览用，不写入 JSON，不持久化）
function M.set_audio_segment(seg_name, start_sec, duration)
    local seg = PISTOL_RELOAD_SEGMENTS[seg_name]
    if seg == nil then
        return false
    end
    seg.start_sec = start_sec
    seg.duration = duration
    return true
end

local SHRangedCmbSubcomp_c = uevrUtils.find_required_object("Class /Script/SHProto.SHRangedCmbSubcomp")
local SHAnimCombatSubcomp_c = uevrUtils.find_required_object("Class /Script/SHProto.SHAnimCombatSubcomp")
-- SHItemWeaponRanged / SHAnimMontagePlayer / AnimInstance class 对象已挪到 libs/reload_hooks.lua
-- （由其集中注册 A 类 UFunction hooks）

-- 事实表 §6：手枪换弹 AnimSequence / montage_parameters.json 条目
local RELOAD_MONTAGE_NAME_MARKERS = {
    "Handgun_Reload",
    "James_Combat_Recoils_Combat_Handgun_Reload",
    "PistolReload",
}

-- 重入/并发保护：hook 与 montage 回调内禁止同步 cancel，避免闪退
-- 注：montage 拦截本身由 libs/reload_hooks.lua 的 montage_guard 保护，
-- 本字段仅防 cancel 链路自身重入
local reload_block_guard = {
    cancelling = false,
}

-- 入口守卫：由 main.lua 在 gripUpdate（~200ms）中发布 _G.__sh2_current_weapon_type
-- 和 _G.__sh2_equipped_weapon，本模块直接读取，不再独立做链式查询。
-- on_tick 中检测到非手枪时跳过核心逻辑并 early return。

local state = rawget(_G, "__sh2_manual_reload_state")
-- 热重载兼容：旧 state 中没有 _was_pistol 字段，补充默认值
if type(state) == "table" and state._was_pistol == nil then
    state._was_pistol = false
end
-- 热重载兼容：旧 state 中没有 hand_attached_to_mag 字段（插入期手跟弹夹标记），补充默认值
if type(state) == "table" and state.hand_attached_to_mag == nil then
    state.hand_attached_to_mag = false
end
if type(state) ~= "table" then
    state = {
        mesh_hidden = false,
        mag_dropped = false,
        manual_reload_active = false,
        weapon = nil,
        weapon_mesh = nil,
        -- Phase 2: 左手持弹 + 插弹
        mag_in_left_hand = false,
        mag_inserted = false,
        left_hand_mag_attachment = nil,
        left_hand_mag_actor = nil,
        -- 插入期左手跟随弹夹标记（热重载持久，防中途重载后标记丢失；对齐 item_door hand_attached_to_key）
        hand_attached_to_mag = false,
        -- Phase 5: 空仓挂机（slide lock）
        slide_locked = false,
        needs_rack = false,
        pending_clip_fill_after_rack = false,
        slide_hooks_installed = false,
        last_ammo_in_clip = nil,
        last_reload_playing = nil,
        last_aim_active = nil,
        pending_cancel_reload = false,
        pending_cancel_reason = nil,
        -- mag drop 动画状态：由 reload_tools 驱动，扩展 actor/root 字段
        mag_drop = reload_tools.new_drop_state(),
        -- 换枪检测：缓存上一帧的武器标识，变化时清理手动换弹状态
        last_weapon_key = nil,
        -- 入口守卫降沿：缓存上一帧是否手枪，检测"手枪→非手枪"切换
        _was_pistol = false,
    }
    -- 扩展 reload_tools 状态：游戏对象引用
    state.mag_drop.actor = nil
    state.mag_drop.root = nil
    -- fall 参数预填充
    state.mag_drop.duration = DROP_DURATION
    state.mag_drop.distance = DROP_DISTANCE
end
_G.__sh2_manual_reload_state = state

-- ============================================================
-- 地图/菜单检测诊断状态（面板读取，定位"菜单中 B 键仍触发退弹"的根因）
-- ============================================================
-- 每 tick 更新的字段（反映当前帧的检测中间值）
-- last_edge_* 字段持久保留到下次 edge 消费（避免下一帧覆盖看不到结果）
local map_menu_debug = {
    pawn_addr = nil,
    has_item_executive = false,
    item_full_name = nil,        -- get_full_name() 完整字符串
    item_first_3 = nil,          -- 前 3 字符（用于 "Map" 前缀匹配）
    in_map_menu = false,
    is_game_paused = false,     -- uevrUtils.isGamePaused()（暂停菜单/暂停状态）
    in_any_menu = false,         -- 综合判定：in_map_menu OR is_game_paused
    get_full_name_error = nil,  -- get_full_name() 抛错时的错误信息（pcall 保护）
    last_check_clock = nil,
    -- 仅在 edge 消费时更新（持久保留到下次 edge 消费）
    last_edge_blocked_by_map = nil,
    last_edge_blocked_by_pause = nil,
    last_edge_dropped = nil,
    last_edge_clock = nil,
    last_edge_in_map_menu = nil, -- 消费 edge 那一帧的判定值
}

-- 每帧刷新 map_menu_debug：pcall 保护所有 UObject 调用，避免单次失败连锁
local function update_map_menu_check(pawn)
    if pawn == nil then
        map_menu_debug.pawn_addr = nil
        map_menu_debug.has_item_executive = false
        map_menu_debug.item_full_name = nil
        map_menu_debug.item_first_3 = nil
        map_menu_debug.in_map_menu = false
        map_menu_debug.get_full_name_error = nil
    else
        pcall(function()
            map_menu_debug.pawn_addr = pawn.get_address and pawn:get_address() or nil
        end)
        local map_item
        pcall(function()
            map_item = uevrUtils.getValid(pawn, {"Items", "ItemExecutive"})
        end)
        map_menu_debug.has_item_executive = map_item ~= nil
        if map_item ~= nil then
            local fn, err
            local ok = pcall(function()
                fn = map_item:get_full_name()
            end)
            if not ok then
                err = fn  -- pcall 把错误放到第一个返回值
                fn = nil
            end
            map_menu_debug.item_full_name = fn
            map_menu_debug.get_full_name_error = err
            if fn ~= nil and #fn >= 3 then
                map_menu_debug.item_first_3 = string.sub(fn, 1, 3)
            else
                map_menu_debug.item_first_3 = nil
            end
            map_menu_debug.in_map_menu = (map_menu_debug.item_first_3 == "Map")
        else
            map_menu_debug.item_full_name = nil
            map_menu_debug.item_first_3 = nil
            map_menu_debug.in_map_menu = false
            map_menu_debug.get_full_name_error = nil
        end
    end
    -- 全局暂停状态（uevrUtils.isGamePaused 由 ui.lua 注册回调更新，覆盖暂停菜单/暂停状态）
    local paused_ok, paused_val = pcall(function()
        if uevrUtils.isGamePaused then return uevrUtils.isGamePaused() end
        return false
    end)
    map_menu_debug.is_game_paused = (paused_ok == true and paused_val == true)
    -- 综合判定：地图菜单 OR 游戏暂停
    map_menu_debug.in_any_menu = map_menu_debug.in_map_menu or map_menu_debug.is_game_paused
    map_menu_debug.last_check_clock = os.clock()
end

-- 诊断面板读取接口：返回当前 map_menu_debug 表
function M.get_map_menu_debug_info()
    return map_menu_debug
end

local function print_log(text, logLevel, tag)
    if rawget(_G, "RELOAD_DIAG_ENABLED") ~= true then
        return
    end
    local label = tag ~= nil and tag or "M_RELOAD"
    print("[" .. label .. "] " .. text)
end

local function safe_tostring(value)
    if value == nil then
        return "nil"
    end
    local ok, text = pcall(function()
        return tostring(value)
    end)
    return ok and text or "<unreadable>"
end

local function log_ammo_event(message)
    if rawget(_G, "RELOAD_DIAG_ENABLED") ~= true then
        return
    end
    print("[AMMO] " .. message)
end

local function format_ammo_result(prefix, result)
    if type(result) ~= "table" then
        return prefix .. ": invalid result"
    end
    if result.error ~= nil then
        return prefix .. " FAILED: " .. tostring(result.error)
    end
    return string.format(
        "%s OK clip %s->%s reserve %s->%s moved=%s added=%s needs_rack=%s",
        prefix,
        safe_tostring(result.clip_before),
        safe_tostring(result.clip_after),
        safe_tostring(result.reserve_before),
        safe_tostring(result.reserve_after),
        safe_tostring(result.moved_to_reserve),
        safe_tostring(result.added),
        safe_tostring(result.needs_rack)
    )
end

local uobject_valid = reload_tools.uobject_valid
local component_display_name = reload_tools.component_display_name

local function is_pistol_weapon(weapon)
    if weapon == nil then
        return false
    end
    local ok, name = pcall(function()
        return weapon:get_full_name()
    end)
    return ok and name ~= nil and name:find("WeaponPistol", 1, true) ~= nil
end

-- 2026-07-31：私有 resolve_combat_chain 已下沉为 reload_tools.resolve_combat_chain 公共工具
-- （reload_tools.lua:1030，公共版本返回 9 字段是此私有 3 字段版本的超集）
-- 调用点 get_pistol_chain 仅使用 .equipped_weapon / .weapon_mesh，公共版本均包含
local resolve_combat_chain = reload_tools.resolve_combat_chain

local function is_pistol_mesh(mesh)
    if mesh == nil then
        return false
    end
    local ok, name = pcall(function()
        return mesh:get_full_name()
    end)
    return ok and name ~= nil and name:find("WeaponPistol", 1, true) ~= nil
end

local function get_pistol_chain()
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    local chain = resolve_combat_chain(pawn)
    if not is_pistol_weapon(chain.equipped_weapon) or chain.weapon_mesh == nil then
        local gripped = attachments.getCurrentGrippedAttachment(Handed.Right)
        if is_pistol_mesh(gripped) then
            chain.weapon_mesh = gripped
        end
    end
    if not is_pistol_weapon(chain.equipped_weapon) and is_pistol_mesh(chain.weapon_mesh) then
        chain.equipped_weapon = chain.weapon_mesh
    end
    if not is_pistol_weapon(chain.equipped_weapon) and not is_pistol_mesh(chain.weapon_mesh) then
        return nil, chain, "not pistol"
    end
    if chain.weapon_mesh == nil then
        return nil, chain, "weapon mesh nil"
    end
    return chain.weapon_mesh, chain, nil
end

-- 入口守卫：读取 main.lua 发布的全局武器类型，判断当前是否持有手枪
local function is_pistol_equipped()
    return rawget(_G, KEYS.current_weapon_type) == "pistol"
end

-- 审计问题1：5 个工具函数提级到 reload_tools，此处保留 local 别名兼容现有调用
local get_socket_world_location = reload_tools.get_socket_world_location

local function get_valid_weapon_mesh(mesh)
    if mesh ~= nil then
        local valid = uevrUtils.getValid(mesh)
        if valid ~= nil then
            return valid
        end
    end
    local live_mesh, _ = get_pistol_chain()
    if live_mesh ~= nil then
        return uevrUtils.getValid(live_mesh)
    end
    return nil
end

local function hide_magazine_bone(mesh)
    mesh = get_valid_weapon_mesh(mesh)
    if mesh == nil then
        return false
    end
    local ok, err = pcall(function()
        if mesh.HideBoneByName == nil then
            error("HideBoneByName missing")
        end
        mesh:HideBoneByName(uevrUtils.fname_from_string(MAG_BONE_NAME), HIDE_BONE_PHYS_BODY)
    end)
    if ok then
        state.mesh_hidden = true
        return true
    end
    print_log("HideBoneByName failed: " .. tostring(err), LogLevel.Warn)
    return false
end

local foreach_component_tree = reload_tools.foreach_component_tree

local function set_drop_fail(reason)
    print_log("engine_drop_mag failed: " .. tostring(reason), LogLevel.Warn)
end

local function set_spawn_mag_fail(reason)
    print_log("spawn_mag failed: " .. tostring(reason), LogLevel.Warn, "SPAWN")
end

local function set_grab_skip(reason)
    print_log("mag_grab skipped: " .. tostring(reason), LogLevel.Warn, "GRAB")
end

local function set_grab_fail(reason)
    print_log("mag_grab failed: " .. tostring(reason), LogLevel.Warn, "GRAB")
end

local bone_name_to_string = reload_tools.bone_name_to_string

local bone_space_component = reload_tools.bone_space_component

local function bone_space_world()
    if rawget(_G, "EBoneSpaces") ~= nil and EBoneSpaces.WorldSpace ~= nil then
        return EBoneSpaces.WorldSpace
    end
    return 0
end

-- 骨骼隔离缓存：缓存 BoneIsChildOf 查询结果，避免每次 spawn 表演件时重复遍历
-- 骨骼层级不会变，缓存到游戏结束无需清理
-- 格式: { [bone_str] = true }  — 值为 true 表示该骨头需要 HideBoneByName
local bone_hide_cache = {}

--- 获取骨骼隔离缓存键（用 SkeletalMesh 资产名 + 目标骨骼名，保证同一 mesh 复用缓存）
---@param mesh_comp userdata
---@param target_bone_name string
---@return string|nil
local function get_bone_hide_cache_key(mesh_comp, target_bone_name)
    local ok, name = pcall(function()
        local sk = mesh_comp.SkeletalMesh
        if sk ~= nil then
            return sk:get_full_name() .. "|" .. target_bone_name
        end
        return mesh_comp:get_full_name() .. "|" .. target_bone_name
    end)
    return ok and name or nil
end

local function show_only_magazine_joint(mesh_comp, mag_bone_name)
    if mesh_comp == nil or mesh_comp.GetNumBones == nil or mesh_comp.SetBoneScaleByName == nil then
        return false
    end
    local bone_space = bone_space_component()
    local scale_hidden = uevrUtils.vector(BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN)
    local scale_one = uevrUtils.vector(1, 1, 1)
    local mag_fname = uevrUtils.fname_from_string(mag_bone_name)

    -- 查找或构建缓存
    local cache_key = get_bone_hide_cache_key(mesh_comp, mag_bone_name)
    local hide_map = cache_key and bone_hide_cache[cache_key] or nil

    local ok = pcall(function()
        local count = mesh_comp:GetNumBones()
        -- 照抄 ik.lua hide_body：先缩整副骨骼，再把弹匣骨恢复 1（与真枪只 HideBone 弹匣对称）
        for i = 0, count - 1 do
            mesh_comp:SetBoneScaleByName(mesh_comp:GetBoneName(i), scale_hidden, bone_space)
        end
        mesh_comp:SetBoneScaleByName(mag_fname, scale_one, bone_space)
        if mesh_comp.HideBoneByName ~= nil and mesh_comp.BoneIsChildOf ~= nil then
            if hide_map == nil then
                -- 第一次：遍历所有骨骼，执行 HideBoneByName 的同时构建缓存
                hide_map = {}
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if bone_str ~= mag_bone_name then
                        local is_ancestor = mesh_comp:BoneIsChildOf(mag_fname, bone_fname)
                        local is_descendant = mesh_comp:BoneIsChildOf(bone_fname, mag_fname)
                        if not is_ancestor and not is_descendant then
                            mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                            hide_map[bone_str] = true
                        else
                            hide_map[bone_str] = false
                        end
                    else
                        hide_map[bone_str] = false
                    end
                end
                if cache_key ~= nil then
                    bone_hide_cache[cache_key] = hide_map
                end
            else
                -- 后续调用：用缓存跳过 BoneIsChildOf，直接 HideBoneByName
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if hide_map[bone_str] == true then
                        mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                    end
                end
            end
        end
    end)
    return ok
end

local copy_component_world_transform = reload_tools.copy_component_world_transform

local function get_bone_world_location(mesh_comp, bone_name)
    if mesh_comp == nil or mesh_comp.GetBoneLocationByName == nil then
        return nil
    end
    local ok, loc = pcall(function()
        return mesh_comp:GetBoneLocationByName(uevrUtils.fname_from_string(bone_name), bone_space_world())
    end)
    if ok and loc ~= nil then
        return loc
    end
    return nil
end

-- 审计问题1：工具函数提级到 reload_tools，此处保留 local 别名兼容现有调用
local get_component_world_location = reload_tools.get_component_world_location
local get_component_world_rotation = reload_tools.get_component_world_rotation

-- 与 main.lua onGripUpdate 相同：按 hands_type 选左手 parent component
local function resolve_left_hand_component()
    local hands_type = configui.getValue("hands_type") or HandsType.None
    local comp = nil
    if hands_type == HandsType.None then
        comp = controllers.getController(Handed.Left)
    elseif hands_type == HandsType.Forearms then
        comp = hands.getHandComponent(Handed.Left)
    elseif hands_type == HandsType.IKArms then
        comp = ik.getCurrentMesh()
    else
        comp = controllers.getController(Handed.Left)
    end
    -- 读档后 controllers/hands 可能仍持有旧世界组件
    comp = uevrUtils.getValid(comp)
    if comp ~= nil and not uobject_valid(comp) then
        return nil
    end
    return comp
end

local function get_left_hand_component_world_transform()
    local left_comp = resolve_left_hand_component()
    if left_comp == nil then
        return nil, nil, "left_hand_component_nil"
    end
    local loc = get_component_world_location(left_comp)
    local rot = get_component_world_rotation(left_comp)
    if loc == nil then
        return nil, nil, "left_hand_component_no_location"
    end
    return loc, rot, nil
end

local function merge_mag_into_grip_update(rA, rM, rS, lA, lM, lS, oR, oL)
    if state.mag_in_left_hand ~= true then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    if uevrUtils.isInCutscene and uevrUtils.isInCutscene() then
        return rA, rM, rS, nil, nil, nil, oR, oL
    end

    local mag = uevrUtils.getValid(state.left_hand_mag_attachment)
    if mag == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end

    local left_comp = resolve_left_hand_component()
    if left_comp == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end

    return rA, rM, rS, mag, left_comp, MAG_ATTACH_SOCKET, oR, magAttachOptions
end

-- B 类 grip update hook 回调入口：左手持弹时覆盖左手附着（由 reload_hooks dispatch 调用）
function M.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
    return merge_mag_into_grip_update(rA, rM, rS, lA, lM, lS, oR, oL)
end

local MAG_CONFIG_PREFIX = "uevr_attachments_pistol_mag_"

local function load_pistol_mag_params()
    -- 优先读 Attachments Config UI 里 pistol_mag 条目（实时调 offset）
    local loc = configui.getValue(MAG_CONFIG_PREFIX .. "position")
    local rot = configui.getValue(MAG_CONFIG_PREFIX .. "rotation")
    local scale = configui.getValue(MAG_CONFIG_PREFIX .. "scale")
    if loc ~= nil and rot ~= nil then
        return {
            location = loc,
            rotation = rot,
            scale = scale or { 1.0, 1.0, 1.0 },
        }
    end

    local defaults = {
        location = { 0.0, 0.0, 0.0 },
        rotation = { 0.0, 0.0, 0.0 },
        scale = { 1.0, 1.0, 1.0 },
    }
    local params = json.load_file("attachments_parameters.json")
    if params ~= nil and params.attachmentOffsets ~= nil then
        for i = 1, #params.attachmentOffsets do
            local entry = params.attachmentOffsets[i]
            if entry ~= nil and entry.id == MAG_LEFT_HAND_ATTACHMENT_ID then
                return entry
            end
        end
    end
    return defaults
end

local function is_left_hand_mag_component(comp)
    if state.mag_in_left_hand ~= true then
        return false
    end
    local mag = uevrUtils.getValid(state.left_hand_mag_attachment)
    local other = uevrUtils.getValid(comp)
    return mag ~= nil and other ~= nil and mag == other
end

local function apply_pistol_mag_transform(poseable)
    if poseable == nil then
        return
    end
    local params = load_pistol_mag_params()
    local loc = params.location or { 0, 0, 0 }
    local rot = params.rotation or { 0, 0, 0 }
    local scale = params.scale or { 1, 1, 1 }
    pcall(function()
        uevrUtils.set_component_relative_location(poseable, uevrUtils.vector(loc))
        uevrUtils.set_component_relative_rotation(poseable, uevrUtils.rotator(rot))
        uevrUtils.set_component_relative_scale(poseable, uevrUtils.vector(scale))
    end)
end

local handsAnimation = nil
local function get_hands_animation()
    if handsAnimation == nil then
        local ok, mod = pcall(require, "libs/hands_animation")
        if ok and type(mod) == "table" then
            handsAnimation = mod
        end
    end
    return handsAnimation
end

local function apply_left_hand_mag_pose()
    if slide_rack_state ~= nil and slide_rack_state.active then
        return
    end
    local ha = get_hands_animation()
    if ha and ha.setHoldingAttachment then
        pcall(function()
            ha.setHoldingAttachment(Handed.Left, MAG_LEFT_HAND_ATTACHMENT_ID)
        end)
    end
end

local function apply_left_hand_slide_pose()
    local ha = get_hands_animation()
    if ha and ha.setHoldingAttachment then
        pcall(function()
            ha.setHoldingAttachment(Handed.Left, "pull_slide")
        end)
    end
end

-- 清除左手握弹姿态，恢复到 open 手势（弹夹掉落时调用）
local function clear_left_hand_mag_pose()
    local ha = get_hands_animation()
    if ha and ha.setHoldingAttachment then
        pcall(function()
            ha.setHoldingAttachment(Handed.Left, nil)
        end)
    end
end

-- B 类 initAttachment hook 回调入口：左手持弹时应用 pistol_mag 偏移和手势（由 reload_hooks dispatch 调用）
function M.on_init_attachment(attachment, gripHand, options)
    if gripHand == Handed.Left and is_left_hand_mag_component(attachment) then
        apply_pistol_mag_transform(attachment)
        apply_left_hand_mag_pose()
    end
end

-- 2026-07-31：私有 resolve_left_hand_world_sources 已删除（死代码，从未被调用）
-- 左手世界坐标统一通过下方别名 reload_tools.get_left_hand_world_location 获取
-- （内部调用公共 M.resolve_left_hand_world_sources，reload_tools.lua:902）
local get_left_hand_world_location = reload_tools.get_left_hand_world_location

-- 与 attachments.attachToController 同源：左手 MotionControllerComponent 世界坐标
local function get_left_motion_controller_spawn_transform()
    local ok_c, controllers_mod = pcall(require, "libs/controllers")
    if not ok_c or controllers_mod == nil then
        return nil, nil, "controllers_module_unavailable"
    end

    local loc = controllers_mod.getControllerLocation(Handed.Left)
    local rot = controllers_mod.getControllerRotation(Handed.Left)
    if loc == nil then
        pcall(function()
            controllers_mod.createController(Handed.Left)
        end)
        loc = controllers_mod.getControllerLocation(Handed.Left)
        rot = controllers_mod.getControllerRotation(Handed.Left)
    end
    if loc == nil then
        local mc = controllers_mod.getController(Handed.Left, false)
        if mc ~= nil then
            local ok_loc, scene_loc = pcall(function()
                return mc:K2_GetComponentLocation()
            end)
            loc = ok_loc and scene_loc or nil
            if rot == nil then
                local ok_rot, scene_rot = pcall(function()
                    return mc:K2_GetComponentRotation()
                end)
                rot = ok_rot and scene_rot or nil
            end
        end
    end
    if loc == nil then
        return nil, nil, "left_motion_controller_nil"
    end
    return loc, rot, nil
end

-- 在 spawn 时根据 socket 朝向偏移 poseable（退弹下落起始位置微调）
local function apply_mag_drop_spawn_offset(poseable, weapon_mesh)
    if poseable == nil or weapon_mesh == nil then
        return 0, 0, 0
    end
    -- 用 reload_tools.local_offset_to_world_delta 计算世界坐标偏移
    -- （内部用 uevrUtils.rotateVector 四元数回退，避免 kismet_math_library 为 nil）
    local socket_rot = nil
    pcall(function()
        socket_rot = weapon_mesh:GetSocketRotation(uevrUtils.fname_from_string(MAG_SOCKET_NAME))
    end)
    local dx, dy, dz = reload_tools.local_offset_to_world_delta(
        socket_rot,
        MAG_DROP_LOCAL_FORWARD,
        MAG_DROP_LOCAL_RIGHT,
        MAG_DROP_LOCAL_DOWN
    )
    dx = dx + (MAG_DROP_OFFSET_X or 0)
    dy = dy + (MAG_DROP_OFFSET_Y or 0)
    dz = dz + (MAG_DROP_OFFSET_Z or 0)
    if poseable.K2_AddWorldOffset ~= nil and (dx ~= 0 or dy ~= 0 or dz ~= 0) then
        pcall(function()
            poseable:K2_AddWorldOffset(uevrUtils.vector(dx, dy, dz), false, reusable_hit_result, false)
        end)
    end
    return dx, dy, dz
end


-- scale 隔离后弹匣骨世界坐标可能偏几 cm；对齐到真枪 magazine_joint 再下落
local function align_poseable_mag_bone(poseable, weapon_mesh, mag_bone_name)
    local target = get_bone_world_location(weapon_mesh, mag_bone_name)
    local current = get_bone_world_location(poseable, mag_bone_name)
    if target == nil or current == nil then
        return false, 0, 0, 0
    end
    local dx = target.X - current.X
    local dy = target.Y - current.Y
    local dz = target.Z - current.Z
    if poseable.K2_AddWorldOffset ~= nil then
        pcall(function()
            poseable:K2_AddWorldOffset(uevrUtils.vector(dx, dy, dz), false, reusable_hit_result, false)
        end)
    end
    return true, dx, dy, dz
end

local apply_poseable_render_flags = reload_tools.apply_poseable_render_flags
local get_actor_root = reload_tools.get_actor_root
local get_drop_scene_component = reload_tools.get_drop_scene_component
local prepare_spawned_actor_visible = reload_tools.prepare_spawned_actor_visible

-- 从 Handgun_02_A_Rig 克隆 Poseable；mag_only=true 时只留 magazine_joint（退弹下落用）
local function spawn_poseable_from_weapon(weapon_mesh, world_loc, world_rot, opts)
    opts = opts or {}
    local mag_only = opts.mag_only ~= false
    local skip_weapon_world_copy = opts.skip_weapon_world_copy == true
    local skip_mag_world_align = opts.skip_mag_world_align == true
    local skip_mag_drop_spawn_offset = opts.skip_mag_drop_spawn_offset == true

    -- 读档后常见：Lua 侧非 nil 但 UObject 已销毁 / SkeletalMesh 资产未就绪 → 原生 AV
    weapon_mesh = uevrUtils.getValid(weapon_mesh)
    if weapon_mesh == nil or not uobject_valid(weapon_mesh) then
        set_spawn_mag_fail("weapon_mesh_invalid")
        return nil, nil
    end
    local sk_asset = nil
    pcall(function()
        sk_asset = weapon_mesh.SkeletalMesh
    end)
    if sk_asset == nil or not uobject_valid(sk_asset) then
        set_spawn_mag_fail("skeletal_mesh_asset_nil")
        return nil, nil
    end
    if world_loc == nil then
        set_spawn_mag_fail("world_loc_nil")
        return nil, nil
    end
    local actor = uevrUtils.spawn_actor(reload_tools.make_spawn_transform(world_loc, world_rot), 1, nil)
    if actor == nil then
        set_spawn_mag_fail("spawn_actor_nil")
        return nil, nil
    end
    local poseable = nil
    local ok_create = pcall(function()
        poseable = uevrUtils.createPoseableMeshFromSkeletalMesh(weapon_mesh, {
            manualAttachment = true,
            relativeTransform = reload_tools.make_spawn_transform(world_loc, world_rot),
            deferredFinish = false,
            parent = actor,
        })
    end)
    if not ok_create or poseable == nil or not uobject_valid(poseable) then
        uevrUtils.destroy_actor(actor)
        set_spawn_mag_fail(ok_create and "create_poseable_nil" or "create_poseable_error")
        return nil, nil
    end
    local show_ok = false
    pcall(function()
        if poseable.SetMobility ~= nil then
            poseable:SetMobility(2)
        end
        if actor.K2_SetRootComponent ~= nil then
            actor:K2_SetRootComponent(poseable)
        end
        if not skip_weapon_world_copy then
            copy_component_world_transform(weapon_mesh, poseable)
        end
        apply_poseable_render_flags(poseable)
        if mag_only then
            show_ok = show_only_magazine_joint(poseable, MAG_BONE_NAME)
            if show_ok and not skip_mag_world_align then
                align_poseable_mag_bone(poseable, weapon_mesh, MAG_BONE_NAME)
                if not skip_mag_drop_spawn_offset then
                    apply_mag_drop_spawn_offset(poseable, weapon_mesh)
                end
            end
        else
            show_ok = true
        end
    end)
    if not show_ok then
        uevrUtils.destroy_actor(actor)
        set_spawn_mag_fail(mag_only and "show_only_magazine_joint_failed" or "spawn_full_pistol_failed")
        return nil, nil
    end
    prepare_spawned_actor_visible(actor)
    print_log(
        mag_only and "spawned performance mag via PoseableMagFromWeapon"
            or "spawned full pistol mesh via PoseableFullPistolFromWeapon",
        LogLevel.Info,
        "SPAWN"
    )
    return actor, poseable
end

local function spawn_full_pistol_poseable(weapon_mesh, world_loc, world_rot)
    return spawn_poseable_from_weapon(weapon_mesh, world_loc, world_rot, { mag_only = false })
end

local function spawn_performance_mag_from_weapon(weapon_mesh, world_loc, world_rot, extra_opts)
    local opts = { mag_only = true }
    if type(extra_opts) == "table" then
        for k, v in pairs(extra_opts) do
            opts[k] = v
        end
    end
    return spawn_poseable_from_weapon(weapon_mesh, world_loc, world_rot, opts)
end

-- =============================================================================
-- Mag Drop 动画：使用 reload_tools 驱动，本层负责引擎调用
-- =============================================================================

local function cancel_mag_drop()
    local drop = state.mag_drop
    if drop.actor ~= nil then
        uevrUtils.destroy_actor(drop.actor)
    end
    reload_tools.cancel(drop)
    drop.actor = nil
    drop.root = nil
end

-- Rotator → {Pitch,Yaw,Roll} 表（已下沉到 reload_tools，此处提前定义别名供下方使用）
local rotator_to_slide_table = reload_tools.rotator_to_slide_table

-- 构造 slide 跟随提供器：每帧从当前 weapon_mesh 的 socket 重新计算世界起点/终点/旋转
-- 用于枪移动时弹夹/弹壳跟随枪体（slide 阶段）
-- socket_name: 枪上的 socket 名（如 MAG_SOCKET_NAME）
-- start_local: {forward, right, down} 起点的 socket 局部偏移
-- end_local:   {forward, right, down} 终点的 socket 局部偏移
-- rot_offset:  {pitch, yaw, roll} 旋转偏移（加到 socket 旋转上，可为 nil）
local function make_slide_follow_provider(socket_name, start_local, end_local, rot_offset)
    -- 缓存上一帧有效 socket 数据：pcall 失败时回退，消除帧间抖动/瞬移
    local last_valid = { loc = nil, rot = nil }
    return function()
        local mesh = get_valid_weapon_mesh(state.weapon_mesh)
        if mesh == nil then
            -- fallback: 重新从 pawn 解析
            mesh = get_pistol_chain()
            if mesh == nil then return nil end
        end
        local socket_loc = get_socket_world_location(mesh, socket_name)
        local socket_rot = nil
        pcall(function()
            socket_rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(socket_name))
        end)
        -- 抖动修复：socket_loc 或 socket_rot 读取失败时，用上一帧缓存值
        if socket_loc == nil then
            socket_loc = last_valid.loc
            if socket_loc == nil then return nil end
        else
            last_valid.loc = socket_loc
        end
        if socket_rot == nil then
            socket_rot = last_valid.rot
            if socket_rot == nil then return nil end
        else
            last_valid.rot = socket_rot
        end

        local sdx, sdy, sdz = reload_tools.local_offset_to_world_delta(
            socket_rot, start_local.forward, start_local.right, start_local.down)
        local edx, edy, edz = reload_tools.local_offset_to_world_delta(
            socket_rot, end_local.forward, end_local.right, end_local.down)

        local rot = nil
        if rot_offset ~= nil then
            local rot_tbl = rotator_to_slide_table(socket_rot)
            if rot_tbl ~= nil then
                rot = {
                    Pitch = (rot_tbl.Pitch or 0) + (rot_offset.pitch or 0),
                    Yaw   = (rot_tbl.Yaw   or 0) + (rot_offset.yaw   or 0),
                    Roll  = (rot_tbl.Roll  or 0) + (rot_offset.roll  or 0),
                }
            end
        end
        return {
            sx = socket_loc.X + sdx, sy = socket_loc.Y + sdy, sz = socket_loc.Z + sdz,
            ex = socket_loc.X + edx, ey = socket_loc.Y + edy, ez = socket_loc.Z + edz,
            start_rot = rot, end_rot = rot,
        }
    end
end

-- 启动 slide+fall（slide-out 退弹用）
local function start_mag_release_drop(actor, world_loc, scene_comp, weapon_mesh)
    local root = get_drop_scene_component(actor, scene_comp)
    if root == nil or world_loc == nil then
        return false
    end

    -- slide 终点 = 起点 + socket 局部偏移
    local slide_ex = world_loc.X
    local slide_ey = world_loc.Y
    local slide_ez = world_loc.Z
    local socket_rot = nil
    if weapon_mesh ~= nil then
        pcall(function()
            socket_rot = weapon_mesh:GetSocketRotation(uevrUtils.fname_from_string(MAG_SOCKET_NAME))
        end)
        local dx, dy, dz = reload_tools.local_offset_to_world_delta(
            socket_rot,
            MAG_DROP_LOCAL_FORWARD,
            MAG_DROP_LOCAL_RIGHT,
            MAG_DROP_LOCAL_DOWN
        )
        slide_ex = world_loc.X + dx + (MAG_DROP_OFFSET_X or 0)
        slide_ey = world_loc.Y + dy + (MAG_DROP_OFFSET_Y or 0)
        slide_ez = world_loc.Z + dz + (MAG_DROP_OFFSET_Z or 0)
    end

    local drop = state.mag_drop
    drop.actor = actor
    drop.root = root

    -- 全程跟转：start_rot/end_rot 用 socket 旋转，follow_provider 每帧刷新使弹夹跟随枪体移动
    local slide_rot = rotator_to_slide_table(socket_rot)
    reload_tools.start_slide(drop, {
        sx = world_loc.X, sy = world_loc.Y, sz = world_loc.Z,
        ex = slide_ex, ey = slide_ey, ez = slide_ez,
        duration = SLIDE_DURATION,
        skip_fall = false,
        interpolate_rot = slide_rot ~= nil,
        start_rot = slide_rot,
        end_rot   = slide_rot,
        follow_provider = make_slide_follow_provider(
            MAG_SOCKET_NAME,
            { forward = MAG_SPAWN_LOCAL_FORWARD, right = MAG_SPAWN_LOCAL_RIGHT, down = MAG_SPAWN_LOCAL_DOWN },
            { forward = MAG_SPAWN_LOCAL_FORWARD + MAG_DROP_LOCAL_FORWARD,
              right   = MAG_SPAWN_LOCAL_RIGHT   + MAG_DROP_LOCAL_RIGHT,
              down    = MAG_SPAWN_LOCAL_DOWN    + MAG_DROP_LOCAL_DOWN },
            { pitch = MAG_DROP_ROT_PITCH, yaw = MAG_DROP_ROT_YAW, roll = MAG_DROP_ROT_ROLL }
        ),
    })

    -- 预填充 fall 参数（transition 时使用）
    drop.duration = DROP_DURATION
    drop.distance = DROP_DISTANCE

    pcall(function()
        root:K2_SetWorldLocation(uevrUtils.vector(world_loc.X, world_loc.Y, world_loc.Z), false, reusable_hit_result, false)
    end)
    return true
end

-- 启动 fall-only（grip-release 用）
-- follow_provider（可选）：使 fall 阶段 x/y 跟随枪体水平移动（走动时弹匣不会原地下坠）
local function start_mag_fall_only(actor, root, world_loc, on_finish, follow_provider)
    if root == nil or world_loc == nil then
        return false
    end
    local drop = state.mag_drop
    drop.actor = actor
    drop.root = root

    reload_tools.start_fall(drop, {
        sx = world_loc.X, sy = world_loc.Y, sz = world_loc.Z,
        duration = DROP_DURATION,
        distance = DROP_DISTANCE,
        on_finish = on_finish,
        follow_provider = follow_provider,
    })
    return true
end

--- Rotator → {Pitch,Yaw,Roll} 表（供 start_slide 欧拉插值；避免 userdata 字段偶发读空）— 已下沉到 reload_tools
local rotator_to_slide_table = reload_tools.rotator_to_slide_table

-- 启动 slide-only（slide-in 插弹用）
-- follow_provider（可选）：每帧从枪体 socket 刷新 slide 起点/终点/旋转，使弹夹跟随枪体移动
local function start_mag_slide_in(actor, root, start_loc, end_loc, start_rot, end_rot, on_finish, follow_provider)
    if root == nil or start_loc == nil or end_loc == nil then
        return false
    end
    local drop = state.mag_drop
    drop.actor = actor
    drop.root = root

    -- 统一成表，避免 userdata Pitch/Yaw/Roll 偶发读失败导致首帧 0,0,0（看起来像 90° 瞬移）
    local sr = rotator_to_slide_table(start_rot)
    local er = rotator_to_slide_table(end_rot)
    local use_rot = sr ~= nil and er ~= nil

    -- 滑入开始先锁到 start_rot，与位移同一帧对齐
    if use_rot and root.K2_SetWorldRotation ~= nil then
        pcall(function()
            root:K2_SetWorldRotation(
                uevrUtils.rotator({ sr.Pitch, sr.Yaw, sr.Roll }),
                false, reusable_hit_result, false)
        end)
    end
    if root.K2_SetWorldLocation ~= nil then
        pcall(function()
            root:K2_SetWorldLocation(
                uevrUtils.vector(start_loc.X, start_loc.Y, start_loc.Z),
                false, reusable_hit_result, false)
        end)
    end

    reload_tools.start_slide(drop, {
        sx = start_loc.X, sy = start_loc.Y, sz = start_loc.Z,
        ex = end_loc.X, ey = end_loc.Y, ez = end_loc.Z,
        duration = SLIDE_DURATION,
        skip_fall = true,
        interpolate_rot = use_rot,
        start_rot = sr,
        end_rot = er,
        on_finish = on_finish,
        follow_provider = follow_provider,
    })
    return true
end

local function finish_mag_drop_visual()
    local drop = state.mag_drop
    if drop.actor ~= nil then
        pcall(function()
            drop.actor:SetHiddenInGame(true, true)
        end)
        uevrUtils.destroy_actor(drop.actor)
    end
    reload_tools.cancel(drop)
    drop.actor = nil
    drop.root = nil
end

-- 每帧驱动 mag drop 动画：调用 reload_tools 计算插值，写入引擎
local function tick_mag_release_drop()
    local drop = state.mag_drop
    if not drop.active or drop.root == nil then
        return
    end

    if drop.phase == "slide" then
        local result = reload_tools.tick_slide(drop)
        if result == nil then return end

        pcall(function()
            drop.root:K2_SetWorldLocation(uevrUtils.vector(result.x, result.y, result.z), false, reusable_hit_result, false)
        end)
        if result.pitch then
            pcall(function()
                drop.root:K2_SetWorldRotation(uevrUtils.rotator({result.pitch, result.yaw, result.roll}), false, reusable_hit_result, false)
            end)
        end

        if result.phase_done then
            if result.all_done then
                -- slide-only 模式完成（slide-in）：销毁 actor
                if drop.actor ~= nil then
                    pcall(function() drop.actor:SetHiddenInGame(true, true) end)
                    uevrUtils.destroy_actor(drop.actor)
                end
                drop.actor = nil
                drop.root = nil
            else
                -- slide-out 完成，自动进入 fall 阶段
                reload_tools.transition_slide_to_fall(drop)
            end
        end
        return
    end

    if drop.phase == "fall" then
        local result = reload_tools.tick_fall(drop)
        if result == nil then return end

        pcall(function()
            drop.root:K2_SetWorldLocation(uevrUtils.vector(result.x, result.y, result.z), false, reusable_hit_result, false)
        end)

        if result.done then
            finish_mag_drop_visual()
            print_log("mag release drop finished", LogLevel.Debug)
        end
    end
end

-- =============================================================================
-- Phase 2: 左胯取弹 → 左手 component attach → proximity 插弹
-- =============================================================================

-- 恢复枪上弹匣 bone 可见
local function show_magazine_bone(mesh)
    mesh = get_valid_weapon_mesh(mesh)
    if mesh == nil then
        return false
    end
    local ok, err = pcall(function()
        if mesh.UnHideBoneByName == nil then
            error("UnHideBoneByName missing")
        end
        mesh:UnHideBoneByName(uevrUtils.fname_from_string(MAG_BONE_NAME))
    end)
    if ok then
        state.mesh_hidden = false
        return true
    end
    print_log("UnHideBoneByName failed: " .. tostring(err), LogLevel.Warn)
    return false
end

local function set_needs_rack(needs)
    state.needs_rack = needs == true
    _G[KEYS.needs_rack] = state.needs_rack
end

local function apply_mag_insert_ammo()
    local offsets = reload_tools.WEAPON_PROFILES.pistol
    local weapon, _, _ = reload_tools.get_equipped_weapon()
    local clip_before = nil
    if weapon ~= nil then
        clip_before = reload_tools.read_clip_ammo(weapon, offsets)
    end
    -- 空仓换弹：弹夹=0 时只扣备弹，等拉栓后再补满；战术换弹 clip>0 则立即补满
    local defer_fill = clip_before == 0
    local result = reload_tools.apply_mag_insert(offsets, {
        defer_clip_fill = defer_fill,
    })
    if defer_fill and result.ok then
        state.pending_clip_fill_after_rack = true
        print_log("[RACK] mag insert deferred clip fill (clip was 0)", LogLevel.Info)
    end
    log_ammo_event(format_ammo_result("mag_insert", result))
    return result
end

-- 前置声明：实现位于 despawn_left_hand_mag 之前（finish_mag_insert_state 在此之前定义，
-- 需提前声明才能引用）
local detach_hand_from_mag

local function finish_mag_insert_state()
    apply_mag_insert_ammo()
    -- 插入完成：手脱附弹夹（restoreHandSnapshot 恢复手部追踪；内部已清手势）
    detach_hand_from_mag("insert_finish")
    clear_left_hand_mag_pose()
    if state.mesh_hidden then
        show_magazine_bone(state.weapon_mesh)
    end
    state.mag_dropped = false
    state.mag_inserted = true
    state.manual_reload_active = false
    state.weapon = nil
    state.weapon_mesh = nil
    _G[KEYS.mag_inserted] = true
end

-- 左手取弹：spawn 表演弹匣，由 attachments 轮询 attachToMesh（与 flashlight 相同链路）
local function spawn_mag_in_hand()
    if state.mag_in_left_hand then
        set_spawn_mag_fail("already_holding")
        print_log("spawn_mag_in_hand: already holding", LogLevel.Debug, "SPAWN")
        return false
    end

    -- 备弹>0 才允许生成表演弹夹；读 st.reserveAmmo（DLL 回调维护的缓存，与面板同源）
    local reserve = reload_tools.sh2_state().reserveAmmo
    if reserve == nil or reserve <= 0 then
        set_spawn_mag_fail("no_reserve:" .. tostring(reserve))
        print_log("spawn_mag_in_hand: reserve ammo <= 0 (" .. tostring(reserve) .. ")", LogLevel.Warn, "SPAWN")
        return false
    end

    local mesh, chain, err = get_pistol_chain()
    if mesh == nil then
        set_spawn_mag_fail("no_pistol:" .. tostring(err or "unknown"))
        print_log("spawn_mag_in_hand: no pistol (" .. tostring(err) .. ")", LogLevel.Warn, "SPAWN")
        return false
    end

    local left_comp = resolve_left_hand_component()
    local spawn_loc, spawn_rot, spawn_err = get_left_hand_component_world_transform()

    if left_comp == nil or spawn_loc == nil then
        set_spawn_mag_fail("no_left_hand_component:" .. tostring(spawn_err or "unknown"))
        print_log("spawn_mag_in_hand: no left hand component (" .. tostring(spawn_err) .. ")", LogLevel.Warn, "SPAWN")
        return false
    end
    -- attachToMesh 内部对 mesh:get_full_name() 无 pcall；失效组件会原生崩溃
    if not uobject_valid(left_comp) then
        set_spawn_mag_fail("left_hand_component_stale")
        print_log("spawn_mag_in_hand: left hand component stale after load", LogLevel.Warn, "SPAWN")
        return false
    end

    local actor, poseable = spawn_performance_mag_from_weapon(mesh, spawn_loc, spawn_rot, {
        skip_weapon_world_copy = true,
        skip_mag_world_align = true,
    })
    if actor == nil or poseable == nil then
        set_spawn_mag_fail("spawn_performance_mag_failed")
        print_log("spawn_mag_in_hand: spawn failed", LogLevel.Warn, "SPAWN")
        return false
    end

    state.mag_in_left_hand = true
    state.mag_inserted = false
    state.left_hand_mag_attachment = poseable
    state.left_hand_mag_actor = actor

    -- attachToMesh + initAttachment hook 应用 pistol_mag 偏移/手势；轮询维持附着
    local attach_ok = pcall(function()
        attachments.attachToMesh(poseable, left_comp, MAG_ATTACH_SOCKET, Handed.Left, magAttachOptions)
    end)
    if not attach_ok then
        print_log("spawn_mag_in_hand: attachToMesh failed, despawning", LogLevel.Warn, "SPAWN")
        state.mag_in_left_hand = false
        state.left_hand_mag_attachment = nil
        state.left_hand_mag_actor = nil
        pcall(function()
            uevrUtils.destroy_actor(actor)
        end)
        set_spawn_mag_fail("attach_to_mesh_failed")
        return false
    end
    apply_pistol_mag_transform(poseable)
    apply_left_hand_mag_pose()
    print_log(
        "spawn_mag_in_hand OK actor=" .. safe_tostring(actor) .. " poseable=" .. safe_tostring(poseable)
            .. " socket=" .. MAG_ATTACH_SOCKET,
        LogLevel.Info,
        "SPAWN"
    )
    return true
end

-- -----------------------------------------------------------------------------
-- 插入期左手跟随弹夹（2026-08-31 用户拍板，item door「手跟钥匙」同构）
-- 动态捕获两步引擎换算，零偏移调校、不改底层 hands.lua：
--   ① executeUEVRCallbacks("on_accessory_attach") 走标准通道：hands.lua attachHandToTarget
--      内部 saveHandSnapshot（供脱附恢复）并把左手所有手势网格组件挂到弹夹 root；
--   ② 对 AttachParent==root 的组件 K2_AttachTo(root, "", 1, false) KeepWorld 重挂：
--      引擎自动改写 RelativeTransform 保持手当前世界位姿，绕过 attachHandToTarget
--      内部 composeRotators(baseRotation, rot) 的固定叠加。
--      按 AttachParent==root 过滤自适应任意手部 profile 组件数，无需预诊断。
-- 挂附时机：弹夹瞬移到管子起点之前，手随弹夹一起瞬移+滑入（手势保持不变）。
-- 脱附（on_accessory_detach → restoreHandSnapshot 恢复手部追踪，重复调用安全）：
--   ① 插入完成；② 滑入中松开左 Grip；③ 异常路径兜底。
-- -----------------------------------------------------------------------------
detach_hand_from_mag = function(reason)
    if not state.hand_attached_to_mag then
        return
    end
    state.hand_attached_to_mag = false
    pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_detach", Handed.Left)
    end)
    -- 手已离开弹夹，恢复 open 手势（幂等；finish 路径的 clear_left_hand_mag_pose 与此重复合规）
    clear_left_hand_mag_pose()
    print_log("[HAND-MAG] detach (" .. tostring(reason) .. ")", LogLevel.Info)
end

local function attach_hand_to_mag_dynamic(root)
    if state.hand_attached_to_mag then
        return true
    end
    if root == nil then
        return false
    end
    -- ① 标准回调挂附：偏移传零值（下一步 KeepWorld 会整体覆盖，此步只为保存快照+挂组件）
    local ok = pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_attach",
            Handed.Left, root, nil, 0, { 0, 0, 0 }, { 0, 0, 0 })
    end)
    if not ok then
        return false
    end
    -- ② KeepWorld 重挂：仅处理 ① 刚挂上的左手组件（右手组件 AttachParent 不会被改，天然过滤）
    pcall(function()
        for _, comp in ipairs(hands.getAllHandComponents()) do
            if comp ~= nil and comp.AttachParent == root and comp.K2_AttachTo ~= nil then
                comp:K2_AttachTo(root, uevrUtils.fname_from_string(""), 1, false)
            end
        end
    end)
    state.hand_attached_to_mag = true
    -- 手势保持不变（幂等重应用，对齐 item_door attach_hand_to_key 的 pull_lock 恢复）
    apply_left_hand_mag_pose()
    print_log("[HAND-MAG] attach (dynamic KeepWorld)", LogLevel.Info)
    return true
end

-- 清理左手弹匣（despawn，不走掉落效果）
local function despawn_left_hand_mag()
    -- 兜底：滑入期间手仍吸附在弹夹上时先脱附，再销毁 actor（避免手挂在已销毁对象上）
    detach_hand_from_mag("despawn")
    if not state.mag_in_left_hand then
        return
    end

    state.mag_in_left_hand = false
    state.left_hand_mag_attachment = nil

    pcall(function()
        attachments.detachGripAttachments(Handed.Left)
    end)
    clear_left_hand_mag_pose()

    local actor = state.left_hand_mag_actor
    state.left_hand_mag_actor = nil
    if actor ~= nil then
        pcall(function()
            uevrUtils.destroy_actor(actor)
        end)
    end

    print_log("despawn_left_hand_mag OK", LogLevel.Debug)
end

-- 从左手 detach 弹匣但保留 actor 供动画使用；返回 actor, poseable, 捕获的世界坐标和旋转
-- 注意：必须在 detach 之前捕获坐标（maintainWorldPositionOnDetachFromParent=false）
-- 持弹时 RelativeRotation 非零；若 detach 后不先清零再写世界位姿，会闪一下约 90° 再回正
-- keep_hand_pose=true：保留握弹手势（插弹 slide-in 路径，手跟随弹夹，手势到插入完成才清）
-- keep_hand_pose=false/nil：清除手势恢复 open（掉落 grip-release drop 路径，行为不变）
local function detach_left_hand_mag_for_animation(keep_hand_pose)
    if not state.mag_in_left_hand then
        return nil, nil, nil, nil
    end
    local poseable = uevrUtils.getValid(state.left_hand_mag_attachment)
    local actor = state.left_hand_mag_actor
    local loc = nil
    local rot = nil
    if poseable ~= nil then
        loc = get_component_world_location(poseable)
        rot = get_component_world_rotation(poseable)
    end
    -- 先清状态，阻止同帧 grip update / apply_pistol_mag_transform 把相对偏移写回
    state.mag_in_left_hand = false
    state.left_hand_mag_attachment = nil
    state.left_hand_mag_actor = nil
    publish_globals()
    pcall(function()
        attachments.detachGripAttachments(Handed.Left)
    end)
    if not keep_hand_pose then
        clear_left_hand_mag_pose()
    end

    -- detach 后：清掉持弹 Relative*，再一次性写回捕获的世界位姿（与 shotgun slide detach 对齐）
    if poseable ~= nil and loc ~= nil then
        local rot_tbl = rotator_to_slide_table(rot)
        pcall(function()
            uevrUtils.set_component_relative_location(poseable, uevrUtils.vector(0, 0, 0))
            uevrUtils.set_component_relative_rotation(poseable, uevrUtils.rotator(0, 0, 0))
        end)
        pcall(function()
            if poseable.K2_SetWorldLocation ~= nil then
                poseable:K2_SetWorldLocation(
                    uevrUtils.vector(loc.X, loc.Y, loc.Z),
                    false, reusable_hit_result, false)
            end
            if rot_tbl ~= nil and poseable.K2_SetWorldRotation ~= nil then
                poseable:K2_SetWorldRotation(
                    uevrUtils.rotator({ rot_tbl.Pitch, rot_tbl.Yaw, rot_tbl.Roll }),
                    false, reusable_hit_result, false)
            end
        end)
        rot = rot_tbl
    end
    return actor, poseable, loc, rot
end

--- 插弹口世界坐标 = magazine_socket_joint + MAG_INSERT_OFFSET（跟随枪旋转）
---@param mesh userdata|nil
---@return table|nil {X,Y,Z}
local function get_mag_insert_world_location(mesh)
    if mesh == nil then
        return nil
    end
    local base = get_socket_world_location(mesh, MAG_SOCKET_NAME)
    if base == nil then
        return nil
    end
    local socket_rot = nil
    pcall(function()
        socket_rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(MAG_SOCKET_NAME))
    end)
    local dx, dy, dz = reload_tools.local_offset_to_world_delta(
        socket_rot,
        MAG_INSERT_OFFSET.forward or 0,
        MAG_INSERT_OFFSET.right or 0,
        MAG_INSERT_OFFSET.down or 0
    )
    return {
        X = (base.X or 0) + dx,
        Y = (base.Y or 0) + dy,
        Z = (base.Z or 0) + dz,
    }
end

-- 启动 slide-in 动画（插弹用）：左手弹匣从固定位置滑入 socket，完成后 despawn + 恢复枪上弹匣骨
-- 旋转策略：start_rot / end_rot 均使用 socket 旋转 + 可调偏移（MAG_SLIDE_IN_ROT_*）
-- 位置策略：起点 = socket + MAG_SLIDE_IN_START_* 偏移（管子概念，与左手位置无关）
-- 终点 = socket + MAG_INSERT_OFFSET（弹夹入仓位）
local function start_slide_in_animation()
    -- keep_hand_pose=true：保留握弹手势（手跟随弹夹滑入，插入完成时才清）
    local actor, poseable, _, _ = detach_left_hand_mag_for_animation(true)
    if actor == nil or poseable == nil then
        if actor ~= nil then
            pcall(function() uevrUtils.destroy_actor(actor) end)
        end
        return false
    end
    local mesh, _ = get_pistol_chain()
    if mesh == nil then
        pcall(function() uevrUtils.destroy_actor(actor) end)
        return false
    end

    -- 终点 = socket + MAG_INSERT_OFFSET（弹夹入仓位）
    local end_loc = get_mag_insert_world_location(mesh)
    if end_loc == nil then
        pcall(function() uevrUtils.destroy_actor(actor) end)
        return false
    end

    -- 起点 = socket 位置 + MAG_SLIDE_IN_START_* 局部偏移（管子概念：枪身正下方固定距离）
    local socket_loc = get_socket_world_location(mesh, MAG_SOCKET_NAME)
    if socket_loc == nil then
        pcall(function() uevrUtils.destroy_actor(actor) end)
        return false
    end
    local socket_rot = nil
    pcall(function()
        socket_rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(MAG_SOCKET_NAME))
    end)
    local sdx, sdy, sdz = reload_tools.local_offset_to_world_delta(
        socket_rot,
        MAG_SLIDE_IN_START_FORWARD,
        MAG_SLIDE_IN_START_RIGHT,
        MAG_SLIDE_IN_START_DOWN
    )
    local start_loc = {
        X = socket_loc.X + sdx,
        Y = socket_loc.Y + sdy,
        Z = socket_loc.Z + sdz,
    }

    -- 统一旋转：start_rot = end_rot = socket旋转 + 可调偏移
    local slide_rot = nil
    if socket_rot ~= nil then
        local base = rotator_to_slide_table(socket_rot)
        slide_rot = {
            Pitch = (base.Pitch or 0) + MAG_SLIDE_IN_ROT_PITCH,
            Yaw   = (base.Yaw or 0) + MAG_SLIDE_IN_ROT_YAW,
            Roll  = (base.Roll or 0) + MAG_SLIDE_IN_ROT_ROLL,
        }
    end

    -- 手跟弹夹：必须在弹夹瞬移到管子起点【之前】完成动态挂附（KeepWorld 锁定手当前
    -- 世界位姿），之后弹夹瞬移/滑入时手作为子物体跟随；若瞬移后才挂附，手会以
    -- "距弹夹 12cm 的悬空偏移"滑入，插完手够不到枪。挂附失败则优雅降级（弹夹独立滑入）
    attach_hand_to_mag_dynamic(poseable)

    -- detach 后立即锁到目标位置和旋转，消除一切中间态
    if poseable ~= nil then
        if slide_rot ~= nil and poseable.K2_SetWorldRotation ~= nil then
            pcall(function()
                poseable:K2_SetWorldRotation(
                    uevrUtils.rotator({ slide_rot.Pitch, slide_rot.Yaw, slide_rot.Roll }),
                    false, reusable_hit_result, false)
            end)
        end
        if poseable.K2_SetWorldLocation ~= nil then
            pcall(function()
                poseable:K2_SetWorldLocation(
                    uevrUtils.vector(start_loc.X, start_loc.Y, start_loc.Z),
                    false, reusable_hit_result, false)
            end)
        end
    end

    local on_finish = function()
        finish_mag_insert_state()
        print_log("slide_in finished", LogLevel.Info)
    end
    -- 跟随提供器：slide-in 期间枪移动时弹夹跟随枪体（起点=入弹口下方管子起点，终点=入弹口）
    local slide_in_provider = make_slide_follow_provider(
        MAG_SOCKET_NAME,
        { forward = MAG_SLIDE_IN_START_FORWARD, right = MAG_SLIDE_IN_START_RIGHT, down = MAG_SLIDE_IN_START_DOWN },
        { forward = MAG_INSERT_OFFSET.forward or 0, right = MAG_INSERT_OFFSET.right or 0, down = MAG_INSERT_OFFSET.down or 0 },
        { pitch = MAG_SLIDE_IN_ROT_PITCH, yaw = MAG_SLIDE_IN_ROT_YAW, roll = MAG_SLIDE_IN_ROT_ROLL }
    )
    local ok = start_mag_slide_in(actor, poseable, start_loc, end_loc, slide_rot, slide_rot, on_finish, slide_in_provider)
    -- detach 已清 mag_in_left_hand 并 publish；此处立即再 publish，用 slide-in active+skip_fall 盖住空窗
    if ok then
        publish_globals()
    end
    return ok
end

-- 启动 grip-release 垂直下落（复用 mag drop fall）：不立即 despawn，先掉落再清理
-- fall 阶段水平跟随枪体：走动/转身时弹匣不会原地下坠脱离枪体
local function start_grip_release_drop()
    local actor, poseable, start_loc, _ = detach_left_hand_mag_for_animation()
    if actor == nil or poseable == nil or start_loc == nil then
        if actor ~= nil then
            pcall(function() uevrUtils.destroy_actor(actor) end)
        end
        return false
    end
    -- 清除左手握弹手势（恢复 open），但不清理 manual_reload_active 状态
    -- （弹夹掉落后玩家仍可重新取弹继续换弹流程）
    clear_left_hand_mag_pose()
    -- 释放卡扣音效：复用 shotgun Pump_Action 事件 2.0-3.7s 片段（SDK 无独立手枪 Mag_Release 事件）
    -- 对齐 shotgun_reload.lua L3669-3671 的 mag_release 触发模式
    trigger_reload_haptic("mag_release")
    local seg_mr = M.get_audio_segment("mag_release")
    if seg_mr then
        audio.play_segment(seg_mr.audio_key, seg_mr.start_sec, seg_mr.duration)
    end
    local on_finish = function()
        -- 下落后无需额外清理：detach_left_hand_mag_for_animation 已在动画前清零左手持弹状态
        -- 不再重复清除，避免覆盖下落期间玩家可能重新抓取的新弹匣状态
        print_log("grip_release drop finished", LogLevel.Info)
    end
    -- fall follow_provider：返回枪体 socket 水平位置（偏移为 0，纯跟随枪体）
    -- tick_fall 会记录初始 socket 位置，计算相对运动，使弹匣跟着枪水平移动
    local fall_provider = make_slide_follow_provider(
        MAG_SOCKET_NAME,
        { forward = 0, right = 0, down = 0 },
        { forward = 0, right = 0, down = 0 },
        nil
    )
    return start_mag_fall_only(actor, poseable, start_loc, on_finish, fall_provider)
end

-- 取消整个手动换弹流程（退弹状态清理）
local function cancel_manual_reload()
    despawn_left_hand_mag()
    cancel_mag_drop()
    if state.mesh_hidden then
        show_magazine_bone(state.weapon_mesh)
    end
    state.mag_dropped = false
    state.manual_reload_active = false
    state.mag_inserted = false
    state.pending_clip_fill_after_rack = false
    state.weapon = nil
    state.weapon_mesh = nil
end

-- 审计问题1：工具函数提级到 reload_tools，此处保留 local 别名兼容现有调用
-- reload_tools.get_current_weapon_key 直接读 _G.__sh2_equipped_weapon（与 KEYS.equipped_weapon 等价）
local get_current_weapon_key = reload_tools.get_current_weapon_key

-- 每 tick 比对武器标识，变化时清理手动换弹状态
-- 覆盖所有换枪路径：玩家切槽位、系统自动收枪、武器销毁
local function tick_weapon_change_watch()
    local current_key = get_current_weapon_key()
    if state.last_weapon_key == nil then
        -- 首帧或从无武器状态切换：只记录，不清理
        state.last_weapon_key = current_key
        return
    end
    if current_key ~= state.last_weapon_key then
        -- 武器变化：清理手动换弹状态
        if state.manual_reload_active or state.mag_in_left_hand or state.pending_clip_fill_after_rack then
            print_log(
                "[WEAPON_SWAP] weapon changed: " .. tostring(state.last_weapon_key) .. " -> " .. tostring(current_key) .. ", cancel manual reload",
                LogLevel.Info
            )
            cancel_manual_reload()
        end
        state.last_weapon_key = current_key
    end
end

-- 左手到插弹口的距离（UE 单位，cm；含 MAG_INSERT_OFFSET）
local function get_left_hand_to_socket_distance(socket_name)
    local mesh, _ = get_pistol_chain()
    if mesh == nil then
        return math.huge
    end
    local socket_loc = nil
    if socket_name == nil or socket_name == MAG_SOCKET_NAME then
        socket_loc = get_mag_insert_world_location(mesh)
    else
        socket_loc = get_socket_world_location(mesh, socket_name)
    end
    if socket_loc == nil then
        return math.huge
    end

    -- 优先用已附着弹匣的世界位置（与 flashlight 附件同源）
    local gripped = attachments.getCurrentGrippedAttachment(Handed.Left)
    local left_hand_loc = gripped and get_component_world_location(gripped) or nil
    if left_hand_loc == nil then
        left_hand_loc = get_component_world_location(resolve_left_hand_component())
    end
    if left_hand_loc == nil then
        left_hand_loc, _, _ = get_left_hand_world_location()
    end

    if left_hand_loc == nil then
        return math.huge
    end

    -- 复用 uevrUtils.distanceBetween
    return uevrUtils.distanceBetween(left_hand_loc, socket_loc) or math.huge
end

-- 插弹：左手弹匣滑入 socket（slide-in），完成后 despawn + 恢复枪上弹匣视觉
local function insert_mag()
    if not state.mag_dropped then
        return false
    end
    if not state.mag_in_left_hand then
        return false
    end

    -- 启动 slide-in 动画；on_finish 内完成 despawn + unhide bone + 状态更新
    if not start_slide_in_animation() then
        -- slide-in 启动失败，退回立即 despawn + unhide
        despawn_left_hand_mag()
        finish_mag_insert_state()
        return false
    end

    -- 插入弹夹音效：从 Play_Wpn_Pistol_Reload 的 mag_insert 起点播放
    audio.play_segment(PISTOL_RELOAD_AUDIO_KEY,
        PISTOL_RELOAD_SEGMENTS.mag_insert.start_sec, PISTOL_RELOAD_SEGMENTS.mag_insert.duration)
    -- 插弹手柄震动：右手 touch_enter
    trigger_reload_haptic("mag_insert")

    print_log("insert_mag slide_in started", LogLevel.Info)
    return true
end

-- =============================================================================
-- Phase 5: 空仓挂机（slide lock）状态维护
-- =============================================================================
local function is_player_pistol(weapon)
    if not uobject_valid(weapon) then
        return false
    end
    if state.weapon ~= nil and weapon == state.weapon then
        return true
    end
    return is_pistol_weapon(weapon)
end

local function get_ranged_reload_player()
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    if pawn == nil then
        return nil
    end
    local animation = uevrUtils.getValid(pawn, {"Animation"})
    if animation == nil or SHAnimCombatSubcomp_c == nil then
        return nil
    end
    local anim_combat = nil
    pcall(function()
        anim_combat = animation:FindSubcomponentByClass(SHAnimCombatSubcomp_c)
    end)
    if anim_combat == nil then
        return nil
    end
    local player = nil
    pcall(function()
        player = anim_combat.RangedReload
    end)
    return player
end

local function is_player_ranged_subcomp(subcomp)
    if not uobject_valid(subcomp) or SHRangedCmbSubcomp_c == nil then
        return false
    end
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    if pawn == nil then
        return false
    end
    local combat = uevrUtils.getValid(pawn, {"Combat"})
    if combat == nil then
        return false
    end
    local ranged = nil
    pcall(function()
        ranged = combat:FindSubcomponentByClass(SHRangedCmbSubcomp_c)
    end)
    return ranged ~= nil and ranged == subcomp
end

local function should_block_native_reload()
    return state.slide_locked == true or state.manual_reload_active == true
end

local function request_cancel_native_reload(reason)
    state.pending_cancel_reload = true
    state.pending_cancel_reason = reason
end

local function montage_name_is_reload(name)
    if name == nil or name == "" then
        return false
    end
    if string.find(string.lower(name), "reload", 1, true) ~= nil then
        return true
    end
    for _, marker in ipairs(RELOAD_MONTAGE_NAME_MARKERS) do
        if string.find(name, marker, 1, true) ~= nil then
            return true
        end
    end
    return false
end

local function ranged_reload_is_active(reload_player)
    if not uobject_valid(reload_player) then
        return false
    end
    local playing = false
    pcall(function()
        playing = reload_player:IsPlaying() == true
    end)
    if playing then
        return true
    end
    local pos = 0
    pcall(function()
        if reload_player.GetPosition ~= nil then
            pos = reload_player:GetPosition() or 0
        end
    end)
    return pos > 0.01
end

-- RangedReload 用 AnimSequence 驱动；IsPlaying 可能 false 但 GetPosition>0，此时 StopRequest 不会被旧逻辑调用
local function stop_ranged_reload_player(reload_player)
    if not uobject_valid(reload_player) then
        return false
    end
    if not ranged_reload_is_active(reload_player) then
        return false
    end
    pcall(function()
        if reload_player.StopRequest ~= nil then
            reload_player:StopRequest()
        elseif reload_player.call ~= nil then
            reload_player:call("StopRequest")
        end
    end)
    pcall(function()
        if reload_player.SetPosition ~= nil then
            reload_player:SetPosition(0.0)
        end
    end)
    pcall(function()
        if reload_player.StopPlaying ~= nil then
            reload_player:StopPlaying()
        end
    end)
    return true
end

local function stop_pawn_reload_montages()
    if reload_block_guard.cancelling then
        return false
    end
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    if not uobject_valid(pawn) then
        return false
    end
    local anim_instance = uevrUtils.getValid(pawn, {"Mesh", "AnimScriptInstance"})
    if not uobject_valid(anim_instance) then
        return false
    end
    local stopped = false
    pcall(function()
        local active = anim_instance:GetCurrentActiveMontage()
        if uobject_valid(active) then
            local ok_name, short_name = pcall(function()
                return uevrUtils.getShortName(active)
            end)
            if ok_name and montage_name_is_reload(short_name) then
                anim_instance:Montage_Stop(0.0, active)
                stopped = true
            end
        end
    end)
    pcall(function()
        if pawn.GetCurrentMontage ~= nil then
            local montage = pawn:GetCurrentMontage()
            if uobject_valid(montage) then
                local ok_name, short_name = pcall(function()
                    return uevrUtils.getShortName(montage)
                end)
                if ok_name and montage_name_is_reload(short_name) then
                    if anim_instance.Montage_Stop ~= nil then
                        anim_instance:Montage_Stop(0.0, montage)
                        stopped = true
                    end
                end
            end
        end
    end)
    return stopped
end

local function cancel_native_reload_anim(reason)
    if reload_block_guard.cancelling then
        return false
    end
    reload_block_guard.cancelling = true
    local cancelled = false
    local ok, err = pcall(function()
        local reload_player = get_ranged_reload_player()
        if stop_ranged_reload_player(reload_player) then
            cancelled = true
        end
        if stop_pawn_reload_montages() then
            cancelled = true
        end
    end)
    reload_block_guard.cancelling = false
    if not ok then
        print_log("cancel_native_reload_anim error: " .. tostring(err), LogLevel.Warn, "SLIDE_LOCK")
        return false
    end
    if cancelled and reason ~= nil and reason ~= "tick" then
        print_log("cancel native reload (" .. tostring(reason) .. ")", LogLevel.Info)
    end
    return cancelled
end

local function process_pending_reload_cancel()
    if state.pending_cancel_reload ~= true then
        return
    end
    state.pending_cancel_reload = false
    local reason = state.pending_cancel_reason
    state.pending_cancel_reason = nil
    cancel_native_reload_anim(reason)
end

-- A 类 montage change hook 回调入口（由 reload_hooks dispatch 调用）
-- reload_hooks 已做 montage_name_is_reload 判断和 Montage_Stop，本函数只决定是否阻止 + 触发 cancel
function M.on_montage_change_check(montage, montageName, animInstance)
    if reload_block_guard.cancelling then
        return false
    end
    if not should_block_native_reload() then
        return false
    end
    -- 延后到 tick 再 cancel，避免在 montage 回调栈内重入
    request_cancel_native_reload("montage_cb")
    return true
end

local function is_reload_montage_player(obj)
    if not uobject_valid(obj) then
        return false
    end
    local reload_player = get_ranged_reload_player()
    if reload_player ~= nil and obj == reload_player then
        return true
    end
    local ok, input_name = pcall(function()
        if obj.GetInputData == nil then
            return nil
        end
        local input = obj:GetInputData()
        if input == nil then
            return nil
        end
        return tostring(input)
    end)
    return ok and input_name ~= nil and input_name:find("Reload", 1, true) ~= nil
end

-- A 类 hook 安装工具（force_bool_return_false / wrap_hook_callback / install_uevr_*）
-- 已挪到 libs/reload_hooks.lua，本文件只保留 hook 回调内部逻辑，通过 M.on_xxx 导出

local function force_release_vr_aim(reason)
    local env = rawget(_G, "VREnvironment")
    if type(env) ~= "table" or type(env.getEnhancer) ~= "function" then
        return
    end
    local enhancer = env:getEnhancer()
    if type(enhancer) ~= "table" then
        return
    end
    pcall(function()
        if type(enhancer._aimPistolLikeAction) == "table"
            and type(enhancer._aimPistolLikeAction.leave) == "function" then
            enhancer._aimPistolLikeAction:leave()
        end
    end)
    -- 不 leave gripRight：保留 aimMode 3（空仓右抓握+RT 调近战）
    enhancer._twoHandAimHold = false
    _G[KEYS.aim_active] = false
    if reason ~= nil then
        print_log("[SLIDE_LOCK] VR aim released: " .. tostring(reason), LogLevel.Info)
    end
end

-- 设置/清除空仓挂机状态（与 needs_rack 解耦：仅空膛/无法击发时锁定）
local function set_slide_locked(locked)
    local old = state.slide_locked == true
    local new = locked == true
    state.slide_locked = new
    _G[KEYS.slide_locked] = state.slide_locked
    _G.__vr_block_fire_when_empty = state.slide_locked
    if state.slide_locked then
        force_release_vr_aim("slide_locked")
    end
end

local function apply_mag_eject_ammo()
    local result = reload_tools.apply_mag_eject(reload_tools.WEAPON_PROFILES.pistol, 1)
    log_ammo_event(format_ammo_result("mag_eject", result))
    if result.ok ~= true then
        return result
    end
    if result.needs_rack == true then
        set_needs_rack(true)
        set_slide_locked(true)
    else
        set_needs_rack(false)
        set_slide_locked(false)
    end
    return result
end

-- A 类 IsFireReady hook 回调入口：slide_locked 时阻止开火（由 reload_hooks dispatch 调用）
function M.on_fire_ready_check(obj)
    return state.slide_locked == true and is_player_pistol(obj)
end

-- A 类 OnOutOfAmmoPerformed hook 回调入口：检测空仓开火（由 reload_hooks dispatch 调用）
function M.on_out_of_ammo(obj)
    if not is_player_pistol(obj) then
        return
    end
    if state.slide_locked == true then
        request_cancel_native_reload("OnOutOfAmmoPerformed_dry")
        return
    end
    set_needs_rack(true)
    set_slide_locked(true)
    request_cancel_native_reload("OnOutOfAmmoPerformed")
    print_log("[SLIDE_LOCK] slide locked by OnOutOfAmmoPerformed", LogLevel.Info)
end

-- A 类 CanBeReloaded hook 回调入口：阻止原生换弹（由 reload_hooks dispatch 调用）
-- 瞄准/空弹时引擎不得发起换弹（瞄准右键/LT 触发换弹的主因）
function M.on_can_be_reloaded_check(obj)
    return should_block_native_reload() and is_player_pistol(obj)
end

-- PlayRequest：空仓挂机时必须 SKIP 原函数（仅 StopRequest 无法阻止 AnimSequence 已开播）
local function locals_anim_data_is_reload(locals)
    if locals == nil then
        return false
    end
    local candidates = { locals.InputData, locals.PlayAnimationData, locals.AnimData, locals.AnimationData }
    for i = 1, #candidates do
        local data = candidates[i]
        if uobject_valid(data) then
            local ok_name, name = pcall(function()
                return uevrUtils.getShortName(data)
            end)
            if ok_name and montage_name_is_reload(name) then
                return true
            end
        end
    end
    return false
end

local function should_skip_reload_montage_play(obj, locals)
    if not should_block_native_reload() then
        return false
    end
    if is_reload_montage_player(obj) then
        return true
    end
    return locals_anim_data_is_reload(locals)
end

-- A 类 PlayRequest/PlayOrOverwriteRequest hook 回调入口（由 reload_hooks dispatch 调用）
-- 返回 true 跳过原函数：空仓挂机时阻止 AnimSequence 启播
function M.on_play_request_check(obj, locals)
    return should_skip_reload_montage_play(obj, locals)
end

-- A 类 OnRangedReload hook 回调入口（由 reload_hooks dispatch 调用）
-- 返回 true 跳过原函数：换弹链入口，skip 防止动画+音效启动（cancel 来不及）
function M.on_ranged_reload_check(obj)
    return should_block_native_reload() and is_player_ranged_subcomp(obj)
end

local function is_aim_active()
    return rawget(_G, KEYS.aim_active) == true
end

local function pawn_has_reload_montage_playing(pawn)
    if not uobject_valid(pawn) then
        return false
    end
    local function montage_is_reload(montage)
        if not uobject_valid(montage) then
            return false
        end
        local ok_name, short_name = pcall(function()
            return uevrUtils.getShortName(montage)
        end)
        return ok_name and montage_name_is_reload(short_name)
    end
    local found = false
    pcall(function()
        if pawn.GetCurrentMontage ~= nil then
            found = montage_is_reload(pawn:GetCurrentMontage())
        end
    end)
    if found then
        return true
    end
    local anim_instance = uevrUtils.getValid(pawn, {"Mesh", "AnimScriptInstance"})
    if uobject_valid(anim_instance) then
        pcall(function()
            found = montage_is_reload(anim_instance:GetCurrentActiveMontage())
        end)
    end
    return found == true
end

-- 瞄准键（RMB/LT）按下时：即时掐掉可能已开播的换弹
local function tick_aim_reload_guard()
    local aim = is_aim_active()
    local was_aim = state.last_aim_active == true
    state.last_aim_active = aim

    if not should_block_native_reload() then
        return
    end

    if aim and not was_aim then
        cancel_native_reload_anim("aim_start")
        request_cancel_native_reload("aim_start")
        print_log("[SLIDE_LOCK] aim pressed while blocked — cancel reload", LogLevel.Info)
    end
end

-- tick 兜底：每帧扫描并掐掉 RangedReload + Pawn 换弹 montage
local function tick_block_native_reload()
    if not should_block_native_reload() then
        state.last_reload_playing = nil
        return
    end
    local ok, err = pcall(function()
        local reload_player = get_ranged_reload_player()
        local playing = ranged_reload_is_active(reload_player)
        local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
        local pawn_has_reload_montage = pawn_has_reload_montage_playing(pawn)
        if not playing and not pawn_has_reload_montage then
            state.last_reload_playing = false
            return
        end
        if state.last_reload_playing ~= true then
            print_log("tick cancel native reload", LogLevel.Info)
        end
        state.last_reload_playing = true
        cancel_native_reload_anim("tick")
    end)
    if not ok then
        print_log("tick_block_native_reload error: " .. tostring(err), LogLevel.Warn, "SLIDE_LOCK")
    end
end

-- slide lock A 类 hooks 已挪到 libs/reload_hooks.lua 集中注册，
-- 本文件通过 M.on_fire_ready_check / M.on_out_of_ammo / M.on_can_be_reloaded_check /
-- M.on_play_request_check / M.on_ranged_reload_check / M.on_montage_change_check 提供回调入口

-- tick 兜底：HasAnyAmmoInClip() 从 true 转为 false 时锁定 slide
-- 仅在未锁定 + 非手动换弹 + 非过场时检测，避免误触发
local function tick_ammo_state_watch(chain)
    if state.slide_locked then
        return
    end
    if state.manual_reload_active then
        state.last_ammo_in_clip = nil
        return
    end
    local weapon = chain and chain.equipped_weapon or nil
    if weapon == nil then
        state.last_ammo_in_clip = nil
        return
    end
    local has_ammo = nil
    pcall(function() has_ammo = weapon:HasAnyAmmoInClip() end)
    if has_ammo == nil then
        state.last_ammo_in_clip = nil
        return
    end
    -- 检测 true→false 转换（玩家打出最后一发）
    if state.last_ammo_in_clip == true and has_ammo == false then
        set_needs_rack(true)
        set_slide_locked(true)
        request_cancel_native_reload("ammo_empty")
        print_log("[SLIDE_LOCK] slide locked by ammo transition (tick fallback)", LogLevel.Info)
    end
    state.last_ammo_in_clip = has_ammo == true
end

-- =============================================================================
-- Phase 6: 拉栓动作（Slide Rack）
-- 混合方案：PoseableMesh 渐进后拉 + SetOutOfAmmo(false) 原生复位
-- =============================================================================

local SLIDE_BONE_NAME = "slide_joint"
-- 激活 accessory：9c651361-...（proximity+grip）；表演挂点：b7e2a1c0-...（见 accessories_parameters.json）
local SLIDE_GRIP_ANIMATION = "pull_slide"
local SLIDE_RACK_ACCESSORY_ID = "b7e2a1c0-8d4f-4e2a-9b1c-0d5f6a7b8c9d"
local SLIDE_RACK_ACCESSORY_PRIORITY = 25
local PULL_THRESHOLD = 4.0          -- 后拉满程距离（cm）
local PULL_SENSITIVITY = 1.5        -- 后拉灵敏度；>1 同样手程套筒动得更快
-- local PUSH_THRESHOLD = 3.0        -- [步枪] 推回完成阈值（cm），步枪将单独建文件

-- 拉栓纯数学状态（reload_tools 管理）
local slide_rack_state = reload_tools.new_slide_rack_state()
-- 业务层扩展：PoseableMesh 引用（依赖游戏 API 对象，不放 reload_tools）
local slide_rack_visual = {
    poseable_actor = nil,
    poseable_mesh = nil,
    bone_hidden = false,            -- 真枪 slide_joint 是否已 HideBoneByName
}

--- 从 weapon_mesh 的 slide_joint socket 旋转提取枪体后方向单位向量
---@param weapon_mesh userdata
---@return table|nil {X, Y, Z} 后方向单位向量
local function get_slide_backward_axis(weapon_mesh)
    if weapon_mesh == nil or weapon_mesh.GetSocketRotation == nil then
        return nil
    end
    local socket_rot = nil
    pcall(function()
        socket_rot = weapon_mesh:GetSocketRotation(
            uevrUtils.fname_from_string(SLIDE_BONE_NAME)
        )
    end)
    if socket_rot == nil then
        -- fallback：用 weapon_mesh 本体旋转
        socket_rot = get_component_world_rotation(weapon_mesh)
    end
    if socket_rot == nil then
        return nil
    end
    -- 获取枪体前方向，取反即为后方向
    local forward = uevrUtils.getForwardVector(socket_rot)
    if forward == nil then
        return nil
    end
    return { X = -(forward.X or 0), Y = -(forward.Y or 0), Z = -(forward.Z or 0) }
end

local function is_left_grip_pressed()
    local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
    return left_grip == true
end

--- 只显示 slide_joint（逻辑对齐 show_only_magazine_joint，共享骨骼隔离缓存）
---@param mesh_comp userdata PoseableMesh 组件
---@param slide_bone_name string 骨骼名
---@return boolean
local function show_only_slide_joint(mesh_comp, slide_bone_name)
    if mesh_comp == nil or mesh_comp.GetNumBones == nil or mesh_comp.SetBoneScaleByName == nil then
        return false
    end
    local bone_space = bone_space_component()
    local scale_hidden = uevrUtils.vector(BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN)
    local scale_one = uevrUtils.vector(1, 1, 1)
    local slide_fname = uevrUtils.fname_from_string(slide_bone_name)

    -- 查找或构建缓存（与 show_only_magazine_joint 共用 bone_hide_cache）
    local cache_key = get_bone_hide_cache_key(mesh_comp, slide_bone_name)
    local hide_map = cache_key and bone_hide_cache[cache_key] or nil

    local ok = pcall(function()
        local count = mesh_comp:GetNumBones()
        for i = 0, count - 1 do
            mesh_comp:SetBoneScaleByName(mesh_comp:GetBoneName(i), scale_hidden, bone_space)
        end
        mesh_comp:SetBoneScaleByName(slide_fname, scale_one, bone_space)
        if mesh_comp.HideBoneByName ~= nil and mesh_comp.BoneIsChildOf ~= nil then
            if hide_map == nil then
                hide_map = {}
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if bone_str ~= slide_bone_name then
                        local is_ancestor = mesh_comp:BoneIsChildOf(slide_fname, bone_fname)
                        local is_descendant = mesh_comp:BoneIsChildOf(bone_fname, slide_fname)
                        if not is_ancestor and not is_descendant then
                            mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                            hide_map[bone_str] = true
                        else
                            hide_map[bone_str] = false
                        end
                    else
                        hide_map[bone_str] = false
                    end
                end
                if cache_key ~= nil then
                    bone_hide_cache[cache_key] = hide_map
                end
            else
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if hide_map[bone_str] == true then
                        mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                    end
                end
            end
        end
    end)
    return ok
end

local function hide_slide_bone(mesh)
    mesh = get_valid_weapon_mesh(mesh)
    if mesh == nil then
        return false
    end
    local ok, err = pcall(function()
        if mesh.HideBoneByName == nil then
            error("HideBoneByName missing")
        end
        mesh:HideBoneByName(uevrUtils.fname_from_string(SLIDE_BONE_NAME), HIDE_BONE_PHYS_BODY)
    end)
    if ok then
        slide_rack_visual.bone_hidden = true
        return true
    end
    print_log("[RACK] HideBoneByName slide_joint failed: " .. tostring(err), LogLevel.Warn)
    return false
end

local function show_slide_bone(mesh)
    if not slide_rack_visual.bone_hidden then
        return true
    end
    mesh = get_valid_weapon_mesh(mesh)
    if mesh == nil then
        return false
    end
    local ok, err = pcall(function()
        if mesh.UnHideBoneByName == nil then
            error("UnHideBoneByName missing")
        end
        mesh:UnHideBoneByName(uevrUtils.fname_from_string(SLIDE_BONE_NAME))
    end)
    if ok then
        slide_rack_visual.bone_hidden = false
        return true
    end
    print_log("[RACK] UnHideBoneByName slide_joint failed: " .. tostring(err), LogLevel.Warn)
    return false
end

local function sync_slide_poseable_to_weapon(weapon_mesh, poseable)
    if weapon_mesh == nil or poseable == nil then
        return false
    end
    return copy_component_world_transform(weapon_mesh, poseable)
end

local function set_slide_rack_hand_parent(poseable)
    rawset(_G, "__sh2_slide_rack_hand_parent", poseable)
end

local function clear_slide_rack_hand_parent()
    rawset(_G, "__sh2_slide_rack_hand_parent", nil)
end

local function attach_left_hand_to_performance_slide()
    local poseable = uevrUtils.getValid(slide_rack_visual.poseable_mesh)
    if poseable == nil then
        return false
    end
    set_slide_rack_hand_parent(poseable)
    pcall(function()
        accessories.attachHandToAccessory(Handed.Left, SLIDE_RACK_ACCESSORY_ID, false)
    end)
    return true
end

--- Spawn PoseableMesh 隔离滑套视觉，每帧跟枪体同步（不走 attachToMesh，避免 grip detach 清掉表演件）
---@param weapon_mesh userdata
---@return boolean
local function spawn_slide_poseable(weapon_mesh)
    weapon_mesh = get_valid_weapon_mesh(weapon_mesh)
    if weapon_mesh == nil then
        return false
    end

    local socket_loc = get_socket_world_location(weapon_mesh, SLIDE_BONE_NAME)
    if socket_loc == nil then
        print_log("[RACK] spawn_slide_poseable: no slide_joint socket", LogLevel.Warn)
        return false
    end
    local socket_rot = nil
    pcall(function()
        socket_rot = weapon_mesh:GetSocketRotation(
            uevrUtils.fname_from_string(SLIDE_BONE_NAME)
        )
    end)

    local actor, poseable = spawn_poseable_from_weapon(weapon_mesh, socket_loc, socket_rot, {
        mag_only = false,
        skip_mag_world_align = true,
        skip_mag_drop_spawn_offset = true,
    })
    if actor == nil or poseable == nil then
        print_log("[RACK] spawn_slide_poseable: spawn failed", LogLevel.Warn)
        return false
    end

    if not show_only_slide_joint(poseable, SLIDE_BONE_NAME) then
        uevrUtils.destroy_actor(actor)
        print_log("[RACK] spawn_slide_poseable: show_only_slide_joint failed", LogLevel.Warn)
        return false
    end

    pcall(function()
        uevrUtils.copyMaterials(weapon_mesh, poseable)
    end)
    apply_poseable_render_flags(poseable)
    sync_slide_poseable_to_weapon(weapon_mesh, poseable)
    align_poseable_mag_bone(poseable, weapon_mesh, SLIDE_BONE_NAME)

    slide_rack_visual.poseable_actor = actor
    slide_rack_visual.poseable_mesh = poseable

    if not hide_slide_bone(weapon_mesh) then
        print_log("[RACK] spawn_slide_poseable: hide real slide failed", LogLevel.Warn)
    end

    attach_left_hand_to_performance_slide()

    print_log("[RACK] PoseableMesh spawned for slide (weapon-sync)", LogLevel.Info)
    return true
end

--- 每帧用 slide_joint 世界坐标做刚性约束。
--- 不能只同步两个 Mesh 的组件原点：骨骼隔离缩放会让两个 slide_joint 存在固定局部偏差，
--- 该偏差随枪旋转后会投影成世界空间上下漂移。
local function update_slide_poseable_position(weapon_mesh)
    local poseable = slide_rack_visual.poseable_mesh
    if poseable == nil then
        return
    end

    weapon_mesh = get_valid_weapon_mesh(weapon_mesh)
    if weapon_mesh == nil then
        return
    end

    -- 先复制完整根变换以保证角度、缩放跟枪，再按实际骨骼世界位置消除 pivot 偏差。
    sync_slide_poseable_to_weapon(weapon_mesh, poseable)

    local weapon_rest_world = get_socket_world_location(weapon_mesh, SLIDE_BONE_NAME)
    local poseable_slide_world = get_socket_world_location(poseable, SLIDE_BONE_NAME)
    local axis_world = get_slide_backward_axis(weapon_mesh)
    if weapon_rest_world == nil or poseable_slide_world == nil or axis_world == nil then
        return
    end

    local target_world = reload_tools.calc_slide_bone_offset(
        weapon_rest_world,
        axis_world,
        slide_rack_state.pull_progress,
        PULL_THRESHOLD
    )

    -- 精确世界修正：target = 真枪静止骨位 + 世界后拉轴 * 行程。
    -- 只平移表演组件，不再做错误的 Euler 逆旋转或混用骨骼/组件空间。
    if poseable.K2_AddWorldOffset ~= nil then
        local dx = target_world.X - poseable_slide_world.X
        local dy = target_world.Y - poseable_slide_world.Y
        local dz = target_world.Z - poseable_slide_world.Z
        pcall(function()
            poseable:K2_AddWorldOffset(
                uevrUtils.vector(dx, dy, dz),
                false,
                reusable_hit_result,
                false
            )
        end)
    end
end

--- 清理 PoseableMesh + 恢复真枪骨骼可见
local function cleanup_slide_visual()
    clear_slide_rack_hand_parent()
    pcall(function()
        accessories.attachHandToAccessory(Handed.Left, nil, false)
    end)

    if slide_rack_visual.poseable_actor ~= nil then
        pcall(function()
            slide_rack_visual.poseable_actor:SetHiddenInGame(true, true)
        end)
        uevrUtils.destroy_actor(slide_rack_visual.poseable_actor)
    end
    slide_rack_visual.poseable_actor = nil
    slide_rack_visual.poseable_mesh = nil

    local mesh, _ = get_pistol_chain()
    show_slide_bone(mesh)
end

--- 重置所有拉栓状态
local function reset_slide_rack_state()
    reload_tools.cancel_slide_rack(slide_rack_state)
    slide_rack_visual.poseable_actor = nil
    slide_rack_visual.poseable_mesh = nil
    slide_rack_visual.bone_hidden = false
    -- 锚定拉栓的移动补偿字段（详见 begin_slide_rack / tick_slide_rack）
    slide_rack_state.start_anchor_dist = nil
end

--- 是否允许拉栓：clip>0 可直接拉；clip=0 须已插弹且等待拉栓后补弹
local function can_perform_slide_rack()
    local _, chain = get_pistol_chain()
    local weapon = chain and chain.equipped_weapon or nil
    if weapon == nil then
        return false
    end
    local clip = reload_tools.read_clip_ammo(weapon, reload_tools.WEAPON_PROFILES.pistol)
    if clip ~= nil and clip > 0 then
        return true
    end
    local ok, has = pcall(function() return weapon:HasAnyAmmoInClip() end)
    if ok and has == true then
        return true
    end
    return state.mag_inserted == true and state.pending_clip_fill_after_rack == true
end

--- 拉栓取消：回弹到空仓挂机位，保持 g_slide_locked
local function cancel_slide_rack(reason)
    slide_rack_state.active = false
    cleanup_slide_visual()
    reset_slide_rack_state()
    print_log("[RACK] slide rack cancelled: " .. tostring(reason), LogLevel.Info)
end

--- 拉栓完成：销毁 PoseableMesh + 补弹（若延迟）+ 原生复位 + 解锁
local function complete_slide_rack()
    if not can_perform_slide_rack() then
        cancel_slide_rack("rack_not_ready")
        return
    end
    slide_rack_state.active = false

    cleanup_slide_visual()

    if state.pending_clip_fill_after_rack then
        local result = reload_tools.rack_fill(reload_tools.WEAPON_PROFILES.pistol)
        if result.ok then
            print_log("[RACK] rack fill dispatched (read reserve -> write reserve -> write clip)", LogLevel.Info)
        else
            print_log("[RACK] rack fill failed: " .. tostring(result.error), LogLevel.Warn)
        end
        state.pending_clip_fill_after_rack = false
    end

    -- 调用原生 SetOutOfAmmo(false) → AnimBP 播弹簧复位
    local mesh, _ = get_pistol_chain()
    local valid_mesh = get_valid_weapon_mesh(mesh)
    if valid_mesh ~= nil and valid_mesh.GetAnimScriptInstance ~= nil then
        local anim_instance = nil
        pcall(function()
            anim_instance = valid_mesh:GetAnimScriptInstance()
        end)
        if anim_instance ~= nil and anim_instance.SetOutOfAmmo ~= nil then
            pcall(function()
                anim_instance:SetOutOfAmmo(false)
            end)
            print_log("[RACK] SetOutOfAmmo(false) → native slide fwd", LogLevel.Info)
        end
    end

    -- 解锁空仓挂机
    M.unlock_slide()

    -- 清理状态
    reset_slide_rack_state()

    -- 套筒复位音效：从 Play_Wpn_Pistol_Reload 的 slide_snap 起点播放
    audio.play_segment(PISTOL_RELOAD_AUDIO_KEY,
        PISTOL_RELOAD_SEGMENTS.slide_snap.start_sec, PISTOL_RELOAD_SEGMENTS.slide_snap.duration)
    -- 套筒回弹手柄震动：右手 touch_enter
    trigger_reload_haptic("slide_snap")

    print_log("[RACK] slide rack complete → can fire", LogLevel.Info)
end

--- accessories slide marker 激活后启动拉栓（proximity + grip 由 accessories.lua 判定）
local function begin_slide_rack()
    if slide_rack_state.active then
        return
    end
    if not state.slide_locked or state.manual_reload_active or state.mag_in_left_hand then
        return
    end
    if not can_perform_slide_rack() then
        if not state.mag_inserted then
            print_log("[RACK] blocked: insert mag before racking", LogLevel.Info)
        else
            print_log("[RACK] blocked: clip empty and mag not ready for rack", LogLevel.Info)
        end
        return
    end

    local lh_pos = controllers.getControllerLocation(Handed.Left)
    if lh_pos == nil then
        return
    end

    local mesh, _ = get_pistol_chain()
    if mesh == nil then
        return
    end

    slide_rack_state.active = true
    slide_rack_state.start_pos = { X = lh_pos.X, Y = lh_pos.Y, Z = lh_pos.Z }
    slide_rack_state.backward_axis = get_slide_backward_axis(mesh)
    slide_rack_state.signed_pull = 0
    slide_rack_state.pull_max = 0
    slide_rack_state.pull_done = false
    slide_rack_state.pull_progress = 0

    -- 移动补偿：以枪体 socket 为锚点，捕获 begin 时刻 (lh - socket) · backward_axis 标量。
    -- tick 时再算 (lh - socket) · backward_axis 之差，玩家走动/转身时该差值保持不变
    -- （正交变换保内积），signed_pull 只反映手相对枪的真实后拉量。
    -- start_anchor_dist 为 nil 时 calc_slide_pull_anchored 走旧 world-space fallback。
    local socket_loc_begin = get_socket_world_location(mesh, SLIDE_BONE_NAME)
    slide_rack_state.start_anchor_dist = reload_tools.capture_slide_anchor(
        lh_pos, socket_loc_begin, slide_rack_state.backward_axis
    )

    if not spawn_slide_poseable(mesh) then
        print_log("[RACK] PoseableMesh spawn failed, fallback to threshold-only", LogLevel.Warn)
    end

    -- 拉栓音效/震动改在后拉到位（pull_done）时播，不在抓上瞬间播
    print_log("[RACK] slide rack started via pull_slide accessory", LogLevel.Info)
end

local slide_rack_hooks_installed = false
local function install_slide_rack_accessory_hooks()
    -- 每次 init 都刷新 _G 派发目标，热重载后旧闭包经 _G 转到新实现
    _G.__sh2_pistol_on_accessory_animation = function(handed, anim)
        if handed ~= Handed.Left or anim ~= SLIDE_GRIP_ANIMATION then
            return
        end
        begin_slide_rack()
    end
    _G.__sh2_pistol_on_accessory_animation_low = function(handed, anim)
        if handed ~= Handed.Left or not slide_rack_state.active then
            return
        end
        if anim ~= nil and anim ~= SLIDE_GRIP_ANIMATION then
            apply_left_hand_slide_pose()
        end
    end
    _G.__sh2_pistol_on_accessory_detach = function(handed)
        if handed ~= Handed.Left or not slide_rack_state.active then
            return
        end
        -- proximity+grip 松手会 detach；拉到位后松手 → 套筒自动回弹并完成拉栓
        if slide_rack_state.pull_done then
            complete_slide_rack()
        else
            cancel_slide_rack("accessory_detach")
        end
    end
    _G.__sh2_pistol_active_left_accessory = function()
        if not slide_rack_state.active then
            return
        end
        if uevrUtils.getValid(slide_rack_visual.poseable_mesh) == nil then
            return
        end
        if not is_left_grip_pressed() then
            return
        end
        return SLIDE_RACK_ACCESSORY_ID, SLIDE_RACK_ACCESSORY_PRIORITY
    end

    if slide_rack_hooks_installed or rawget(_G, "__sh2_slide_rack_hooks_installed") then
        slide_rack_hooks_installed = true
        return
    end
    uevrUtils.registerUEVRCallback("on_accessory_animation", function(handed, anim)
        local fn = rawget(_G, "__sh2_pistol_on_accessory_animation")
        if type(fn) == "function" then
            fn(handed, anim)
        end
    end)
    -- 低优先级：在 hands/ik 设完手势后再处理竞争，且绝不 clear pull_slide
    uevrUtils.registerUEVRCallback("on_accessory_animation", function(handed, anim)
        local fn = rawget(_G, "__sh2_pistol_on_accessory_animation_low")
        if type(fn) == "function" then
            fn(handed, anim)
        end
    end, -100)
    uevrUtils.registerUEVRCallback("on_accessory_detach", function(handed)
        local fn = rawget(_G, "__sh2_pistol_on_accessory_detach")
        if type(fn) == "function" then
            fn(handed)
        end
    end)
    uevrUtils.registerUEVRCallback("active_left_accessory", function()
        local fn = rawget(_G, "__sh2_pistol_active_left_accessory")
        if type(fn) == "function" then
            return fn()
        end
    end)
    slide_rack_hooks_installed = true
    _G.__sh2_slide_rack_hooks_installed = true
end

--- 每帧拉栓调度（由 on_tick 调用；激活由 accessories pull_slide 回调触发）
local function tick_slide_rack(cached_mesh)
    if not state.slide_locked then
        if slide_rack_state.active then
            cancel_slide_rack("not_locked")
        end
        return
    end

    if state.manual_reload_active or state.mag_in_left_hand then
        if slide_rack_state.active then
            cancel_slide_rack("manual_reload_active")
        end
        return
    end

    if not slide_rack_state.active then
        return
    end

    if not can_perform_slide_rack() then
        cancel_slide_rack("rack_not_ready")
        return
    end

    local lh_pos = controllers.getControllerLocation(Handed.Left)
    if lh_pos == nil then
        cancel_slide_rack("no_left_pos")
        return
    end

    local mesh = cached_mesh or select(1, get_pistol_chain())
    if mesh == nil then
        cancel_slide_rack("no_mesh")
        return
    end

    -- 后拉轴每帧随枪更新，保证枪旋转时投影与表演件一致
    slide_rack_state.backward_axis = get_slide_backward_axis(mesh)

    -- 移动补偿：优先用「锚定到枪 socket」的算法。
    -- signed_pull = (lh - socket) · backward_axis 的当前值 - begin 时刻值
    -- 玩家走动/转身时 (lh-socket) 与 backward_axis 同步变换，内积不变 → signed_pull 不受影响。
    -- start_anchor_dist/socket_loc 为 nil 时 calc_slide_pull_anchored 内部走旧 world-space fallback。
    local socket_loc = get_socket_world_location(mesh, SLIDE_BONE_NAME)
    local raw_signed, raw_progress = reload_tools.calc_slide_pull_anchored(
        lh_pos, socket_loc, slide_rack_state.backward_axis,
        slide_rack_state.start_anchor_dist, PULL_THRESHOLD, slide_rack_state.start_pos
    )
    if PULL_SENSITIVITY ~= nil and PULL_SENSITIVITY ~= 1.0 then
        raw_signed = raw_signed * PULL_SENSITIVITY
        raw_progress = raw_progress * PULL_SENSITIVITY
    end
    if raw_progress > 1.0 then
        raw_progress = 1.0
    end
    if raw_signed > PULL_THRESHOLD then
        raw_signed = PULL_THRESHOLD
    end
    if not slide_rack_state.pull_done then
        -- 拉栓全程后拉距离只增不减，防止抖动或松手前滑套回弹
        if raw_signed > slide_rack_state.signed_pull then
            slide_rack_state.signed_pull = raw_signed
        end
        if raw_progress > slide_rack_state.pull_progress then
            slide_rack_state.pull_progress = raw_progress
        end
        if raw_signed > slide_rack_state.pull_max then
            slide_rack_state.pull_max = raw_signed
        end
    else
        -- 后拉到位后保持满行程，直到松手 detach 触发 complete
        slide_rack_state.pull_progress = math.max(slide_rack_state.pull_progress, 1.0)
        slide_rack_state.signed_pull = math.max(slide_rack_state.signed_pull, PULL_THRESHOLD)
    end
    local signed_pull = slide_rack_state.signed_pull
    local pull_progress = slide_rack_state.pull_progress

    -- 更新 PoseableMesh 滑套位置
    update_slide_poseable_position(mesh)

    -- 表演件存在时才隐藏真枪 slide，避免 spawn 失败时两边都不可见
    if slide_rack_visual.poseable_mesh ~= nil and not slide_rack_visual.bone_hidden then
        hide_slide_bone(mesh)
        -- show_only_slide_joint 仅在 spawn 时调用一次（L2414），无需每帧重设
    end

    -- 后拉到位判定：此时才播拉栓音（抓上手时不播）
    if not slide_rack_state.pull_done and reload_tools.is_pull_done(signed_pull, PULL_THRESHOLD) then
        slide_rack_state.pull_done = true
        print_log("[RACK] pull done (max=" .. string.format("%.1f", slide_rack_state.pull_max) .. "cm)", LogLevel.Info)
        audio.play_segment(PISTOL_RELOAD_AUDIO_KEY,
            PISTOL_RELOAD_SEGMENTS.pull_slide.start_sec, PISTOL_RELOAD_SEGMENTS.pull_slide.duration)
        trigger_reload_haptic("pull_slide")
    end

    -- [步枪] 推回完成判定（步枪 reload 脚本使用 is_push_done；手枪松手 detach 完成）
    -- if slide_rack_state.pull_done and reload_tools.is_push_done(PULL_THRESHOLD, signed_pull, 3.0) then
    --     complete_slide_rack()
    --     return
    -- end
end

function M.engine_drop_mag()
    if state.mag_dropped or state.mag_drop.active then
        set_drop_fail("already_dropped_or_dropping")
        return false
    end

    local mesh, chain, err = get_pistol_chain()
    if mesh == nil then
        set_drop_fail(tostring(err or "no_pistol"))
        return false
    end

    local spawn_loc = get_socket_world_location(mesh, MAG_SOCKET_NAME)
    if spawn_loc == nil then
        spawn_loc = get_socket_world_location(mesh, MAG_BONE_NAME)
    end
    if spawn_loc == nil then
        set_drop_fail("no_spawn_socket")
        return false
    end

    -- 须在 HideBone 之前克隆姿态，否则 CopyPoseFromSkeletalComponent 会复制已隐藏的弹匣
    -- skip_mag_drop_spawn_offset=true：不在 spawn 时立即偏移，改由 slide-out 动画滑出
    local actor, scene_comp = spawn_performance_mag_from_weapon(mesh, spawn_loc, nil, {
        skip_mag_drop_spawn_offset = true,
    })
    if actor == nil then
        set_drop_fail("spawn_performance_mag_failed")
        return false
    end

    if not hide_magazine_bone(mesh) then
        uevrUtils.destroy_actor(actor)
        set_drop_fail("hide_bone_failed")
        return false
    end

    -- 注意：spawn_performance_mag_from_weapon 内部会调用
    -- copy_component_world_transform + align_poseable_mag_bone，
    -- 把 poseable 强制对齐到 weapon_mesh 的弹匣骨位置，覆盖 spawn_loc。
    -- 所以 spawn 偏移必须在 align 之后、传入 start_mag_release_drop 之前应用。
    local drop_loc = get_component_world_location(scene_comp) or get_bone_world_location(scene_comp, MAG_BONE_NAME) or spawn_loc

    -- 应用 spawn 局部偏移：沿 magazine_socket 局部坐标系偏移，跟随枪旋转
    -- （枪斜着也能跟着歪，不会偏到枪外面）
    local spawn_socket_rot = nil
    pcall(function()
        spawn_socket_rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(MAG_SOCKET_NAME))
    end)
    local sdx, sdy, sdz = reload_tools.local_offset_to_world_delta(
        spawn_socket_rot,
        MAG_SPAWN_LOCAL_FORWARD,
        MAG_SPAWN_LOCAL_RIGHT,
        MAG_SPAWN_LOCAL_DOWN
    )
    drop_loc = {
        X = drop_loc.X + sdx,
        Y = drop_loc.Y + sdy,
        Z = drop_loc.Z + sdz,
    }

    -- slide-out：先沿 socket 方向滑出，再垂直下落（weapon_mesh 用于计算 slide 偏移方向）
    if not start_mag_release_drop(actor, drop_loc, scene_comp, mesh) then
        uevrUtils.destroy_actor(actor)
        -- hide_magazine_bone 已执行，需恢复
        if state.mesh_hidden then
            show_magazine_bone(mesh)
        end
        set_drop_fail("start_mag_drop_failed")
        return false
    end

    state.weapon = chain.equipped_weapon
    state.weapon_mesh = mesh
    state.mag_dropped = true
    state.manual_reload_active = true

    -- Phase 4: 退弹时改写弹药；仅弹夹=0 时触发 needs_rack / slide lock
    local ammo_result = apply_mag_eject_ammo()
    if ammo_result.ok ~= true then
        print_log("engine_drop_mag ammo failed: " .. tostring(ammo_result.error), LogLevel.Warn, "AMMO")
    end
    request_cancel_native_reload("engine_drop_mag")
    if ammo_result.needs_rack == true then
        print_log("[SLIDE_LOCK] slide locked by engine_drop_mag (empty clip)", LogLevel.Info)
    else
        print_log("[SLIDE_LOCK] tactical eject — slide stays forward", LogLevel.Info)
    end

    -- 退弹音效：从 Play_Wpn_Pistol_Reload 起点播放 mag_drop 段
    audio.play_segment(PISTOL_RELOAD_AUDIO_KEY,
        PISTOL_RELOAD_SEGMENTS.mag_drop.start_sec, PISTOL_RELOAD_SEGMENTS.mag_drop.duration)
    -- 退弹手柄震动：右手 touch_enter
    trigger_reload_haptic("mag_drop")

    print_log("engine_drop_mag OK", LogLevel.Info)
    return true
end

-- Phase 5 公开 API：解除空仓挂机（Phase 6 拉栓动作完成后调用）
function M.unlock_slide()
    set_slide_locked(false)
    set_needs_rack(false)
    state.pending_clip_fill_after_rack = false
    -- 清除 last_ammo_in_clip 防止 unlock 后立即被 tick 兜底重新锁定
    state.last_ammo_in_clip = nil
    state.last_reload_playing = nil
    print_log("[SLIDE_LOCK] slide unlocked", LogLevel.Info)
end

publish_globals = function()
    _G[KEYS.manual_reload_active] = state.manual_reload_active == true
    _G[KEYS.mag_dropped] = state.mag_dropped == true
    _G[KEYS.mag_in_left_hand] = state.mag_in_left_hand == true
    _G[KEYS.mag_inserted] = state.mag_inserted == true
    _G[KEYS.slide_locked] = state.slide_locked == true
    _G.__vr_block_fire_when_empty = state.slide_locked == true
    _G[KEYS.needs_rack] = state.needs_rack == true
    -- block_closed_hands_dock：取弹→插弹完成期间阻止 closed hands dock 吸附
    -- 窗口 = 左手持弹 OR slide-in 进行中（detach 后 mag_in_left_hand 已清，靠 mag_drop.active+skip_fall 盖空窗）
    -- 退弹后、尚未取弹：不阻止；grip-release 下落（fall / skip_fall=false）也不阻止
    local drop = state.mag_drop
    local slide_in_active = type(drop) == "table" and drop.active == true and drop.skip_fall == true
    _G[KEYS.block_closed_hands_dock] = (state.mag_in_left_hand == true) or slide_in_active
end

local function on_tick()
    -- 底层音频计时器：每帧检查播放是否到期，到期自动 ak_comp:Stop()
    -- 放在入口守卫之前，确保切枪/过场时音频也能正常停止，避免音频泄漏
    audio.tick()

    -- 单一入口守卫：非手枪时整个模块 no-op，仅发布全局状态
    -- 降沿检测：从手枪切到非手枪时清理手动换弹残留
    local was_pistol = state._was_pistol
    state._was_pistol = is_pistol_equipped()
    if not state._was_pistol then
        if was_pistol and (state.manual_reload_active or state.mag_in_left_hand or state.pending_clip_fill_after_rack) then
            print_log("[WEAPON_SWAP] pistol -> non-pistol, cancel manual reload", LogLevel.Info)
            cancel_manual_reload()
        end
        -- 仅在从手枪切走时发布一次全局清理；非手枪期间不覆盖 shotgun_reload 发布的 g_mag_in_left_hand 等
        if was_pistol then
            publish_globals()
        end
        return
    end

    -- M1 优化：在 on_tick 入口缓存一次 chain，避免子函数重复解析 UObject 链
    local _, cached_chain = get_pistol_chain()

    -- 手枪状态下的换枪检测（同类型手枪切换，地址不同则清理）
    pcall(tick_weapon_change_watch)

    -- 消费 09 发布的 B 键上升沿
    -- 菜单/地图/暂停状态下不退弹：
    --   (1) 地图菜单：pawn.Items.ItemExecutive 的 full_name 以 "Map" 开头（参考 main.lua:1156-1162）
    --   (2) 暂停状态：uevrUtils.isGamePaused() 为 true（覆盖暂停菜单等其他菜单场景，
    --       这些场景下 ItemExecutive 通常为 nil，原 map 检查覆盖不到）
    -- 消费 edge 即丢弃，避免菜单关闭后立刻退弹（陈旧 edge）
    -- 注：update_map_menu_check 已用 pcall 保护所有 UObject 调用，并写入 map_menu_debug 供面板诊断
    update_map_menu_check(cached_chain.pawn)
    local _in_any_menu = map_menu_debug.in_any_menu
    if rawget(_G, KEYS.mag_drop_edge) == true then
        _G[KEYS.mag_drop_edge] = false
        -- 记录 edge 消费时的关键状态（持久保留到下次 edge 消费，便于面板观察）
        map_menu_debug.last_edge_in_map_menu = _in_any_menu
        map_menu_debug.last_edge_clock = os.clock()
        if not _in_any_menu then
            map_menu_debug.last_edge_dropped = true
            map_menu_debug.last_edge_blocked_by_map = false
            map_menu_debug.last_edge_blocked_by_pause = false
            M.engine_drop_mag()
        else
            map_menu_debug.last_edge_dropped = false
            -- 区分被哪种信号阻止（便于面板诊断）
            map_menu_debug.last_edge_blocked_by_map = map_menu_debug.in_map_menu
            map_menu_debug.last_edge_blocked_by_pause = map_menu_debug.is_game_paused
        end
    end

    -- 消费 09 发布的右扳机 dry fire 上升沿：空仓挂机时播放空仓扣扳机音效
    if rawget(_G, KEYS.dry_fire_edge) == true then
        _G[KEYS.dry_fire_edge] = false
        if state.slide_locked then
            play_dry_fire_sound()
        end
    end

    -- 消费左胯取弹 edge
    if rawget(_G, KEYS.mag_grab_edge) == true then
        _G[KEYS.mag_grab_edge] = false
        if not state.mag_dropped then
            set_grab_skip("mag_not_dropped")
        elseif state.mag_in_left_hand then
            set_grab_skip("already_holding")
        else
            spawn_mag_in_hand()
        end
    end

    -- 消费左手 grip 松开
    if rawget(_G, KEYS.mag_grab_release) == true then
        _G[KEYS.mag_grab_release] = false
        if state.mag_in_left_hand and not state.mag_inserted then
            if not start_grip_release_drop() then
                despawn_left_hand_mag()
                if state.mag_dropped then
                    cancel_manual_reload()
                end
            end
        end
    end

    -- 插弹 proximity 检测
    if state.mag_dropped and state.mag_in_left_hand and not state.mag_inserted then
        local dist = get_left_hand_to_socket_distance(MAG_SOCKET_NAME)
        if dist < MAG_INSERT_DISTANCE then
            insert_mag()
        end
    end

    if uevrUtils.isInCutscene and uevrUtils.isInCutscene() then
        -- Phase 6: 过场中清理拉栓状态（避免 PoseableMesh 残留）
        if slide_rack_state.active then
            cancel_slide_rack("cutscene")
        end
        publish_globals()
        return
    end

    -- tick_mag_release_drop + tick_slide_rack 移至 PostCalculateStereoViewOffset（VR 变换更新后），
    -- 消除枪移动时弹夹/枪栓跟随的 1 帧滞后（PostEngineTick 时 VR 控制器变换尚未更新）
    -- 此处仅保留非视觉逻辑；视觉位置在 stereo view 回调中更新

    -- Phase 5: 延后处理 hook 请求的 cancel（避免在 hook 栈内重入）
    -- A 类 hooks 安装与重试已由 libs/reload_hooks.lua 负责
    pcall(process_pending_reload_cancel)

    -- Phase 5: tick 兜底检测 HasAnyAmmoInClip() true→false 转换
    pcall(tick_ammo_state_watch, cached_chain)

    -- Phase 5: tick 兜底掐掉原生换弹动画
    pcall(tick_block_native_reload)

    -- Phase 6: 拉栓动作调度已移至 PostCalculateStereoViewOffset（与弹夹视觉同步）

    -- 持弹时持续应用 pistol_mag UI 偏移，便于 Attachments Config 实时预览
    if state.mag_in_left_hand then
        if uobject_valid(state.left_hand_mag_attachment) then
            apply_pistol_mag_transform(state.left_hand_mag_attachment)
        else
            -- 读档后表演件可能已被引擎销毁，避免对悬空指针持续写 transform
            print_log("left_hand_mag_attachment stale; clearing hold state", LogLevel.Warn, "SPAWN")
            state.mag_in_left_hand = false
            state.left_hand_mag_attachment = nil
            state.left_hand_mag_actor = nil
            pcall(clear_left_hand_mag_pose)
        end
    end

    publish_globals()
end

local function on_level_change()
    cancel_manual_reload()
    -- Phase 6: 关卡切换 = 武器销毁，清理拉栓状态 + PoseableMesh
    if slide_rack_state.active then
        cancel_slide_rack("level_change")
    end
    -- 读档/切关后 Wwise 事件 UObject 可能已失效；清空缓存以便下次 play 重 resolve
    pcall(function()
        audio.invalidate_cache()
    end)
    _G[KEYS.mag_drop_edge] = false
    _G[KEYS.mag_grab_edge] = false
    _G[KEYS.mag_grab_release] = false
    _G[KEYS.mag_inserted] = false
    _G[KEYS.dry_fire_edge] = false
    -- Phase 5: 关卡切换 = 武器销毁，清除空仓挂机状态（避免新关卡继承 stale lock）
    set_slide_locked(false)
    set_needs_rack(false)
    state.pending_clip_fill_after_rack = false
    state.last_ammo_in_clip = nil
    state.last_reload_playing = nil
    state.last_aim_active = nil
    publish_globals()
end

function M.init()
    -- 代码世代：热重载后控制台应出现这行；与 shotgun_reload 同策略用 _G 间接调用
    local CODE_REV = 3
    print("[PISTOL_RELOAD] init CODE_REV=" .. tostring(CODE_REV))

    local MODULE_TOKEN = {}
    _G.__sh2_pistol_live_token = MODULE_TOKEN

    -- 热重载清理：若重载前左手仍吸附在旧弹夹 actor 上（旧 state 可能无标记），
    -- 强制发一次 detach 恢复手部追踪（restoreHandSnapshot 无快照时 no-op，重复调用安全）；
    -- 随后旧弹夹 actor 由既有 despawn/cancel 链路销毁，避免手挂在已销毁对象上
    pcall(function()
        uevrUtils.executeUEVRCallbacks("on_accessory_detach", Handed.Left)
    end)
    state.hand_attached_to_mag = false

    local real_on_tick = on_tick
    local function guarded_on_tick()
        if rawget(_G, "__sh2_pistol_live_token") ~= MODULE_TOKEN then
            return
        end
        real_on_tick()
    end
    -- 弹夹 + 枪栓视觉 tick：在 PostCalculateStereoViewOffset（VR 变换更新后）执行，
    -- 消除枪移动时弹夹/枪栓跟随的 1 帧滞后
    local function guarded_mag_drop_visual_tick()
        if rawget(_G, "__sh2_pistol_live_token") ~= MODULE_TOKEN then
            return
        end
        if not state._was_pistol then
            return
        end
        if uevrUtils.isInCutscene and uevrUtils.isInCutscene() then
            return
        end
        -- slide-in 期间松开左 Grip：手立即脱附恢复追踪，弹夹继续独立滑入（2026-08-31 拍板）。
        -- 不能用 KEYS.mag_grab_release edge：UEVR_09 仅在 mag_in_left_hand=true 时发布，
        -- slide-in 期间该标志已清零收不到；改为 flag 门控轮询（窗口仅 0.25s，开销可忽略）
        if state.hand_attached_to_mag and not is_left_grip_pressed() then
            detach_hand_from_mag("grip_release")
        end
        -- M1 优化：缓存一次 chain，传给子函数
        local cached_mesh = select(1, get_pistol_chain())
        tick_mag_release_drop()
        -- Phase 6: 拉栓动作调度（读取左手控制器 + 枪体 socket，需 VR 变换已更新）
        pcall(tick_slide_rack, cached_mesh)
    end
    local real_on_level = on_level_change
    local function guarded_on_level()
        if rawget(_G, "__sh2_pistol_live_token") ~= MODULE_TOKEN then
            return
        end
        real_on_level()
    end

    -- 注册手枪换弹音频事件（底层 audio.lua 缓存 UAkAudioEvent 对象，上层只负责"插入CD"）
    -- register_event 内部幂等，热重载时重复调用安全
    audio.register_event(
        PISTOL_RELOAD_AUDIO_KEY,
        "Play_Wpn_Pistol_Reload",
        "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Pistol/Play_Wpn_Pistol_Reload.Play_Wpn_Pistol_Reload"
    )
    -- 注册 mag_release 段复用的霰弹枪 Pump_Action 事件（register_event 幂等，shotgun_reload 已注册也安全）
    audio.register_event(
        PISTOL_MAG_RELEASE_AUDIO_KEY,
        "Play_Wpn_Shotgun_Pump_Action",
        "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Shotgun/Play_Wpn_Shotgun_Pump_Action.Play_Wpn_Shotgun_Pump_Action"
    )
    -- 注册 dry fire 音效事件（绕开 PostEventByName hook 链，走 SpawnAkComponentAtLocation 独立路径）
    audio.register_event(
        PISTOL_DRY_FIRE_AUDIO_KEY,
        DRY_FIRE_AUDIO_EVENT,
        PISTOL_DRY_FIRE_EVENT_PATH
    )

    -- 向公共 hook 入口注册本模块：A+B 类 hooks 由 reload_hooks 集中安装并 dispatch
    reload_hooks.register_weapon_module("pistol", M)

    -- 通用 grip block：当 g_block_closed_hands_dock=true 时阻止 closed_hands dock 吸附
    -- （取弹→插弹完成期间，左手持弹匣或正在插弹，不应被 proximity 重新吸到 closed hands dock）
    accessories.registerGripBlock(KEYS.block_closed_hands_dock, "closed_hands")

    -- C 类 accessory hooks（pull_slide）仍由本文件自己安装
    install_slide_rack_accessory_hooks()

    -- 热重载关键：tick / level / client_restart 经 _G 间接调用，避免旧闭包继续跑陈旧逻辑
    _G.__sh2_pistol_on_tick = guarded_on_tick
    _G.__sh2_pistol_mag_drop_visual_tick = guarded_mag_drop_visual_tick
    _G.__sh2_pistol_on_level_change = guarded_on_level
    -- 暴露模块表给面板（对齐 shotgun/rifle 的 __sh2_xxx_reload_module）
    _G.__sh2_pistol_reload_module = M

    publish_globals()

    if rawget(_G, "__sh2_manual_reload_initialized") then
        print("[PISTOL_RELOAD] hot-reload: rebound tick via _G (CODE_REV=" .. tostring(CODE_REV) .. ")")
        return M
    end

    uevrUtils.registerPostEngineTickCallback(function()
        local fn = rawget(_G, "__sh2_pistol_on_tick")
        if type(fn) == "function" then
            fn()
        end
    end)

    -- 弹夹视觉位置在 PostCalculateStereoViewOffset 更新（VR 控制器变换已更新），
    -- 消除枪移动时弹夹跟随的 1 帧滞后；仅 view_index==0 时执行（每帧只更新一次）
    uevrUtils.registerPostCalculateStereoViewCallback(function(device, view_index)
        if view_index ~= 0 then return end
        local fn = rawget(_G, "__sh2_pistol_mag_drop_visual_tick")
        if type(fn) == "function" then
            fn()
        end
    end)

    uevrUtils.registerPreLevelChangeCallback(function()
        local fn = rawget(_G, "__sh2_pistol_on_level_change")
        if type(fn) == "function" then
            fn()
        end
    end)

    -- 读档常见走 ClientRestart 而非 PersistentLevel 指针变化；同样需要清状态/音频缓存
    uevrUtils.registerUEVRCallback("on_client_restart", function()
        local fn = rawget(_G, "__sh2_pistol_on_level_change")
        if type(fn) == "function" then
            fn()
        end
    end)

    vr_globals.compat.on_script_reset(function()
        local fn = rawget(_G, "__sh2_pistol_on_level_change")
        if type(fn) == "function" then
            fn()
        end
        _G.__sh2_manual_reload_initialized = nil
    end)

    _G.__sh2_manual_reload_initialized = true
    print("[PISTOL_RELOAD] indirection tick registered (CODE_REV=" .. tostring(CODE_REV) .. ")")
    print_log("pistol_reload loaded (using reload_tools)", LogLevel.Info)
    return M
end

return M
