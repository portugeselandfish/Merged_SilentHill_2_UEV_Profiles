
--[[修改说明：
0. 2026-07-31：拉栓完成防误开栓 — 墙钟冷却 + 松手闩锁
   - 根因：仅 30 帧 cooldown 在 VR 高帧率下偏短；且握着不松手时冷却一结束立刻 begin→rotate_up
   - 修复：complete 后 0.5s 墙钟冷却 + bolt_regrab_needs_release（必须松开左 grip 才允许再抓）
1. 2026-07-28：complete_bolt 条件化 Strategy D — 修复第二发后无法抛壳/第三发打不出
   - 根因：complete 无条件 write_idle + 清 backup → 下一发 block 捕获 idle 当备份 → restore 无抛壳
   - 开火拉栓完成：不写 idle，保留 Lua backup（同霰弹枪：内存可被 idle 覆盖，backup 供下发复用）
   - 开栓装弹（本轮 clip+1）完成：写 idle 阻止引擎自动拉栓，仍保留 backup
   - 主动拉栓未装弹：complete 时 restore 拉栓前备份（pull_done 已 skip restore）
2. 2026-07-28：断点续拉修复 — pause→resume 时 start_pos 重捕 + 累加基准偏移
   - 问题：松手后重新握住枪栓无法继续上拉/后拉（start_pos 未更新，投影从旧起点算，棘轮锁不更新）
   - 修复：tick_detect_bolt_grip 重新握住时，将已累积的 signed_rotate/signed_pull 保存为 rotate_base/pull_base，
     重捕 start_pos 为当前左手位置，清零 signed_rotate/signed_pull 和 progress
   - 各阶段 tick 函数：投影结果 + base 偏移 → 总进度 = (raw投影 + base) / threshold
   - 阶段切换时重置对应 base 为 0
   - new_slide_rack_state 新增 rotate_base、pull_base 字段
3. 2026-07-27：check_shell_proximity 加 shell_2 门控
   - 新增条件：state.shells_component == nil（shell_1 已入仓销毁）+ state.shell2_proximity_enabled == true（lerp 完成）
   - 修复 bug：shell_1/shell_2 json 偏移 6.74cm < SHELL_INSERT_DISTANCE 10cm，
     当 shell_1 在装弹口 10cm 内触发 proximity 时，shell_2 也在 10cm 范围内（挂同一左手），
     下一帧 shell_2 误触发 insert_shells(2) → 同手双发同时入仓 +2
   - 霰弹枪 SHELL_INSERT_DISTANCE=5cm < 6.74cm，shell_2 在范围外，无此 bug
   - 门控语义：shell_1 存在时不允许 shell_2 入仓 + shell_2 lerp 未完成不允许入仓
2. 2026-07-27：shell slide-in 旋转改为世界坐标系 offset（已撤销，见 5.）
   - 原因：bone_bullet socket 局部 Z 轴水平（沿枪管），local frame 下 yaw 不对应垂直轴
           + pitch=-90° 触发万向锁，pitch/roll 退化为同轴旋转
   - 改为世界坐标系后：pitch=世界 Y, yaw=世界 Z (垂直), roll=世界 X，调参直观
   - ⚠️ 此改动已于 2026-07-30 撤销（见 5.），因 socket 已从 bone_bullet 改为 bone_lock，
     bone_lock 轴向标准（X=前,Y=右,Z=上），local frame 正常无万向锁
   - 霰弹枪不受影响（已于 2026-07-31 改用 reload_tools.compose_local_rot_offset 公共版本）
4. 2026-07-30：枪栓 4 阶段接入运动补偿锚定算法 — 修复移动中无法拉栓
   - 根因：原 calc_slide_pull / calc_slide_rotate 用世界坐标 (lh - start_pos) · axis，
     玩家走动/转身时 start_pos 是 begin 时刻的世界坐标，已脱离枪体 → 投影漂移
   - 修复：begin_bolt + 4 阶段 tick + resume 路径全部改用 reload_tools.calc_slide_pull_anchored
     / calc_slide_rotate_anchored，以 (lh - socket) · axis 之差为 signed 值
     玩家走动/转身时 (lh-socket) 与 axis 同步变换，内积不变 → signed 只反映手相对枪的真实位移
   - begin_bolt 捕获 start_anchor_dist（rotate_up 阶段，up_axis）
   - rotate_up→pull 切换：重捕 start_anchor_dist（pull 阶段，backward_axis）
   - push→rotate_down 切换：重捕 start_anchor_dist（rotate_down 阶段，取反 up_axis）
   - tick_detect_bolt_grip resume 路径：重捕 start_anchor_dist（按当前阶段选 axis）
   - start_anchor_dist/socket_loc 为 nil 时 calc_slide_xxx_anchored 走旧 world-space fallback
   - reload_tools 新增 capture_slide_anchor / calc_slide_pull_anchored / calc_slide_rotate_anchored
   - new_slide_rack_state 新增 start_anchor_dist 字段
5. 2026-07-30：shell slide-in 旋转从 world coords 切回 local coords — 修复入膛角度随枪体漂移
   - 根因：compose_world_rot_offset 在世界坐标系应用 offset（pitch=世界 Y, yaw=世界 Z, roll=世界 X），
     枪 yaw 时 socket_rot 变了但 offset 仍为世界值 → 子弹相对枪身的夹角变化
   - 修复：build_shell_slide_rotations 改用 reload_tools.compose_local_rot_offset（与霰弹枪一致），
     offset 在 socket 局部 frame 应用，枪怎么转 offset 跟着转 → 入膛角度相对枪身始终不变
   - SHELL_SLIDE_END_ROT_OFFSET / SHELL_SLIDE_START_TILT 初值设为 {pitch=90, yaw=90, roll=0}
     （照抄霰弹枪；start=end 表示滑入无旋转，验证工具正确性，后续可微调某轴）
   - 撤销 2.（2026-07-27 world coords 改动）：socket 已从 bone_bullet 改为 bone_lock，
     bone_lock 轴向标准（X=前,Y=右,Z=上），local frame 无万向锁问题
   - 霰弹枪已于 2026-07-31 改用 reload_tools.compose_local_rot_offset 公共版本（与步枪一致）
]]--
local uevrUtils = require("libs/uevr_utils")
local mathLib = require("libs/core/math_lib")
local attachments = require("libs/attachments")
local accessories = require("libs/accessories")
local controllers = require("libs/controllers")
local hands = require("libs/hands")
local configui = require("libs/configui")
local vr_globals = require("UEVR_00_init_globals")
local reload_tools = require("libs/reload_tools")
local reload_hooks = require("libs/reload_hooks")
local audio = require("libs/audio")
local event_feedback = require("UEVR_11_EventFeedback")

local M = {}

local KEYS = vr_globals.KEYS

-- =============================================================================
-- 常量配置
-- =============================================================================

-- 武器识别标记
local RIFLE_NAME_MARKER = "WeaponRifle"

-- Socket 名称
-- 装弹吸附：步枪上方拉栓位置用 bone_lock（枪栓位置，玩家手可达；2026-07-26 从 bone_bullet 改）
-- 枪栓：bone_lock（步枪探测确认，对应霰弹枪 bone_forearm）
-- 装弹口和拉栓位置是同一区域（装弹和拉栓耦合）
-- 2026-07-26：从 bone_bullet（弹膛深处，不可达）改为 bone_lock（枪栓位置，玩家手能到达）
local SHELL_INSERT_SOCKET = "bone_lock"
-- 相对装弹 socket 的局部偏移（cm）
-- 坐标系（bone_lock socket 实测，非标准 UE 轴向；标准映射 forward→X, right→Y, down→-Z）：
--   forward → 往右（水平，正=右）
--   right   → 往下（垂直！正=下，负=上）← 这是垂直轴
--   down    → 往前（水平，正=枪口方向）
-- 终点：装弹口吸附点（proximity + 滑入终点）
-- 2026-07-26 实测调好：forward正值向右, down正值向前, right=0.0（居中）
local SHELL_INSERT_OFFSET = { forward = 0.0, down = 11.0, right = 0.0 }
-- 滑入起点相对终点再往上的距离（cm）。沿 right 轴（垂直，负值=上）偏移，从上往下滑入
-- forward/down 强制与终点相同，避免路径前后/左右斜穿枪身
local SHELL_SLIDE_APPROACH_DOWN = 8.0
local BOLT_BONE_NAME = "bone_lock"            -- 步枪枪栓骨（对应霰弹枪 bone_forearm）

local HIDE_BONE_PHYS_BODY = 0

-- 步枪弹壳 StaticMesh 资产路径（SDK dump 确认：SniperRifle_Shell_01_A）
local SHELL_MESH_PATH = "/Game/Game/Art/Items/SniperRifle/SniperRifle_Shell_01_A.SniperRifle_Shell_01_A"

-- attachments_parameters.json 中左手持弹条目 id（动画名 rifle_shell_insert）
-- Phase 2.1：双弹装填，shell_1 + shell_2 两个独立 actor，各自走 json 偏移配置
local SHELL_LEFT_HAND_ATTACHMENT_ID = "rifle_shell_1"
local SHELL_CONFIG_PREFIX = "uevr_attachments_rifle_shell_1_"
local SHELL_LEFT_HAND_ATTACHMENT_ID_2 = "rifle_shell_2"
local SHELL_CONFIG_PREFIX_2 = "uevr_attachments_rifle_shell_2_"
local SHELL_HAND_ANIMATION = "rifle_shell_insert"

-- 与 pistol_reload / main.lua 相同的 hands_type 枚举
local HandsType = {
    None = 1,
    Forearms = 2,
    IKArms = 3,
}

-- 策略 C：阻止引擎自动拉栓（ASHItemWeaponRangedSingleAction，CXX dump）
local PREPARE_ANIM_DATA_OFF = 0xC68
local PREPARE_ANIM_DATA_SIZE = 0xB0

-- 策略 D：idle 固定值（3 次 dump 确认同会话+跨武器切换一致）
-- 用途：开栓装弹（本轮 clip+1）完成时写入，覆盖 post-fire 值，防止引擎自动拉栓
-- 开火拉栓完成不写 idle（避免下一发 block 捕获 idle；真实 backup 由 Lua 保留复用）
local IDLE_PREPARE_ANIM_DATA = {
    0x000036370000FC63, -- qword[0]
    0x0000000000027A34, -- qword[1]
    0x00000000000AEE5F, -- qword[2] (疑似指针)
    0x0000000000187576, -- qword[3] (疑似指针)
    0x0000000000000000, -- qword[4]
    0x0000000000000000, -- qword[5]
    0x000000000040C3DB, -- qword[6]
    0x000000003E4CCCCD, -- qword[7]  (float 0.2)
    0x0000000000000000, -- qword[8]
    0x0000000000000000, -- qword[9]
    0x0000000000000000, -- qword[10]
    0x0000000000000000, -- qword[11]
    0x0000000000000000, -- qword[12]
    0x0000000000000000, -- qword[13]
    0x000000003E4CCCCD, -- qword[14] (float 0.2)
    0x0000000000000000, -- qword[15]
    0x0000000000000000, -- qword[16]
    0x0000000000000000, -- qword[17]
    0x0000000000000000, -- qword[18]
    0x0000000000000000, -- qword[19]
    0x0000000000000000, -- qword[20]
    0x3F80000000000001, -- qword[21] (float 1.0)
}

-- 插弹 proximity 距离（cm）
local SHELL_INSERT_DISTANCE = 5.0

-- 左手 attach socket（与 pistol 共用 hand_l_bn）
local SHELL_ATTACH_SOCKET = "hand_l_bn"

-- Phase 2.1：shell_1 despawn 后 shell_2 lerp 滑到 shell_1 初始位置
local SHELL_LERP_DURATION = 0.20

-- 松手垂直掉落（与 pistol DROP_* 对齐）
local SHELL_DROP_DURATION = 0.5
local SHELL_DROP_DISTANCE = 120.0

-- 入膛滑入动画时长（秒）
local SHELL_SLIDE_DURATION = 0.25

-- 旋转相对位移的延迟（0~0.95）
local SHELL_SLIDE_ROT_DELAY = 0.40

-- 入膛统一朝向（不跟手，避免不同握持角穿模）
-- 2026-07-30：从世界坐标系切回局部坐标系（reload_tools.compose_local_rot_offset）
-- 原因：world offset 枪一动入膛角度漂移（world pitch/yaw/roll 不跟随 socket）；
--       local offset 在 socket 局部 frame 应用，枪怎么转入膛角度相对枪身始终不变。
-- 初值照抄霰弹枪 {pitch=90, yaw=90, roll=0}（start=end 表示无旋转，验证工具正确性）；
-- 后续可微调某个轴改变入膛朝向。
local SHELL_SLIDE_END_ROT_OFFSET = { pitch = 0.0, yaw = 0.0, roll = 90.0 }
local SHELL_SLIDE_START_TILT = { pitch = 0.0, yaw = 0.0, roll = 45.0 }

-- 左手 attach 选项（参照 pistol magAttachOptions）
local shellAttachOptions = {
    detachFromOriginOnGrip = true,
    maintainWorldPositionOnDetachFromOrigin = false,
    detachFromParentOnRelease = true,
    maintainWorldPositionOnDetachFromParent = false,
    reattachToOriginOnRelease = false,
    restoreTransformToOriginOnReattach = false,
    useZeroTransformOnReattach = false,
    allowChildVisibilityHandling = false,
    allowChildHiddenInGameHandling = false,
    allowRenderInMainPassHandling = false,
}

-- 拉栓距离阈值（cm）：左手后拉到位的满程距离
local BOLT_PULL_THRESHOLD = 8.0
-- 拉栓前推完成阈值（cm）：后拉到位后，前推离原位 < 此值算完成
local BOLT_PUSH_DONE_DIST = 8.0
-- 拉栓最大骨骼位移（cm）：PoseableMesh 枪栓跟随 bolt_value 的最大后移距离
local BOLT_BONE_MAX_DISTANCE = 8.0

-- B-3 旋转数据：拉栓旋转阶段参数
-- rotate_up: pitch 0→77°，rotate_down: pitch 77°→0°（均由左手沿枪体上方向投影驱动，跟手浮点）
-- Yaw=180 Roll=90 固定，space=1（ComponentSpace）
local BOLT_ROTATE_UP_ANGLE = 77.0
local BOLT_ROTATE_YAW = 180.0
local BOLT_ROTATE_ROLL = 90.0
local BOLT_ROTATE_SPACE = 1
-- 上拉/下压满程手移距离（cm）：与后拉同构，沿枪体 Up 轴投影
 -- 越小越灵敏（手少动一点就能旋满）。原 6.0 手感偏远，2026-07-26 调到 3.5
local BOLT_ROTATE_THRESHOLD = 5.0
local BOLT_ROTATE_DOWN_DIST = 5.0
local BOLT_ROTATE_TOLERANCE = 5.0 -- 旋转到位容差（度，仅作 pitch 兜底）
-- 下压完成后再开栓保护：墙钟冷却（与帧率无关）+ 必须先松左 grip（防握着不放立刻又 rotate_up）
local BOLT_REGRAB_COOLDOWN_SEC = 0.5

-- Montage markers（SDK dump 确认：James_Rifle_Recoil_Separate_Overload 中的 AnimNotify）
-- 注：当前 on_play_request_check / on_montage_change_check 都 return false（放行），markers 仅作参考
-- 实际 AnimNotify：AnimNotify_SingleActionPrepareReady_0 / SHAnimNotify_PlayAudioWeapon_0-3 / AnimNotify_AkEvent_C_1-3
local BOLT_MONTAGE_MARKERS = {
    bolt_rotate_up = "BoltRotateUp",
    bolt_pull = "BoltPull",
    bolt_push = "BoltPush",
    bolt_rotate_down = "BoltRotateDown",
    -- SDK 确认的实际 AnimNotify 名（供未来需要精确匹配时使用）
    single_action_prepare_ready = "AnimNotify_SingleActionPrepareReady_0",
    montage_name = "James_Rifle_Recoil_Separate_Overload",
}

-- 从 accessories_parameters.json 读取的步枪左手 marker UUID（init 时填充）
-- bolt_marker_uuid: 本体枪栓 UUID（低 priority，用于拉栓完成后挂回真枪）
-- bolt_perf_marker_uuid: 表演枪栓 UUID（高 priority，拉栓期间左手优先附着此 marker）
-- grip_animation: 本体用 "rifle_offhand"（Holder），表演枪栓用 "pull_lock"（performance foregrip bolt）
local bolt_marker_uuid = nil
local bolt_perf_marker_uuid = nil

-- 步枪音效分段配置（硬编码，与手枪 PISTOL_RELOAD_SEGMENTS 同模式）
-- diagnose 面板滑条可临时修改内存值供预览，不写入 JSON
local RIFLE_AUDIO_SEGMENTS = {
    shell_insert     = { audio_key = "rifle_reload",    start_sec = 0.233, duration = 0.524 },
    bolt_rotate_up   = { audio_key = "rifle_bolt",      start_sec = 0.000, duration = 0.320 },
    bolt_pull        = { audio_key = "rifle_bolt",      start_sec = 0.535, duration = 0.300 },
    bolt_push        = { audio_key = "rifle_bolt",      start_sec = 0.770, duration = 0.300 },
    bolt_rotate_down = { audio_key = "rifle_bolt",      start_sec = 2.359, duration = 0.750 },
    mag_release      = { audio_key = "rifle_bolt",      start_sec = 2.984, duration = 2.121 },
    dry_fire         = { audio_key = "rifle_dry_fire",  start_sec = 0.00, duration = 1.00 },
}

-- 获取指定音效段的参数（供本模块和 diagnose 面板共用）
function M.get_audio_segment(seg_name)
    return RIFLE_AUDIO_SEGMENTS[seg_name]
end

-- 播放指定音效段（供面板按钮调用）
function M.play_audio_segment(seg_name)
    local seg = RIFLE_AUDIO_SEGMENTS[seg_name]
    if seg == nil then
        return false
    end
    audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
    return true
end

-- 临时修改音效段参数（仅 diagnose 面板预览用，不写入 JSON，不持久化）
function M.set_audio_segment(seg_name, start_sec, duration)
    local seg = RIFLE_AUDIO_SEGMENTS[seg_name]
    if seg == nil then
        return false
    end
    seg.start_sec = start_sec
    seg.duration = duration
    return true
end

-- Dry fire 音效事件名（SDK dump 确认：Play_Wpn_Rifle_Shot_No_Ammo）
local DRY_FIRE_AUDIO_EVENT = "Play_Wpn_Rifle_Shot_No_Ammo"
local RIFLE_DRY_FIRE_KEY = "rifle_dry_fire"
local RIFLE_DRY_FIRE_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Rifle/Play_Wpn_Rifle_Shot_No_Ammo.Play_Wpn_Rifle_Shot_No_Ammo"

-- 音效资产完整路径（SDK dump 确认：/Game/WWiseAudio/Events/Characters/James/James_Weapons/Rifle/）
local RIFLE_RELOAD_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Rifle/Play_Wpn_Rifle_Reload.Play_Wpn_Rifle_Reload"
local RIFLE_BOLT_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Rifle/Play_Wpn_Rifle_Bolt_Action.Play_Wpn_Rifle_Bolt_Action"
-- 步枪特有：拉栓关闭音效（旋转↓到位，霰弹枪无此分离事件）
local RIFLE_BOLT_CLOSE_EVENT_PATH =
    "/Game/WWiseAudio/Events/Characters/James/James_Weapons/Rifle/Play_Wpn_Rifle_Bolt_Close.Play_Wpn_Rifle_Bolt_Close"

-- Handed 全局由 libs/uevr_utils.lua 定义（Left = 0, Right = 1）

-- 前向声明：spawn/despawn 等在定义点之前就会调用；必须 local，避免与 shotgun/pistol 抢全局名
local publish_globals
local publish_bolt_busy_flags
local BOLT_BUSY_KEY = "g_rifle_bolt_busy"
local BOLT_OPEN_KEY = "g_rifle_bolt_open"

-- =============================================================================
-- 本地状态（热重载兼容）
-- =============================================================================

local state = rawget(_G, "__sh2_rifle_reload_state")
if type(state) == "table" and state._was_rifle == nil then
    state._was_rifle = false
end
if type(state) ~= "table" then
    state = {
        -- Phase 2: 双弹装填
        reload_active = false,           -- 复用 g_manual_reload_active
        shells_in_hand = false,          -- 左手是否持有任意一发弹壳模型
        shells_actor = nil,              -- shell_1 表演模型 actor
        shells_component = nil,          -- shell_1 StaticMeshComponent（attach 到左手）
        -- Phase 2.1: shell_2 独立 actor
        shells_actor2 = nil,             -- shell_2 表演模型 actor
        shells_component2 = nil,         -- shell_2 StaticMeshComponent（独立 attach 到左手）
        shell2_proximity_enabled = false,-- shell_2 是否参与 proximity 检测
        shell2_doomed = false,           -- shell_2 注定无法入仓
        shell2_lerp = nil,               -- shell_2 lerp 状态
        shell_slide = nil,               -- 入膛滑入动画状态
        shell_slide2 = nil,              -- shell_2 入膛滑入动画状态
        shell_drop = nil,                -- 松手垂直掉落状态
        shell_drop2 = nil,               -- shell_2 松手掉落状态
        -- Phase 3: 拉栓上膛
        needs_bolt = false,              -- 每发开火后置 true，手动拉栓完成后置 false
        bolt_active = false,             -- VR 手动拉栓是否进行中
        bolt_completed_this_cycle = false, -- 本轮拉栓是否已调用引擎同步
        -- 策略 C：PrepareAnimData 清零备份
        prepare_anim_data_nulled = false,
        prepare_anim_data_backup = nil,  -- { weapon_addr=, bytes= {qword...} }
        last_clip_ammo = nil,            -- 弹匣变化兜底检测开火 → needs_bolt
        -- Phase 3.5: PoseableMesh
        bolt_poseable = nil,             -- 枪栓 PoseableMesh 组件
        bolt_poseable_actor = nil,       -- 枪栓 PoseableMesh actor（销毁用）
        bolt_bone_hidden = false,        -- 真枪 bone_lock 是否已隐藏
        bolt_offhand_gripping = false,   -- 左手是否正握着 rifle_offhand
        post_bolt_keep_left_frames = 0,  -- 拉完栓后短暂粘住左手
        bolt_anchor_frozen = nil,        -- 表演枪栓生成时冻结锚点
        was_empty = false,               -- 策略E：打空仓标记（步枪暂禁用，始终保持 false）
        bolt_detach_cooldown = 0,        -- 兼容旧逻辑；实际以墙钟+闩锁为准
        bolt_regrab_block_until = 0,     -- os.clock 截止：此前禁止再 begin_bolt
        bolt_regrab_needs_release = false, -- true 时必须先松开左 grip 才允许再抓枪栓
        bolt_was_active_pull = false,    -- §16.4: 主动拉栓（needs_bolt=false）标记，控制 block/restore/EndNotify 行为
        bolt_reloaded_this_cycle = false, -- 本轮拉栓期间发生过 clip+1（开栓装弹）→ complete 时写 idle
        -- 武器切换检测
        last_weapon_key = nil,
        _was_rifle = false,
        -- Phase 5: slide_locked 借用手枪机制驱动 00/09 禁瞄准 + dry fire
        slide_locked = false,
        -- bolt 状态由 reload_tools.new_slide_rack_state() 持有，下方 init 时补充
        bolt_rack = nil,
        -- ShellSpawn 诊断
        last_grab_skip = nil,
        last_spawn_fail = nil,
        last_spawn_step = nil,
        spawn_attempt_count = 0,
        spawn_success_count = 0,
    }
    state.bolt_rack = reload_tools.new_slide_rack_state()
    state.bolt_rack.phase = "rotate_up"
    state.bolt_rack.rotate_progress = 0
    state.bolt_rack.current_pitch = 0
    state.bolt_rack.signed_rotate = 0
    state.bolt_rack.rotate_up_done = false
    state.shell_drop = reload_tools.new_drop_state()
    state.shell_drop.duration = SHELL_DROP_DURATION
    state.shell_drop.distance = SHELL_DROP_DISTANCE
    state.shell_drop2 = reload_tools.new_drop_state()
    state.shell_drop2.duration = SHELL_DROP_DURATION
    state.shell_drop2.distance = SHELL_DROP_DISTANCE
end
-- 热重载后确保 bolt_rack 存在
if state.bolt_rack == nil then
    state.bolt_rack = reload_tools.new_slide_rack_state()
    state.bolt_rack.phase = "rotate_up"
    state.bolt_rack.rotate_progress = 0
    state.bolt_rack.current_pitch = 0
    state.bolt_rack.signed_rotate = 0
    state.bolt_rack.rotate_up_done = false
end
if state.prepare_anim_data_nulled == nil then
    state.prepare_anim_data_nulled = false
end
if state.bolt_was_active_pull == nil then
    state.bolt_was_active_pull = false
end
if state.bolt_reloaded_this_cycle == nil then
    state.bolt_reloaded_this_cycle = false
end
if state.shell_drop == nil then
    state.shell_drop = reload_tools.new_drop_state()
    state.shell_drop.duration = SHELL_DROP_DURATION
    state.shell_drop.distance = SHELL_DROP_DISTANCE
end
if state.shell_drop2 == nil then
    state.shell_drop2 = reload_tools.new_drop_state()
    state.shell_drop2.duration = SHELL_DROP_DURATION
    state.shell_drop2.distance = SHELL_DROP_DISTANCE
end
-- 热重载后补齐 Phase 2.1 字段
if state.shell2_proximity_enabled == nil then state.shell2_proximity_enabled = false end
if state.shell2_doomed == nil then state.shell2_doomed = false end
if state.shell2_lerp == nil then state.shell2_lerp = nil end
if state.shell_slide2 == nil then state.shell_slide2 = nil end
-- 热重载后补齐诊断字段
if state.spawn_attempt_count == nil then state.spawn_attempt_count = 0 end
if state.spawn_success_count == nil then state.spawn_success_count = 0 end
if state.bolt_offhand_gripping == nil then state.bolt_offhand_gripping = false end
if state.bolt_detach_cooldown == nil then state.bolt_detach_cooldown = 0 end
if state.bolt_regrab_block_until == nil then state.bolt_regrab_block_until = 0 end
if state.bolt_regrab_needs_release == nil then state.bolt_regrab_needs_release = false end
-- 热重载后补齐 slide_locked 字段
if state.slide_locked == nil then state.slide_locked = false end
-- 热重载后补齐断点续拉 base 字段
if state.bolt_rack ~= nil then
    if state.bolt_rack.rotate_base == nil then state.bolt_rack.rotate_base = 0 end
    if state.bolt_rack.pull_base == nil then state.bolt_rack.pull_base = 0 end
end
if state.post_bolt_keep_left_frames == nil then state.post_bolt_keep_left_frames = 0 end
if state.was_empty == nil then state.was_empty = false end
-- 热重载：清掉可能残留的 was_empty，避免空仓仍拦拉栓
state.was_empty = false

-- 关键：把 state 写回 _G，保证热重载后新模块复用同一 state 表
_G.__sh2_rifle_reload_state = state



-- bolt 视觉：始终读写共享 state，避免热重载后本地表与 state 分叉出孤儿 actor
local bolt_visual = setmetatable({}, {
    __index = function(_, key)
        if key == "poseable_actor" then
            return state.bolt_poseable_actor
        end
        if key == "poseable_mesh" then
            return state.bolt_poseable
        end
        return nil
    end,
    __newindex = function(_, key, value)
        if key == "poseable_actor" then
            state.bolt_poseable_actor = value
        elseif key == "poseable_mesh" then
            state.bolt_poseable = value
        end
    end,
})

-- 重入保护：hook 与回调内禁止同步 cancel
local reload_block_guard = { cancelling = false }

-- =============================================================================
-- D7: 通用工具函数（日志/音频/触觉/诊断）
-- =============================================================================

-- 控制台/诊断 print：受 RELOAD_DIAG_ENABLED 门控
local function print_log(text, logLevel, tag)
    if rawget(_G, "RELOAD_DIAG_ENABLED") ~= true then
        return
    end
    local label = tag ~= nil and tag or "RIFLE_RELOAD"
    local msg = "[" .. label .. "] " .. tostring(text)
    print(msg)
end

-- 诊断日志：shell spawn / grip 相关事件（受 RELOAD_DIAG_ENABLED 开关门控）
local function diag_log(message, force)
    if not force and rawget(_G, "RELOAD_DIAG_ENABLED") ~= true then
        return
    end
    print("[SHELL_SPAWN] " .. tostring(message))
end

-- 诊断日志：子弹滑入 proximity 检测（受 RELOAD_DIAG_ENABLED 开关门控）
local function diag_log_insert_prox(message, force)
    if not force and rawget(_G, "RELOAD_DIAG_ENABLED") ~= true then
        return
    end
    print("[INSERT_PROX] " .. tostring(message))
end

-- 诊断日志：枪身前后左右向量（受 RELOAD_DIAG_ENABLED 开关门控）
local function diag_log_bolt_axis(message, force)
    if not force and rawget(_G, "RELOAD_DIAG_ENABLED") ~= true then
        return
    end
    print("[BOLT_AXIS] " .. tostring(message))
end

local function read_component_world_snapshot(comp)
    if comp == nil then
        return nil
    end
    local snap = { loc = nil, scale = nil, socket = nil, bone = nil }
    pcall(function()
        if comp.K2_GetComponentToWorld ~= nil then
            local wt = comp:K2_GetComponentToWorld()
            if wt ~= nil then
                pcall(function()
                    snap.loc = {
                        X = wt.Translation.X or 0,
                        Y = wt.Translation.Y or 0,
                        Z = wt.Translation.Z or 0,
                    }
                end)
                pcall(function()
                    snap.scale = {
                        X = wt.Scale3D.X or 0,
                        Y = wt.Scale3D.Y or 0,
                        Z = wt.Scale3D.Z or 0,
                    }
                end)
            end
        end
    end)
    if snap.loc == nil then
        snap.loc = reload_tools.get_component_world_location(comp)
    end
    pcall(function()
        snap.socket = reload_tools.get_socket_world_location(comp, BOLT_BONE_NAME)
    end)
    pcall(function()
        if comp.GetBoneLocationByName ~= nil then
            local space = 0
            if rawget(_G, "EBoneSpaces") ~= nil and EBoneSpaces.WorldSpace ~= nil then
                space = EBoneSpaces.WorldSpace
            end
            snap.bone = comp:GetBoneLocationByName(
                uevrUtils.fname_from_string(BOLT_BONE_NAME), space)
        end
    end)
    return snap
end

local function set_spawn_fail(step, reason)
    state.last_spawn_step = step
    state.last_spawn_fail = reason
    print_log("spawn_shells FAIL step=" .. tostring(step) .. " reason=" .. tostring(reason), LogLevel.Warn)
end

local function set_spawn_ok(detail)
    state.last_spawn_fail = nil
    state.last_spawn_step = "ok"
    state.spawn_success_count = (state.spawn_success_count or 0) + 1
    local msg = "OK " .. tostring(detail or "")
    print_log("spawn_shells " .. msg, LogLevel.Info)
end

local function set_grab_skip(reason)
    state.last_grab_skip = reason
    print_log("grab skipped: " .. tostring(reason), LogLevel.Debug)
end

local uobject_valid = reload_tools.uobject_valid

-- 触发换弹手柄震动
local function trigger_reload_haptic(action)
    if event_feedback and type(event_feedback.play_reload_haptic) == "function" then
        pcall(event_feedback.play_reload_haptic, action)
    end
end

-- 播放空仓扣扳机（dry fire）音效
local function play_dry_fire_sound()
    local seg = RIFLE_AUDIO_SEGMENTS.dry_fire
    if seg == nil then
        return false
    end
    local ok, result = pcall(audio.play_segment, seg.audio_key, seg.start_sec, seg.duration)
    return ok and result == true
end

-- =============================================================================
-- D9: 私有工具（保留在 rifle_reload.lua，不下沉）
-- =============================================================================

-- 读 qword 块（PrepareAnimData 备份/调试）— 复制自 shotgun L573
local function read_qword_blob(obj, offset, size)
    if obj == nil or type(obj.read_qword) ~= "function" then
        return nil
    end
    local bytes = {}
    local n = math.floor(size / 8)
    for i = 0, n - 1 do
        local ok, q = pcall(function() return obj:read_qword(offset + i * 8) end)
        if not ok then
            return nil
        end
        bytes[#bytes + 1] = q or 0
    end
    return bytes
end

-- 写 qword 块（还原 PrepareAnimData）— 复制自 shotgun L589
local function write_qword_blob(obj, offset, bytes)
    if obj == nil or type(obj.write_qword) ~= "function" or type(bytes) ~= "table" then
        return false
    end
    for i = 1, #bytes do
        local ok = pcall(function()
            obj:write_qword(offset + (i - 1) * 8, bytes[i] or 0)
        end)
        if not ok then
            return false
        end
    end
    return true
end

-- 清零 PrepareAnimData（策略 C 核心）— 复制自 shotgun L604
local function zero_qword_blob(obj, offset, size)
    if obj == nil or type(obj.write_qword) ~= "function" then
        return false
    end
    local n = math.floor(size / 8)
    for i = 0, n - 1 do
        local ok = pcall(function()
            obj:write_qword(offset + i * 8, 0)
        end)
        if not ok then
            return false
        end
    end
    return true
end

-- PrepareAnimData 诊断：对比当前值 vs 备份 — 复制自 shotgun L621，内部 chain 名改 rifle
local function diag_dump_prepare_anim_data(label)
    local weapon = resolve_rifle_weapon()
    if weapon == nil then
        return
    end
    local cur = read_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, PREPARE_ANIM_DATA_SIZE)
    local backup = state.prepare_anim_data_backup
    local backup_bytes = backup ~= nil and backup.bytes or nil

    local function fmt_qwords(bytes)
        if bytes == nil then return "nil" end
        local parts = {}
        local n = #bytes
        local max_show = 4
        for i = 1, math.min(max_show, n) do
            parts[#parts + 1] = string.format("%016X", bytes[i] or 0)
        end
        if n > max_show * 2 then
            parts[#parts + 1] = "..."
            for i = n - max_show + 1, n do
                parts[#parts + 1] = string.format("%016X", bytes[i] or 0)
            end
        elseif n > max_show then
            for i = max_show + 1, n do
                parts[#parts + 1] = string.format("%016X", bytes[i] or 0)
            end
        end
        return table.concat(parts, " ")
    end

    local diffs = {}
    if cur ~= nil and backup_bytes ~= nil then
        for i = 1, math.min(#cur, #backup_bytes) do
            if (cur[i] or 0) ~= (backup_bytes[i] or 0) then
                diffs[#diffs + 1] = string.format("[%d] %016X→%016X", i - 1, backup_bytes[i] or 0, cur[i] or 0)
            end
        end
    end

    local clip = nil
    pcall(function()
        local off = reload_tools.WEAPON_PROFILES.rifle
        clip = reload_tools.read_clip_ammo(weapon, off)
    end)

    print_log(string.format(
        "PREP_ANIM_DIAG [%s] clip=%s needs_bolt=%s cur=%s",
        label, tostring(clip), tostring(state.needs_bolt), fmt_qwords(cur)), LogLevel.Info)
    if backup_bytes ~= nil then
        print_log(string.format(
            "PREP_ANIM_DIAG [%s] backup=%s",
            label, fmt_qwords(backup_bytes)), LogLevel.Info)
    end
    if #diffs > 0 then
        print_log(string.format(
            "PREP_ANIM_DIAG [%s] DIFF vs backup: %s",
            label, table.concat(diffs, " | ")), LogLevel.Info)
    else
        print_log(string.format(
            "PREP_ANIM_DIAG [%s] SAME as backup (no diff)", label), LogLevel.Info)
    end
end

-- 骨骼隔离缓存：缓存 BoneIsChildOf 查询结果
local bone_isolation_cache = {}

-- 获取骨骼隔离缓存键 — 复制自 shotgun L1369
local function get_bone_isolation_cache_key(mesh_comp, target_bone_name)
    local ok, name = pcall(function()
        local sk = mesh_comp.SkeletalMesh
        if sk ~= nil then
            return sk:get_full_name() .. "|" .. target_bone_name
        end
        return mesh_comp:get_full_name() .. "|" .. target_bone_name
    end)
    return ok and name or nil
end

-- PoseableMesh 只显示目标骨（隐藏兄弟）— 复制自 shotgun L1380
local BONE_SCALE_HIDDEN = 0.001
local bone_space_component = reload_tools.bone_space_component
local bone_name_to_string = reload_tools.bone_name_to_string
local read_bone_scale = reload_tools.read_bone_scale

local function show_only_bone(mesh_comp, bone_name)
    if mesh_comp == nil or mesh_comp.GetNumBones == nil then
        return false
    end
    local bone_space = bone_space_component()
    local scale_hidden = uevrUtils.vector(BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN, BONE_SCALE_HIDDEN)
    local keep_fname = uevrUtils.fname_from_string(bone_name)
    local count = -1
    pcall(function() count = mesh_comp:GetNumBones() end)

    local cache_key = get_bone_isolation_cache_key(mesh_comp, bone_name)
    local iso_map = cache_key and bone_isolation_cache[cache_key] or nil

    if iso_map == nil and count > 0 and mesh_comp.GetBoneName ~= nil and mesh_comp.BoneIsChildOf ~= nil then
        iso_map = {}
        for i = 0, count - 1 do
            local bn = mesh_comp:GetBoneName(i)
            local bstr = bone_name_to_string(bn) or "?"
            if bstr == bone_name then
                iso_map[bstr] = "target"
            else
                local is_ancestor, is_descendant = false, false
                pcall(function() is_ancestor = mesh_comp:BoneIsChildOf(keep_fname, bn) end)
                pcall(function() is_descendant = mesh_comp:BoneIsChildOf(bn, keep_fname) end)
                if is_ancestor then
                    iso_map[bstr] = "ancestor"
                elseif is_descendant then
                    iso_map[bstr] = "descendant"
                else
                    iso_map[bstr] = "sibling"
                end
            end
        end
        if cache_key ~= nil then
            bone_isolation_cache[cache_key] = iso_map
        end
    end

    local ok = pcall(function()
        -- TARGET_SCALE=1.0：照抄 rifle_diagnose.lua B-3 测试（生成枪栓大小正确）
        -- 霰弹枪护木用 0.1 是因护木体积大需缩小；步枪枪栓不需缩小，用 1.0
        local TARGET_SCALE = 1.0
        local scale_target = uevrUtils.vector(TARGET_SCALE, TARGET_SCALE, TARGET_SCALE)
        if mesh_comp.SetBoneScaleByName ~= nil then
            for i = 0, count - 1 do
                mesh_comp:SetBoneScaleByName(mesh_comp:GetBoneName(i), scale_hidden, bone_space)
            end
            if iso_map ~= nil then
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if iso_map[bone_str] == "target" then
                        mesh_comp:SetBoneScaleByName(bone_fname, scale_target, bone_space)
                    end
                end
            else
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if bone_str == bone_name then
                        mesh_comp:SetBoneScaleByName(bone_fname, scale_target, bone_space)
                    end
                end
            end
        end
        if mesh_comp.HideBoneByName ~= nil then
            if iso_map ~= nil then
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    local role = iso_map[bone_str]
                    if role == "sibling" or role == "descendant" then
                        mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                    end
                end
            else
                for i = 0, count - 1 do
                    local bone_fname = mesh_comp:GetBoneName(i)
                    local bone_str = bone_name_to_string(bone_fname)
                    if bone_str ~= bone_name then
                        mesh_comp:HideBoneByName(bone_fname, HIDE_BONE_PHYS_BODY)
                    end
                end
            end
        end
    end)

    local s_holder = read_bone_scale(mesh_comp, "Holder", bone_space)
    local s_root = read_bone_scale(mesh_comp, "bone_root", bone_space)
    local s_lock = read_bone_scale(mesh_comp, bone_name, bone_space)
    return ok
end

-- 对齐 PoseableMesh 枪栓骨到原 mesh — 复制自 shotgun L1482 align_poseable_pump_bone
-- 将 PoseableMesh 的某 socket 对齐到真枪 mesh 同名 socket 世界位置（已下沉到 reload_tools.align_poseable_socket）
local function align_poseable_bolt_bone(poseable, weapon_mesh, bone_name)
    return reload_tools.align_poseable_socket(poseable, weapon_mesh, bone_name)
end

-- 新增包装：安全调用 HideBoneByName（含 pcall + log）
local function hide_bone_by_name_safe(mesh_comp, bone_name)
    if mesh_comp == nil or mesh_comp.HideBoneByName == nil then
        return false
    end
    if bone_name == nil or bone_name == "" then
        return false
    end
    local ok, err = pcall(function()
        mesh_comp:HideBoneByName(uevrUtils.fname_from_string(bone_name), HIDE_BONE_PHYS_BODY)
    end)
    if not ok then
        print_log("hide_bone_by_name_safe FAIL bone=" .. tostring(bone_name) .. " err=" .. tostring(err), LogLevel.Warn)
        return false
    end
    return true
end

-- 新增包装：安全调用 UnHideBoneByName（含 pcall + log）
local function unhide_bone_by_name_safe(mesh_comp, bone_name)
    if mesh_comp == nil or mesh_comp.UnHideBoneByName == nil then
        return false
    end
    if bone_name == nil or bone_name == "" then
        return false
    end
    local ok, err = pcall(function()
        mesh_comp:UnHideBoneByName(uevrUtils.fname_from_string(bone_name))
    end)
    if not ok then
        print_log("unhide_bone_by_name_safe FAIL bone=" .. tostring(bone_name) .. " err=" .. tostring(err), LogLevel.Warn)
        return false
    end
    return true
end

-- =============================================================================
-- D1: 武器识别与对象链（复用 reload_tools.resolve_combat_chain）
-- =============================================================================

local function is_rifle_weapon(weapon)
    if weapon == nil then
        return false
    end
    local ok, name = pcall(function()
        return weapon:get_full_name()
    end)
    return ok and name ~= nil and name:find(RIFLE_NAME_MARKER, 1, true) ~= nil
end

local function is_rifle_equipped()
    return rawget(_G, KEYS.current_weapon_type) == "rifle"
end

-- 获取步枪武器链：返回 weapon_mesh, chain, err
local function get_rifle_chain()
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    local chain = reload_tools.resolve_combat_chain(pawn)
    if not is_rifle_weapon(chain.equipped_weapon) or chain.weapon_mesh == nil then
        local gripped = attachments.getCurrentGrippedAttachment(Handed.Right)
        if gripped ~= nil then
            local ok, name = pcall(function() return gripped:get_full_name() end)
            if ok and name and name:find(RIFLE_NAME_MARKER, 1, true) then
                chain.weapon_mesh = gripped
                if chain.equipped_weapon == nil then
                    chain.equipped_weapon = gripped
                end
            end
        end
    end
    if not is_rifle_weapon(chain.equipped_weapon) and not is_rifle_weapon(chain.weapon_mesh) then
        return nil, chain, "not rifle"
    end
    if chain.weapon_mesh == nil then
        return nil, chain, "weapon mesh nil"
    end
    return chain.weapon_mesh, chain, nil
end

local function resolve_rifle_weapon()
    local _, chain = get_rifle_chain()
    local weapon = chain and chain.equipped_weapon or nil
    if weapon == nil or not is_rifle_weapon(weapon) then
        return nil
    end
    return weapon
end

local function weapon_addr_of(weapon)
    if weapon == nil or weapon.get_address == nil then
        return nil
    end
    local ok, a = pcall(function() return weapon:get_address() end)
    if ok and type(a) == "number" then
        return a
    end
    return nil
end

-- =============================================================================
-- D2: 策略 C — 清零 SingleActionPrepareAnimData（阻止引擎自动拉栓）
-- =============================================================================

--- 开火后：备份（若无）并清零 PrepareAnimData，阻止引擎自动拉栓
local function block_prepare_anim_data(reason)
    local weapon = resolve_rifle_weapon()
    if weapon == nil then
        return false
    end
    local wa = weapon_addr_of(weapon)

    if state.prepare_anim_data_nulled then
        -- §16.4 改动#11: nulled=true 时无论 backup 是否存在都视为已 block
        -- backup=nil（全零场景）或 backup.weapon_addr 匹配都直接返回 true
        if state.prepare_anim_data_backup == nil
            or state.prepare_anim_data_backup.weapon_addr == wa then
            return true
        end
    end

    if state.prepare_anim_data_backup == nil
        or state.prepare_anim_data_backup.weapon_addr ~= wa then
        local blob = read_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, PREPARE_ANIM_DATA_SIZE)
        if blob == nil then
            print_log("prepare_anim_data block FAIL: cannot backup @+0xC68", LogLevel.Warn)
            return false
        end
        local blob_summary = {}
        for i = 1, math.min(4, #blob) do
            blob_summary[#blob_summary + 1] = string.format("q%d=0x%016X", i - 1, blob[i] or 0)
        end
        print_log("prepare_anim_data block READ blob: " .. table.concat(blob_summary, " ")
            .. " (n=" .. #blob .. ")", LogLevel.Info)
        local all_zero = true
        for i = 1, #blob do
            if (blob[i] or 0) ~= 0 then
                all_zero = false
                break
            end
        end
        if all_zero then
            -- §16.4 改动#11: 全零时仍标记 nulled=true 并返回 true（不存 backup）
            -- 保证 prepare_anim_data_nulled 状态一致，restore 时自动跳过写回并重置 nulled
            state.prepare_anim_data_nulled = true
            print_log("prepare_anim_data block: field already zero, nulled=true (no backup stored) reason="
                .. tostring(reason), LogLevel.Info)
            return true
        end
        state.prepare_anim_data_backup = { weapon_addr = wa, bytes = blob }
        print_log("prepare_anim_data backup STORED weapon=0x" .. string.format("%X", wa)
            .. " qwords=" .. #blob, LogLevel.Info)
    else
        print_log("prepare_anim_data block: backup EXISTS, skip re-read (weapon=0x"
            .. string.format("%X", wa) .. ")", LogLevel.Info)
    end

    local zero_ok = zero_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, PREPARE_ANIM_DATA_SIZE)
    if not zero_ok then
        print_log("prepare_anim_data block FAIL: cannot zero @+0xC68", LogLevel.Warn)
        return false
    end

    state.prepare_anim_data_nulled = true
    print_log("prepare_anim_data BLOCKED reason=" .. tostring(reason)
        .. " weapon=" .. (wa and string.format("0x%X", wa) or "?"), LogLevel.Info)
    return true
end

--- 写回清零前的 PrepareAnimData（拉栓完成 / 上弹解锁开火必需）
local function restore_prepare_anim_data(reason, discard_backup)
    local backup = state.prepare_anim_data_backup
    if not state.prepare_anim_data_nulled then
        if discard_backup then
            state.prepare_anim_data_backup = nil
        end
        return false
    end
    if backup == nil or type(backup.bytes) ~= "table" then
        state.prepare_anim_data_nulled = false
        state.prepare_anim_data_backup = nil
        return false
    end

    local weapon = resolve_rifle_weapon()
    local wa = weapon_addr_of(weapon)
    local write_ok = false
    if weapon ~= nil and wa ~= nil and wa == backup.weapon_addr then
        write_ok = write_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, backup.bytes)
    else
        print_log("prepare_anim_data restore skipped (weapon gone/changed), reason="
            .. tostring(reason), LogLevel.Debug)
    end

    state.prepare_anim_data_nulled = false
    if discard_backup then
        state.prepare_anim_data_backup = nil
    end
    if write_ok then
        print_log("prepare_anim_data RESTORED reason=" .. tostring(reason)
            .. " keep_backup=" .. tostring(not discard_backup), LogLevel.Info)
    end
    return write_ok
end

--- 策略 D：写入 idle 固定值到 PrepareAnimData
local function write_idle_prepare_anim_data(reason)
    local weapon = resolve_rifle_weapon()
    if weapon == nil then
        print_log("write_idle_prepare_anim_data FAIL: weapon nil reason=" .. tostring(reason), LogLevel.Warn)
        return false
    end
    local write_ok = write_qword_blob(weapon, PREPARE_ANIM_DATA_OFF, IDLE_PREPARE_ANIM_DATA)
    if write_ok then
        state.prepare_anim_data_nulled = false
        print_log("prepare_anim_data IDLE WRITTEN reason=" .. tostring(reason)
            .. " (覆盖为 idle 固定值，防止自动拉栓)", LogLevel.Info)
    else
        print_log("write_idle_prepare_anim_data FAIL: cannot write @+0xC68 reason=" .. tostring(reason), LogLevel.Warn)
    end
    return write_ok
end

--- §16.4 公共函数：调用 OnRangedSingleActionPrepareEnd 告知引擎拉栓周期结束
--- 供 complete_bolt（告知引擎结束）和 begin_bolt 主动拉栓分支（清理残留 Prepare 状态）复用
--- EndNotify 在引擎未进入 Prepare 状态时调用无害
local function call_on_ranged_single_action_prepare_end(reason)
    local pawn = uevr and uevr.api and uevr.api:get_local_pawn(0) or nil
    local chain = reload_tools.resolve_combat_chain(pawn)
    local subcomp = chain and chain.ranged or nil
    if subcomp == nil or reload_tools.SHRangedCmbSubcomp_c == nil then
        return false
    end
    local ok, err = pcall(function()
        local fn = reload_tools.SHRangedCmbSubcomp_c:find_function("OnRangedSingleActionPrepareEnd")
        if fn ~= nil then
            subcomp:call_function(fn, nil, 0)
        end
    end)
    if not ok then
        print_log("call_on_ranged_single_action_prepare_end FAIL reason="
            .. tostring(reason) .. " err=" .. tostring(err), LogLevel.Warn)
        return false
    end
    print_log("OnRangedSingleActionPrepareEnd called reason=" .. tostring(reason), LogLevel.Info)
    return true
end

--- 开火成功：needs_bolt + 清零 PrepareAnimData（挡自动拉栓）
local function mark_needs_bolt(source)
    if state.needs_bolt and not state.bolt_completed_this_cycle then
        return
    end
    state.needs_bolt = true
    state.bolt_completed_this_cycle = false
    block_prepare_anim_data(source)
    print_log("needs_bolt = true (" .. tostring(source) .. ")", LogLevel.Info)
end

--- 弹匣弹药变化监听（同霰弹枪逻辑，pump→bolt）
--- [TEMP 2026-07-26] 步枪暂时禁用策略E「打空仓 was_empty」全部分支：
--- 霰弹枪空仓不要求立刻泵，可先上弹再泵；步枪必须先开栓才能上弹。
--- 旧逻辑：clip→0 只设 was_empty 不 mark_needs_bolt + ensure 在 was_empty 时拒生成表演枪栓
--- → 空仓完全不能拉栓 → 无法上弹。步枪空仓/非空仓统一：开火即 needs_bolt，可拉栓。
local function tick_clip_fire_watch(weapon, clip)
    if weapon == nil then
        state.last_clip_ammo = nil
        return
    end
    if type(clip) ~= "number" then
        return
    end
    local prev = state.last_clip_ammo
    if prev ~= nil and clip < prev then
        -- [[ was_empty / strategy E DISABLED for rifle
        -- if clip == 0 then
        --     state.was_empty = true
        --     print_log("tick_clip_fire_watch EMPTY FIRE " .. tostring(prev) .. "→0 (was_empty=true, strategy E)", LogLevel.Info)
        -- else
        --     print_log("tick_clip_fire_watch FIRE DETECTED " .. tostring(prev) .. "→" .. tostring(clip), LogLevel.Info)
        --     mark_needs_bolt("clip_delta " .. tostring(prev) .. "→" .. tostring(clip))
        -- end
        -- ]]
        -- 空仓与非空仓一视同仁：都 mark_needs_bolt，允许立刻拉栓上弹
        print_log("tick_clip_fire_watch FIRE DETECTED " .. tostring(prev) .. "→" .. tostring(clip)
            .. (clip == 0 and " (empty, no was_empty)" or ""), LogLevel.Info)
        mark_needs_bolt("clip_delta " .. tostring(prev) .. "→" .. tostring(clip))
    elseif prev ~= nil and clip > prev then
        -- [[ was_empty empty_reload branch DISABLED
        -- if state.was_empty then
        --     mark_needs_bolt("empty_reload_" .. tostring(prev) .. "→" .. tostring(clip))
        --     block_prepare_anim_data("empty_reload_ensure_blocked")
        --     print_log("tick_clip_fire_watch EMPTY_RELOAD " .. tostring(prev) .. "→" .. tostring(clip)
        --         .. " (needs_bolt=true + PrepareAnimData blocked, strategy E)", LogLevel.Info)
        -- elseif state.needs_bolt or state.bolt_active then
        -- ]]
        if state.needs_bolt or state.bolt_active then
            -- 步枪 ≠ 霰弹枪：开栓后从上口上弹时弹匣会 +1。
            -- 旧逻辑照抄霰弹枪「clip↑ 清 needs_pump」→ tick_bolt 立刻 cancel_bolt("not_needed")
            -- → 表演枪栓被销毁、真枪合栓。needs_bolt 只应由 complete_bolt 清除。
            print_log("clip INCREASE keep needs_bolt (open-bolt reload) "
                .. tostring(prev) .. "→" .. tostring(clip)
                .. " bolt_active=" .. tostring(state.bolt_active)
                .. " shells_in_hand=" .. tostring(state.shells_in_hand), LogLevel.Info)
            if state.bolt_active then
                -- 标记本轮开栓装弹：complete_bolt 写 idle 阻止引擎自动拉栓
                state.bolt_reloaded_this_cycle = true
                block_prepare_anim_data("clip_increase_keep_bolt_open")
            end
        else
            print_log("tick_clip_fire_watch clip INCREASE (no needs_bolt) " .. tostring(prev) .. "→" .. tostring(clip), LogLevel.Info)
        end
    end
    state.last_clip_ammo = clip
end

-- =============================================================================
-- C: A 类 hook 回调入口（由 reload_hooks dispatch 调用）
-- =============================================================================

-- 判断 obj 是否为玩家步枪（防 AI 武器误触）
local function is_player_rifle(obj)
    if not uobject_valid(obj) then
        return false
    end
    return is_rifle_equipped()
end

-- 判断是否应阻止原生换弹（强制手动装弹时为 true）
local BLOCK_NATIVE_RELOAD = false

local function should_block_native_reload()
    if not BLOCK_NATIVE_RELOAD then
        return false
    end
    return is_rifle_equipped()
end

-- IsFireReady 决策（reload_hooks 透传）：
--   true     = 强制 false（needs_bolt，拦开火）
--   "allow"  = 强制 true（手动拉栓完成，可开火）
--   false    = 放行引擎原函数
function M.on_fire_ready_check(obj)
    if not is_player_rifle(obj) then
        return false
    end
    if state.needs_bolt and not state.bolt_completed_this_cycle then
        return true
    elseif state.bolt_completed_this_cycle and not state.needs_bolt then
        return "allow"
    end
    return false
end

-- OnOutOfAmmoPerformed hook 回调：步枪不需要（同霰弹枪）
-- slide_locked 由 on_tick 读弹药触发，dry fire 由 dry_fire_edge 路径处理
function M.on_out_of_ammo(obj)
    -- no-op: 步枪纯手动装弹，无引擎自动换弹要 cancel
end

-- 强制释放 VR 瞄准状态
local function force_release_vr_aim(reason)
    local env = rawget(_G, "VREnvironment")
    if type(env) ~= "table" or type(env.getEnhancer) ~= "function" then
        return
    end
    local enhancer = env:getEnhancer()
    if type(enhancer) ~= "table" then
        return
    end
    pcall(function()
        if type(enhancer._aimPistolLikeAction) == "table"
            and type(enhancer._aimPistolLikeAction.leave) == "function" then
            enhancer._aimPistolLikeAction:leave()
        end
    end)
    -- 不 leave gripRight：保留 aimMode 3（空仓右抓握+RT 调近战）
    enhancer._twoHandAimHold = false
    _G[KEYS.aim_active] = false
    if reason ~= nil then
        print_log("[RIFLE_SLIDE_LOCK] VR aim released: " .. tostring(reason), LogLevel.Info)
    end
end

-- CanBeReloaded hook 回调
function M.on_can_be_reloaded_check(obj)
    return false
end

-- PlayRequest/PlayOrOverwriteRequest hook 回调
function M.on_play_request_check(obj, locals)
    return false
end

-- OnRangedReload hook 回调
function M.on_ranged_reload_check(obj)
    return false
end

-- Montage 变化回调
function M.on_montage_change_check(montage, montageName, animInstance)
    return false
end

-- RequestManualFire post hook：开火成功 → needs_bolt
function M.on_fire_success(ranged_subcomp)
    if not is_rifle_equipped() then
        return
    end
    mark_needs_bolt("RequestManualFire")
end

-- OnRangedSingleActionPrepareEnd post hook
function M.on_single_action_prepare_end(montage, endType)
    if not is_rifle_equipped() then
        return
    end
    if not state.needs_bolt then
        return
    end
    print_log("PrepareEnd while needs_bolt (strategy C leak?) endType=" .. tostring(endType), LogLevel.Warn)
end

-- =============================================================================
-- D6: 左手/弹壳手/Hook 通用
-- =============================================================================

-- 按 hands_type 选左手 mesh
local function resolve_left_hand_component()
    local hands_type = configui.getValue("hands_type") or HandsType.None
    if hands_type == HandsType.None then
        return controllers.getController(Handed.Left)
    elseif hands_type == HandsType.Forearms then
        return hands.getHandComponent(Handed.Left)
    elseif hands_type == HandsType.IKArms then
        local ok_ik, ik_mod = pcall(require, "libs/ik")
        if ok_ik and ik_mod and ik_mod.getCurrentMesh then
            return ik_mod.getCurrentMesh()
        end
    end
    return controllers.getController(Handed.Left)
end

-- 弹药模型必须跟 VR 左手控制器
local function resolve_shell_hand_parent()
    local mc = controllers.getController(Handed.Left)
    if mc == nil then
        pcall(function()
            controllers.createController(Handed.Left)
        end)
        mc = controllers.getController(Handed.Left)
    end
    return mc
end

-- 左手弹药 spawn/跟随
local function get_shell_hand_world_transform()
    local left_comp = resolve_shell_hand_parent()
    if left_comp == nil then
        return nil, nil, nil, "motion_controller_nil", nil
    end
    local loc = reload_tools.get_component_world_location(left_comp)
        or controllers.getControllerLocation(Handed.Left)
    local rot = reload_tools.get_component_world_rotation(left_comp)
        or controllers.getControllerRotation(Handed.Left)
    if loc == nil then
        return nil, nil, left_comp, "motion_controller_no_location", nil
    end
    return loc, rot, left_comp, nil, "motion_controller"
end

--- bone_lock + 用户语义偏移 → 世界坐标
local function get_shell_socket_offset_world_location(mesh, offset)
    if mesh == nil then
        return nil, nil
    end
    local base = reload_tools.get_socket_world_location(mesh, SHELL_INSERT_SOCKET)
    if base == nil then
        return nil, nil
    end
    offset = offset or {}
    local rot = nil
    pcall(function()
        if mesh.GetSocketRotation ~= nil then
            rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(SHELL_INSERT_SOCKET))
        end
    end)
    local dx, dy, dz = 0, 0, 0
    if rot ~= nil then
        -- 标准映射（与 pistol_reload 一致）：forward→X, right→Y, down→-Z
        -- 注意：shotgun 用的是错位映射（X=往下,Y=向后,Z=向左），那是因为 bone_forearm socket 轴向非标准
        -- rifle 的 bone_lock socket 轴向同 weapon mesh（X=前,Y=右,Z=上），用标准映射
        dx, dy, dz = reload_tools.local_offset_to_world_delta(
            rot,
            offset.forward or 0,
            offset.right or 0,
            offset.down or 0
        )
    else
        -- fallback：无 socket 旋转时，forward→X, right→Y, down→-Z
        dx = offset.forward or 0
        dy = offset.right or 0
        dz = -(offset.down or 0)
    end
    return SHELL_INSERT_SOCKET, {
        X = (base.X or 0) + dx,
        Y = (base.Y or 0) + dy,
        Z = (base.Z or 0) + dz,
    }
end

--- 装弹口世界坐标（proximity / 滑入终点）
local function get_shell_insert_world_location(mesh)
    return get_shell_socket_offset_world_location(mesh, SHELL_INSERT_OFFSET)
end

--- 滑入动画固定起点（在终点正上方 SHELL_SLIDE_APPROACH_DOWN cm 处，从上往下滑入）
-- 注意：rifle 的垂直轴是 right（正值=下），所以 start 的 right = end.right - APPROACH
local function get_shell_slide_start_world_location(mesh)
    local start_offset = {
        forward = SHELL_INSERT_OFFSET.forward or 0,
        right = (SHELL_INSERT_OFFSET.right or 0) - (SHELL_SLIDE_APPROACH_DOWN or 0),
        down = SHELL_INSERT_OFFSET.down or 0,
    }
    return get_shell_socket_offset_world_location(mesh, start_offset)
end

--- 滑入目标：同装弹口
local function resolve_shell_insert_socket(mesh)
    return get_shell_insert_world_location(mesh)
end

--- bone_lock 世界旋转（入膛朝向基准）
local function get_shell_insert_socket_rotation(mesh)
    if mesh == nil then
        return nil
    end
    local rot = nil
    pcall(function()
        if mesh.GetSocketRotation ~= nil then
            rot = mesh:GetSocketRotation(uevrUtils.fname_from_string(SHELL_INSERT_SOCKET))
        end
    end)
    if rot == nil then
        rot = reload_tools.get_component_world_rotation(mesh)
    end
    return rot
end

local rotator_to_slide_table = reload_tools.rotator_to_slide_table

--- 相对基准旋转叠加局部偏移
-- 2026-07-30：从 compose_world_rot_offset 切回 compose_local_rot_offset
-- 原因：world offset 在世界坐标系应用，枪旋转时入膛角度相对枪身会漂移；
--       local offset 在 socket 局部 frame 应用，枪怎么转 offset 跟着转，夹角始终不变。
-- 霰弹枪已于 2026-07-31 改用 reload_tools.compose_local_rot_offset 公共版本；
-- 步枪 bone_lock socket 轴向同 weapon mesh（X=前,Y=右,Z=上），local frame 正常，无万向锁。

--- 构造统一的滑入起止旋转
local function build_shell_slide_rotations(mesh)
    local socket_rot = get_shell_insert_socket_rotation(mesh)
    if socket_rot == nil then
        return nil, nil
    end
    local end_rot = reload_tools.compose_local_rot_offset(socket_rot, SHELL_SLIDE_END_ROT_OFFSET)
    local start_rot = reload_tools.compose_local_rot_offset(socket_rot, SHELL_SLIDE_START_TILT)
    if end_rot == nil then
        end_rot = socket_rot
    end
    if start_rot == nil then
        start_rot = end_rot
    end
    return rotator_to_slide_table(start_rot), rotator_to_slide_table(end_rot)
end

--- 起止欧拉角几乎相同则不做旋转插值
local function shell_slide_rots_equal(a, b)
    if a == nil or b == nil then
        return false
    end
    local eps = 0.05
    return math.abs((a.Pitch or 0) - (b.Pitch or 0)) < eps
        and math.abs((a.Yaw or 0) - (b.Yaw or 0)) < eps
        and math.abs((a.Roll or 0) - (b.Roll or 0)) < eps
end

-- 入膛滑入动画的 follow_provider：每帧从枪体 socket 刷新起点/终点/旋转
-- 使弹壳在滑入阶段跟随枪体移动（走动/转身时弹壳不会脱离入弹口）
-- 同时也被 shell drop（start_single_shell_drop）复用作为 fall 阶段水平跟随的参照点
-- 对齐 shotgun_reload.lua:2783 make_shell_slide_follow_provider
local function make_shell_slide_follow_provider()
    return function()
        local mesh, _ = get_rifle_chain()
        if mesh == nil then
            return nil
        end
        local _, start_pos = get_shell_slide_start_world_location(mesh)
        local _, end_pos = resolve_shell_insert_socket(mesh)
        if start_pos == nil or end_pos == nil then
            return nil
        end
        local start_rot, end_rot = build_shell_slide_rotations(mesh)
        return {
            sx = start_pos.X, sy = start_pos.Y, sz = start_pos.Z,
            ex = end_pos.X, ey = end_pos.Y, ez = end_pos.Z,
            start_rot = start_rot, end_rot = end_rot,
        }
    end
end

-- 左手持弹姿势 on：rifle_shell_insert
local function apply_left_hand_shell_pose()
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, SHELL_HAND_ANIMATION)
    end)
end

-- 左手持弹姿势 off
local function clear_left_hand_shell_pose()
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, false)
    end)
    pcall(function()
        if attachments.setActiveAnimation ~= nil then
            attachments.setActiveAnimation(nil, Handed.Left)
        end
    end)
    print("[RIFLE_RELOAD] pose=off → false (force open)")
end

-- 读取左手持弹偏移参数（Phase 2.1：参数化支持 shell_1 / shell_2）
local function load_rifle_shell_params(attachment_id, config_prefix)
    attachment_id = attachment_id or SHELL_LEFT_HAND_ATTACHMENT_ID
    config_prefix = config_prefix or SHELL_CONFIG_PREFIX
    local loc = configui.getValue(config_prefix .. "position")
    local rot = configui.getValue(config_prefix .. "rotation")
    local scale = configui.getValue(config_prefix .. "scale")
    if loc ~= nil and rot ~= nil then
        return {
            location = loc,
            rotation = rot,
            scale = scale or { 1.0, 1.0, 1.0 },
        }
    end
    local defaults = {
        location = { 0.0, 0.0, 0.0 },
        rotation = { 0.0, 0.0, 0.0 },
        scale = { 1.0, 1.0, 1.0 },
    }
    local params = json.load_file("attachments_parameters.json")
    if params ~= nil and params.attachmentOffsets ~= nil then
        for i = 1, #params.attachmentOffsets do
            local entry = params.attachmentOffsets[i]
            if entry ~= nil and entry.id == attachment_id then
                return entry
            end
        end
    end
    return defaults
end

-- 应用左手持弹偏移到 component
local function apply_rifle_shell_transform(comp, attachment_id, config_prefix)
    if comp == nil then
        return
    end
    local params = load_rifle_shell_params(attachment_id, config_prefix)
    local loc = params.location or { 0, 0, 0 }
    local rot = params.rotation or { 0, 0, 0 }
    local scale = params.scale or { 1, 1, 1 }
    pcall(function()
        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(loc))
        uevrUtils.set_component_relative_rotation(comp, uevrUtils.rotator(rot))
        uevrUtils.set_component_relative_scale(comp, uevrUtils.vector(scale))
    end)
end

local function is_left_hand_shell_component(comp)
    if state.shells_in_hand ~= true then
        return false
    end
    local shells = uevrUtils.getValid(state.shells_component)
    local other = uevrUtils.getValid(comp)
    return shells ~= nil and other ~= nil and shells == other
end

-- =============================================================================
-- C: B 类附件 hook 回调入口
-- =============================================================================

-- grip update 合并：左手持弹时挂到 MotionController
function M.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
    if state.shells_in_hand ~= true then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    if uevrUtils.isInCutscene and uevrUtils.isInCutscene() then
        return rA, rM, rS, nil, nil, nil, oR, oL
    end
    local shells = uevrUtils.getValid(state.shells_component)
    if shells == nil and state.shells_component2 ~= nil then
        shells = uevrUtils.getValid(state.shells_component2)
    end
    if shells == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    local left_comp = resolve_shell_hand_parent()
    if left_comp == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    return rA, rM, rS, shells, left_comp, nil, oR, shellAttachOptions
end

-- initAttachment：应用 rifle_shells 偏移 + 持弹姿势
function M.on_init_attachment(attachment, gripHand, options)
    if gripHand ~= Handed.Left then
        return
    end
    local comp1 = uevrUtils.getValid(state.shells_component)
    local comp2 = uevrUtils.getValid(state.shells_component2)
    local att = uevrUtils.getValid(attachment)
    if comp1 ~= nil and att ~= nil and comp1 == att then
        apply_rifle_shell_transform(attachment)
        apply_left_hand_shell_pose()
    elseif comp2 ~= nil and att ~= nil and comp2 == att then
        if state.shell2_proximity_enabled or state.shell2_doomed then
            apply_rifle_shell_transform(attachment,
                SHELL_LEFT_HAND_ATTACHMENT_ID, SHELL_CONFIG_PREFIX)
        else
            apply_rifle_shell_transform(attachment,
                SHELL_LEFT_HAND_ATTACHMENT_ID_2, SHELL_CONFIG_PREFIX_2)
        end
        apply_left_hand_shell_pose()
    end
end

-- =============================================================================
-- D4: PoseableMesh 隔离（枪栓视觉隔离 + 旋转驱动）
-- =============================================================================

local copy_weapon_world_transform = reload_tools.copy_component_world_transform
local apply_poseable_render_flags = reload_tools.apply_poseable_render_flags
local prepare_spawned_actor_visible = reload_tools.prepare_spawned_actor_visible

-- 从 weapon_mesh 组件世界旋转提取枪体后方向单位向量（不使用 bone_lock socket，因其 X 轴朝侧面）
-- 诊断：武器组件 X 轴也是侧向（测试反馈：从左拉变右拉），疑似 Y 轴才是枪管方向
-- 当前策略：用 -RightVector（Y 轴取反）作为后拉方向；每次拉栓打印一次三轴诊断日志（受 [Reload] 开关控制）
local bolt_axis_diag_printed = false
local function get_bolt_backward_axis(weapon_mesh)
    if weapon_mesh == nil then
        return nil
    end
    local comp_rot = reload_tools.get_component_world_rotation(weapon_mesh)
    if comp_rot == nil then
        return nil
    end
    -- 一次性打印三轴诊断（forward/right/up），便于确认哪个轴是枪管方向
    -- flag 由 begin_bolt 入口重置，使每次拉栓都能打印一次最新向量
    -- 受 rifle_diagnose [Reload] 开关控制；开关关闭时 log_raw 内部直接 return
    if not bolt_axis_diag_printed then
        bolt_axis_diag_printed = true
        pcall(function()
            local fwd = uevrUtils.getForwardVector(comp_rot)
            local right = nil
            local up = nil
            if kismet_math_library ~= nil then
                if kismet_math_library.GetRightVector ~= nil then
                    right = kismet_math_library:GetRightVector(comp_rot)
                end
                if kismet_math_library.GetUpVector ~= nil then
                    up = kismet_math_library:GetUpVector(comp_rot)
                end
            end
            diag_log_bolt_axis(string.format(
                "comp_rot (P=%s Y=%s R=%s) | forward=(%s,%s,%s) | right=(%s,%s,%s) | up=(%s,%s,%s)",
                tostring(comp_rot.Pitch or comp_rot.pitch),
                tostring(comp_rot.Yaw or comp_rot.yaw),
                tostring(comp_rot.Roll or comp_rot.roll),
                tostring(fwd and fwd.X), tostring(fwd and fwd.Y), tostring(fwd and fwd.Z),
                tostring(right and right.X), tostring(right and right.Y), tostring(right and right.Z),
                tostring(up and up.X), tostring(up and up.Y), tostring(up and up.Z)
            ))
        end)
    end
    -- 用 -RightVector 作为后拉方向（猜测 Y 轴 = 枪管前方）
    local right = nil
    if kismet_math_library ~= nil and kismet_math_library.GetRightVector ~= nil then
        pcall(function()
            right = kismet_math_library:GetRightVector(comp_rot)
        end)
    end
    if right == nil then
        -- fallback：用 forward 取反（旧逻辑，已知不正确但保底）
        local forward = uevrUtils.getForwardVector(comp_rot)
        if forward == nil then
            return nil
        end
        return { X = -(forward.X or 0), Y = -(forward.Y or 0), Z = -(forward.Z or 0) }
    end
    return { X = -(right.X or 0), Y = -(right.Y or 0), Z = -(right.Z or 0) }
end

-- 枪栓上拉方向：组件 UpVector（下压阶段取反）
local function get_bolt_rotate_axis(weapon_mesh, invert)
    if weapon_mesh == nil then
        return nil
    end
    local comp_rot = reload_tools.get_component_world_rotation(weapon_mesh)
    if comp_rot == nil then
        return nil
    end
    local up = nil
    if kismet_math_library ~= nil and kismet_math_library.GetUpVector ~= nil then
        pcall(function()
            up = kismet_math_library:GetUpVector(comp_rot)
        end)
    end
    if up == nil then
        -- fallback：世界 Up
        up = { X = 0, Y = 0, Z = 1 }
    end
    local sx = up.X or 0
    local sy = up.Y or 0
    local sz = up.Z or 0
    if invert then
        return { X = -sx, Y = -sy, Z = -sz }
    end
    return { X = sx, Y = sy, Z = sz }
end

-- 隐藏真枪的 bone_lock（避免与 PoseableMesh 重叠）— 调用 D9 hide_bone_by_name_safe
local function hide_bolt_bone(mesh)
    if mesh == nil then
        return false
    end
    local ok = hide_bone_by_name_safe(mesh, BOLT_BONE_NAME)
    if ok then
        state.bolt_bone_hidden = true
    end
    return ok
end

-- 恢复真枪 bone_lock 显示 — 调用 D9 unhide_bone_by_name_safe
local function show_bolt_bone(mesh)
    if mesh == nil then
        return false
    end
    local ok = unhide_bone_by_name_safe(mesh, BOLT_BONE_NAME)
    if ok then
        state.bolt_bone_hidden = false
    end
    return ok
end

-- 隐藏表演枪栓视觉（保留骨架，参照 shotgun hide_pump_poseable_visual — 已弃用但保留接口）
local function hide_bolt_poseable_visual(poseable, actor)
    pcall(function()
        if poseable ~= nil then
            if poseable.SetVisibility ~= nil then
                poseable:SetVisibility(false, true)
            end
            if poseable.SetHiddenInGame ~= nil then
                poseable:SetHiddenInGame(true, true)
            end
        end
    end)
    pcall(function()
        if actor ~= nil then
            if actor.SetActorHiddenInGame ~= nil then
                actor:SetActorHiddenInGame(true)
            end
            local root = actor.RootComponent
            if root ~= nil then
                if root.SetVisibility ~= nil then
                    root:SetVisibility(false, true)
                end
                if root.SetHiddenInGame ~= nil then
                    root:SetHiddenInGame(true, true)
                end
            end
        end
    end)
end

local function bolt_poseable_is_valid()
    return uevrUtils.getValid(bolt_visual.poseable_mesh) ~= nil
        and uevrUtils.getValid(bolt_visual.poseable_actor) ~= nil
end

local function clear_stale_bolt_poseable_refs()
    local mesh_dead = bolt_visual.poseable_mesh ~= nil and uevrUtils.getValid(bolt_visual.poseable_mesh) == nil
    local actor_dead = bolt_visual.poseable_actor ~= nil and uevrUtils.getValid(bolt_visual.poseable_actor) == nil
    if mesh_dead or actor_dead then
        bolt_visual.poseable_mesh = nil
        bolt_visual.poseable_actor = nil
        state.bolt_poseable = nil
        state.bolt_poseable_actor = nil
        rawset(_G, "__sh2_bolt_hand_parent", nil)
    end
end

local function set_bolt_hand_parent(poseable)
    rawset(_G, "__sh2_bolt_hand_parent", poseable)
end

local function clear_bolt_hand_parent()
    rawset(_G, "__sh2_bolt_hand_parent", nil)
end

-- 重入保护
local bolt_attach_busy = false
local bolt_begin_busy = false
local bolt_spawn_busy = false

local function bolt_callback_locked()
    return bolt_attach_busy or bolt_begin_busy or bolt_spawn_busy
end

--- 藏真枪枪栓后左手改挂表演件
-- 仅在 state.bolt_offhand_gripping=true 时才 attach（由 tick_detect_bolt_grip 驱动）
-- 不再使用 is_left_grip_pressed() 作为 fallback：双手控枪时 LB 持续按下会导致开火后立即吸附
local function attach_left_hand_to_performance_bolt(do_reattach)
    local poseable = uevrUtils.getValid(bolt_visual.poseable_mesh)
    if poseable == nil then
        return false
    end
    set_bolt_hand_parent(poseable)
    local attach_uuid = bolt_perf_marker_uuid or bolt_marker_uuid
    if do_reattach ~= true or bolt_attach_busy or attach_uuid == nil then
        return true
    end
    if state.bolt_offhand_gripping ~= true then
        return true
    end
    bolt_attach_busy = true
    state.bolt_offhand_gripping = true
    pcall(function()
        accessories.attachHandToAccessory(Handed.Left, attach_uuid, false)
    end)
    bolt_attach_busy = false
    return true
end

-- 左手改挂回真枪 bone_lock
-- 仅在 state.bolt_offhand_gripping=true 时才 attach
local function reattach_left_hand_to_real_bolt(reason)
    clear_bolt_hand_parent()
    if bolt_marker_uuid == nil or bolt_attach_busy then
        return false
    end
    if state.bolt_offhand_gripping ~= true then
        return false
    end
    bolt_attach_busy = true
    state.bolt_offhand_gripping = true
    local ok = pcall(function()
        accessories.attachHandToAccessory(Handed.Left, bolt_marker_uuid, false)
    end)
    bolt_attach_busy = false
    return ok
end

local function sock_delta_cm(weapon_mesh, poseable)
    local w = reload_tools.get_socket_world_location(weapon_mesh, BOLT_BONE_NAME)
    local p = reload_tools.get_socket_world_location(poseable, BOLT_BONE_NAME)
    if w == nil or p == nil then
        return nil
    end
    local dx = (w.X or 0) - (p.X or 0)
    local dy = (w.Y or 0) - (p.Y or 0)
    local dz = (w.Z or 0) - (p.Z or 0)
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function poseable_visibility_snapshot(poseable, actor)
    local hidden = nil
    local vis = nil
    pcall(function()
        if actor ~= nil and actor.bHidden ~= nil then
            hidden = actor.bHidden
        end
    end)
    pcall(function()
        if poseable ~= nil and poseable.bVisible ~= nil then
            vis = poseable.bVisible
        elseif poseable ~= nil and poseable.IsVisible ~= nil then
            vis = poseable:IsVisible()
        end
    end)
    local addr_a, addr_m = nil, nil
    pcall(function()
        if actor ~= nil and actor.get_address ~= nil then
            addr_a = string.format("0x%X", actor:get_address())
        end
    end)
    pcall(function()
        if poseable ~= nil and poseable.get_address ~= nil then
            addr_m = string.format("0x%X", poseable:get_address())
        end
    end)
    return {
        actor_hidden = hidden,
        mesh_visible = vis,
        actor_addr = addr_a,
        mesh_addr = addr_m,
    }
end

-- 更新 PoseableMesh：对齐 shotgun update_pump_poseable_position + D4 改造（pull/push 阶段追加旋转）
local last_update_pos_trace = 0
local function update_bolt_poseable_position(weapon_mesh, progress)
    local poseable = uevrUtils.getValid(bolt_visual.poseable_mesh)
    if weapon_mesh == nil or poseable == nil then
        return
    end
    copy_weapon_world_transform(weapon_mesh, poseable)

    -- BLOCKER-1: 表演枪栓生成时已冻结锚点，用冻结值重投影
    local weapon_rest_world, axis_world
    local frozen = state.bolt_anchor_frozen
    if frozen ~= nil then
        local root_now = nil
        pcall(function()
            if weapon_mesh.K2_GetComponentToWorld ~= nil then
                root_now = weapon_mesh:K2_GetComponentToWorld()
            end
        end)
        if root_now ~= nil then
            local base_tf = nil
            pcall(function()
                if kismet_math_library ~= nil and kismet_math_library.ComposeTransforms ~= nil then
                    base_tf = kismet_math_library:ComposeTransforms(frozen.forearm_local, root_now)
                end
            end)
            if base_tf ~= nil and base_tf.Translation ~= nil then
                weapon_rest_world = {
                    X = base_tf.Translation.X or 0,
                    Y = base_tf.Translation.Y or 0,
                    Z = base_tf.Translation.Z or 0,
                }
            end
            pcall(function()
                if kismet_math_library ~= nil then
                    if kismet_math_library.TransformVector ~= nil then
                        axis_world = kismet_math_library:TransformVector(root_now, frozen.axis_local)
                    elseif kismet_math_library.TransformDirection ~= nil then
                        axis_world = kismet_math_library:TransformDirection(root_now, frozen.axis_local)
                    end
                end
            end)
        end
        if weapon_rest_world == nil or axis_world == nil then
            weapon_rest_world = reload_tools.get_socket_world_location(weapon_mesh, BOLT_BONE_NAME)
            axis_world = get_bolt_backward_axis(weapon_mesh)
        end
    else
        weapon_rest_world = reload_tools.get_socket_world_location(weapon_mesh, BOLT_BONE_NAME)
        axis_world = get_bolt_backward_axis(weapon_mesh)
    end

    local poseable_bone_world = reload_tools.get_socket_world_location(poseable, BOLT_BONE_NAME)
    if weapon_rest_world == nil or poseable_bone_world == nil or axis_world == nil then
        local now = os.clock()
        if now - last_update_pos_trace > 0.25 then
            last_update_pos_trace = now
        end
        return
    end

    local target_world = reload_tools.calc_slide_bone_offset(
        weapon_rest_world, axis_world, progress, BOLT_BONE_MAX_DISTANCE)

    local dx, dy, dz = 0, 0, 0
    if poseable.K2_AddWorldOffset ~= nil then
        dx = target_world.X - poseable_bone_world.X
        dy = target_world.Y - poseable_bone_world.Y
        dz = target_world.Z - poseable_bone_world.Z
        pcall(function()
            poseable:K2_AddWorldOffset(
                uevrUtils.vector(dx, dy, dz), false, reusable_hit_result, false)
        end)
    end

    -- D4 改造：在 pull/push 阶段每帧追加 set_bone_rotation_by_name_safe 保持旋转 77°
    local rack = state.bolt_rack
    local phase = rack and rack.phase or nil
    if phase == "pull" or phase == "push" then
        reload_tools.set_bone_rotation_by_name_safe(
            poseable, BOLT_BONE_NAME,
            BOLT_ROTATE_UP_ANGLE, BOLT_ROTATE_YAW, BOLT_ROTATE_ROLL, BOLT_ROTATE_SPACE)
    elseif phase == "rotate_up" or phase == "rotate_down" then
        -- 旋转阶段：应用当前旋转进度（由 tick_bolt_rotate_up/down 驱动，此处同步保持）
        local pitch = (rack and rack.current_pitch) or 0
        reload_tools.set_bone_rotation_by_name_safe(
            poseable, BOLT_BONE_NAME,
            pitch, BOLT_ROTATE_YAW, BOLT_ROTATE_ROLL, BOLT_ROTATE_SPACE)
    end

    local now = os.clock()
    local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist > 5.0 or (now - last_update_pos_trace) > 0.15 then
        last_update_pos_trace = now
        local w_snap = read_component_world_snapshot(weapon_mesh)
        local p_snap = read_component_world_snapshot(poseable)
    end
end

-- Spawn PoseableMesh（对齐 shotgun spawn_pump_poseable，改 bone_forearm → bone_lock）
local function spawn_bolt_poseable(weapon_mesh)
    if bolt_spawn_busy then
        return bolt_poseable_is_valid()
    end
    weapon_mesh = uevrUtils.getValid(weapon_mesh)
    if weapon_mesh == nil then
        return false
    end

    bolt_spawn_busy = true
    local ok_body, result = pcall(function()
        clear_stale_bolt_poseable_refs()
        if bolt_poseable_is_valid() then
            local progress = 0
            if state.bolt_active and state.bolt_rack ~= nil then
                progress = state.bolt_rack.pull_progress or 0
            end
            update_bolt_poseable_position(weapon_mesh, progress)
            local dist = sock_delta_cm(weapon_mesh, bolt_visual.poseable_mesh)
            if dist ~= nil and dist > 40.0 then
                pcall(function()
                    if bolt_visual.poseable_actor ~= nil then
                        uevrUtils.destroy_actor(bolt_visual.poseable_actor)
                    end
                end)
                bolt_visual.poseable_actor = nil
                bolt_visual.poseable_mesh = nil
                state.bolt_poseable_actor = nil
                state.bolt_poseable = nil
                clear_bolt_hand_parent()
            else
                if not state.bolt_bone_hidden then
                    hide_bolt_bone(weapon_mesh)
                end
                attach_left_hand_to_performance_bolt(true)
                local snap = poseable_visibility_snapshot(bolt_visual.poseable_mesh, bolt_visual.poseable_actor)
                return true
            end
        end

        local sk_asset = nil
        pcall(function() sk_asset = weapon_mesh.SkeletalMesh end)
        if sk_asset == nil or uevrUtils.getValid(sk_asset) == nil then
            print_log("spawn_bolt_poseable: SkeletalMesh asset nil", LogLevel.Warn)
            return false
        end

        local socket_loc = reload_tools.get_socket_world_location(weapon_mesh, BOLT_BONE_NAME)
        if socket_loc == nil then
            print_log("spawn_bolt_poseable: no bone_lock socket location", LogLevel.Warn)
            return false
        end
        local socket_rot = nil
        pcall(function()
            socket_rot = weapon_mesh:GetSocketRotation(uevrUtils.fname_from_string(BOLT_BONE_NAME))
        end)
        if socket_rot == nil then
            socket_rot = reload_tools.get_component_world_rotation(weapon_mesh)
        end

        local w_before = read_component_world_snapshot(weapon_mesh)

        local actor = uevrUtils.spawn_actor(
            reload_tools.make_spawn_transform(socket_loc, socket_rot), 1, nil)
        if actor == nil then
            print_log("spawn_bolt_poseable: spawn_actor failed", LogLevel.Warn)
            return false
        end

        local poseable = nil
        local ok_create = pcall(function()
            poseable = uevrUtils.createPoseableMeshFromSkeletalMesh(weapon_mesh, {
                manualAttachment = true,
                relativeTransform = reload_tools.make_spawn_transform(socket_loc, socket_rot),
                deferredFinish = false,
                parent = actor,
            })
        end)
        if not ok_create or poseable == nil or uevrUtils.getValid(poseable) == nil then
            uevrUtils.destroy_actor(actor)
            print_log("spawn_bolt_poseable: createPoseableMesh failed", LogLevel.Warn)
            return false
        end

        pcall(function()
            if poseable.SetMobility ~= nil then
                poseable:SetMobility(2)
            end
            if actor.K2_SetRootComponent ~= nil then
                actor:K2_SetRootComponent(poseable)
            end
        end)
        local copy_ok = copy_weapon_world_transform(weapon_mesh, poseable)

        pcall(function()
            uevrUtils.copyMaterials(weapon_mesh, poseable)
        end)
        align_poseable_bolt_bone(poseable, weapon_mesh, BOLT_BONE_NAME)
        show_only_bone(poseable, BOLT_BONE_NAME)
        prepare_spawned_actor_visible(actor)
        apply_poseable_render_flags(poseable)

        bolt_visual.poseable_actor = actor
        bolt_visual.poseable_mesh = poseable
        state.bolt_poseable_actor = actor
        state.bolt_poseable = poseable
        set_bolt_hand_parent(poseable)
        local hide_ok = hide_bolt_bone(weapon_mesh)
        attach_left_hand_to_performance_bolt(true)
        local snap = poseable_visibility_snapshot(poseable, actor)
        print_log("spawn_bolt_poseable: hidden poseable ready (hand attach), hid real bone_lock", LogLevel.Info)
        return true
    end)
    bolt_spawn_busy = false
    if not ok_body then
        return false
    end
    return result == true
end

-- BLOCKER-1: 表演枪栓生成时冻结锚点
local function freeze_bolt_anchor(mesh)
    if state.bolt_anchor_frozen ~= nil then
        return
    end
    if mesh == nil then
        return
    end
    local root_tf = nil
    pcall(function()
        if mesh.K2_GetComponentToWorld ~= nil then
            root_tf = mesh:K2_GetComponentToWorld()
        end
    end)
    local forearm_world = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
    local axis_world = get_bolt_backward_axis(mesh)
    if root_tf == nil or forearm_world == nil or axis_world == nil then
        return
    end
    local inv_root = nil
    pcall(function()
        if kismet_math_library ~= nil and kismet_math_library.InvertTransform ~= nil then
            inv_root = kismet_math_library:InvertTransform(root_tf)
        end
    end)
    if inv_root == nil then
        return
    end
    local forearm_tf_world = nil
    pcall(function()
        local forearm_ftrans = nil
        pcall(function()
            if kismet_math_library.MakeTransform ~= nil then
                forearm_ftrans = kismet_math_library:MakeTransform(
                    uevrUtils.vector(forearm_world.X, forearm_world.Y, forearm_world.Z),
                    uevrUtils.rotator(0, 0, 0),
                    uevrUtils.vector(1, 1, 1))
            end
        end)
        if forearm_ftrans ~= nil then
            forearm_tf_world = kismet_math_library:ComposeTransforms(forearm_ftrans, inv_root)
        end
    end)
    local axis_local = nil
    pcall(function()
        if kismet_math_library.InverseTransformVector ~= nil then
            axis_local = kismet_math_library:InverseTransformVector(root_tf,
                uevrUtils.vector(axis_world.X, axis_world.Y, axis_world.Z))
        elseif kismet_math_library.InverseTransformDirection ~= nil then
            axis_local = kismet_math_library:InverseTransformDirection(root_tf,
                uevrUtils.vector(axis_world.X, axis_world.Y, axis_world.Z))
        end
    end)
    if forearm_tf_world == nil or axis_local == nil then
        return
    end
    state.bolt_anchor_frozen = {
        forearm_local = forearm_tf_world,
        axis_local = axis_local,
    }
end

-- §16.4: needs_bolt 或 bolt_offhand_gripping 期间预生成/保持表演枪栓
local last_poseable_valid_state = nil
local function ensure_bolt_poseable_ready()
    -- §16.4 改动#2: 触发条件从 needs_bolt=true 改为 needs_bolt OR bolt_offhand_gripping
    -- 主动拉栓时 gripping=true 即可预生成表演枪栓，不再需要 needs_bolt=true
    if not (state.needs_bolt or state.bolt_offhand_gripping) then
        return false
    end
    -- [[ was_empty block DISABLED：空仓也必须能预生成表演枪栓以便拉栓上弹
    -- if state.was_empty and not state.bolt_active then
    --     return false
    -- end
    -- ]]
    if state.reload_active or state.shells_in_hand then
        return false
    end
    local mesh = select(1, get_rifle_chain())
    if mesh == nil then
        return false
    end
    clear_stale_bolt_poseable_refs()
    if not bolt_poseable_is_valid() then
        if not spawn_bolt_poseable(mesh) then
            last_poseable_valid_state = false
            return false
        end
        last_poseable_valid_state = true
    elseif last_poseable_valid_state ~= true then
        last_poseable_valid_state = true
    end
    if not state.bolt_bone_hidden then
        hide_bolt_bone(mesh)
    end
    freeze_bolt_anchor(mesh)
    if not state.bolt_active then
        update_bolt_poseable_position(mesh, 0)
    end
    return bolt_poseable_is_valid()
end

-- 清理 PoseableMesh + 恢复真枪 bone_lock 显示
local function cleanup_bolt_visual(opts)
    opts = opts or {}
    local snap = poseable_visibility_snapshot(bolt_visual.poseable_mesh, bolt_visual.poseable_actor)
    clear_bolt_hand_parent()

    local mesh, _ = get_rifle_chain()
    if mesh ~= nil and state.bolt_bone_hidden then
        show_bolt_bone(mesh)
    elseif state.bolt_bone_hidden then
        state.bolt_bone_hidden = false
    end

    if opts.skip_reattach ~= true then
        local want_left = opts.keep_left_grip == true
        if not want_left then
            local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
            want_left = state.bolt_offhand_gripping == true
                or left_grip == true
                or (type(left_grip) == "number" and left_grip > 0.5)
        end
        if want_left then
            reattach_left_hand_to_real_bolt("cleanup_before_destroy")
        end
    end

    if bolt_visual.poseable_actor ~= nil then
        pcall(function()
            bolt_visual.poseable_actor:SetHiddenInGame(true, true)
        end)
        local ok, err = pcall(function()
            uevrUtils.destroy_actor(bolt_visual.poseable_actor)
        end)
    end
    bolt_visual.poseable_actor = nil
    bolt_visual.poseable_mesh = nil
    state.bolt_poseable_actor = nil
    state.bolt_poseable = nil

    if opts.skip_reattach ~= true then
        local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
        local want_left = opts.keep_left_grip == true
            or state.bolt_offhand_gripping == true
            or left_grip == true
            or (type(left_grip) == "number" and left_grip > 0.5)
        if want_left then
            reattach_left_hand_to_real_bolt("cleanup_after_destroy")
        end
    end
end

-- =============================================================================
-- D3: 拉栓上膛（4 阶段状态机：rotate_up → pull → push → rotate_down）
-- =============================================================================

-- 左手 grip 是否按下
-- 主源：accessories.cachedGripState（XINPUT LB，与 accessories 系统同源）
-- 辅源：VREnvironment.leftGrip（OpenXR grip action，OpenXR binding 正确时也能用）
-- 任一源检测到即视为按下（OR 逻辑，防止单一信号源失效）
local function is_left_grip_pressed()
    -- 主源：与 accessories 系统同源（proximity/attach 都靠它）
    if accessories ~= nil and type(accessories.isGripDown) == "function" then
        if accessories.isGripDown(Handed.Left) then
            return true
        end
    end
    -- 辅源：VREnvironment.leftGrip（OpenXR binding 映射正确时可用）
    local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
    if left_grip == true then
        return true
    end
    return type(left_grip) == "number" and left_grip > 0.5
end

-- 拉栓完成后是否禁止再次开栓：墙钟冷却 OR 尚未松开左 grip
-- 见到 grip up 立即清闩锁；冷却未结束仍阻断。避免「握着不放」等冷却结束立刻又 rotate_up
local function bolt_regrab_blocked()
    if state.bolt_regrab_needs_release == true and not is_left_grip_pressed() then
        state.bolt_regrab_needs_release = false
    end
    local until_t = state.bolt_regrab_block_until or 0
    if until_t > 0 and os.clock() < until_t then
        return true
    end
    return state.bolt_regrab_needs_release == true
end

-- 获取左手世界坐标
local function get_left_hand_location()
    local loc = select(1, get_shell_hand_world_transform())
    if loc ~= nil then
        return loc
    end
    return reload_tools.get_left_hand_world_location()
end

-- 开始拉栓手势（由 tick_detect_bolt_grip 触发）
-- D3 核心改造：初始化 4 阶段状态机，phase = "rotate_up"
local function begin_bolt()
    if bolt_callback_locked() then
        return
    end
    if state.bolt_active then
        return  -- 已在拉栓中
    end
    if bolt_regrab_blocked() then
        state.bolt_offhand_gripping = false
        return
    end
    -- §16.4 改动#3: 移除 if not needs_bolt then return 守卫
    -- 不删除则改动#1#2 放行但 begin_bolt 仍 return，拉栓进不去状态机
    local mesh, _ = get_rifle_chain()
    if mesh == nil then
        print_log("begin_bolt: no rifle mesh", LogLevel.Warn)
        return
    end
    -- 每轮拉栓重置开栓装弹标记（complete 时据此决定是否写 idle）
    state.bolt_reloaded_this_cycle = false
    -- §16.4 改动#7+#12: 主动拉栓（needs_bolt=false）时 block PrepareAnimData
    -- 防止引擎残留的 "needs bolt" data 导致持续循环拉栓（不停抛壳）
    if not state.needs_bolt then
        state.bolt_was_active_pull = true
        -- 改动#12: block 前先调 EndNotify 清理引擎残留 Prepare 状态
        -- 重载脚本后引擎可能残留上一会话的 Prepare 状态，直接 block 时引擎在拉栓过程中
        -- 读到残留数据并循环拉栓（不停抛壳）。EndNotify 在引擎未进入 Prepare 状态时调用无害
        call_on_ranged_single_action_prepare_end("active_bolt_begin_clear_residual")
        block_prepare_anim_data("active_bolt_begin")
    else
        state.bolt_was_active_pull = false
    end
    -- 每次拉栓开始重置 bolt_axis 一次性打印 flag，使每次拉栓都能打印一次最新枪体向量
    bolt_axis_diag_printed = false
    bolt_begin_busy = true
    local ok_run, err_run = pcall(function()
        if not spawn_bolt_poseable(mesh) then
            print_log("begin_bolt: spawn_bolt_poseable failed, continue without visual isolation", LogLevel.Warn)
        end
        freeze_bolt_anchor(mesh)
        local lh_pos = get_left_hand_location()
        if lh_pos == nil then
            print_log("begin_bolt: no left hand position", LogLevel.Warn)
            return
        end
        local rack = state.bolt_rack
        rack.active = true
        rack.start_pos = { X = lh_pos.X, Y = lh_pos.Y, Z = lh_pos.Z }
        rack.backward_axis = get_bolt_backward_axis(mesh)
        rack.signed_pull = 0
        rack.pull_max = 0
        rack.pull_done = false
        rack.pull_progress = 0
        rack.returning = false
        -- D3：4 阶段状态机，上拉由左手沿 Up 轴投影驱动
        rack.phase = "rotate_up"
        rack.rotate_axis = get_bolt_rotate_axis(mesh, false)
        rack.signed_rotate = 0
        rack.rotate_max = 0
        rack.rotate_up_done = false
        rack.rotate_progress = 0
        rack.current_pitch = 0
        rack.rotate_base = 0
        rack.pull_base = 0
        -- 运动补偿：捕获 rotate_up 阶段的锚定标量 (lh - socket) · rotate_axis
        -- nil 时 tick_bolt_rotate_up 走旧 world-space fallback
        local socket_loc_begin = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
        rack.start_anchor_dist = reload_tools.capture_slide_anchor(lh_pos, socket_loc_begin, rack.rotate_axis)
        state.bolt_active = true
        -- 音效：bolt_rotate_up
        local seg = M.get_audio_segment("bolt_rotate_up")
        audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
        print_log("bolt begin (4-phase: rotate_up→pull→push→rotate_down, poseable="
            .. tostring(bolt_poseable_is_valid()) .. ")", LogLevel.Info)
    end)
    bolt_begin_busy = false
    if not ok_run then
        print_log("begin_bolt: PCALL FAIL err=" .. tostring(err_run), LogLevel.Warn)
    end
end

-- tick_bolt_rotate_up：旋转↑阶段（Pitch 0→77°）— 左手沿枪体 Up 投影驱动
local function tick_bolt_rotate_up(cached_mesh)
    local rack = state.bolt_rack
    local mesh = cached_mesh or select(1, get_rifle_chain())
    if mesh == nil then
        cancel_bolt("no_mesh")
        return
    end

    -- 左手未握枪栓时：冻结在当前旋转进度
    if not state.bolt_offhand_gripping then
        if bolt_poseable_is_valid() then
            update_bolt_poseable_position(mesh, 0)
        end
        return
    end

    local lh_pos = get_left_hand_location()
    if lh_pos == nil then
        pause_bolt("no_left_pos")
        return
    end

    rack.rotate_axis = get_bolt_rotate_axis(mesh, false)
    -- 运动补偿：优先用锚定算法 (lh-socket)·axis 之差，玩家走动/转身时投影不变
    -- start_anchor_dist/socket_loc 为 nil 时 calc_slide_rotate_anchored 走旧 world-space fallback
    local socket_loc = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
    local signed_rotate_raw, rotate_progress_raw = reload_tools.calc_slide_rotate_anchored(
        lh_pos, socket_loc, rack.rotate_axis, rack.start_anchor_dist, BOLT_ROTATE_THRESHOLD, rack.start_pos
    )

    -- 断点续拉：累加基准偏移（pause→resume 时已累积的进度）
    local rotate_base = rack.rotate_base or 0
    local signed_rotate = signed_rotate_raw + rotate_base
    -- 总进度：(base + 本段投影) / threshold
    local rotate_progress = (signed_rotate_raw + rotate_base) / BOLT_ROTATE_THRESHOLD

    if rotate_progress > 1.0 then rotate_progress = 1.0 end
    if signed_rotate > BOLT_ROTATE_THRESHOLD then signed_rotate = BOLT_ROTATE_THRESHOLD end
    if rotate_progress < 0 then rotate_progress = 0 end

    -- 方向锁定（只增不减，防抖动回弹）
    if not rack.rotate_up_done then
        if signed_rotate > (rack.signed_rotate or 0) then
            rack.signed_rotate = signed_rotate
        end
        if rotate_progress > (rack.rotate_progress or 0) then
            rack.rotate_progress = rotate_progress
        end
        if signed_rotate > (rack.rotate_max or 0) then
            rack.rotate_max = signed_rotate
        end
    end

    local locked_progress = rack.rotate_progress or 0
    local pitch = reload_tools.calc_rotation_lerp(locked_progress, 0, BOLT_ROTATE_UP_ANGLE, "linear")
    rack.current_pitch = pitch

    if bolt_poseable_is_valid() then
        update_bolt_poseable_position(mesh, 0)
    end

    if not rack.rotate_up_done
        and (reload_tools.is_rotate_up_done(rack.signed_rotate, BOLT_ROTATE_THRESHOLD)
            or reload_tools.is_angle_reached(pitch, BOLT_ROTATE_UP_ANGLE, BOLT_ROTATE_TOLERANCE)) then
        rack.rotate_up_done = true
        rack.current_pitch = BOLT_ROTATE_UP_ANGLE
        rack.rotate_progress = 1.0
        rack.rotate_base = 0
        trigger_reload_haptic("bolt_rotate_up")
        rack.phase = "pull"
        rack.pull_done = false
        rack.signed_pull = 0
        rack.pull_progress = 0
        rack.pull_base = 0
        -- 重新捕获左手位置作为 pull 起点
        lh_pos = get_left_hand_location()
        if lh_pos ~= nil then
            rack.start_pos = { X = lh_pos.X, Y = lh_pos.Y, Z = lh_pos.Z }
            -- 运动补偿：重捕 pull 阶段的锚定标量
            -- 先刷新 backward_axis 与 tick_bolt_pull 一致（rotate_up 期间未刷新，可能过时）
            rack.backward_axis = get_bolt_backward_axis(mesh)
            local socket_loc_pull = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
            rack.start_anchor_dist = reload_tools.capture_slide_anchor(lh_pos, socket_loc_pull, rack.backward_axis)
        end
        local seg = M.get_audio_segment("bolt_pull")
        audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
        print_log("bolt rotate_up done → pull phase (pitch=" .. tostring(BOLT_ROTATE_UP_ANGLE)
            .. " lift=" .. string.format("%.1f", rack.rotate_max or 0) .. "cm)", LogLevel.Info)
    end
end

-- tick_bolt_pull：后拉阶段（复用 calc_slide_pull_anchored + is_pull_done，每帧保持 77° 旋转）
local function tick_bolt_pull(cached_mesh)
    local rack = state.bolt_rack
    local mesh = cached_mesh or select(1, get_rifle_chain())
    if mesh == nil then
        cancel_bolt("no_mesh")
        return
    end

    -- 每帧保持旋转 77°（D4 改造：pull/push 阶段追加 set_bone_rotation_by_name_safe）
    local poseable = uevrUtils.getValid(bolt_visual.poseable_mesh)
    if poseable ~= nil then
        reload_tools.set_bone_rotation_by_name_safe(
            poseable, BOLT_BONE_NAME,
            BOLT_ROTATE_UP_ANGLE, BOLT_ROTATE_YAW, BOLT_ROTATE_ROLL, BOLT_ROTATE_SPACE)
    end

    -- 左手未握枪栓时：跳过位置更新，枪栓冻结在最后位置
    if not state.bolt_offhand_gripping then
        if bolt_poseable_is_valid() then
            update_bolt_poseable_position(mesh, rack.pull_progress)
        end
        return
    end

    local lh_pos = get_left_hand_location()
    if lh_pos == nil then
        pause_bolt("no_left_pos")
        return
    end

    -- 后拉轴每帧随枪更新（BLOCKER-1: 冻结锚点）
    if state.bolt_anchor_frozen ~= nil then
        local frozen_axis = nil
        local root_now = nil
        pcall(function()
            if mesh.K2_GetComponentToWorld ~= nil then
                root_now = mesh:K2_GetComponentToWorld()
            end
        end)
        if root_now ~= nil then
            pcall(function()
                if kismet_math_library ~= nil then
                    if kismet_math_library.TransformVector ~= nil then
                        frozen_axis = kismet_math_library:TransformVector(root_now, state.bolt_anchor_frozen.axis_local)
                    elseif kismet_math_library.TransformDirection ~= nil then
                        frozen_axis = kismet_math_library:TransformDirection(root_now, state.bolt_anchor_frozen.axis_local)
                    end
                end
            end)
        end
        if frozen_axis ~= nil then
            rack.backward_axis = { X = frozen_axis.X or 0, Y = frozen_axis.Y or 0, Z = frozen_axis.Z or 0 }
        else
            rack.backward_axis = get_bolt_backward_axis(mesh)
        end
    else
        rack.backward_axis = get_bolt_backward_axis(mesh)
    end

    -- 运动补偿：优先用锚定算法 (lh-socket)·axis 之差，玩家走动/转身时投影不变
    local socket_loc = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
    local signed_pull_raw, pull_progress_raw = reload_tools.calc_slide_pull_anchored(
        lh_pos, socket_loc, rack.backward_axis, rack.start_anchor_dist, BOLT_PULL_THRESHOLD, rack.start_pos
    )

    -- 断点续拉：累加基准偏移
    local pull_base = rack.pull_base or 0
    local signed_pull = signed_pull_raw + pull_base
    local pull_progress = (signed_pull_raw + pull_base) / BOLT_PULL_THRESHOLD

    -- 钳制
    if pull_progress > 1.0 then pull_progress = 1.0 end
    if signed_pull > BOLT_PULL_THRESHOLD then signed_pull = BOLT_PULL_THRESHOLD end
    if pull_progress < 0 then pull_progress = 0 end

    -- 方向锁定（只增不减，防止抖动）
    if not rack.pull_done then
        if signed_pull > rack.signed_pull then
            rack.signed_pull = signed_pull
        end
        if pull_progress > rack.pull_progress then
            rack.pull_progress = pull_progress
        end
        if signed_pull > rack.pull_max then
            rack.pull_max = signed_pull
        end
    end

    local locked_signed_pull = rack.signed_pull
    local locked_progress = rack.pull_progress

    -- 更新 PoseableMesh 枪栓位置
    update_bolt_poseable_position(mesh, locked_progress)

    -- 表演件存在时隐藏真枪枪栓
    if bolt_visual.poseable_mesh ~= nil and not state.bolt_bone_hidden then
        hide_bolt_bone(mesh)
    end

    -- 后拉到位判定（仅首次）→ 切到 push 阶段
    if not rack.pull_done and reload_tools.is_pull_done(locked_signed_pull, BOLT_PULL_THRESHOLD) then
        rack.pull_done = true
        rack.phase = "push"
        rack.pull_base = 0
        -- 还原 PrepareAnimData → 触发原生动画（含抛壳）
        -- §16.4 改动#8: 主动拉栓（bolt_was_active_pull=true）时跳过 restore
        -- 主动拉栓无需触发抛壳（未开火/未发射弹）；开火拉栓仍 restore 触发抛壳
        if state.bolt_was_active_pull then
            print_log("bolt pull done: active pull, skip restore_prepare_anim_data (no eject)", LogLevel.Info)
        else
            restore_prepare_anim_data("pull_done_eject", false)
        end
        -- 音效：bolt_pull 到位（bolt_back 段）
        local seg = M.get_audio_segment("bolt_pull")
        audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
        trigger_reload_haptic("bolt_pull")
        print_log("bolt pull done (max=" .. string.format("%.1f", rack.pull_max) .. "cm) → push phase", LogLevel.Info)
    end
end

-- tick_bolt_push：前推阶段（复用 is_push_done + calc_slide_bone_offset，每帧保持 77° 旋转）
local function tick_bolt_push(cached_mesh)
    local rack = state.bolt_rack
    local mesh = cached_mesh or select(1, get_rifle_chain())
    if mesh == nil then
        cancel_bolt("no_mesh")
        return
    end

    -- 每帧保持旋转 77°
    local poseable = uevrUtils.getValid(bolt_visual.poseable_mesh)
    if poseable ~= nil then
        reload_tools.set_bone_rotation_by_name_safe(
            poseable, BOLT_BONE_NAME,
            BOLT_ROTATE_UP_ANGLE, BOLT_ROTATE_YAW, BOLT_ROTATE_ROLL, BOLT_ROTATE_SPACE)
    end

    -- 左手未握枪栓时：冻结
    if not state.bolt_offhand_gripping then
        if bolt_poseable_is_valid() then
            update_bolt_poseable_position(mesh, rack.pull_progress)
        end
        return
    end

    local lh_pos = get_left_hand_location()
    if lh_pos == nil then
        pause_bolt("no_left_pos")
        return
    end

    -- 后拉轴每帧随枪更新
    if state.bolt_anchor_frozen ~= nil then
        local frozen_axis = nil
        local root_now = nil
        pcall(function()
            if mesh.K2_GetComponentToWorld ~= nil then
                root_now = mesh:K2_GetComponentToWorld()
            end
        end)
        if root_now ~= nil then
            pcall(function()
                if kismet_math_library ~= nil then
                    if kismet_math_library.TransformVector ~= nil then
                        frozen_axis = kismet_math_library:TransformVector(root_now, state.bolt_anchor_frozen.axis_local)
                    elseif kismet_math_library.TransformDirection ~= nil then
                        frozen_axis = kismet_math_library:TransformDirection(root_now, state.bolt_anchor_frozen.axis_local)
                    end
                end
            end)
        end
        if frozen_axis ~= nil then
            rack.backward_axis = { X = frozen_axis.X or 0, Y = frozen_axis.Y or 0, Z = frozen_axis.Z or 0 }
        else
            rack.backward_axis = get_bolt_backward_axis(mesh)
        end
    else
        rack.backward_axis = get_bolt_backward_axis(mesh)
    end

    -- 运动补偿：优先用锚定算法 (lh-socket)·axis 之差，玩家走动/转身时投影不变
    local socket_loc = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
    local signed_pull_raw, pull_progress_raw = reload_tools.calc_slide_pull_anchored(
        lh_pos, socket_loc, rack.backward_axis, rack.start_anchor_dist, BOLT_PULL_THRESHOLD, rack.start_pos
    )

    -- 断点续拉：累加基准偏移
    local pull_base = rack.pull_base or 0
    local signed_pull = signed_pull_raw + pull_base
    local pull_progress = (signed_pull_raw + pull_base) / BOLT_PULL_THRESHOLD

    -- 钳制
    if pull_progress > 1.0 then pull_progress = 1.0 end
    if signed_pull > BOLT_PULL_THRESHOLD then signed_pull = BOLT_PULL_THRESHOLD end
    if pull_progress < 0 then pull_progress = 0 end

    -- 方向锁定（后拉到位后：只减不增）
    if signed_pull < rack.signed_pull then
        rack.signed_pull = signed_pull
    end
    if pull_progress < rack.pull_progress then
        rack.pull_progress = pull_progress
    end

    local locked_signed_pull = rack.signed_pull
    local locked_progress = rack.pull_progress

    -- 更新 PoseableMesh 枪栓位置
    update_bolt_poseable_position(mesh, locked_progress)

    -- 前推到位判定 → 切到 rotate_down 阶段（重新捕获起点 + 取反 Up 轴）
    if reload_tools.is_push_done(BOLT_PULL_THRESHOLD, locked_signed_pull, BOLT_PUSH_DONE_DIST) then
        rack.phase = "rotate_down"
        rack.signed_rotate = 0
        rack.rotate_max = 0
        rack.rotate_progress = 0
        rack.rotate_base = 0
        rack.pull_base = 0
        rack.rotate_axis = get_bolt_rotate_axis(mesh, true)
        local lh_down = get_left_hand_location()
        if lh_down ~= nil then
            rack.start_pos = { X = lh_down.X, Y = lh_down.Y, Z = lh_down.Z }
            -- 运动补偿：重捕 rotate_down 阶段的锚定标量（用取反后的 rotate_axis）
            local socket_loc_down = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
            rack.start_anchor_dist = reload_tools.capture_slide_anchor(lh_down, socket_loc_down, rack.rotate_axis)
        end
        -- 音效：bolt_push 到位
        local seg = M.get_audio_segment("bolt_push")
        audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
        trigger_reload_haptic("bolt_push")
        print_log("bolt push done → rotate_down phase", LogLevel.Info)
    end
end

-- tick_bolt_rotate_down：旋转↓阶段（Pitch 77°→0°）— 左手沿 -Up 投影驱动
local function tick_bolt_rotate_down(cached_mesh)
    local rack = state.bolt_rack
    local mesh = cached_mesh or select(1, get_rifle_chain())
    if mesh == nil then
        cancel_bolt("no_mesh")
        return
    end

    -- 左手未握枪栓时：冻结在当前旋转进度
    if not state.bolt_offhand_gripping then
        if bolt_poseable_is_valid() then
            update_bolt_poseable_position(mesh, 0)
        end
        return
    end

    local lh_pos = get_left_hand_location()
    if lh_pos == nil then
        pause_bolt("no_left_pos")
        return
    end

    -- 下压：相对本阶段起点沿 -Up 投影（满程后 progress→1，pitch→0）
    rack.rotate_axis = get_bolt_rotate_axis(mesh, true)
    -- 运动补偿：优先用锚定算法 (lh-socket)·axis 之差，玩家走动/转身时投影不变
    local socket_loc = reload_tools.get_socket_world_location(mesh, BOLT_BONE_NAME)
    local signed_rotate_raw, rotate_progress_raw = reload_tools.calc_slide_rotate_anchored(
        lh_pos, socket_loc, rack.rotate_axis, rack.start_anchor_dist, BOLT_ROTATE_DOWN_DIST, rack.start_pos
    )

    -- 断点续拉：累加基准偏移
    local rotate_base = rack.rotate_base or 0
    local signed_rotate = signed_rotate_raw + rotate_base
    local rotate_progress = (signed_rotate_raw + rotate_base) / BOLT_ROTATE_DOWN_DIST

    if rotate_progress > 1.0 then rotate_progress = 1.0 end
    if signed_rotate > BOLT_ROTATE_DOWN_DIST then signed_rotate = BOLT_ROTATE_DOWN_DIST end
    if rotate_progress < 0 then rotate_progress = 0 end

    -- 方向锁定（只增不减）
    if signed_rotate > (rack.signed_rotate or 0) then
        rack.signed_rotate = signed_rotate
    end
    if rotate_progress > (rack.rotate_progress or 0) then
        rack.rotate_progress = rotate_progress
    end
    if signed_rotate > (rack.rotate_max or 0) then
        rack.rotate_max = signed_rotate
    end

    local locked_progress = rack.rotate_progress or 0
    local pitch = reload_tools.calc_rotation_lerp(locked_progress, BOLT_ROTATE_UP_ANGLE, 0, "linear")
    rack.current_pitch = pitch

    if bolt_poseable_is_valid() then
        update_bolt_poseable_position(mesh, 0)
    end

    if reload_tools.is_rotate_up_done(rack.signed_rotate, BOLT_ROTATE_DOWN_DIST)
        or reload_tools.is_angle_reached(pitch, 0, BOLT_ROTATE_TOLERANCE) then
        rack.current_pitch = 0
        rack.rotate_progress = 1.0
        trigger_reload_haptic("bolt_rotate_down")
        local seg = M.get_audio_segment("bolt_rotate_down")
        audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
        print_log("bolt rotate_down done → complete_bolt (down="
            .. string.format("%.1f", rack.rotate_max or 0) .. "cm)", LogLevel.Info)
        complete_bolt()
    end
end

-- complete_bolt：完成拉栓 → needs_bolt=false + 引擎同步 + 音效/触觉
-- PrepareAnimData 收尾分三类（同霰弹枪：保留 Lua backup 供下发 block 复用，勿清 backup）：
--   1) 本轮 clip+1（开栓装弹）→ write_idle 阻止引擎自动拉栓
--   2) 主动拉栓未装弹 → restore 拉栓前备份（pull_done 已 skip）
--   3) 开火拉栓 → pull_done 已 restore 真实抛壳数据，此处不写 idle
function complete_bolt()
    local rack = state.bolt_rack
    local was_active_pull = state.bolt_was_active_pull == true
    local reloaded_this_cycle = state.bolt_reloaded_this_cycle == true
    rack.active = false
    state.bolt_active = false
    state.needs_bolt = false
    state.bolt_completed_this_cycle = true
    state.bolt_anchor_frozen = nil
    state.was_empty = false
    state.post_bolt_keep_left_frames = 0
    -- 强制 detach + 墙钟冷却 + 松手闩锁（防下压完成瞬间又 begin→rotate_up）
    state.bolt_detach_cooldown = 0
    state.bolt_regrab_block_until = os.clock() + BOLT_REGRAB_COOLDOWN_SEC
    state.bolt_regrab_needs_release = true
    state.bolt_offhand_gripping = false
    state.bolt_was_active_pull = false
    state.bolt_reloaded_this_cycle = false

    local restored = not state.prepare_anim_data_nulled
    local prep_action = "leave"

    -- 先把手挂回真枪枪栓，再触发原生动画
    clear_bolt_hand_parent()
    local mesh_pre, _ = get_rifle_chain()
    if mesh_pre ~= nil and state.bolt_bone_hidden then
        show_bolt_bone(mesh_pre)
    end

    -- §16.4 改动#13: 引擎同步改用公共函数（无条件调用，回退为原样）
    call_on_ranged_single_action_prepare_end("complete_bolt")

    if reloaded_this_cycle then
        -- 开栓装弹：写 idle 挡引擎自动拉栓；保留 backup（勿用 idle 污染下发捕获）
        write_idle_prepare_anim_data("complete_bolt_after_reload")
        prep_action = "write_idle"
    elseif was_active_pull then
        -- 主动拉栓未装弹：pull_done 跳过了 restore，此处还原拉栓前数据（保留 backup）
        restore_prepare_anim_data("complete_active_pull_no_reload", false)
        prep_action = "restore_active"
        restored = true
    else
        -- 开火拉栓：pull_done 已 restore 真实数据；不写 idle，保留 backup 供下发复用
        prep_action = "leave_restored"
    end

    -- 音效：bolt_rotate_down（已在 tick_bolt_rotate_down 播放，此处不重复）

    -- 触觉
    trigger_reload_haptic("bolt_complete")

    -- 销毁表演件
    cleanup_bolt_visual({ keep_left_grip = true, skip_reattach = true })
    -- 强制 detach 左手（不挂回真枪 bolt_marker，让玩家重新手动靠近 holder 才吸附）
    pcall(function()
        accessories.attachHandToAccessory(Handed.Left, nil, false)
    end)

    print_log("bolt complete → needs_bolt=false prep=" .. prep_action
        .. " restored=" .. tostring(restored)
        .. " keep_backup=" .. tostring(state.prepare_anim_data_backup ~= nil)
        .. " IsFireReady=allow (left hand detached + "
        .. string.format("%.1fs", BOLT_REGRAB_COOLDOWN_SEC)
        .. " cooldown + grip-release latch)", LogLevel.Info)
end

-- 取消拉栓（武器切换/mesh丢失/装弹冲突等异常场景）
function cancel_bolt(reason)
    local rack = state.bolt_rack
    if reason == "accessory_detach" or reason == "no_left_pos" then
        print_log("cancel_bolt WARNING: reason=" .. tostring(reason)
            .. " should use pause_bolt, not cancel_bolt. This indicates a code path issue.",
            LogLevel.Warn)
    end
    rack.active = false
    state.bolt_active = false
    state.bolt_anchor_frozen = nil
    -- §16.4 改动#10: 主动拉栓被取消时，restore PrepareAnimData（防陈旧 backup）+ 重置标记
    if state.bolt_was_active_pull then
        restore_prepare_anim_data("cancel_active_pull", true)
        state.bolt_was_active_pull = false
    end
    state.bolt_reloaded_this_cycle = false
    cleanup_bolt_visual()
    print_log("bolt cancelled: " .. tostring(reason), LogLevel.Info)
end

--- 暂停拉栓（松手/左手位置丢失）：保持 bolt_active=true，枪栓冻结在当前位置
function pause_bolt(reason)
    state.bolt_offhand_gripping = false
    print_log("bolt paused (" .. tostring(reason) .. "), lock frozen at progress="
        .. string.format("%.2f", state.bolt_rack.pull_progress)
        .. " phase=" .. tostring(state.bolt_rack.phase), LogLevel.Info)
end

-- 每帧驱动拉栓后左手粘住逻辑 + 发布 regrab 阻断 flag（供 grip_block）
local function tick_post_bolt_keep_left()
    -- 兼容旧帧冷却字段（热重载残留）；主路径用墙钟+闩锁
    local cd = state.bolt_detach_cooldown or 0
    if cd > 0 then
        state.bolt_detach_cooldown = cd - 1
    end
    if bolt_regrab_blocked() or cd > 0 then
        rawset(_G, KEYS.rifle_bolt_detach_cooldown or "g_rifle_bolt_detach_cooldown", true)
    else
        rawset(_G, KEYS.rifle_bolt_detach_cooldown or "g_rifle_bolt_detach_cooldown", false)
    end

    local frames = state.post_bolt_keep_left_frames or 0
    if frames <= 0 then
        return
    end
    state.post_bolt_keep_left_frames = frames - 1
    if frames % 4 == 0 then
        local left_grip = rawget(_G, "VREnvironment") and _G.VREnvironment.leftGrip
        local gripping = state.bolt_offhand_gripping == true
            or left_grip == true
            or (type(left_grip) == "number" and left_grip > 0.5)
        if gripping then
            reattach_left_hand_to_real_bolt("post_complete_tick")
        end
    end
end

-- tick 检测左手是否吸附到表演枪栓（替代被删除的 on_accessory_animation hook）
-- 拉栓前：查询 accessory 系统 proximity 决定的 active left accessory
--        若 == bolt_perf_marker_uuid 且左手 grip 按下 → 置 bolt_offhand_gripping 触发 begin_bolt
-- 拉栓中：左手 grip 松开 → pause_bolt（冻结在当前进度，可重新握住继续）
-- 性能：表演枪栓未生成时不查询；拉栓前 active_left_accessory 每 20 帧问一次
local BOLT_GRIP_QUERY_INTERVAL = 20
local bolt_grip_query_frame = 0

local function tick_detect_bolt_grip()
    if bolt_perf_marker_uuid == nil then
        return
    end
    -- 装弹中不检测拉栓吸附
    if state.reload_active or state.shells_in_hand then
        return
    end
    -- §16.4 改动#6: 移除 poseable 早期 return（鸡生蛋：gripping 需 proximity 检测，
    -- 但 proximity 检测需 poseable 存在，poseable 需 gripping=true 才生成）
    -- bolt_perf_marker_uuid 注册在真枪 mesh 的 bone_lock socket，proximity 检测不依赖 poseable 存在
    -- 仅在 poseable 有效时才 set_bolt_hand_parent
    if bolt_poseable_is_valid() then
        -- 开栓全程保持 hand_parent → proximity/attach 的 bone_lock 始终指向表演件
        set_bolt_hand_parent(uevrUtils.getValid(bolt_visual.poseable_mesh))
    end

    if not state.bolt_active then
        -- 拉栓完成保护期内禁止再握（即使 proximity 仍命中 pull_lock）
        if bolt_regrab_blocked() then
            state.bolt_offhand_gripping = false
            return
        end
        -- 拉栓前：active_left_accessory 此时不会被本模块 claim（bolt_offhand_gripping=false），
        -- 查询结果仅由 accessory 系统 proximity 决定，无反馈循环
        -- 每 BOLT_GRIP_QUERY_INTERVAL 帧才执行一次（避免每帧扫全部 callback）
        bolt_grip_query_frame = bolt_grip_query_frame + 1
        if bolt_grip_query_frame < BOLT_GRIP_QUERY_INTERVAL then
            return
        end
        bolt_grip_query_frame = 0
        local active_left = uevrUtils.executeUEVRCallbacksWithPriorityResult("active_left_accessory")
        local grip_pressed = is_left_grip_pressed()
        local match = active_left == bolt_perf_marker_uuid
        if match and grip_pressed then
            state.bolt_offhand_gripping = true
        else
            state.bolt_offhand_gripping = false
        end
    else
        -- 拉栓中（含暂停开栓装弹后回来）：
        -- 松 grip → pause；再握必须 proximity 命中表演枪栓，不能「任意左 grip」就 gripping
        -- （旧逻辑任意 grip→gripping→claim，再叠 hand_parent 被清 → 吸附到真枪 bone_lock）
        local sticky = (state.post_bolt_keep_left_frames or 0) > 0
        local grip_pressed = is_left_grip_pressed()
        if not grip_pressed then
            bolt_grip_query_frame = 0
            if state.bolt_offhand_gripping and not sticky and not bolt_callback_locked() then
                pause_bolt("left_grip_released")
            end
            return
        end
        if state.bolt_offhand_gripping or sticky then
            return
        end
        -- 暂停后重新握住：靠 proximity 命中表演枪栓
        bolt_grip_query_frame = bolt_grip_query_frame + 1
        if bolt_grip_query_frame < BOLT_GRIP_QUERY_INTERVAL then
            return
        end
        bolt_grip_query_frame = 0
        local active_left = uevrUtils.executeUEVRCallbacksWithPriorityResult("active_left_accessory")
        if active_left == bolt_perf_marker_uuid then
            state.bolt_offhand_gripping = true
            attach_left_hand_to_performance_bolt(true)
            -- 断点续拉：重捕 start_pos + 保存已累积进度为 base 偏移
            local resume_pos = get_left_hand_location()
            if resume_pos ~= nil and state.bolt_rack ~= nil then
                local rack = state.bolt_rack
                local phase = rack.phase or "rotate_up"
                if phase == "rotate_up" or phase == "rotate_down" then
                    rack.rotate_base = rack.signed_rotate or 0
                    rack.signed_rotate = 0
                    rack.rotate_progress = 0
                elseif phase == "pull" or phase == "push" then
                    rack.pull_base = rack.signed_pull or 0
                    rack.signed_pull = 0
                    rack.pull_progress = 0
                end
                rack.start_pos = { X = resume_pos.X, Y = resume_pos.Y, Z = resume_pos.Z }
                -- 运动补偿：重捕锚定标量（根据当前阶段刷新 axis 后捕获，避免暂停期间 axis 过时）
                local mesh_resume = select(1, get_rifle_chain())
                if mesh_resume ~= nil then
                    local socket_loc_resume = reload_tools.get_socket_world_location(mesh_resume, BOLT_BONE_NAME)
                    local axis_resume
                    if phase == "rotate_up" or phase == "rotate_down" then
                        axis_resume = get_bolt_rotate_axis(mesh_resume, phase == "rotate_down")
                        rack.rotate_axis = axis_resume
                    else
                        axis_resume = get_bolt_backward_axis(mesh_resume)
                        rack.backward_axis = axis_resume
                    end
                    rack.start_anchor_dist = reload_tools.capture_slide_anchor(resume_pos, socket_loc_resume, axis_resume)
                end
                print_log("bolt resume: start_pos recaptured, "
                    .. tostring(phase) .. " base=" .. string.format("%.2f", rack.rotate_base or rack.pull_base or 0)
                    .. " phase=" .. tostring(phase), LogLevel.Info)
            end
        end
    end
end

-- tick_bolt：4 阶段 dispatch
local function tick_bolt(cached_mesh)
    tick_post_bolt_keep_left()
    -- §16.4 改动#1: 移除 not needs_bolt early return，每帧都走到 tick_detect_bolt_grip
    -- needs_bolt 只控制 slide_locked + 开火后引擎同步，不控制 begin_bolt 是否允许
    -- 表演枪栓生命周期由 proximity 检测 + gripping 驱动，pause 时保留（不 cleanup）

    -- 装弹中：枪栓冻结在拉开位置（不 cancel），左手已脱开去持弹；装完后再握栓继续前推/旋转↓
    if state.reload_active or state.shells_in_hand then
        if state.bolt_offhand_gripping then
            state.bolt_offhand_gripping = false
        end
        -- bolt_active 保持 true（spawn 时已 pause）；此处只跟枪同步视觉，勿每帧 pause 刷日志
        -- 持弹期间仍保持 hand_parent，避免装完瞬间 proximity 落到真枪 bone_lock
        if bolt_poseable_is_valid() then
            set_bolt_hand_parent(uevrUtils.getValid(bolt_visual.poseable_mesh))
            local mesh_sync = cached_mesh or select(1, get_rifle_chain())
            if mesh_sync ~= nil then
                update_bolt_poseable_position(mesh_sync, state.bolt_rack and state.bolt_rack.pull_progress or 0)
            end
        end
        publish_bolt_busy_flags()
        return
    end

    -- grip 前预生成 + 跟枪同步
    ensure_bolt_poseable_ready()

    -- tick 检测左手吸附状态（替代 on_accessory_animation hook）
    tick_detect_bolt_grip()

    if not state.bolt_active then
        if state.bolt_offhand_gripping then
            begin_bolt()
        end
        publish_bolt_busy_flags()
        return
    end

    -- 4 阶段 dispatch
    local rack = state.bolt_rack
    local phase = rack.phase or "rotate_up"
    if phase == "rotate_up" then
        tick_bolt_rotate_up(cached_mesh)
    elseif phase == "pull" then
        tick_bolt_pull(cached_mesh)
    elseif phase == "push" then
        tick_bolt_push(cached_mesh)
    elseif phase == "rotate_down" then
        tick_bolt_rotate_down(cached_mesh)
    else
        -- 异常 phase：重置到 rotate_up
        print_log("tick_bolt: unknown phase=" .. tostring(phase) .. ", reset to rotate_up", LogLevel.Warn)
        rack.phase = "rotate_up"
        rack.signed_rotate = 0
        rack.rotate_progress = 0
        rack.rotate_up_done = false
        rack.current_pitch = 0
    end
    publish_bolt_busy_flags()
end

-- =============================================================================
-- D5: 弹壳生成/掉落/滑入
-- =============================================================================

-- 生成单发弹壳模型到左手
local function spawn_single_shell(weapon_mesh, spawn_loc, spawn_rot, identity_xf, shell_index)
    local actor = uevrUtils.spawn_actor(
        reload_tools.make_spawn_transform(spawn_loc, spawn_rot), 1, nil)
    if actor == nil then
        set_spawn_fail("spawn_actor_" .. tostring(shell_index), "uevrUtils.spawn_actor returned nil")
        return nil, nil
    end

    -- 用 PoseableMesh 替换 StaticMeshComponent（完整子弹 = bone_bullet + bone_shell 拼合）
    -- 原理：复制武器 SkeletalMesh → 隔离 bone_bullet/bone_shell → 拼成完整子弹
    local comp = nil
    local ok_create = pcall(function()
        comp = uevrUtils.createPoseableMeshFromSkeletalMesh(weapon_mesh, {
            manualAttachment = true,
            relativeTransform = identity_xf,
            deferredFinish = false,
            parent = actor,
        })
    end)
    if not ok_create or comp == nil then
        uevrUtils.destroy_actor(actor)
        set_spawn_fail("comp" .. tostring(shell_index), "createPoseableMeshFromSkeletalMesh failed")
        return nil, nil
    end

    -- 复制世界变换 + 材质（让 PoseableMesh 与武器当前姿态对齐）
    pcall(function() reload_tools.copy_component_world_transform(weapon_mesh, comp) end)
    pcall(function() uevrUtils.copyMaterials(weapon_mesh, comp) end)

    -- 骨骼隔离：祖先骨骼缩到 0.01，bone_bullet=scale_bullet，bone_shell=1.0（ComponentSpace）
    local bone_space_cs = reload_tools.bone_space_component()  -- ComponentSpace
    local scale_hidden = uevrUtils.vector(0.01, 0.01, 0.01)
    local scale_bullet = uevrUtils.vector(0.011, 0.011, 0.011)  -- bone_bullet ComponentSpace scale
    local scale_shell  = uevrUtils.vector(1.0, 1.0, 1.0)
    local bone_fname_bullet = uevrUtils.fname_from_string("bone_bullet")
    local bone_fname_shell  = uevrUtils.fname_from_string("bone_shell")
    local bone_count = -1
    pcall(function() bone_count = comp:GetNumBones() end)
    if bone_count > 0 and comp.SetBoneScaleByName ~= nil then
        pcall(function()
            -- 缩全部祖先骨骼到 0.01
            for i = 0, bone_count - 1 do
                comp:SetBoneScaleByName(comp:GetBoneName(i), scale_hidden, bone_space_cs)
            end
            -- 恢复 bone_bullet=0.011（弹头）
            if bone_fname_bullet ~= nil then
                comp:SetBoneScaleByName(bone_fname_bullet, scale_bullet, bone_space_cs)
            end
            -- 恢复 bone_shell=1.0（弹壳）
            if bone_fname_shell ~= nil then
                comp:SetBoneScaleByName(bone_fname_shell, scale_shell, bone_space_cs)
            end
        end)
    end

    -- 应用 bullet ComponentSpace offset（弹头相对弹壳偏移，参数由隔离测试确认）
    -- 关键改造：用 ComponentSpace 相对偏移（bullet_cs = shell_cs + offset）
    -- 旧 BoneSpace(orig+offset) 方案因 orig 随 spawn pose 漂移而废弃
    -- 新方案：读 shell 的 ComponentSpace 位置（实时值），bullet_cs = shell_cs + offset
    if bone_fname_bullet ~= nil and bone_fname_shell ~= nil
       and comp.SetBoneLocationByName ~= nil and comp.GetBoneLocationByName ~= nil then
        pcall(function()
            local shell_cs = comp:GetBoneLocationByName(bone_fname_shell, bone_space_cs)
            if shell_cs ~= nil then
                local sx = tonumber(shell_cs.X) or 0
                local sy = tonumber(shell_cs.Y) or 0
                local sz = tonumber(shell_cs.Z) or 0
                -- bullet ComponentSpace offset 相对 shell：X=0, Y=6.25, Z=0
                comp:SetBoneLocationByName(bone_fname_bullet,
                    uevrUtils.vector(sx + 0.0,
                                     sy + 6.25,
                                     sz + 0.0),
                    bone_space_cs)
            end
        end)
    end

    -- 渲染标志
    pcall(function() reload_tools.apply_poseable_render_flags(comp) end)
    pcall(function() reload_tools.prepare_spawned_actor_visible(actor) end)

    pcall(function()
        if comp.SetMobility ~= nil then
            comp:SetMobility(2)
        end
        if actor.K2_SetRootComponent ~= nil then
            actor:K2_SetRootComponent(comp)
        end
    end)

    local function apply_offset()
        if shell_index == 2 then
            apply_rifle_shell_transform(comp, SHELL_LEFT_HAND_ATTACHMENT_ID_2, SHELL_CONFIG_PREFIX_2)
        else
            apply_rifle_shell_transform(comp)
        end
    end

    local attach_ok, attach_err = pcall(function()
        attachments.attachToController(comp, Handed.Left, shellAttachOptions)
    end)

    apply_offset()
    pcall(function()
        local mc = resolve_shell_hand_parent()
        if mc ~= nil and comp.K2_AttachTo ~= nil then
            comp:K2_AttachTo(mc, uevrUtils.fname_from_string(""), 2, false)
            apply_offset()
        end
    end)

    local after_loc = reload_tools.get_component_world_location(comp)

    return actor, comp
end

--- 步枪装弹口是否已拉开（后拉到位）。与霰弹枪不同：必须先开栓才能上弹。
local function is_bolt_open_for_reload()
    local rack = state.bolt_rack
    if rack == nil then
        return false
    end
    -- 栓必须仍在本轮拉栓流程中（或表演件仍在），否则开栓视觉已没了
    if not state.bolt_active and not bolt_poseable_is_valid() then
        return false
    end
    if rack.pull_done == true then
        return true
    end
    -- 容差：后拉几乎满程也视为开口可用
    return (rack.pull_progress or 0) >= 0.95
end

--- 取弹前把左手从枪栓 accessory 脱开，跟回手柄；枪栓冻结在拉开位（不 cancel）
-- 重要：不要 clear_bolt_hand_parent。accessories 对 socket=bone_lock 会读 __sh2_bolt_hand_parent；
-- 若清掉，装完再握栓时左手会吸附到真枪 bone_lock（合栓位）=「吸附到本体枪栓」。
local function release_left_hand_from_bolt_for_shells(reason)
    state.bolt_offhand_gripping = false
    local poseable = uevrUtils.getValid(bolt_visual.poseable_mesh)
    if poseable ~= nil then
        set_bolt_hand_parent(poseable)
    end
    pcall(function()
        accessories.attachHandToAccessory(Handed.Left, nil, false)
    end)
    if state.bolt_active then
        pause_bolt(reason or "shell_grab")
    end
end

local function spawn_shells_in_hand()
    state.spawn_attempt_count = (state.spawn_attempt_count or 0) + 1
    state.last_grab_skip = nil
    state.last_spawn_fail = nil
    state.last_spawn_step = "begin"

    if state.shells_in_hand then
        set_grab_skip("already_holding")
        return false
    end

    -- 步枪：闩未拉开不能抓弹（与霰弹枪底部上弹不同）
    if not is_bolt_open_for_reload() then
        local rack = state.bolt_rack
        set_grab_skip(string.format(
            "bolt_not_open active=%s phase=%s pull_done=%s progress=%.2f",
            tostring(state.bolt_active),
            tostring(rack and rack.phase),
            tostring(rack and rack.pull_done),
            (rack and rack.pull_progress) or 0))
        return false
    end

    local reserve = reload_tools.sh2_state().reserveAmmo
    if reserve == nil or reserve <= 0 then
        set_spawn_fail("reserve", "no reserve ammo (" .. tostring(reserve) .. ")")
        return false
    end

    -- 先脱开枪栓吸附，否则左手仍挂 bone_lock，子弹却 attach 到手柄 → 手/弹错位
    release_left_hand_from_bolt_for_shells("shell_grab")

    local spawn_loc, spawn_rot, left_comp, hand_err, loc_source = get_shell_hand_world_transform()
    if left_comp == nil or spawn_loc == nil then
        set_spawn_fail("left_hand_comp", "no left motion controller (" .. tostring(hand_err) .. ")")
        return false
    end
    local ik_comp = resolve_left_hand_component()
    local ik_sock = ik_comp and reload_tools.get_socket_world_location(ik_comp, SHELL_ATTACH_SOCKET) or nil
    local ik_root = ik_comp and reload_tools.get_component_world_location(ik_comp) or nil

    -- 获取武器 SkeletalMesh（用于创建 PoseableMesh 完整子弹，替换原 SniperRifle_Shell_01_A 空弹壳）
    local weapon_mesh, _, mesh_err = get_rifle_chain()
    if weapon_mesh == nil then
        set_spawn_fail("mesh_find", "weapon_mesh nil (" .. tostring(mesh_err) .. ")")
        return false
    end

    local identity_xf = uevrUtils.get_transform()

    local actor1, comp1 = spawn_single_shell(weapon_mesh, spawn_loc, spawn_rot, identity_xf, 1)
    if actor1 == nil or comp1 == nil then
        return false
    end

    state.shells_in_hand = true
    state.shells_actor = actor1
    state.shells_component = comp1
    state.reload_active = true
    state.shells_actor2 = nil
    state.shells_component2 = nil
    state.shell2_proximity_enabled = false
    state.shell2_doomed = false
    state.shell2_lerp = nil

    local spawned_two = false
    if reserve >= 2 then
        local actor2, comp2 = spawn_single_shell(weapon_mesh, spawn_loc, spawn_rot, identity_xf, 2)
        if actor2 ~= nil and comp2 ~= nil then
            state.shells_actor2 = actor2
            state.shells_component2 = comp2
            spawned_two = true
        end
    end

    apply_left_hand_shell_pose()

    publish_globals()
    -- 诊断：确认 g_mag_in_left_hand 已发布（UEVR_09 gripLeft.leave 依赖此标志触发 mag_grab_release）
    diag_log("spawn_shells OK g_mag_in_left_hand="
        .. tostring(_G[KEYS.mag_in_left_hand]) .. " shells_in_hand=" .. tostring(state.shells_in_hand)
        .. " bolt_open=true phase=" .. tostring(state.bolt_rack and state.bolt_rack.phase))
    set_spawn_ok("shell in left hand reserve=" .. tostring(reserve) .. " shells=" .. (spawned_two and "2" or "1"))
    return true
end

-- 取消松手掉落
local function cancel_shell_drop(drop_state)
    drop_state = drop_state or state.shell_drop
    if drop_state == nil then
        return
    end
    if drop_state.actor ~= nil
       and drop_state.actor ~= state.shells_actor
       and drop_state.actor ~= state.shells_actor2 then
        pcall(function()
            uevrUtils.destroy_actor(drop_state.actor)
        end)
    end
    reload_tools.cancel(drop_state)
    drop_state.actor = nil
    drop_state.root = nil
end

-- 销毁左手所有弹壳模型
local function despawn_left_hand_shells()
    cancel_shell_drop(state.shell_drop)
    cancel_shell_drop(state.shell_drop2)
    pcall(function()
        attachments.detachGripAttachments(Handed.Left)
    end)
    if state.shells_actor ~= nil then
        pcall(function()
            state.shells_actor:K2_DestroyActor()
        end)
        state.shells_actor = nil
    end
    if state.shells_actor2 ~= nil then
        pcall(function()
            state.shells_actor2:K2_DestroyActor()
        end)
        state.shells_actor2 = nil
    end
    state.shells_component = nil
    state.shells_component2 = nil
    state.shells_in_hand = false
    state.reload_active = false
    state.shell2_proximity_enabled = false
    state.shell2_doomed = false
    state.shell2_lerp = nil
    -- 步枪无装弹门，不调用 show_loading_gate
    clear_left_hand_shell_pose()
    publish_globals()
end

-- 从左手 detach 单发弹壳但保留 actor 供掉落动画
local function detach_shell_for_animation(shell_index)
    local is_shell2 = (shell_index == 2)
    local actor = is_shell2 and state.shells_actor2 or state.shells_actor
    local comp = is_shell2 and state.shells_component2 or state.shells_component
    if actor == nil or comp == nil then
        return nil, nil, nil
    end
    local root = uevrUtils.getValid(comp)
    local loc = nil
    if root ~= nil then
        loc = reload_tools.get_component_world_location(root)
    end
    if is_shell2 then
        state.shells_actor2 = nil
        state.shells_component2 = nil
        state.shell2_proximity_enabled = false
        state.shell2_doomed = false
        state.shell2_lerp = nil
    else
        state.shells_actor = nil
        state.shells_component = nil
    end
    if state.shells_actor == nil and state.shells_actor2 == nil then
        state.shells_in_hand = false
        state.reload_active = false
        -- 步枪无装弹门，不调用 show_loading_gate
        clear_left_hand_shell_pose()
    end
    pcall(function()
        if attachments.detachSingleAttachment ~= nil then
            attachments.detachSingleAttachment(comp)
        else
            attachments.detachGripAttachments(Handed.Left)
        end
    end)
    publish_globals()
    if root ~= nil and loc ~= nil then
        pcall(function()
            root:K2_SetWorldLocation(
                uevrUtils.vector(loc.X, loc.Y, loc.Z),
                false,
                reusable_hit_result,
                false
            )
        end)
    end
    return actor, root, loc
end

-- 启动单发弹壳的垂直掉落
local function start_single_shell_drop(shell_index)
    local actor, root, start_loc = detach_shell_for_animation(shell_index)
    if actor == nil or root == nil or start_loc == nil then
        if actor ~= nil then
            pcall(function() uevrUtils.destroy_actor(actor) end)
        end
        return false
    end
    local drop = (shell_index == 2) and state.shell_drop2 or state.shell_drop
    if drop == nil then
        drop = reload_tools.new_drop_state()
        drop.duration = SHELL_DROP_DURATION
        drop.distance = SHELL_DROP_DISTANCE
        if shell_index == 2 then
            state.shell_drop2 = drop
        else
            state.shell_drop = drop
        end
    end
    drop.actor = actor
    drop.root = root
    local on_finish = function()
        if drop.actor ~= nil then
            pcall(function() drop.actor:SetHiddenInGame(true, true) end)
            pcall(function() uevrUtils.destroy_actor(drop.actor) end)
        end
        drop.actor = nil
        drop.root = nil
        print_log("shell_" .. shell_index .. " grip_release drop finished", LogLevel.Info)
    end
    reload_tools.start_fall(drop, {
        sx = start_loc.X, sy = start_loc.Y, sz = start_loc.Z,
        duration = SHELL_DROP_DURATION,
        distance = SHELL_DROP_DISTANCE,
        on_finish = on_finish,
        -- fall 阶段水平跟随枪体：走动/转身时弹壳不会原地下坠脱离枪体
        -- 复用 shell slide 的 follow_provider（返回枪体 socket 位置作为参照点）
        -- tick_fall 会记录初始位置，计算相对运动，使弹壳跟着枪水平移动
        -- 对齐 shotgun_reload.lua:2844
        follow_provider = make_shell_slide_follow_provider(),
    })
    return true
end

-- 松手：垂直掉落（shell_1 + shell_2 同时掉落）
local function start_shell_grip_release_drop()
    local ok1 = start_single_shell_drop(1)
    local ok2 = false
    if state.shells_actor2 ~= nil or state.shells_component2 ~= nil then
        ok2 = start_single_shell_drop(2)
    end
    return ok1 or ok2
end

-- 每帧驱动单发掉落动画
local function tick_single_shell_drop(drop)
    if drop == nil or not drop.active or drop.root == nil or drop.phase ~= "fall" then
        return
    end
    local result = reload_tools.tick_fall(drop)
    if result == nil then
        return
    end
    pcall(function()
        drop.root:K2_SetWorldLocation(
            uevrUtils.vector(result.x, result.y, result.z),
            false, reusable_hit_result, false
        )
    end)
end

local function tick_shell_drop()
    tick_single_shell_drop(state.shell_drop)
    tick_single_shell_drop(state.shell_drop2)
end

-- =============================================================================
-- D5: shell_2 lerp 过渡（shell_1 despawn 后触发）
-- =============================================================================

local function start_shell2_lerp()
    if state.shells_component2 == nil then
        return false
    end
    local comp2 = uevrUtils.getValid(state.shells_component2)
    if comp2 == nil then
        return false
    end
    local start_loc = nil
    pcall(function()
        start_loc = {
            X = comp2.RelativeLocation.X or 0,
            Y = comp2.RelativeLocation.Y or 0,
            Z = comp2.RelativeLocation.Z or 0,
        }
    end)
    if start_loc == nil then
        return false
    end
    local shell1_params = load_rifle_shell_params(SHELL_LEFT_HAND_ATTACHMENT_ID, SHELL_CONFIG_PREFIX)
    local end_loc = shell1_params.location or { 0, 0, 0 }
    local end_vec = uevrUtils.vector(end_loc)

    state.shell2_lerp = {
        active = true,
        start_t = os.clock(),
        duration = SHELL_LERP_DURATION,
        comp = comp2,
        start_loc = start_loc,
        end_loc = { X = end_vec.X, Y = end_vec.Y, Z = end_vec.Z },
    }
    state.shell2_proximity_enabled = false
    return true
end

local function tick_shell2_lerp()
    if state.shell2_lerp == nil or not state.shell2_lerp.active then
        return
    end
    local lerp = state.shell2_lerp
    local comp = lerp.comp
    if comp == nil or uevrUtils.getValid(comp) == nil then
        state.shell2_lerp = nil
        return
    end
    local elapsed = os.clock() - lerp.start_t
    local t = elapsed / math.max(lerp.duration, 0.001)
    if t >= 1.0 then
        pcall(function()
            uevrUtils.set_component_relative_location(comp, lerp.end_loc)
        end)
        state.shell2_lerp = nil
        if not state.shell2_doomed then
            state.shell2_proximity_enabled = true
        end
        return
    end
    local eased = t * t
    local x = lerp.start_loc.X + (lerp.end_loc.X - lerp.start_loc.X) * eased
    local y = lerp.start_loc.Y + (lerp.end_loc.Y - lerp.start_loc.Y) * eased
    local z = lerp.start_loc.Z + (lerp.end_loc.Z - lerp.start_loc.Z) * eased
    pcall(function()
        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(x, y, z))
    end)
end

-- 入膛滑入动画
local function slide_shells_into_chamber(shell_index, prefer_socket_name, prefer_pos)
    if shell_index == nil then shell_index = 1 end
    local is_shell2 = (shell_index == 2)

    local actor = is_shell2 and state.shells_actor2 or state.shells_actor
    local comp = is_shell2 and state.shells_component2 or state.shells_component
    local slide_state_ref = is_shell2 and state.shell_slide2 or state.shell_slide

    if actor == nil then
        return false
    end
    if slide_state_ref ~= nil and slide_state_ref.active then
        return false
    end

    if is_shell2 and state.shell2_lerp ~= nil then
        state.shell2_lerp = nil
    end

    local mesh, _ = get_rifle_chain()
    if mesh == nil then
        if is_shell2 then
            pcall(function() state.shells_actor2:K2_DestroyActor() end)
            state.shells_actor2 = nil
            state.shells_component2 = nil
            state.shell2_lerp = nil
            state.shell2_proximity_enabled = false
            state.shell2_doomed = false
            if state.shells_actor == nil then
                state.shells_in_hand = false
                state.reload_active = false
                clear_left_hand_shell_pose()
            end
            publish_globals()
        else
            despawn_left_hand_shells()
        end
        return false
    end

    local socket_name = prefer_socket_name
    local chamber_pos = prefer_pos
    if chamber_pos == nil then
        socket_name, chamber_pos = resolve_shell_insert_socket(mesh)
    end
    if chamber_pos == nil then
        print("[RIFLE_RELOAD] slide: no insert socket " .. tostring(SHELL_INSERT_SOCKET))
        if is_shell2 then
            pcall(function() state.shells_actor2:K2_DestroyActor() end)
            state.shells_actor2 = nil
            state.shells_component2 = nil
            state.shell2_lerp = nil
            state.shell2_proximity_enabled = false
            state.shell2_doomed = false
            if state.shells_actor == nil then
                state.shells_in_hand = false
                state.reload_active = false
                clear_left_hand_shell_pose()
            end
            publish_globals()
        else
            despawn_left_hand_shells()
        end
        return false
    end

    local root = uevrUtils.getValid(comp)
    if root == nil then
        root = actor
    end

    local start_pos = select(2, get_shell_slide_start_world_location(mesh))
    if start_pos == nil then
        print("[RIFLE_RELOAD] slide: fixed start failed, abort (no hand fallback)")
        if is_shell2 then
            pcall(function() state.shells_actor2:K2_DestroyActor() end)
            state.shells_actor2 = nil
            state.shells_component2 = nil
            state.shell2_lerp = nil
            state.shell2_proximity_enabled = false
            state.shell2_doomed = false
            if state.shells_actor == nil then
                state.shells_in_hand = false
                state.reload_active = false
                clear_left_hand_shell_pose()
            end
            publish_globals()
        else
            despawn_left_hand_shells()
        end
        return false
    end

    local start_rot, end_rot = build_shell_slide_rotations(mesh)
    local use_rot = start_rot ~= nil and end_rot ~= nil
    local interpolate_rot = use_rot and not shell_slide_rots_equal(start_rot, end_rot)

    print(string.format(
        "[RIFLE_RELOAD] slide_%d → socket=%s start=(%.1f,%.1f,%.1f) end=(%.1f,%.1f,%.1f) rot=%s",
        shell_index,
        tostring(socket_name),
        start_pos.X or 0, start_pos.Y or 0, start_pos.Z or 0,
        chamber_pos.X or 0, chamber_pos.Y or 0, chamber_pos.Z or 0,
        interpolate_rot and "lerp" or (use_rot and "lock" or "off")
    ))

    -- 步枪无装弹门，不调用 hide_loading_gate

    pcall(function()
        if attachments.detachSingleAttachment ~= nil then
            attachments.detachSingleAttachment(comp)
        else
            attachments.detachGripAttachments(Handed.Left)
        end
    end)

    if is_shell2 then
        state.shells_in_hand = false
        clear_left_hand_shell_pose()
    else
        if state.shells_actor2 == nil then
            state.shells_in_hand = false
            clear_left_hand_shell_pose()
        end
    end
    publish_globals()

    if root ~= nil then
        pcall(function()
            uevrUtils.set_component_relative_location(root, uevrUtils.vector(0, 0, 0))
            uevrUtils.set_component_relative_rotation(root, uevrUtils.rotator(0, 0, 0))
        end)
        pcall(function()
            if root.K2_SetWorldLocation ~= nil then
                root:K2_SetWorldLocation(
                    uevrUtils.vector(start_pos.X, start_pos.Y, start_pos.Z),
                    false, reusable_hit_result, false)
            end
            if use_rot and root.K2_SetWorldRotation ~= nil then
                root:K2_SetWorldRotation(
                    uevrUtils.rotator({ start_rot.Pitch, start_rot.Yaw, start_rot.Roll }),
                    false, reusable_hit_result, false)
            end
        end)
    end

    local new_slide = {}
    if is_shell2 then
        state.shell_slide2 = new_slide
    else
        state.shell_slide = new_slide
    end

    reload_tools.start_slide(new_slide, {
        sx = start_pos.X, sy = start_pos.Y, sz = start_pos.Z,
        ex = chamber_pos.X, ey = chamber_pos.Y, ez = chamber_pos.Z,
        duration = SHELL_SLIDE_DURATION,
        skip_fall = true,
        interpolate_rot = interpolate_rot,
        start_rot = start_rot,
        end_rot = end_rot,
        rot_delay = SHELL_SLIDE_ROT_DELAY,
        -- slide 阶段跟随枪体移动：走动/转身时弹壳不会脱离入弹口
        -- 对齐 shotgun_reload.lua:3147
        follow_provider = make_shell_slide_follow_provider(),
        on_finish = function()
            if is_shell2 then
                if state.shells_actor2 ~= nil then
                    pcall(function() state.shells_actor2:K2_DestroyActor() end)
                    state.shells_actor2 = nil
                end
                state.shells_component2 = nil
                state.shell_slide2 = nil
                state.shells_in_hand = false
                state.reload_active = false
                state.shell2_proximity_enabled = false
                state.shell2_doomed = false
                state.shell2_lerp = nil
                -- 步枪无装弹门，不调用 show_loading_gate
                clear_left_hand_shell_pose()
                publish_globals()
                print_log("shell_2 slid into chamber and despawned → reload flow end", LogLevel.Info)
            else
                if state.shells_actor ~= nil then
                    pcall(function() state.shells_actor:K2_DestroyActor() end)
                    state.shells_actor = nil
                end
                state.shells_component = nil
                state.shell_slide = nil
                if state.shells_actor2 ~= nil then
                    local weapon = rawget(_G, KEYS.equipped_weapon)
                    local offsets = reload_tools.WEAPON_PROFILES.rifle
                    local clip = reload_tools.read_clip_ammo(weapon, offsets)
                    local clip_size = reload_tools.read_clip_size(weapon, offsets)
                    local reserve = reload_tools.sh2_state().reserveAmmo
                    if clip ~= nil and clip_size ~= nil and clip < clip_size
                       and (reserve == nil or reserve > 0) then
                        state.shell2_doomed = false
                        start_shell2_lerp()
                        print_log("shell_1 done → shell_2 lerp started (clip not full)", LogLevel.Info)
                    else
                        state.shell2_doomed = true
                        start_shell2_lerp()
                        print_log(string.format(
                            "shell_1 done → shell_2 doomed (clip=%s/%s reserve=%s), lerp then wait drop",
                            tostring(clip), tostring(clip_size), tostring(reserve)), LogLevel.Info)
                    end
                else
                    state.shells_in_hand = false
                    state.reload_active = false
                    -- 步枪无装弹门，不调用 show_loading_gate
                    clear_left_hand_shell_pose()
                    print_log("shell_1 done → no shell_2, reload flow end", LogLevel.Info)
                end
                publish_globals()
            end
        end,
    })

    new_slide.root = root
    return true
end

-- 每帧驱动单个 slide
local function tick_single_shell_slide(slide_state)
    if slide_state == nil or not slide_state.active then
        return
    end
    local slide = slide_state
    local root = slide.root
    if root == nil then
        return
    end

    local result = reload_tools.tick_slide(slide)
    if result == nil then
        return
    end

    if result.all_done or slide_state == nil then
        return
    end

    pcall(function()
        if root.K2_SetWorldLocation ~= nil then
            root:K2_SetWorldLocation(
                uevrUtils.vector(result.x, result.y, result.z),
                false, reusable_hit_result, false)
        end
        if result.pitch ~= nil and root.K2_SetWorldRotation ~= nil then
            root:K2_SetWorldRotation(
                uevrUtils.rotator({ result.pitch, result.yaw, result.roll }),
                false, reusable_hit_result, false)
        end
    end)
end

local function tick_shell_slide()
    tick_single_shell_slide(state.shell_slide)
    tick_single_shell_slide(state.shell_slide2)
end

-- 插弹：proximity 每次入舱写 +1，并播滑入
local function insert_shells(shell_index, socket_name, socket_pos)
    if shell_index == nil then shell_index = 1 end
    local weapon = rawget(_G, KEYS.equipped_weapon)
    if weapon == nil then
        return false
    end

    local offsets = reload_tools.WEAPON_PROFILES.rifle
    local clip = reload_tools.read_clip_ammo(weapon, offsets)
    local clip_size = reload_tools.read_clip_size(weapon, offsets)
    local reserve = reload_tools.sh2_state().reserveAmmo

    local wrote_ammo = false
    print(string.format(
        "[RIFLE_RELOAD] insert_shells DIAG clip=%s size=%s reserve=%s condition=%s",
        tostring(clip), tostring(clip_size), tostring(reserve),
        tostring(clip ~= nil and clip_size ~= nil and clip < clip_size)))
    if clip ~= nil and clip_size ~= nil and clip < clip_size then
        wrote_ammo = reload_tools.apply_shell_insert(offsets) == true
        print(string.format(
            "[RIFLE_RELOAD] shell_%d insert ammo queued=%s clip=%s/%s reserve_cache=%s",
            shell_index, tostring(wrote_ammo), tostring(clip), tostring(clip_size), tostring(reserve)))
    else
        print(string.format(
            "[RIFLE_RELOAD] insert ammo write SKIPPED shell_%d clip=%s size=%s reserve=%s",
            shell_index, tostring(clip), tostring(clip_size), tostring(reserve)
        ))
    end

    slide_shells_into_chamber(shell_index, socket_name, socket_pos)

    local seg = M.get_audio_segment("shell_insert")
    audio.play_segment(seg.audio_key, seg.start_sec, seg.duration)
    trigger_reload_haptic("shell_insert")

    print(string.format(
        "[RIFLE_RELOAD] insert ok shell_%d socket=%s wrote_ammo=%s",
        shell_index, tostring(socket_name), tostring(wrote_ammo)
    ))
    return true
end

-- 每帧检测弹壳与装弹口的距离
local function check_shell_proximity(cached_mesh)
    if not state.shells_in_hand then
        return
    end

    local shell_index = nil
    local ref_comp = nil
    if state.shells_component ~= nil
       and (state.shell_slide == nil or not state.shell_slide.active) then
        shell_index = 1
        ref_comp = state.shells_component
    elseif state.shells_component2 ~= nil
           and state.shells_component == nil
           and (state.shell_slide2 == nil or not state.shell_slide2.active)
           and state.shell2_proximity_enabled == true then
        -- 2026-07-27 门控：shell_1 入仓销毁后 + shell_2 lerp 完成后才允许 shell_2 proximity
        -- 修复 shell_1/shell_2 偏移 6.74cm < SHELL_INSERT_DISTANCE 10cm 导致的同手双发同时触发
        shell_index = 2
        ref_comp = state.shells_component2
    end
    if shell_index == nil then
        local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
        if state._last_no_prox_log == nil or (now - state._last_no_prox_log) >= 1.5 then
            state._last_no_prox_log = now
            diag_log_insert_prox(string.format(
                "insert_prox SKIP shells_in_hand=true comp1=%s slide1=%s comp2=%s slide2=%s",
                tostring(state.shells_component ~= nil),
                tostring(state.shell_slide ~= nil and state.shell_slide.active or false),
                tostring(state.shells_component2 ~= nil),
                tostring(state.shell_slide2 ~= nil and state.shell_slide2.active or false)
            ))
        end
        return
    end

    local weapon = rawget(_G, KEYS.equipped_weapon)
    if weapon ~= nil then
        local offsets = reload_tools.WEAPON_PROFILES.rifle
        local clip = reload_tools.read_clip_ammo(weapon, offsets)
        local clip_size = reload_tools.read_clip_size(weapon, offsets)
        if clip ~= nil and clip_size ~= nil and clip >= clip_size then
            local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
            if state._last_prox_fail_log == nil or (now - state._last_prox_fail_log) >= 1.5 then
                state._last_prox_fail_log = now
                diag_log_insert_prox(string.format(
                    "insert_prox FAIL clip_full clip=%s/%s",
                    tostring(clip), tostring(clip_size)))
            end
            return
        end
    end

    local mesh = cached_mesh or select(1, get_rifle_chain())
    if mesh == nil then
        local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
        if state._last_prox_fail_log == nil or (now - state._last_prox_fail_log) >= 1.5 then
            state._last_prox_fail_log = now
            diag_log_insert_prox("insert_prox FAIL mesh=nil (get_rifle_chain returned nil)")
        end
        return
    end

    local ref_pos = nil
    if ref_comp ~= nil then
        ref_pos = reload_tools.get_component_world_location(ref_comp)
    end
    if ref_pos == nil then
        ref_pos = get_left_hand_location()
    end
    if ref_pos == nil then
        local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
        if state._last_prox_fail_log == nil or (now - state._last_prox_fail_log) >= 1.5 then
            state._last_prox_fail_log = now
            diag_log_insert_prox("insert_prox FAIL ref_pos=nil (shell comp + left hand both nil)")
        end
        return
    end

    local socket_name, socket_pos = get_shell_insert_world_location(mesh)
    if socket_name == nil or socket_pos == nil then
        local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
        if state._last_prox_fail_log == nil or (now - state._last_prox_fail_log) >= 1.5 then
            state._last_prox_fail_log = now
            diag_log_insert_prox(string.format(
                "insert_prox FAIL socket=nil (bone_lock not found on mesh=%s)",
                tostring(mesh ~= nil)))
        end
        return
    end

    local dist = reload_tools.vector_distance(
        { X = ref_pos.X, Y = ref_pos.Y, Z = ref_pos.Z },
        { X = socket_pos.X, Y = socket_pos.Y, Z = socket_pos.Z }
    )

    local now = (uevrUtils.get_game_time_seconds and uevrUtils.get_game_time_seconds()) or os.clock()
    if state._last_insert_prox_log == nil or (now - state._last_insert_prox_log) >= 0.8 then
        state._last_insert_prox_log = now
        diag_log_insert_prox(string.format(
            "insert_prox shell_%d socket=%s fwd=%.0f down=%.0f right=%.0f dist=%.1fcm thresh=%.1fcm",
            shell_index,
            socket_name,
            SHELL_INSERT_OFFSET.forward or 0,
            SHELL_INSERT_OFFSET.down or 0,
            SHELL_INSERT_OFFSET.right or 0,
            dist,
            SHELL_INSERT_DISTANCE
        ))
    end

    if dist < SHELL_INSERT_DISTANCE then
        insert_shells(shell_index, socket_name, socket_pos)
    end
end

-- 取消手动装弹
local function cancel_manual_reload(reason)
    reload_block_guard.cancelling = true
    cancel_shell_drop(state.shell_drop)
    cancel_shell_drop(state.shell_drop2)
    state.shell2_lerp = nil
    state.shell2_proximity_enabled = false
    state.shell2_doomed = false
    if state.shell_slide ~= nil or state.shell_slide2 ~= nil then
        if state.shells_actor ~= nil then
            pcall(function()
                state.shells_actor:K2_DestroyActor()
            end)
            state.shells_actor = nil
        end
        if state.shells_actor2 ~= nil then
            pcall(function()
                state.shells_actor2:K2_DestroyActor()
            end)
            state.shells_actor2 = nil
        end
        state.shells_component = nil
        state.shells_component2 = nil
        state.shells_in_hand = false
        state.reload_active = false
        state.shell_slide = nil
        state.shell_slide2 = nil
        clear_left_hand_shell_pose()
        publish_globals()
    else
        despawn_left_hand_shells()
    end
    if state.bolt_active or bolt_visual.poseable_actor ~= nil then
        cancel_bolt(reason)
    end
    reload_block_guard.cancelling = false
    print_log("manual reload cancelled: " .. tostring(reason), LogLevel.Info)
end

-- =============================================================================
-- C 类 accessory hooks（拉栓 grip+proximity）— 自注册
-- =============================================================================

local bolt_hooks_installed = false

-- tick 触发改造：删除 on_accessory_animation / on_accessory_detach hook
-- 左手吸附由 accessory 系统（pull_lock grip_animation）自然处理
-- begin_bolt / pause_bolt 由 tick_detect_bolt_grip 驱动（拉栓前吸附查询节流）
local function install_bolt_accessory_hooks()
    _G.__sh2_rifle_active_left_accessory = function()
        -- 持弹/装弹中绝不 claim：否则左胯取弹 grip 会把左手拽回枪栓
        if state.reload_active or state.shells_in_hand then
            return
        end
        -- 拉栓完成后的冷却/松手闩锁期内不 claim（让左手自由，避免立刻又吸回枪栓）
        if bolt_regrab_blocked() or (state.bolt_detach_cooldown or 0) > 0 then
            return
        end
        local sticky = (state.post_bolt_keep_left_frames or 0) > 0
        -- 仅在「正握着枪栓」或粘滞期才 claim。
        -- 旧逻辑：bolt_active + 任意左 grip → claim，导致栓开后去胯取弹时手被强行挂回枪栓。
        if not sticky and state.bolt_offhand_gripping ~= true then
            return
        end
        if not is_left_grip_pressed() then
            return
        end
        if bolt_poseable_is_valid() and bolt_perf_marker_uuid ~= nil then
            return bolt_perf_marker_uuid, 30
        end
        return bolt_marker_uuid, 25
    end

    if bolt_hooks_installed or rawget(_G, "__sh2_rifle_bolt_hooks_installed") then
        bolt_hooks_installed = true
        return
    end

    uevrUtils.registerUEVRCallback("active_left_accessory", function()
        local fn = rawget(_G, "__sh2_rifle_active_left_accessory")
        if type(fn) == "function" then
            return fn()
        end
    end)

    bolt_hooks_installed = true
    _G.__sh2_rifle_bolt_hooks_installed = true
end

-- =============================================================================
-- D8: 武器切换检测
-- =============================================================================

local function tick_weapon_change_watch()
    local key = reload_tools.get_current_weapon_key()
    if key == state.last_weapon_key then
        return
    end
    if state.last_weapon_key ~= nil then
        print_log("weapon changed (key " .. tostring(state.last_weapon_key) .. " → " .. tostring(key) .. ")", LogLevel.Info)
        restore_prepare_anim_data("weapon_change", true)
        cancel_manual_reload("weapon_change")
        if state.bolt_active or bolt_visual.poseable_actor ~= nil then
            cleanup_bolt_visual()
            state.bolt_active = false
            if state.bolt_rack ~= nil then
                state.bolt_rack.active = false
            end
        end
        state.needs_bolt = false
        state.bolt_completed_this_cycle = false
        state.bolt_was_active_pull = false
        state.bolt_reloaded_this_cycle = false
        state.last_clip_ammo = nil
    end
    state.last_weapon_key = key
end

-- =============================================================================
-- 全局状态发布
-- =============================================================================

-- 拉栓 flag：字面量键名（防 KEYS 热重载缺字段）；tick_bolt / on_tick 都会发
publish_bolt_busy_flags = function()
    local busy = state.bolt_active == true
        or state.bolt_offhand_gripping == true
        or ((state.post_bolt_keep_left_frames or 0) > 0)
    local open = state.bolt_active == true and bolt_poseable_is_valid()
    rawset(_G, BOLT_BUSY_KEY, busy == true)
    rawset(_G, BOLT_OPEN_KEY, open == true)
    if type(KEYS.rifle_bolt_busy) == "string" then
        rawset(_G, KEYS.rifle_bolt_busy, busy == true)
    end
    if type(KEYS.rifle_bolt_open) == "string" then
        rawset(_G, KEYS.rifle_bolt_open, open == true)
    end
end

publish_globals = function()
    _G[KEYS.manual_reload_active] = state.reload_active == true
    _G[KEYS.mag_in_left_hand] = state.shells_in_hand == true
    _G[KEYS.block_closed_hands_dock] = state.reload_active == true
    _G[KEYS.slide_locked] = state.slide_locked == true
    publish_bolt_busy_flags()
end

-- =============================================================================
-- D8: 生命周期回调
-- =============================================================================

local function on_tick()
    audio.tick()

    local was_rifle = state._was_rifle
    state._was_rifle = is_rifle_equipped()
    if not state._was_rifle then
        if rawget(_G, KEYS.mag_grab_edge) == true then
            local wt = tostring(rawget(_G, KEYS.current_weapon_type) or "none")
            if state._last_non_rf_grab_log_wt ~= wt then
                state._last_non_rf_grab_log_wt = wt
                -- 诊断：edge 到达但步枪未装备 → is_rifle_equipped()=false，edge 不会被步枪消费
                -- force=true：这是定位 mag_release 问题的关键线索，强制写不受开关控制
                diag_log("EDGE_REACHES_NOT_RIFLE weapon_type=" .. wt .. " is_rifle_equipped=false → edge NOT consumed by rifle", true)
            end
        else
            state._last_non_rf_grab_log_wt = nil
        end
        if was_rifle then
            print_log("weapon swap: rifle → non-rifle, cancel all", LogLevel.Info)
            restore_prepare_anim_data("weapon_swap", true)
            if state.reload_active or state.shells_in_hand or state.bolt_active
                or bolt_visual.poseable_actor ~= nil then
                cancel_manual_reload("weapon_swap")
            end
            cleanup_bolt_visual()
            state.bolt_active = false
            state.needs_bolt = false
            state.was_empty = false
            state.bolt_was_active_pull = false
            state.bolt_reloaded_this_cycle = false
            state.last_clip_ammo = nil
            state.slide_locked = false
            state.bolt_offhand_gripping = false
            _G[KEYS.slide_locked] = false
            publish_globals()
        else
            rawset(_G, BOLT_BUSY_KEY, false)
            rawset(_G, BOLT_OPEN_KEY, false)
            rawset(_G, KEYS.rifle_bolt_detach_cooldown or "g_rifle_bolt_detach_cooldown", false)
        end
        return
    end
    state._last_non_rf_grab_log_wt = nil

    local weapon = resolve_rifle_weapon()
    local clip = nil
    if weapon ~= nil then
        local offsets = reload_tools.WEAPON_PROFILES.rifle
        clip = reload_tools.read_clip_ammo(weapon, offsets)
    end

    pcall(tick_weapon_change_watch)
    pcall(tick_clip_fire_watch, weapon, clip)

    -- slide_locked 同步
    do
        if weapon ~= nil then
            local should_lock = (state.needs_bolt == true) or (type(clip) == "number" and clip <= 0)
            if should_lock then
                if not state.slide_locked then
                    state.slide_locked = true
                    _G[KEYS.slide_locked] = true
                    publish_globals()
                    force_release_vr_aim("slide_locked")
                end
            else
                if state.slide_locked then
                    state.slide_locked = false
                    _G[KEYS.slide_locked] = false
                    publish_globals()
                end
            end
        end
    end

    -- 消费 UEVR_09 发布的左胯取弹 edge
    if rawget(_G, KEYS.mag_grab_edge) == true then
        _G[KEYS.mag_grab_edge] = false
        print("[RIFLE_RELOAD] grab_edge consumed")
        diag_log("grab_edge consumed by rifle, shells_in_hand=" .. tostring(state.shells_in_hand))
        if state.shells_in_hand then
            set_grab_skip("already_holding")
        else
            local spawn_ok = spawn_shells_in_hand()
            diag_log("spawn_shells_in_hand result=" .. tostring(spawn_ok)
                .. " last_fail=" .. tostring(state.last_spawn_fail)
                .. " last_skip=" .. tostring(state.last_grab_skip))
        end
    end

    -- 消费左手 grip 松开 edge
    if rawget(_G, KEYS.mag_grab_release) == true then
        _G[KEYS.mag_grab_release] = false
        diag_log("grab_release EDGE detected shells_in_hand="
            .. tostring(state.shells_in_hand) .. " actor1=" .. tostring(state.shells_actor ~= nil)
            .. " comp1=" .. tostring(state.shells_component ~= nil))
        if state.shells_in_hand then
            diag_log("grab_release -> vertical fall")
            trigger_reload_haptic("mag_release")
            local seg_mr = M.get_audio_segment("mag_release")
            audio.play_segment(seg_mr.audio_key, seg_mr.start_sec, seg_mr.duration)
            local drop_ok = start_shell_grip_release_drop()
            diag_log("start_shell_grip_release_drop=" .. tostring(drop_ok))
            if not drop_ok then
                despawn_left_hand_shells()
            end
        else
            -- force=true：松手信号到达但 shells_in_hand=false 属异常，强制写日志
            diag_log("grab_release received but shells_in_hand=false (already consumed or spawned failed?)", true)
        end
    end

    -- 消费 dry fire edge
    if rawget(_G, KEYS.dry_fire_edge) == true then
        _G[KEYS.dry_fire_edge] = false
        if state.slide_locked then
            play_dry_fire_sound()
        end
    end

    -- M1 优化：缓存一次 chain，避免子函数重复解析 UObject 链
    local cached_mesh = select(1, get_rifle_chain())

    -- Phase 2: 双弹 proximity 检测
    check_shell_proximity(cached_mesh)

    -- 持弹时持续应用偏移
    if state.shells_in_hand and state.shells_component ~= nil then
        apply_rifle_shell_transform(state.shells_component)
    end
    -- shell_2 attach 关系维护
    if state.shells_in_hand and state.shells_component2 ~= nil then
        local comp2 = uevrUtils.getValid(state.shells_component2)
        local mc = resolve_shell_hand_parent()
        if comp2 ~= nil and mc ~= nil then
            local parent = nil
            pcall(function() parent = comp2.AttachParent end)
            if parent ~= mc then
                pcall(function()
                    comp2:K2_AttachTo(mc, uevrUtils.fname_from_string(""), 0, false)
                end)
            end
        end
    end
    -- shell_2 偏移应用
    if state.shells_in_hand and state.shells_component2 ~= nil then
        if state.shell2_lerp == nil then
            if state.shell2_proximity_enabled or state.shell2_doomed then
                apply_rifle_shell_transform(state.shells_component2,
                    SHELL_LEFT_HAND_ATTACHMENT_ID, SHELL_CONFIG_PREFIX)
            else
                apply_rifle_shell_transform(state.shells_component2,
                    SHELL_LEFT_HAND_ATTACHMENT_ID_2, SHELL_CONFIG_PREFIX_2)
            end
        end
    end

    tick_shell2_lerp()

    -- Phase 2.5: 入膛滑入 + 松手掉落 + 枪栓驱动已移至 PostCalculateStereoViewOffset（VR 变换更新后），
    -- 消除枪移动时弹壳/枪栓跟随的 1 帧滞后（与 pistol tick_slide_rack 同策略）
    -- shell_drop 现在也有 follow_provider（水平跟随枪体），必须与 slide 同步在 stereo view 后执行
    -- bolt 同样在 stereo view 后执行：copy_weapon_world_transform 读取的是当帧 VR 变换

    publish_globals()
end

local function on_level_change()
    restore_prepare_anim_data("level_change", true)
    cancel_manual_reload("level_change")
    cleanup_bolt_visual()
    state.bolt_active = false
    state.needs_bolt = false
    state.bolt_completed_this_cycle = false
    state.bolt_was_active_pull = false
    state.bolt_reloaded_this_cycle = false
    state.last_clip_ammo = nil
    pcall(function()
        audio.invalidate_cache()
    end)
    publish_globals()
end

-- =============================================================================
-- 诊断接口（供 rifle_diagnose.lua 查询）
-- =============================================================================

--- 获取步枪换弹内部状态快照
function M.get_state()
    return {
        reload_active = state.reload_active,
        shells_in_hand = state.shells_in_hand,
        needs_bolt = state.needs_bolt,
        bolt_active = state.bolt_active,
        bolt_pull_done = state.bolt_rack and state.bolt_rack.pull_done or false,
        bolt_progress = state.bolt_rack and state.bolt_rack.pull_progress or 0,
        bolt_phase = state.bolt_rack and state.bolt_rack.phase or "rotate_up",
        bolt_rotate_progress = state.bolt_rack and state.bolt_rack.rotate_progress or 0,
        bolt_current_pitch = state.bolt_rack and state.bolt_rack.current_pitch or 0,
        bolt_completed = state.bolt_completed_this_cycle,
        bolt_completed_this_cycle = state.bolt_completed_this_cycle,
        slide_locked = state.slide_locked,
        prepare_anim_data_nulled = state.prepare_anim_data_nulled == true,
        bolt_was_active_pull = state.bolt_was_active_pull == true,
        bolt_reloaded_this_cycle = state.bolt_reloaded_this_cycle == true,
        last_clip_ammo = state.last_clip_ammo,
        last_grab_skip = state.last_grab_skip,
        last_spawn_fail = state.last_spawn_fail,
        last_spawn_step = state.last_spawn_step,
        spawn_attempt_count = state.spawn_attempt_count or 0,
        spawn_success_count = state.spawn_success_count or 0,
        has_shells_actor = state.shells_actor ~= nil,
        has_shells_actor2 = state.shells_actor2 ~= nil,
        has_shells_component2 = state.shells_component2 ~= nil,
        shell2_proximity_enabled = state.shell2_proximity_enabled == true,
        shell2_doomed = state.shell2_doomed == true,
        shell2_lerp_active = state.shell2_lerp ~= nil and state.shell2_lerp.active == true,
        shell_slide_active = state.shell_slide ~= nil and state.shell_slide.active == true,
        shell_slide2_active = state.shell_slide2 ~= nil and state.shell_slide2.active == true,
        weapon_type = rawget(_G, KEYS.current_weapon_type),
    }
end

function M.get_status()
    return M.get_state()
end

--- 获取 shell_2 详细诊断信息
function M.get_shell2_diag()
    local diag = {
        has_actor2 = state.shells_actor2 ~= nil,
        has_component2 = state.shells_component2 ~= nil,
        actor2_valid = false,
        comp2_valid = false,
        world_loc = nil,
        relative_loc = nil,
        shell2_lerp_active = state.shell2_lerp ~= nil and state.shell2_lerp.active == true,
        shell2_doomed = state.shell2_doomed == true,
        shell2_proximity_enabled = state.shell2_proximity_enabled == true,
        shell_slide2_active = state.shell_slide2 ~= nil and state.shell_slide2.active == true,
    }
    local comp2 = uevrUtils.getValid(state.shells_component2)
    if comp2 ~= nil then
        diag.comp2_valid = true
        local wloc = reload_tools.get_component_world_location(comp2)
        if wloc ~= nil then
            diag.world_loc = {
                X = wloc.X or wloc.x or 0,
                Y = wloc.Y or wloc.y or 0,
                Z = wloc.Z or wloc.z or 0,
            }
        end
        pcall(function()
            diag.relative_loc = {
                X = comp2.RelativeLocation.X or 0,
                Y = comp2.RelativeLocation.Y or 0,
                Z = comp2.RelativeLocation.Z or 0,
            }
        end)
    end
    local actor2 = uevrUtils.getValid(state.shells_actor2)
    if actor2 ~= nil then
        diag.actor2_valid = true
    end
    return diag
end

--- 获取 shell_1 详细诊断信息
function M.get_shell1_diag()
    local diag = {
        has_actor = state.shells_actor ~= nil,
        has_component = state.shells_component ~= nil,
        actor_valid = false,
        comp_valid = false,
        world_loc = nil,
        relative_loc = nil,
        shell_slide_active = state.shell_slide ~= nil and state.shell_slide.active == true,
    }
    local comp = uevrUtils.getValid(state.shells_component)
    if comp ~= nil then
        diag.comp_valid = true
        local wloc = reload_tools.get_component_world_location(comp)
        if wloc ~= nil then
            diag.world_loc = {
                X = wloc.X or wloc.x or 0,
                Y = wloc.Y or wloc.y or 0,
                Z = wloc.Z or wloc.z or 0,
            }
        end
        pcall(function()
            diag.relative_loc = {
                X = comp.RelativeLocation.X or 0,
                Y = comp.RelativeLocation.Y or 0,
                Z = comp.RelativeLocation.Z or 0,
            }
        end)
    end
    local actor = uevrUtils.getValid(state.shells_actor)
    if actor ~= nil then
        diag.actor_valid = true
    end
    return diag
end

--- 当前是否拉栓锁定（needs_bolt 且未完成）
function M.is_bolt_locked()
    return state.needs_bolt and not state.bolt_completed_this_cycle
end

--- 获取 PrepareAnimData 备份
function M.get_prepare_anim_data_backup()
    local backup = state.prepare_anim_data_backup
    if backup == nil then
        return nil
    end
    local bytes_copy = {}
    if type(backup.bytes) == "table" then
        for i = 1, #backup.bytes do
            bytes_copy[i] = backup.bytes[i]
        end
    end
    return { weapon_addr = backup.weapon_addr, bytes = bytes_copy }
end

-- =============================================================================
-- 初始化
-- =============================================================================

function M.init()
    local CODE_REV = 8
    print("[RIFLE_RELOAD] init CODE_REV=" .. tostring(CODE_REV))

    if rawget(_G, "__sh2_rifle_code_rev") ~= CODE_REV then
        _G.__sh2_rifle_code_rev = CODE_REV
        _G.__sh2_rifle_reload_initialized = nil
        print("[RIFLE_RELOAD] CODE_REV changed → will (re)register indirection tick")
    end

    local MODULE_TOKEN = {}
    _G.__sh2_rifle_live_token = MODULE_TOKEN
    local real_on_tick = on_tick
    local function guarded_on_tick()
        if rawget(_G, "__sh2_rifle_live_token") ~= MODULE_TOKEN then
            return
        end
        real_on_tick()
    end
    local real_on_level = on_level_change
    local function guarded_on_level()
        if rawget(_G, "__sh2_rifle_live_token") ~= MODULE_TOKEN then
            return
        end
        real_on_level()
    end
    -- 入膛滑入 + 松手掉落 + 枪栓驱动视觉 tick：在 PostCalculateStereoViewOffset（VR 变换更新后）执行，
    -- 消除枪移动时弹壳/枪栓跟随的 1 帧滞后（与 pistol tick_slide_rack 同策略）
    -- 仅步枪装备 + 非过场时执行；tick_shell_slide / tick_shell_drop / tick_bolt 内部对 active 自检
    -- shell_drop 现在也有 follow_provider（水平跟随枪体），必须与 slide 同步在 stereo view 后执行
    -- bolt 也在 stereo view 后执行：copy_weapon_world_transform 读取的是当帧 VR 变换
    -- 对齐 pistol_reload.lua:3129 guarded_mag_drop_visual_tick（含 tick_slide_rack 状态逻辑）
    local function guarded_rifle_visual_tick()
        if rawget(_G, "__sh2_rifle_live_token") ~= MODULE_TOKEN then
            return
        end
        if not state._was_rifle then
            return
        end
        if uevrUtils.isInCutscene and uevrUtils.isInCutscene() then
            return
        end
        -- M1 优化：缓存一次 chain，传给子函数
        local cached_mesh = select(1, get_rifle_chain())
        pcall(tick_shell_slide)
        pcall(tick_shell_drop)
        pcall(tick_bolt, cached_mesh)
    end

    -- 注册步枪音频事件（底层 audio.lua 缓存 UAkAudioEvent 对象）
    -- SDK dump 确认路径：/Game/WWiseAudio/Events/Characters/James/James_Weapons/Rifle/
    audio.register_event(
        "rifle_reload",
        "Play_Wpn_Rifle_Reload",
        RIFLE_RELOAD_EVENT_PATH,
        4.984   -- override_max_dur：Rifle_Reload 总时长(秒)，防止 MaximumDuration 为 0 时 SeekOnEvent 不执行
    )
    audio.register_event(
        "rifle_bolt",
        "Play_Wpn_Rifle_Bolt_Action",
        RIFLE_BOLT_EVENT_PATH
    )
    audio.register_event(
        "rifle_bolt_close",
        "Play_Wpn_Rifle_Bolt_Close",
        RIFLE_BOLT_CLOSE_EVENT_PATH
    )
    audio.register_event(
        RIFLE_DRY_FIRE_KEY,
        DRY_FIRE_AUDIO_EVENT,
        RIFLE_DRY_FIRE_EVENT_PATH
    )

    -- 从 accessories_parameters.json 读取步枪左手 marker UUID
    if bolt_marker_uuid == nil then
        pcall(function()
            local params = json.load_file("accessories_parameters.json")
            if params and params.accessories then
                -- SDK dump 确认：步枪 skeletal mesh 类名为 SHItemBase_Sniper_Rifle_01_Skeletal
                local rifle_entry = params.accessories["SHItemBase_Sniper_Rifle_01_Skeletal"]
                if type(rifle_entry) == "table" then
                    for uuid, entry in pairs(rifle_entry) do
                        if type(entry) == "table" and type(entry.label) == "string" then
                            if entry.label == "performance foregrip (bolt)" then
                                bolt_perf_marker_uuid = uuid
                            else
                                bolt_marker_uuid = uuid
                            end
                        end
                    end
                end
            end
        end)
        if bolt_marker_uuid ~= nil then
            print_log("bolt marker UUID loaded: " .. tostring(bolt_marker_uuid), LogLevel.Info)
        else
            print_log("WARNING: bolt marker UUID not found in accessories_parameters.json", LogLevel.Warn)
        end
        if bolt_perf_marker_uuid ~= nil then
            print_log("bolt perf marker UUID loaded: " .. tostring(bolt_perf_marker_uuid), LogLevel.Info)
        else
            print_log("WARNING: bolt perf marker UUID not found in accessories_parameters.json", LogLevel.Warn)
        end
    end

    -- 注册步枪武器模块到 reload_hooks dispatch
    reload_hooks.register_weapon_module("rifle", M)
    install_bolt_accessory_hooks()

    -- 注册 grip_block：拉栓完成冷却期内阻断 holder(rifle_offhand) 和 pull_lock 的 proximity attach
    -- KEYS.rifle_bolt_detach_cooldown 由 tick_post_bolt_keep_left 每帧更新
    -- 持弹时同样阻断：防止左手被重新吸附到枪栓，子弹跟手柄、手模挂枪栓错位
    -- 开栓期间阻断 Holder：装完回手应吸表演枪栓，不要吸到枪身 rifle_offhand
    pcall(function()
        accessories.registerGripBlock(KEYS.rifle_bolt_detach_cooldown, "rifle_offhand")
        accessories.registerGripBlock(KEYS.rifle_bolt_detach_cooldown, "pull_lock")
        accessories.registerGripBlock(KEYS.mag_in_left_hand, "rifle_offhand")
        accessories.registerGripBlock(KEYS.mag_in_left_hand, "pull_lock")
        accessories.registerGripBlock(KEYS.rifle_bolt_open, "rifle_offhand")
    end)

    -- 热重载关键：tick 必须经 _G 间接调用
    _G.__sh2_rifle_on_tick = guarded_on_tick
    _G.__sh2_rifle_on_level_change = guarded_on_level
    _G.__sh2_rifle_visual_tick = guarded_rifle_visual_tick
    _G.__sh2_rifle_reload_module = M

    publish_globals()

    if rawget(_G, "__sh2_rifle_reload_initialized") then
        print("[RIFLE_RELOAD] hot-reload: rebound tick via _G (CODE_REV=" .. tostring(CODE_REV) .. ")")
        print("[RIFLE_RELOAD] 若行为仍旧：请做一次完整 Reset Scripts / 重启，清掉旧闭包")
        return M
    end

    uevrUtils.registerPostEngineTickCallback(function()
        local fn = rawget(_G, "__sh2_rifle_on_tick")
        if type(fn) == "function" then
            fn()
        end
    end)

    -- 入膛滑入 + 松手掉落视觉 tick：在 PostCalculateStereoViewOffset（VR 变换更新后）执行，
    -- 消除枪移动时弹壳跟随的 1 帧滞后（与 shotgun shell_slide_visual_tick 同策略）
    -- 仅 view_index==0 时执行（每帧只更新一次）
    uevrUtils.registerPostCalculateStereoViewCallback(function(device, view_index)
        if view_index ~= 0 then return end
        local fn = rawget(_G, "__sh2_rifle_visual_tick")
        if type(fn) == "function" then
            fn()
        end
    end)

    uevrUtils.registerPreLevelChangeCallback(function()
        local fn = rawget(_G, "__sh2_rifle_on_level_change")
        if type(fn) == "function" then
            fn()
        end
    end)

    uevrUtils.registerUEVRCallback("on_client_restart", function()
        local fn = rawget(_G, "__sh2_rifle_on_level_change")
        if type(fn) == "function" then
            fn()
        end
    end)

    vr_globals.compat.on_script_reset(function()
        pcall(restore_prepare_anim_data, "script_reset", true)
        local fn = rawget(_G, "__sh2_rifle_on_level_change")
        if type(fn) == "function" then
            fn()
        end
        _G.__sh2_rifle_reload_initialized = nil
        _G.__sh2_rifle_code_rev = nil
    end)

    _G.__sh2_rifle_reload_initialized = true
    _G.__sh2_rifle_reload = M
    print("[RIFLE_RELOAD] indirection tick registered (CODE_REV=" .. tostring(CODE_REV) .. ")")
    print_log("rifle_reload loaded (CODE_REV=8: was_empty/strategy-E disabled; empty fire also mark_needs_bolt so bolt can open for reload)", LogLevel.Info)

    return M
end

-- 单独热重载本文件时 main 不会再调 init：文件末尾自调
M.init()

return M