local module_name = "UEVR_00_init_globals"
if package.loaded[module_name] ~= nil then
    return package.loaded[module_name]
end

-- UEVR_00_init_globals.lua
-- 两件事：
--   1) compat —— UEVR Lua 环境适配层（回调 / VR 句柄 / json / log / debug 兜底）。
--      其它文件统一用：local compat = require("UEVR_00_init_globals").compat
--   2) vr_globals —— VR 运行时全局状态的只读访问层（沿用 REVR 版语义）。
--
-- 该文件文件名以 UEVR_00 开头，UEVR auto-run 时最先执行，保证 shim 在其它模块之前装好。
--
-- Consumers:
--   UEVR_09_Immersion_Enhancer_SH2.lua -> KEYS.weapon_slot_*, KEYS.last_slot_haptic_class,
--                                         isTwoHandingWeapon()（副手空闲判定、syncTwoHandAim）
--                                         KEYS.rifle_bolt_busy / KEYS.mag_in_left_hand
--                                         （useLeftDown 守卫：拉栓或左手持弹时禁 Key.E）
--                                         KEYS.remote_grab_whitelist_hit（gripLeft→E 条件）
--   pistol_reload.lua                  -> KEYS.current_weapon_type, KEYS.equipped_weapon（入口守卫 + 换枪检测）
--   shotgun_reload.lua / rifle_reload.lua -> KEYS.mag_* / slide_locked / dry_fire_edge 等
--   remote_grab.lua                    -> KEYS.remote_grab_e_edge / store_edge / whitelist_hit / left_prop_active
--   libs/accessories.lua               -> g_is_two_handing_weapon（左手 activeLeftAccessory 非 nil 时 true）
--                                       g_block_closed_hands_dock（消费：proximity 跳过 closed_hands；发布见 pistol_reload）
--                                       KEYS.rifle_bolt_* / KEYS.mag_in_left_hand（registerGripBlock）
--   UEVR_10_HapticFeedback.lua         -> KEYS.current_weapon_*, haptic_routing_mode, leon_grenade
--   UEVR_12_diagnose.lua               -> getWeaponId, getHapticRoutingMode, isPullpinActive,
--                                         isTwoHandingWeapon()（诊断面板显示 two_handing_weapon）
-- Publishers:
--   UEVR_09 -> pullpin_active, __vr_weapon_slot_*, __vr_last_slot_haptic_class, aim_active,
--              g_mag_drop_edge（右手 VR B 短按退弹）
--              g_remote_grab_e_edge / g_remote_grab_store_edge（左手激光白名单拾取 / 左肩存放）
--   remote_grab.lua -> g_remote_grab_whitelist_hit / g_remote_grab_left_prop_active
--   libs/accessories.lua -> g_is_two_handing_weapon（左手 activeLeftAccessory 非 nil 时 true）
--   pistol_reload.lua -> g_block_closed_hands_dock（发布：mag_in_left_hand 或 slide-in 期间 true）
--                       g_mag_in_left_hand / g_slide_locked 等（手枪）
--   shotgun_reload.lua -> g_mag_in_left_hand / g_manual_reload_active 等（霰弹）
--   rifle_reload.lua  -> g_mag_in_left_hand / g_slide_locked；
--                       KEYS.rifle_bolt_busy / rifle_bolt_open / rifle_bolt_detach_cooldown
--   UEVR_04 -> resetRuntimeGlobals()（输入通道重启时调用）
--   UEVR_10 -> __vr_current_weapon_*, leon_grenade
--   main.lua -> __sh2_current_weapon_type, __sh2_equipped_weapon（武器类型与对象，~200ms 发布）

-- =============================================================================
-- [COMPAT] UEVR 环境适配层
-- =============================================================================

local compat = {}

-- UEVR 的 json 是全局表，提供 dump_string/load_string/dump_file/load_file，
-- 但没有 REFramework 风格的 encode/decode；这里补上别名。
function compat.install_json_shim()
    if json == nil then
        return
    end
    if type(json.encode) ~= "function" and type(json.dump_string) == "function" then
        json.encode = function(value, indent) return json.dump_string(value, indent) end
    end
    if type(json.decode) ~= "function" and type(json.load_string) == "function" then
        json.decode = function(text) return json.load_string(text) end
    end
end

-- UEVR sandbox 没有 REFramework 的全局 log 表，用 print 兜底（逐个方法补齐，兼容已有部分 log 表）。
function compat.install_log_shim()
    if type(rawget(_G, "log")) ~= "table" then
        _G.log = {}
    end
    local writer = (type(print) == "function") and print or function() end
    local levels = { "info", "warn", "error", "debug" }
    for _, level in ipairs(levels) do
        if type(_G.log[level]) ~= "function" then
            _G.log[level] = function(msg)
                writer("[UEVR Gestures][" .. level .. "] " .. tostring(msg))
            end
        end
    end
end

-- debug.traceback 在 UEVR 沙盒里不保证存在；xpcall 处理器要用到。
function compat.install_debug_shim()
    if type(rawget(_G, "debug")) ~= "table" then
        _G.debug = {}
    end
    if type(_G.debug.traceback) ~= "function" then
        _G.debug.traceback = function(message) return tostring(message or "") end
    end
end

-- --- 回调封装：把 REFramework 的 re.on_* 映射到 uevr.sdk.callbacks.* ---

function compat.get_callbacks()
    if uevr ~= nil and uevr.sdk ~= nil and uevr.sdk.callbacks ~= nil then
        return uevr.sdk.callbacks
    end
    return nil
end

function compat.on_draw_ui(fn)
    local callbacks = compat.get_callbacks()
    if callbacks ~= nil and type(callbacks.on_draw_ui) == "function" then
        callbacks.on_draw_ui(fn)
        return true
    end
    return false
end

function compat.on_script_reset(fn)
    local callbacks = compat.get_callbacks()
    if callbacks ~= nil and type(callbacks.on_script_reset) == "function" then
        callbacks.on_script_reset(fn)
        return true
    end
    return false
end

function compat.on_frame(fn)
    local callbacks = compat.get_callbacks()
    if callbacks ~= nil and type(callbacks.on_frame) == "function" then
        callbacks.on_frame(fn)
        return true
    end
    return false
end

function compat.on_pre_engine_tick(fn)
    local callbacks = compat.get_callbacks()
    if callbacks ~= nil and type(callbacks.on_pre_engine_tick) == "function" then
        callbacks.on_pre_engine_tick(fn)
        return true
    end
    return false
end

function compat.on_post_engine_tick(fn)
    local callbacks = compat.get_callbacks()
    if callbacks ~= nil and type(callbacks.on_post_engine_tick) == "function" then
        callbacks.on_post_engine_tick(fn)
        return true
    end
    return false
end

-- --- VR 句柄/数据访问 ---

function compat.get_vr()
    if uevr ~= nil and uevr.params ~= nil and uevr.params.vr ~= nil then
        return uevr.params.vr
    end
    return nil
end

function compat.is_uevr()
    return compat.get_vr() ~= nil
end

-- UEVR 的 get_action_handle / get_*_joystick_source 在句柄无效时返回 0。
function compat.is_valid_handle(handle)
    if handle == nil or handle == false then
        return false
    end

    local handle_type = type(handle)
    if handle_type == "number" then
        return handle ~= 0
    end

    if handle_type == "userdata" then
        local hex = tostring(handle):match("0x(%x+)")
        if hex ~= nil then
            return tonumber(hex, 16) ~= 0
        end
        return true
    end

    return true
end

-- 预分配 UEVR 数据类型（get_pose / get_joystick_axis 是 out 参数，必须传 userdata）。
function compat.new_vector3f()
    if Vector3f ~= nil and type(Vector3f.new) == "function" then
        return Vector3f.new(0.0, 0.0, 0.0)
    end
    return nil
end

function compat.new_quaternionf()
    if Quaternionf ~= nil and type(Quaternionf.new) == "function" then
        return Quaternionf.new(0.0, 0.0, 0.0, 1.0)
    end
    return nil
end

function compat.new_vector2f()
    if Vector2f ~= nil and type(Vector2f.new) == "function" then
        return Vector2f.new(0.0, 0.0)
    end
    return nil
end

compat.install_json_shim()
compat.install_log_shim()
compat.install_debug_shim()

-- =============================================================================
-- [GLOBALS] VR 运行时全局状态（只读访问层）
-- =============================================================================

local KEYS = {
    current_weapon_id = "__vr_current_weapon_id",
    current_weapon_display_name = "__vr_current_weapon_display_name",
    haptic_routing_mode = "__vr_haptic_routing_mode",
    last_slot_haptic_class = "__vr_last_slot_haptic_class",
    weapon_slot_region = "__vr_weapon_slot_region",
    weapon_slot_binding = "__vr_weapon_slot_binding",
    weapon_slot_key = "__vr_weapon_slot_key",
    weapon_slot_source = "__vr_weapon_slot_source",
    weapon_slot_at = "__vr_weapon_slot_at",
    two_handing_weapon = "g_is_two_handing_weapon",  -- 保留兼容（已不再由 accessories 发布）
    left_accessory_attached = "g_left_accessory_attached",
    active_left_accessory_label = "g_active_left_accessory_label",
    left_grip_held = "g_left_grip_held",
    heal_active = "g_is_heal_active",
    pullpin_active = "pullpin_active",
    aim_active = "g_is_aim_active",
    leon_grenade = "leon_grenade",
    manual_reload_active = "g_manual_reload_active",
    mag_dropped = "g_mag_dropped",
    mag_in_left_hand = "g_mag_in_left_hand",
    needs_rack = "g_needs_rack",
    block_closed_hands_dock = "g_block_closed_hands_dock",
    mag_grab_edge = "g_mag_grab_edge",
    mag_drop_edge = "g_mag_drop_edge",
    mag_grab_release = "g_mag_grab_release",
    mag_inserted = "g_mag_inserted",
    -- 治疗系统：spawn/despawn 对称 4 信号（分手机制，09 文件发布 → heal.lua 消费）
    heal_spawn_left_edge = "g_heal_spawn_left_edge",
    heal_spawn_right_edge = "g_heal_spawn_right_edge",
    heal_despawn_left_edge = "g_heal_despawn_left_edge",
    heal_despawn_right_edge = "g_heal_despawn_right_edge",
    -- 治疗系统：分手道具状态（heal.lua 发布，09 文件守卫读取）
    heal_left_prop_active = "g_heal_left_prop_active",
    heal_right_prop_active = "g_heal_right_prop_active",
    -- Phase 5: 空仓挂机（slide lock）状态
    slide_locked = "g_slide_locked",
    -- 右扳机默认状态扣动（空仓挂机时 dry fire 信号）
    dry_fire_edge = "g_dry_fire_edge",
    -- 步枪拉栓：rifle_reload 发布；UEVR_09 useLeftDown / accessories grip_block 消费
    rifle_bolt_busy = "g_rifle_bolt_busy",                 -- bolt_active 或左手握栓
    rifle_bolt_open = "g_rifle_bolt_open",                 -- 开栓且表演枪栓有效（挡 Holder）
    rifle_bolt_detach_cooldown = "g_rifle_bolt_detach_cooldown", -- 拉栓完成后短暂冷却
    -- 武器类型与对象：由 main.lua getWeaponMesh() 发布（~200ms），供其他模块直接读取
    current_weapon_type = "__sh2_current_weapon_type",
    equipped_weapon = "__sh2_equipped_weapon",
    -- §17: 手动收枪信号（UEVR_09 发布 → DLL sh2:allow_unequip_once 消费）
    manual_unequip_signal = "__sh2_manual_unequip_signal",
    -- 左手激光白名单拾取（remote_grab.lua）
    remote_grab_whitelist_hit = "g_remote_grab_whitelist_hit", -- remote_grab 发布；09 gripLeft 读取
    remote_grab_e_edge = "g_remote_grab_e_edge",             -- 09 发布；remote_grab 消费
    remote_grab_store_edge = "g_remote_grab_store_edge",     -- 09 左肩 store 发布；remote_grab 消费
    remote_grab_left_prop_active = "g_remote_grab_left_prop_active", -- remote_grab 发布；互斥守卫
}

local function ensure_bool_default(key)
    if rawget(_G, key) == nil then
        _G[key] = false
    end
end

local function ensure_global_default(key, default_value)
    if rawget(_G, key) == nil then
        _G[key] = default_value
    end
end

ensure_global_default(KEYS.current_weapon_id, "")
ensure_global_default(KEYS.current_weapon_display_name, "")
-- =============================================================================
-- 【HAPTIC_ROUTING_MODE】武器震动路由模式
--   0 = 按武器ID分类（需从游戏内存读取武器ID，UEVR 第一阶段一般读不到）
--   1 = 按武器槽位分类（从 UEVR_09 手势槽位获取，默认）
-- =============================================================================
ensure_global_default(KEYS.haptic_routing_mode, 1)
ensure_global_default(KEYS.last_slot_haptic_class, "Pistol")
ensure_global_default(KEYS.weapon_slot_region, "none")
ensure_global_default(KEYS.weapon_slot_binding, "none")
ensure_global_default(KEYS.weapon_slot_key, "none")
ensure_global_default(KEYS.weapon_slot_source, "none")
ensure_global_default(KEYS.weapon_slot_at, 0.0)

ensure_bool_default(KEYS.two_handing_weapon)
ensure_bool_default(KEYS.left_accessory_attached)
ensure_global_default(KEYS.active_left_accessory_label, nil)
ensure_bool_default(KEYS.left_grip_held)
ensure_bool_default(KEYS.heal_active)
ensure_bool_default(KEYS.pullpin_active)
ensure_bool_default(KEYS.aim_active)
ensure_bool_default(KEYS.manual_reload_active)
ensure_bool_default(KEYS.mag_dropped)
ensure_bool_default(KEYS.mag_in_left_hand)
ensure_bool_default(KEYS.needs_rack)
ensure_bool_default(KEYS.block_closed_hands_dock)
ensure_bool_default(KEYS.mag_grab_edge)
ensure_bool_default(KEYS.mag_drop_edge)
ensure_bool_default(KEYS.mag_grab_release)
ensure_bool_default(KEYS.mag_inserted)
-- 治疗系统 4 个 edge 信号 + 2 个分手道具状态
ensure_bool_default(KEYS.heal_spawn_left_edge)
ensure_bool_default(KEYS.heal_spawn_right_edge)
ensure_bool_default(KEYS.heal_despawn_left_edge)
ensure_bool_default(KEYS.heal_despawn_right_edge)
ensure_bool_default(KEYS.heal_left_prop_active)
ensure_bool_default(KEYS.heal_right_prop_active)
ensure_bool_default(KEYS.slide_locked)
ensure_bool_default(KEYS.dry_fire_edge)
ensure_bool_default(KEYS.rifle_bolt_busy)
ensure_bool_default(KEYS.rifle_bolt_open)
ensure_bool_default(KEYS.rifle_bolt_detach_cooldown)
ensure_global_default(KEYS.current_weapon_type, "none")
ensure_global_default(KEYS.equipped_weapon, nil)
ensure_bool_default(KEYS.manual_unequip_signal)
ensure_bool_default(KEYS.remote_grab_whitelist_hit)
ensure_bool_default(KEYS.remote_grab_e_edge)
ensure_bool_default(KEYS.remote_grab_store_edge)
ensure_bool_default(KEYS.remote_grab_left_prop_active)

-- 输入通道 reset 时只清瞬态 motion/输入标志；武器 ID、槽位、震动路由等上下文保留。
local RUNTIME_RESET_DEFAULTS = {
    [KEYS.two_handing_weapon] = false,
    [KEYS.left_accessory_attached] = false,
    [KEYS.active_left_accessory_label] = nil,
    [KEYS.left_grip_held] = false,
    [KEYS.heal_active] = false,
    [KEYS.pullpin_active] = false,
    [KEYS.aim_active] = false,
    [KEYS.manual_reload_active] = false,
    [KEYS.mag_dropped] = false,
    [KEYS.mag_in_left_hand] = false,
    [KEYS.needs_rack] = false,
    [KEYS.block_closed_hands_dock] = false,
    [KEYS.mag_grab_edge] = false,
    [KEYS.mag_drop_edge] = false,
    [KEYS.mag_grab_release] = false,
    [KEYS.mag_inserted] = false,
    [KEYS.heal_spawn_left_edge] = false,
    [KEYS.heal_spawn_right_edge] = false,
    [KEYS.heal_despawn_left_edge] = false,
    [KEYS.heal_despawn_right_edge] = false,
    [KEYS.heal_left_prop_active] = false,
    [KEYS.heal_right_prop_active] = false,
    [KEYS.slide_locked] = false,
    [KEYS.dry_fire_edge] = false,
    [KEYS.rifle_bolt_busy] = false,
    [KEYS.rifle_bolt_open] = false,
    [KEYS.rifle_bolt_detach_cooldown] = false,
    [KEYS.manual_unequip_signal] = false,
    [KEYS.remote_grab_whitelist_hit] = false,
    [KEYS.remote_grab_e_edge] = false,
    [KEYS.remote_grab_store_edge] = false,
    [KEYS.remote_grab_left_prop_active] = false,
}

local vr_globals = {
    KEYS = KEYS,
    compat = compat,
}

function vr_globals.resetRuntimeGlobals()
    for key, default_value in pairs(RUNTIME_RESET_DEFAULTS) do
        _G[key] = default_value
    end
end

function vr_globals.getWeaponId()
    local weapon_id = rawget(_G, KEYS.current_weapon_id)
    if type(weapon_id) == "string" and weapon_id ~= "" then
        return weapon_id
    end
    return nil
end

function vr_globals.getCurrentWeaponDisplayName()
    local display_name = rawget(_G, KEYS.current_weapon_display_name)
    if type(display_name) == "string" and display_name ~= "" then
        return display_name
    end
    return nil
end

function vr_globals.getHapticRoutingMode()
    return tonumber(rawget(_G, KEYS.haptic_routing_mode)) or 0
end

function vr_globals.getLastSlotHapticClass()
    return rawget(_G, KEYS.last_slot_haptic_class)
end

function vr_globals.getLastWeaponSlotEvent()
    return {
        region = rawget(_G, KEYS.weapon_slot_region),
        binding = rawget(_G, KEYS.weapon_slot_binding),
        key = rawget(_G, KEYS.weapon_slot_key),
        source = rawget(_G, KEYS.weapon_slot_source),
        at = rawget(_G, KEYS.weapon_slot_at),
    }
end

-- 2026-07-28：基于 active_left_accessory_label 判断，而非旧的 g_is_two_handing_weapon
-- 只有 Holder/foregrip 类 marker 才算双手持枪（装弹/拉栓不算）
local TWO_HAND_LABELS = {
    ["Holder"] = true,
    ["foregrip"] = true,
    ["performance foregrip (bolt)"] = true,
    ["performance foregrip (pump)"] = true,
}

function vr_globals.isTwoHandingWeapon()
    local label = rawget(_G, KEYS.active_left_accessory_label)
    return label ~= nil and TWO_HAND_LABELS[label] == true
end

function vr_globals.getActiveLeftAccessoryLabel()
    return rawget(_G, KEYS.active_left_accessory_label)
end

function vr_globals.isLeftAccessoryAttached()
    return rawget(_G, KEYS.left_accessory_attached) == true
end

-- 2026-07-29：左手 grip 按下状态（由 UEVR_09 gripLeft.action 的 enter/leave 维护）
-- 供 RE_12 诊断显示与 syncTwoHandAim 前置检查使用
function vr_globals.isLeftGripHeld()
    return rawget(_G, KEYS.left_grip_held) == true
end

function vr_globals.isHealActive()
    return rawget(_G, KEYS.heal_active) == true
end

function vr_globals.isMotionPaused()
    return rawget(_G, KEYS.motion_paused) == true
end

function vr_globals.isPullpinActive()
    return rawget(_G, KEYS.pullpin_active) == true
end

function vr_globals.isAimActive()
    return rawget(_G, KEYS.aim_active) == true
end

function vr_globals.isManualReloadActive()
    return rawget(_G, KEYS.manual_reload_active) == true
end

function vr_globals.isMagDropped()
    return rawget(_G, KEYS.mag_dropped) == true
end

function vr_globals.isMagInLeftHand()
    return rawget(_G, KEYS.mag_in_left_hand) == true
end

function vr_globals.isRifleBoltBusy()
    return rawget(_G, KEYS.rifle_bolt_busy) == true
end

function vr_globals.isSlideLocked()
    return rawget(_G, KEYS.slide_locked) == true
end

-- 空仓挂机时禁止向游戏注入瞄准（RMB/LT），否则 AnimBP 会播换弹混合动画
-- 通用判断：所有枪械空仓挂机时均禁瞄准，不限于手枪（为霰弹枪等接入预留）
function vr_globals.isAimInputAllowed()
    return rawget(_G, KEYS.slide_locked) ~= true
end

-- 武器类型与对象（由 main.lua getWeaponMesh() 发布，~200ms）
function vr_globals.getCurrentWeaponType()
    return rawget(_G, KEYS.current_weapon_type) or "none"
end

function vr_globals.getEquippedWeapon()
    return rawget(_G, KEYS.equipped_weapon)
end

function vr_globals.isPistolEquipped()
    return rawget(_G, KEYS.current_weapon_type) == "pistol"
end

-- 仅供诊断面板查询的安全 stub：原 REVR 由游戏侧脚本发布这些全局，
-- 本移植不读取引擎内存，缺省返回安全值，避免诊断面板报错。
function vr_globals.isSupportDocked()
    return rawget(_G, "g_is_support_docked") == true
end

function vr_globals.isTwoHandAimingActive()
    return rawget(_G, "g_is_two_hand_aiming_active") == true
end

function vr_globals.getLastPlayerDamage()
    local damage = rawget(_G, "__vr_last_player_damage")
    if type(damage) == "table" then
        return damage
    end
    return {}
end

package.loaded[module_name] = vr_globals

return vr_globals
