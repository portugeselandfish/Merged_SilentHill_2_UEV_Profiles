--[[修改说明：
1. 远程抓取（Remote Grab）模块：通过左手激光射线检测白名单可拾取物（血瓶/注射器/弹药），按 E 键触发飞行抓取并附着到 hand_l_bn 插槽
2. L1/L2 两级缓存架构（对齐 open_latch.lua）：
   - L1：全图 ASHItem 枚举仅在关卡加载/pawn 变化/过场成功拾取后重建
   - L2：激光命中时从 L1 缓存纯数学锥体筛选，不再触发引擎枚举
3. 任何销毁表演体路径（shoulder store / flight finish fail / flight mesh lost / holding mesh lost）均不触发 L1 重建：
   - 世界 ASHItem 本体仅在成功拾取瞬时被引擎销毁，此刻飞行开始（begin_prop_flight）从 L1 定点移除该项（见 6）。
   - 其余销毁分支只涉及表演体（显示 mesh），与世界本体无关，重扫属冗余空跑，故全部取消其重建。
4. [RM 停用] Root Motion 禁制（拾取飞行期间抑制 root motion）实测不生效，故整体停用：
   - monitor_item_flight_root_motion 保留为仅骨架的空模板（函数体已用 Lua 块注释包裹），供以后优化复用；
   - start_item_rm_disable / restore_item_rm 定义及各调用点全部注释，pre/post tick 注册块一并注释。
5. [性能] load_attachment_params 的 JSON 回退分支增加附件参数缓存：
   - 删除了"每帧 json.load_file + 线性扫描"（attachments_parameters.json 属静态配置，读一次后按 attachment_id 缓存复用）；
   - configui 面板命中分支保持实时查询、不缓存，避免面板改动后不生效。
6. [性能] 拾取成功（begin_prop_flight）不再同步全图重建 L1，改为从 L1 定点移除被拾取项（O(n) 纯内存，替代全图扫描）：
   - 被拾取物品本体已被引擎销毁、激光不可命中，不会再次触发拾取，故无需"已拾取"标记（2026-09-04 用户定案）。
]]--

--[[修改说明（2026-09-04，统一 pawn 检测，方案A）：
1. pawn 变化检测上移到 main.lua（check_pawn_globally 广播 on_pawn_changed）。
2. check_cache_invalidation 删除自检测 pawn 块，只保留 L1 重建调度执行 + 2s 重试。
3. 删除自注册 UEVR on_level_change 回调，改由 main 统一转发到新 M.on_level_change（销毁表演体+清 L1+重建）。
4. 新增 M.on_pawn_changed(reason)：pawn_nil 清 pending/retry；pawn_changed/level_change 调度重建。不新增诊断日志。
]]--

-- =============================================================================
-- 依赖引入
-- =============================================================================
local uevrUtils = require("libs/uevr_utils")      -- UEVR 引擎工具函数
local attachments = require("libs/attachments")    -- 附件挂载/卸载
local controllers = require("libs/controllers")    -- 手部控制器
local interaction = require("libs/interaction")    -- 激光射线交互
local reload_tools = require("libs/reload_tools") -- 装弹工具（组件位置/旋转）
local mathLib = require("libs/core/math_lib")      -- 数学库（四元数/变换）
local configui = require("libs/configui")          -- UI 配置面板
local hands = require("libs/hands")                -- 手部动画/姿态
local ik = require("libs/ik")                      -- IK 骨骼控制
local vr_globals = require("UEVR_00_init_globals")  -- 全局变量注册表
local compat = vr_globals.compat                   -- 兼容性 API
local event_feedback = nil
pcall(function()
    event_feedback = require("UEVR_11_EventFeedback") -- 触觉反馈
end)

local M = {}

-- =============================================================================
-- 常量定义
-- =============================================================================
local CACHE_INTERVAL = 0.20                    -- 缓存更新节流间隔（秒）
local AWAIT_BODY_TIMEOUT = 2.00                 -- 等待 ItemContext Mesh 超时（秒）
local FLIGHT_DURATION = 0.30                    -- 表演体飞行时长（秒）
local SHITEM_CLASS = "Class /Script/SHProto.SHItem" -- ASHItem 基类路径（全图枚举用）

-- 锥体回退参数（射线常打墙/地，沿射线锥体范围内找白名单物品）
local CONE_HALF_ANGLE_DEG = 14.0                -- 锥体半角（度）
local CONE_MIN_RADIUS = 30.0                   -- 近端最小半径（cm，防止射线起点太窄）
local CONE_MAX_RADIUS_DEFAULT = 280.0          -- 远端最大半径默认值（cm）
local cone_max_radius = CONE_MAX_RADIUS_DEFAULT -- 当前生效的远端最大半径（可 UI 调）

-- 枚举只认角色附近（实测引擎最远拾取约185cm，留余量到300cm）
local ENUM_MAX_RANGE_CM = 300.0
local ENUM_MAX_RANGE_CM2 = ENUM_MAX_RANGE_CM * ENUM_MAX_RANGE_CM -- 平方比较用

local LEFT_ATTACH_SOCKET = "hand_l_bn"          -- 左手附着插槽名

-- =============================================================================
-- 配置加载/保存（JSON 文件持久化）
-- =============================================================================
local CONFIG_REL = "remote_grab_config.json"    -- 配置文件相对路径
local feature_enabled = true                    -- 功能总开关
local gripleft_release_store_enabled = false    -- 松开左抓握键入包（默认关闭）
local rg_config = nil                           -- 配置表
local rg_json = nil                             -- JSON 库引用

-- 获取 JSON 库
local function get_rg_json()
    if rg_json ~= nil then
        return rg_json
    end
    local ok, mod = pcall(require, "json")
    if ok then
        rg_json = mod
    end
    return rg_json
end

-- 加载配置文件
local function load_rg_config()
    local json = get_rg_json()
    if json == nil or json.load_file == nil then
        return {}
    end
    local ok, cfg = pcall(json.load_file, CONFIG_REL)
    if ok and type(cfg) == "table" then
        return cfg
    end
    return {}
end

-- 保存配置文件
local function save_rg_config()
    local json = get_rg_json()
    if json == nil or json.dump_file == nil or type(rg_config) ~= "table" then
        return
    end
    pcall(json.dump_file, CONFIG_REL, rg_config)
end

-- 应用配置到运行时变量
local function apply_rg_config()
    if type(rg_config) ~= "table" then
        rg_config = {}
    end
    if rg_config.enabled == nil then
        rg_config.enabled = true
    end
    if type(rg_config.cone_max_radius) ~= "number" then
        rg_config.cone_max_radius = CONE_MAX_RADIUS_DEFAULT
    end
    if rg_config.gripleft_release_store == nil then
        rg_config.gripleft_release_store = false
    end
    feature_enabled = rg_config.enabled ~= false
    cone_max_radius = rg_config.cone_max_radius
    -- 限制范围：CONE_MIN_RADIUS ~ 800cm
    if cone_max_radius < CONE_MIN_RADIUS then
        cone_max_radius = CONE_MIN_RADIUS
    elseif cone_max_radius > 800 then
        cone_max_radius = 800
    end
    rg_config.cone_max_radius = cone_max_radius
    gripleft_release_store_enabled = rg_config.gripleft_release_store == true
end

-- 模块加载时立即读取并应用配置
rg_config = load_rg_config()
apply_rg_config()

-- 对外接口：查询功能是否启用
function M.is_enabled()
    return feature_enabled == true
end

-- =============================================================================
-- 全局变量 Key 定义（在 UEVR_00_init_globals.KEYS 中登记）
-- =============================================================================
local KEY_WHITELIST_HIT = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_whitelist_hit) or "g_remote_grab_whitelist_hit"
local KEY_E_EDGE = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_e_edge) or "g_remote_grab_e_edge"
local KEY_STORE_EDGE = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_store_edge) or "g_remote_grab_store_edge"
local KEY_PROP_ACTIVE = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_left_prop_active) or "g_remote_grab_left_prop_active"
local KEY_HEAL_LEFT = (vr_globals.KEYS and vr_globals.KEYS.heal_left_prop_active) or "g_heal_left_prop_active"
local KEY_MAG_LEFT = (vr_globals.KEYS and vr_globals.KEYS.mag_in_left_hand) or "g_mag_in_left_hand"

-- =============================================================================
-- 白名单物品数据定义
-- =============================================================================

-- 每种可拾取物的 Attachment ID（与右手 ItemBase 同源）
local PROP_ATTACHMENT_IDS = {
    health_drink = "ItemBase_BP_C_HealthDrink_01_B",
    syringe = "ItemBase_BP_C_Syringe_03_A",
    handgun_ammo = "ItemBase_BP_C_HandgunAmmoClosed_01_A",
    shotgun_ammo = "ItemBase_BP_C_ShotgunAmmo_01_B",
    rifle_ammo = "ItemBase_BP_C_SniperRifleAmmo_01_A",
}

-- 每种物品的备用 Mesh 路径（用于 spawn 表演体时找不到 mesh_asset 的兜底）
local FALLBACK_MESH_PATHS = {
    health_drink = "/Game/Game/Art/Items/HealthDrink/HealthDrink_01_B.HealthDrink_01_B",
    syringe = "/Game/Game/Art/Items/Syringe/Syringe_03_C.Syringe_03_C",
    handgun_ammo = "/Game/Game/Art/Items/HandgunAmmo/HandgunAmmoClosed_01_A.HandgunAmmoClosed_01_A",
    shotgun_ammo = "/Game/Game/Art/Items/ShotgunAmmo/ShotgunAmmo_01_B.ShotgunAmmo_01_B",
    rifle_ammo = "/Game/Game/Art/Items/SniperRifleAmmo/SniperRifleAmmo_01_A.SniperRifleAmmo_01_A",
}

-- 每种物品在左手持有状态下的手部动画
local PROP_HAND_ANIMATIONS = {
    health_drink = "drink_potion",
    handgun_ammo = "ammo_box",
    shotgun_ammo = "ammo_box",
    rifle_ammo = "ammo_box",
}

-- 手部类型枚举（与 main.lua / pistol_reload 相同）
local HandsType = {
    None = 1,       -- 默认
    Forearms = 2,   -- 前臂
    IKArms = 3,     -- IK 手臂
}

-- 状态机枚举（远程抓取流程的四个阶段）
local State = {
    Idle = "idle",              -- 空闲：等待激光命中
    AwaitBody = "await_body",   -- 等待 ItemContext Mesh 就绪
    Flying = "flying",          -- 飞行：表演体从命中点飞到左手
    Holding = "holding",        -- 持有：表演体附着在左手
}

-- =============================================================================
-- 运行时状态（M._state）
-- =============================================================================
M._state = {
    phase = State.Idle,                         -- 当前状态机阶段
    last_cache_t = 0,                           -- 上次缓存更新时间戳
    hit_valid = false,                          -- 命中缓存是否有效
    hit_prop_type = nil,                        -- 命中物品的白名单类型
    hit_actor = nil,                            -- 命中的 ASHItem Actor
    hit_component = nil,                        -- 命中的 StaticMeshComponent
    hit_mesh_asset = nil,                       -- 命中的 StaticMesh 资源
    hit_loc = nil,                              -- 命中位置（世界坐标）
    hit_rot = nil,                              -- 命中旋转
    pending = nil,                              -- 待处理物品数据（AwaitBody 阶段）
    body_mesh = nil,                            -- 本体 Mesh（用于隐藏）
    actor = nil,                                -- 表演体 Actor（spawn 出来的）
    mesh_comp = nil,                            -- 表演体 StaticMeshComponent
    prop_type = nil,                            -- 当前持有物品类型
    attachment_id = nil,                        -- 当前 Attachment ID
    flight_start_t = nil,                       -- 飞行开始时间
    flight_start_loc = nil,                     -- 飞行起点位置
    flight_start_rot = nil,                     -- 飞行起点旋转
    -- 左肩 store：先藏再下一帧 Destroy，避免同帧卸挂+Destroy 叠卡
    pending_destroy_actor = nil,
    -- L1/L2 两级缓存（对齐 open_latch.lua）
    l1_cache = nil,             -- L1 全量白名单物品缓存（数组）
    l1_cache_valid = false,     -- L1 缓存是否有效
    l1_rebuild_pending = false, -- L1 重建是否挂起
    l1_rebuild_time = nil,      -- L1 重建调度时间
    l1_retry_pending = false,   -- L1 重试是否挂起
    l1_retry_time = nil,        -- L1 重试调度时间
    l1_skip_empty_retry = false, -- 过场结束重建置位：本次结果为空时跳过 2s 重试（仅过场路径用）
    last_pawn_ref = nil,        -- 上次 pawn 引用（用于检测 pawn 变化）
    -- 附件参数缓存：key=attachment_id -> {location,rotation,scale}（仅缓存 JSON 回退分支的静态结果，
    -- configui 面板命中分支保持实时查询，不缓存，避免面板改动不生效）
    attachment_params_cache = {},
    -- Root Motion 禁制（物品拾取飞行期间抑制 root motion）
    rm_active = false,          -- 当前是否每帧强制 IgnoreRootMotion
    rm_needs_reset = false,     -- 是否变更过 RM，需在退出时恢复 RM=3
    rm_anim_montage_c = nil,    -- AnimMontage 类缓存（避免每帧 find_uobject）
    -- 注：不设 rm_tick_registered：热重载后 M._state 重建字段失效，防重标志放 _G（见 tick 注册节）
}

-- =============================================================================
-- 基础工具函数
-- =============================================================================

-- 复用的射线命中结果缓冲（避免每帧分配新对象）
local reusable_hit = rawget(_G, "reusable_hit_result")

-- 日志打印（已禁用：严禁主脚本打印日志到 UEVR 控制台，用户定案 2026-09-05）
-- 保留为空函数，避免改动所有调用点；如需排障请改用专用诊断脚本输出。
local function print_log(msg, level) end

-- 设置全局布尔变量（用于跨模块通信）
local function set_global_bool(key, value)
    pcall(function()
        _G[key] = value == true
    end)
end

-- 发布命中缓存有效状态（写入全局变量 + 更新本地状态）
local function publish_hit_valid(valid)
    set_global_bool(KEY_WHITELIST_HIT, valid == true)
    M._state.hit_valid = valid == true
end

-- 发布道具激活状态（写入全局变量）
local function publish_prop_active(active)
    set_global_bool(KEY_PROP_ACTIVE, active == true)
end

-- 检测左手是否被其他功能占用（治疗/装弹/远程抓取本身）
local function left_hand_occupied()
    if rawget(_G, KEY_HEAL_LEFT) == true then
        return true
    end
    if rawget(_G, KEY_MAG_LEFT) == true then
        return true
    end
    if rawget(_G, KEY_PROP_ACTIVE) == true then
        return true
    end
    return false
end

-- =============================================================================
-- Root Motion 禁制（物品拾取飞行期间抑制 root motion）—— 已停用模板
-- 实测不生效，故禁用全部 RM 相关功能。以下为一个模板占位，供以后复用参考：
-- 原方案参考 unlock_door.lua monitor_door_montage_root_motion：pre+post 双 tick，
-- 第一道每帧 SetRootMotionMode(1)，第二道全表扫描 /Engine/Transient.AnimMontage_*
-- 关 translation/rotation，共享资产不动以避免污染别的动画。
-- 若未来要启用：删除下方 monitor 函数体前的 --[[ 与结尾 ]]--，并恢复
-- start_item_rm_disable / restore_item_rm 两段定义及各调用点（见全文注释标记）。
-- =============================================================================

---- 开启禁制：置 rm_active，采样期间每帧强制 IgnoreRootMotion
--local function start_item_rm_disable()
--    M._state.rm_active = true
--    M._state.rm_needs_reset = true
--end
--
---- 恢复 RM=3（游戏默认 RootMotionFromMontagesOnly），并停止采样
--local function restore_item_rm()
--    if M._state.rm_needs_reset then
--        pcall(function()
--            local pawn = uevrUtils.get_local_pawn()
--            if pawn ~= nil and pawn.Mesh ~= nil then
--                local anim_instance = pawn.Mesh.AnimScriptInstance
--                if anim_instance ~= nil then
--                    anim_instance:SetRootMotionMode(3) -- RootMotionFromMontagesOnly
--                end
--            end
--        end)
--        M._state.rm_needs_reset = false
--    end
--    M._state.rm_active = false
--end

-- [RM 模板] 每帧强制禁用 root motion（停用中，仅保留骨架，不产生任何副作用）
local function monitor_item_flight_root_motion()
    --[[
    if not M._state.rm_active then
        return
    end
    local pawn = uevrUtils.get_local_pawn()
    if pawn == nil or pawn.Mesh == nil then
        return
    end
    local anim_instance = pawn.Mesh.AnimScriptInstance
    if anim_instance == nil then
        return
    end

    -- 第一道：每帧强制 IgnoreRootMotion（ERootMotionMode:IgnoreRootMotion），覆盖游戏 AnimBP 的 per-frame 复位
    pcall(function()
        anim_instance:SetRootMotionMode(2) -- IgnoreRootMotion
    end)

    -- 第二道：全表扫描，对 Transient montage 直接关 translation/rotation
    local uevr = rawget(_G, "uevr")
    local api = uevr and uevr.api
    if api ~= nil then
        if M._state.rm_anim_montage_c == nil then
            pcall(function()
                M._state.rm_anim_montage_c = api:find_uobject("Class /Script/Engine.AnimMontage")
            end)
        end
        local AnimMontage_c = M._state.rm_anim_montage_c
        if AnimMontage_c ~= nil then
            local all_montages = nil
            pcall(function()
                all_montages = AnimMontage_c:get_objects_matching(false)
            end)
            if all_montages ~= nil then
                for _, montage in ipairs(all_montages) do
                    local name = nil
                    pcall(function() name = montage:get_full_name() end)
                    -- 只动 /Engine/Transient.AnimMontage_*，别动共享资产
                    if name and string.find(name, "/Engine/Transient.", 1, true) then
                        pcall(function()
                            if montage.bEnableRootMotionTranslation ~= nil then
                                montage.bEnableRootMotionTranslation = false
                            end
                            if montage.bEnableRootMotionRotation ~= nil then
                                montage.bEnableRootMotionRotation = false
                            end
                        end)
                    end
                end
            end
        end
    end
    ]]--
end

-- =============================================================================
-- 白名单分类与命名工具
-- =============================================================================

-- 根据名称关键词匹配白名单类型（healthdrink/syringe/ammo+细分）
local function classify_name(name)
    if type(name) ~= "string" or name == "" then
        return nil
    end
    local lower = string.lower(name)
    if string.find(lower, "healthdrink", 1, true) then
        return "health_drink"
    end
    if string.find(lower, "syringe", 1, true) then
        return "syringe"
    end
    if string.find(lower, "ammo", 1, true) then
        if string.find(lower, "shotgun", 1, true) then
            return "shotgun_ammo"
        end
        if string.find(lower, "sniper", 1, true) or string.find(lower, "rifle", 1, true) then
            return "rifle_ammo"
        end
        return "handgun_ammo"  -- 默认归类为手枪弹药
    end
    return nil  -- 不在白名单中
end

-- 设置左手持有动画（根据物品类型选择对应动画名）
local function set_left_hand_animation(prop_type_or_nil)
    local anim = nil
    if prop_type_or_nil ~= nil then
        anim = PROP_HAND_ANIMATIONS[prop_type_or_nil]
    end
    pcall(function()
        hands.setHoldingAttachment(Handed.Left, anim)
    end)
end

-- 从 Actor/MeshComponent/MeshAsset 的 FullName 中识别白名单类型
local function classify_actor_or_mesh(actor, mesh_comp, mesh_asset)
    local names = {}
    pcall(function()
        if actor ~= nil then
            names[#names + 1] = actor:get_full_name()
        end
    end)
    pcall(function()
        if mesh_comp ~= nil then
            names[#names + 1] = mesh_comp:get_full_name()
        end
    end)
    pcall(function()
        if mesh_asset ~= nil then
            names[#names + 1] = mesh_asset:get_full_name()
        end
    end)
    -- 依次尝试各层级的 FullName，命中任一即返回
    for i = 1, #names do
        local prop_type = classify_name(names[i])
        if prop_type ~= nil then
            return prop_type, names[i]
        end
    end
    return nil, names[1]  -- 未命中白名单时返回 nil + 第一个名称（用于日志）
end

-- =============================================================================
-- 变换与手部组件工具
-- =============================================================================

-- 复制向量（转调 mathLib.copyVector，保留本地名以兼容内部调用点 + rt_copy_*）
local function copy_vector(v)
    return mathLib.copyVector(v)
end

-- 复制 Rotator（转调 mathLib.copyRotator，保留本地名以兼容内部调用点 + rt_copy_*）
local function copy_rotator(r)
    return mathLib.copyRotator(r)
end

-- 解析左手组件（按手部类型选择控制器/手组件/IK 网格）
local function resolve_left_hand_component()
    local hands_type = configui.getValue("hands_type") or HandsType.None
    local comp = nil
    if hands_type == HandsType.None then
        comp = controllers.getController(Handed.Left)
    elseif hands_type == HandsType.Forearms then
        comp = hands.getHandComponent(Handed.Left)
    elseif hands_type == HandsType.IKArms then
        comp = ik.getCurrentMesh()
    else
        comp = controllers.getController(Handed.Left)
    end
    return uevrUtils.getValid(comp)
end

-- 加载 StaticMesh 资源（先按路径查找，再按 Class 查找）
local function load_static_mesh(mesh_path)
    local mesh = nil
    pcall(function()
        mesh = uevrUtils.find_required_object("StaticMesh " .. mesh_path)
    end)
    if mesh == nil then
        pcall(function()
            mesh = uevrUtils.find_instance_of("Class /Script/Engine.StaticMesh", mesh_path)
        end)
    end
    return mesh
end

-- =============================================================================
-- 附件参数加载与变换
-- =============================================================================

-- 加载附件偏移参数（从配置 UI 或 JSON 文件读取）
local function load_attachment_params(attachment_id)
    local defaults = {
        location = { 0.0, 0.0, 0.0 },
        rotation = { 0.0, 0.0, 0.0 },
        scale = { 1.0, 1.0, 1.0 },
    }
    if attachment_id == nil then
        return defaults
    end
    -- 优先从配置面板读取
    local prefix = "uevr_attachments_" .. attachment_id .. "_"
    local loc = configui.getValue(prefix .. "position")
    local rot = configui.getValue(prefix .. "rotation")
    local scale = configui.getValue(prefix .. "scale")
    if loc ~= nil and rot ~= nil then
        return {
            location = { loc.X or loc[1] or 0, loc.Y or loc[2] or 0, loc.Z or loc[3] or 0 },
            rotation = { rot.X or rot[1] or 0, rot.Y or rot[2] or 0, rot.Z or rot[3] or 0 },
            scale = scale and { scale.X or scale[1] or 1, scale.Y or scale[2] or 1, scale.Z or scale[3] or 1 }
                or defaults.scale,
        }
    end
    -- 回退：从 attachments_parameters.json 读取（静态配置，命中后缓存，避免每帧重复读盘+解析）
    local cache = M._state.attachment_params_cache
    local cached = cache[attachment_id]
    if cached ~= nil then
        return {
            location = { cached.location[1], cached.location[2], cached.location[3] },
            rotation = { cached.rotation[1], cached.rotation[2], cached.rotation[3] },
            scale = { cached.scale[1], cached.scale[2], cached.scale[3] },
        }
    end
    pcall(function()
        local params = json.load_file("attachments_parameters.json")
        if params ~= nil and params.attachmentOffsets ~= nil then
            for i = 1, #params.attachmentOffsets do
                local entry = params.attachmentOffsets[i]
                if entry ~= nil and entry.id == attachment_id then
                    defaults = {
                        location = entry.location or defaults.location,
                        rotation = entry.rotation or defaults.rotation,
                        scale = entry.scale or defaults.scale,
                    }
                    break
                end
            end
        end
    end)
    -- 无论是否命中都把结果写入缓存（文件静态，未命中即记默认值），下次直接命中缓存
    cache[attachment_id] = defaults
    return defaults
end

-- 构建附件选项（不保持世界位置，直接附加到插槽）
local function make_attach_options(attachment_id)
    return {
        detachFromOriginOnGrip = true,
        maintainWorldPositionOnDetachFromOrigin = false,
        detachFromParentOnRelease = true,
        maintainWorldPositionOnDetachFromParent = false,
        reattachToOriginOnRelease = false,
        restoreTransformToOriginOnReattach = false,
        useZeroTransformOnReattach = false,
        allowChildVisibilityHandling = false,
        allowChildHiddenInGameHandling = false,
        allowRenderInMainPassHandling = false,
        attachmentId = attachment_id,
    }
end

-- 应用附件变换（设置相对位置/旋转/缩放）
local function apply_prop_transform(comp, attachment_id)
    if comp == nil then
        return
    end
    local params = load_attachment_params(attachment_id)
    local loc = params.location or { 0, 0, 0 }
    local rot = params.rotation or { 0, 0, 0 }
    local scale = params.scale or { 1, 1, 1 }
    pcall(function()
        uevrUtils.set_component_relative_location(comp, uevrUtils.vector(loc))
        uevrUtils.set_component_relative_rotation(comp, uevrUtils.rotator(rot))
        uevrUtils.set_component_relative_scale(comp, uevrUtils.vector(scale))
    end)
end

-- =============================================================================
-- 飞行插值工具（表演体从命中点飞到左手）
-- =============================================================================

-- 位置线性插值（转调 mathLib.vectorLerp，保留本地名以兼容内部调用点）
local function flight_lerp_loc(a, b, t)
    return mathLib.vectorLerp(a, b, t)
end

-- 旋转最短路径插值（转调 mathLib.rotatorLerp，保留本地名以兼容内部调用点）
local function flight_lerp_rot(a, b, t)
    return mathLib.rotatorLerp(a, b, t)
end

-- 设置组件世界变换（使用复用的 hit_result 缓冲）
local function set_prop_world_pose(comp, loc, rot)
    if comp == nil or loc == nil then
        return
    end
    pcall(function()
        if reusable_hit ~= nil then
            comp:K2_SetWorldLocation(uevrUtils.vector(loc.X, loc.Y, loc.Z), false, reusable_hit, false)
            if rot ~= nil then
                comp:K2_SetWorldRotation(
                    uevrUtils.rotator(rot.Pitch, rot.Yaw, rot.Roll),
                    false,
                    reusable_hit,
                    false
                )
            end
        end
    end)
end

-- 隐藏本体 Mesh + Actor（用于拾取时隐藏地上的物品）
local function hide_body_mesh(body_mesh)
    body_mesh = uevrUtils.getValid(body_mesh)
    if body_mesh == nil then
        return
    end
    pcall(function()
        if body_mesh.SetVisibility ~= nil then
            body_mesh:SetVisibility(false, true)
        end
        if body_mesh.SetHiddenInGame ~= nil then
            body_mesh:SetHiddenInGame(true, true)
        end
        local owner = body_mesh.GetOwner and body_mesh:GetOwner() or nil
        if owner ~= nil then
            if owner.SetActorHiddenInGame ~= nil then
                owner:SetActorHiddenInGame(true)
            elseif owner.SetHiddenInGame ~= nil then
                owner:SetHiddenInGame(true, true)
            end
        end
    end)
end

-- 计算左手附着位置（hand_l_bn 插槽 + attachment 相对偏移 → 世界坐标）
local function get_hand_attach_world(left_comp, attachment_id)
    left_comp = uevrUtils.getValid(left_comp)
    if left_comp == nil then
        return nil, nil
    end
    local params = load_attachment_params(attachment_id)
    local loc_off = params.location or { 0, 0, 0 }
    local rot_off = params.rotation or { 0, 0, 0 }
    local socket = uevrUtils.fname_from_string(LEFT_ATTACH_SOCKET)
    local socket_loc = nil
    local socket_rot = nil
    -- 尝试获取插槽的世界位置和旋转
    pcall(function()
        if left_comp.GetSocketLocation ~= nil then
            socket_loc = left_comp:GetSocketLocation(socket)
        end
        if left_comp.GetSocketRotation ~= nil then
            socket_rot = left_comp:GetSocketRotation(socket)
        end
    end)
    -- 回退：使用组件的世界位置/旋转
    if socket_loc == nil then
        pcall(function()
            socket_loc = left_comp:K2_GetComponentLocation()
            socket_rot = left_comp:K2_GetComponentRotation()
        end)
    end
    if socket_loc == nil then
        return nil, nil
    end
    -- 将相对偏移转换为世界坐标
    local local_pos = mathLib.vector(loc_off[1] or 0, loc_off[2] or 0, loc_off[3] or 0)
    local local_rot = mathLib.rotator(rot_off[1] or 0, rot_off[2] or 0, rot_off[3] or 0)
    local world_loc, world_rot = mathLib.childWorldTransform(
        socket_loc,
        socket_rot,
        local_pos,
        local_rot
    )
    return copy_vector(world_loc), copy_rotator(world_rot) or copy_rotator(socket_rot)
end

-- 清空命中缓存
local function clear_hit_cache()
    M._state.hit_prop_type = nil
    M._state.hit_actor = nil
    M._state.hit_component = nil
    M._state.hit_mesh_asset = nil
    M._state.hit_loc = nil
    M._state.hit_rot = nil
    publish_hit_valid(false)
end

-- =============================================================================
-- L1/L2 两级缓存（对齐 open_latch.lua）
-- L1 全量 ASHItem 扫描仅关卡加载/pawn 变化/过场结束/拾取后触发；
-- L2 激光锥体筛选从 L1 缓存纯数学计算，不再触发引擎枚举。
-- =============================================================================

-- 统一调度 L1 重建（延迟 5 秒 + 0 条目时 2 秒重试）
-- 触发路径：pawn 引用变化、关卡切换、过场结束、拾取成功
local function schedule_l1_rebuild()
    if M._state.l1_rebuild_pending then
        M._state.l1_rebuild_time = os.time()
        M._state.l1_retry_pending = false
        return
    end
    M._state.l1_rebuild_pending = true
    M._state.l1_rebuild_time = os.time()
    M._state.l1_retry_pending = false
end

-- L1 全图扫描：一次枚举所有 ASHItem，白名单过滤，缓存 actor/component/mesh/loc/rot
-- ASHItem 位置一旦加载不会变化，L1 缓存仅在关卡切换/pawn 变化/过场结束/拾取后重建
-- 注意：必须在 check_cache_invalidation 之前定义，Lua 中 local function 不具有前向引用提升
-- 所有被 build_l1_cache 调用的 helper 也必须在它之前定义

-- 获取 Actor 世界位置和旋转
local function get_actor_world_loc_rot(actor)
    local loc, rot = nil, nil
    pcall(function()
        if actor ~= nil and actor.K2_GetActorLocation ~= nil then
            loc = actor:K2_GetActorLocation()
        end
    end)
    pcall(function()
        if actor ~= nil and actor.K2_GetActorRotation ~= nil then
            rot = actor:K2_GetActorRotation()
        end
    end)
    return loc, rot
end

-- 解析物品的视觉组件（MeshComponent + StaticMesh）
local function resolve_item_visual(actor)
    local mesh_comp = nil
    local mesh_asset = nil
    pcall(function()
        mesh_comp = actor and actor.Mesh or nil
    end)
    mesh_comp = uevrUtils.getValid(mesh_comp)
    if mesh_comp ~= nil then
        pcall(function()
            mesh_asset = mesh_comp.StaticMesh
        end)
        -- 如果主 MeshComponent 没有 StaticMesh，尝试查找子组件
        if mesh_asset == nil then
            pcall(function()
                local children = mesh_comp.AttachChildren
                if children ~= nil then
                    for i = 1, #children do
                        local child = children[i]
                        if child ~= nil and child.StaticMesh ~= nil then
                            mesh_comp = child
                            mesh_asset = child.StaticMesh
                            break
                        end
                    end
                end
            end)
        end
    end
    -- 回退：使用 RootComponent
    if mesh_asset == nil then
        pcall(function()
            local root = actor and actor.RootComponent or nil
            if root ~= nil and root.StaticMesh ~= nil then
                mesh_comp = root
                mesh_asset = root.StaticMesh
            end
        end)
    end
    return mesh_comp, mesh_asset
end

local function build_l1_cache()
    if feature_enabled ~= true then
        M._state.l1_cache = nil
        M._state.l1_cache_valid = false
        return
    end

    local actors = nil
    pcall(function()
        actors = uevrUtils.getAllActorsOfClass(SHITEM_CLASS)
    end)
    if actors == nil or #actors == 0 then
        pcall(function()
            actors = uevrUtils.find_all_of(SHITEM_CLASS, false)
        end)
    end
    if actors == nil then
        M._state.l1_cache = nil
        M._state.l1_cache_valid = false
        return
    end

    local matches = {}
    local total = #actors
    for i = 1, total do
        local actor = uevrUtils.getValid(actors[i])
        if actor ~= nil then
            -- 不做 item_already_collected 检测：引擎销毁后下次枚举自然消失
            local mesh_comp, mesh_asset = resolve_item_visual(actor)
            local prop_type, matched_name = classify_actor_or_mesh(actor, mesh_comp, mesh_asset)
            if prop_type ~= nil then
                local loc, rot = get_actor_world_loc_rot(actor)
                if mesh_comp ~= nil then
                    local cloc = reload_tools.get_component_world_location(mesh_comp)
                    local crot = reload_tools.get_component_world_rotation(mesh_comp)
                    if cloc ~= nil then loc = cloc end
                    if crot ~= nil then rot = crot end
                end
                if mesh_asset == nil and FALLBACK_MESH_PATHS[prop_type] ~= nil then
                    mesh_asset = load_static_mesh(FALLBACK_MESH_PATHS[prop_type])
                end
                table.insert(matches, {
                    actor = actor,
                    component = mesh_comp,
                    mesh_asset = mesh_asset,
                    prop_type = prop_type,
                    name = matched_name,
                    loc = copy_vector(loc),
                    rot = copy_rotator(rot) or { Pitch = 0, Yaw = 0, Roll = 0 },
                })
            end
        end
    end

    M._state.l1_cache = matches
    M._state.l1_cache_valid = true
end

-- 拾取成功后从 L1 定点移除被拾取的物品（O(n) 纯内存，替代全量重建）
-- 世界 ASHItem 本体在成功拾取瞬时被引擎销毁，激光打不到、不会再触发拾取，
-- 因此无需"已拾取"标记；从 L1 移除即保证 L2 不再命中该项。
local function remove_from_l1_cache(target_actor)
    if target_actor == nil then
        return
    end
    local l1 = M._state.l1_cache
    if l1 == nil or #l1 == 0 then
        return
    end
    local j = 1
    for i = 1, #l1 do
        if l1[i].actor ~= target_actor then
            l1[j] = l1[i]
            j = j + 1
        end
    end
    for k = j, #l1 do
        l1[k] = nil
    end
end

-- 每帧执行 L1 重建调度（到期重建 + 0 条目重试）。
-- pawn 变化检测已统一到 main.lua（check_pawn_globally），经 M.on_pawn_changed 喂入，
-- 此处不再 get_local_pawn；pawn==nil 的清理也由 on_pawn_changed("pawn_nil") 处理。
local function check_cache_invalidation()
    -- 首次重建：延迟 5 秒等关卡资源加载
    if M._state.l1_rebuild_pending and os.time() - (M._state.l1_rebuild_time or 0) >= 5 then
        local ok, err = pcall(build_l1_cache)
        if not ok then
            M._state.l1_rebuild_pending = false
            M._state.l1_retry_pending = true
            M._state.l1_retry_time = os.time()
        else
            M._state.l1_rebuild_pending = false

            -- 每次成功构建后复位过场跳过标志，仅当次过场生效，防残留误跳过后续重试
            local skip_empty = M._state.l1_skip_empty_retry
            M._state.l1_skip_empty_retry = false

            if (M._state.l1_cache == nil or #M._state.l1_cache == 0) then
                if not skip_empty then
                    M._state.l1_retry_pending = true
                    M._state.l1_retry_time = os.time()
                end
            end
        end
    end

    -- 重试：2 秒后再重建一次
    if M._state.l1_retry_pending and os.time() - (M._state.l1_retry_time or 0) >= 2 then
        pcall(build_l1_cache)
        M._state.l1_retry_pending = false
    end
end

-- =============================================================================
-- 命中结果处理与白名单查找
-- =============================================================================

-- 规范化射线命中结果（兼容不同格式）
local function normalize_hit_result(raw_hit)
    if raw_hit == nil then
        return nil
    end
    if type(raw_hit) == "table" then
        return raw_hit
    end
    local cleaned = nil
    pcall(function()
        if uevrUtils.getCleanHitResult ~= nil then
            cleaned = uevrUtils.getCleanHitResult(raw_hit)
        end
    end)
    return cleaned or raw_hit
end

-- 从命中结果中提取 XYZ 分量
local function vec_xyz(v)
    if v == nil then
        return nil, nil, nil
    end
    return v.X or v[1], v.Y or v[2], v.Z or v[3]
end

-- 点到线段距离平方（转调 mathLib.pointSegmentDistanceSquared，保留本地名以兼容内部调用点）
local function dist_sq_point_to_segment(p, a, b)
    return mathLib.pointSegmentDistanceSquared(p, a, b)
end

-- 检查物品是否已被收集（通过 bWasCollected 属性或 WasCollected() 方法）
local function item_already_collected(actor)
    local collected = false
    pcall(function()
        if actor.bWasCollected == true then
            collected = true
        elseif actor.WasCollected ~= nil and actor:WasCollected() == true then
            collected = true
        end
    end)
    return collected
end

-- 从命中结果中提取 Actor（支持 HitActor/Actor/Component:GetOwner）
local function actor_from_hit(hit)
    local actor = nil
    pcall(function()
        actor = hit.HitActor or hit.Actor
    end)
    if actor == nil then
        pcall(function()
            local comp = hit.Component or hit.HitComponent
            if comp ~= nil and comp.GetOwner ~= nil then
                actor = comp:GetOwner()
            end
        end)
    end
    return uevrUtils.getValid(actor)
end

-- 快路径：射线真打到白名单 Actor 时直接用（可跳过枚举）
local function find_whitelist_item_from_hit(hit)
    local actor = actor_from_hit(hit)
    if actor == nil or item_already_collected(actor) then
        return nil
    end

    local hit_comp = nil
    pcall(function()
        hit_comp = hit.Component or hit.HitComponent
    end)
    hit_comp = uevrUtils.getValid(hit_comp)

    local mesh_comp, mesh_asset = resolve_item_visual(actor)
    if mesh_comp == nil and hit_comp ~= nil then
        mesh_comp = hit_comp
        pcall(function()
            mesh_asset = hit_comp.StaticMesh
        end)
    end

    local prop_type, matched_name = classify_actor_or_mesh(actor, mesh_comp, mesh_asset)
    if prop_type == nil and hit_comp ~= nil then
        prop_type, matched_name = classify_actor_or_mesh(nil, hit_comp, mesh_asset)
    end
    if prop_type == nil then
        return nil
    end

    local loc, rot = get_actor_world_loc_rot(actor)
    if mesh_comp ~= nil then
        local cloc = reload_tools.get_component_world_location(mesh_comp)
        local crot = reload_tools.get_component_world_rotation(mesh_comp)
        if cloc ~= nil then loc = cloc end
        if crot ~= nil then rot = crot end
    end
    if loc == nil then
        loc = hit.Location or hit.ImpactPoint
    end

    return {
        actor = actor,
        component = mesh_comp or hit_comp,
        mesh_asset = mesh_asset,
        prop_type = prop_type,
        name = matched_name,
        loc = loc,
        rot = rot,
        dist = 0,
        via = "direct_hit",
    }
end

-- 回退（L2 锥体筛选）：从 L1 缓存纯数学筛选，不再枚举引擎 ASHItem
-- 评分逻辑不变（14° 锥体半角、30cm 近端、cone_max_radius 远端、lateral/(along+1) 最优）
local function find_whitelist_item_along_laser(hit)
    if not M._state.l1_cache_valid or M._state.l1_cache == nil then
        return nil
    end

    local aim = hit.Location or hit.ImpactPoint or hit.TraceEnd
    local start = hit.TraceStart
    if aim == nil and start == nil then
        return nil
    end
    if start == nil then
        start = aim
    end
    if aim == nil then
        aim = start
    end

    local pawn_loc = nil
    pcall(function()
        local pawn = uevrUtils.get_local_pawn()
        if pawn ~= nil and pawn.K2_GetActorLocation ~= nil then
            pawn_loc = pawn:K2_GetActorLocation()
        end
    end)
    local px, py, pz = vec_xyz(pawn_loc)
    if px == nil then
        return nil
    end

    local best = nil
    local best_score = nil
    local seg_len = 0
    do
        local sx, sy, sz = vec_xyz(start)
        local ax, ay, az = vec_xyz(aim)
        if sx ~= nil and ax ~= nil then
            local dx, dy, dz = ax - sx, ay - sy, az - sz
            seg_len = math.sqrt(dx * dx + dy * dy + dz * dz)
        end
    end
    if seg_len < 1.0 then
        seg_len = 1.0
    end
    local tan_half = math.tan(math.rad(CONE_HALF_ANGLE_DEG))

    -- 遍历 L1 缓存中的所有白名单物品
    local l1 = M._state.l1_cache
    for i = 1, #l1 do
        local entry = l1[i]
        local loc = entry.loc
        if loc ~= nil then
            local ix, iy, iz = vec_xyz(loc)
            if ix ~= nil then
                local dxp, dyp, dzp = ix - px, iy - py, iz - pz
                local range2 = dxp * dxp + dyp * dyp + dzp * dzp
                -- 超出角色 300cm：跳过
                if range2 <= ENUM_MAX_RANGE_CM2 then
                    local d_ray2, t = dist_sq_point_to_segment(loc, start, aim)
                    local ok = false
                    local score = nil
                    if d_ray2 ~= nil and t ~= nil and t >= 0 and t <= 1.05 then
                        local along = t * seg_len
                        local lateral = math.sqrt(d_ray2)
                        local allowed = along * tan_half
                        if allowed < CONE_MIN_RADIUS then
                            allowed = CONE_MIN_RADIUS
                        elseif allowed > cone_max_radius then
                            allowed = cone_max_radius
                        end
                        if lateral <= allowed then
                            ok = true
                            score = lateral / (along + 1.0)
                        end
                    end
                    if ok and (best_score == nil or score < best_score) then
                        best_score = score
                        best = {
                            actor = entry.actor,
                            component = entry.component,
                            mesh_asset = entry.mesh_asset,
                            prop_type = entry.prop_type,
                            name = entry.name,
                            loc = entry.loc,
                            rot = entry.rot,
                            dist = math.sqrt(d_ray2),
                            via = "cone_l1",
                        }
                    end
                end
            end
        end
    end
    return best
end

-- 更新命中缓存：先尝试快路径，失败后走 L2 锥体筛选
local function update_hit_cache_from_hit(raw_hit)
    local hit = normalize_hit_result(raw_hit)
    if hit == nil then
        clear_hit_cache()
        return
    end

    local item = find_whitelist_item_from_hit(hit)
    if item == nil then
        item = find_whitelist_item_along_laser(hit)
    end
    if item == nil then
        clear_hit_cache()
        return
    end

    local mesh_asset = item.mesh_asset
    if mesh_asset == nil and FALLBACK_MESH_PATHS[item.prop_type] ~= nil then
        mesh_asset = load_static_mesh(FALLBACK_MESH_PATHS[item.prop_type])
    end

    M._state.hit_prop_type = item.prop_type
    M._state.hit_actor = item.actor
    M._state.hit_component = item.component
    M._state.hit_mesh_asset = mesh_asset
    M._state.hit_loc = copy_vector(item.loc)
    M._state.hit_rot = copy_rotator(item.rot) or { Pitch = 0, Yaw = 0, Roll = 0 }
    publish_hit_valid(M._state.hit_loc ~= nil)
end

-- =============================================================================
-- Spawn 表演体与销毁工具
-- =============================================================================

-- 从 body_mesh 解析 Attachment ID，或使用白名单默认值
local function resolve_attachment_id(body_mesh, prop_type)
    local id = nil
    pcall(function()
        if body_mesh ~= nil and attachments.getAttachmentIDFromAttachment ~= nil then
            id = attachments.getAttachmentIDFromAttachment(body_mesh)
        end
    end)
    if type(id) == "string" and id ~= "" and id ~= "_" then
        return id
    end
    return PROP_ATTACHMENT_IDS[prop_type]
end

-- Spawn 表演体（临时 Actor + StaticMeshComponent，用于飞行动画）
local function spawn_prop_mesh(pending, attachment_id)
    local mesh_asset = pending.mesh_asset
    if mesh_asset == nil and FALLBACK_MESH_PATHS[pending.prop_type] ~= nil then
        mesh_asset = load_static_mesh(FALLBACK_MESH_PATHS[pending.prop_type])
    end
    if mesh_asset == nil then
        print_log("spawn failed: no mesh for " .. tostring(pending.prop_type), 3)
        return nil, nil
    end

    local spawn_loc = pending.loc or { X = 0, Y = 0, Z = 0 }
    local spawn_rot = pending.rot or { Pitch = 0, Yaw = 0, Roll = 0 }
    local actor = nil
    pcall(function()
        actor = uevrUtils.spawn_actor(
            reload_tools.make_spawn_transform(spawn_loc, spawn_rot), 1, nil)
    end)
    if actor == nil then
        print_log("spawn_actor failed", 3)
        return nil, nil
    end

    local identity_xf = uevrUtils.get_transform()
    local mesh_comp = nil
    pcall(function()
        mesh_comp = uevrUtils.createStaticMeshComponent(mesh_asset, {
            manualAttachment = true,
            relativeTransform = identity_xf,
            deferredFinish = false,
            parent = actor,
        })
    end)
    if mesh_comp == nil then
        pcall(function()
            uevrUtils.destroy_actor(actor)
        end)
        print_log("createStaticMeshComponent failed", 3)
        return nil, nil
    end

    -- 设置 mesh 为可移动
    pcall(function()
        if mesh_comp.SetMobility ~= nil then
            mesh_comp:SetMobility(2)  -- Movable
        end
        if actor.K2_SetRootComponent ~= nil then
            actor:K2_SetRootComponent(mesh_comp)
        end
        if reusable_hit ~= nil then
            mesh_comp:K2_SetWorldLocation(uevrUtils.vector(spawn_loc), false, reusable_hit, false)
            mesh_comp:K2_SetWorldRotation(uevrUtils.rotator(spawn_rot), false, reusable_hit, false)
        end
    end)

    return actor, mesh_comp
end

-- 执行上帧排队的 Actor 销毁（延迟一帧销毁，避免同帧卸挂+Destroy 叠卡）
local function flush_pending_destroy_actor()
    local actor = M._state.pending_destroy_actor
    if actor == nil then
        return
    end
    M._state.pending_destroy_actor = nil
    pcall(function()
        uevrUtils.destroy_actor(actor)
    end)
end

-- 销毁表演体（左肩 store 或功能禁用时调用）
local function destroy_prop_internal(reason)
    local actor = M._state.actor

    -- [RM 已停用] 任何销毁路径都恢复 root motion（即使启用也由 begin_prop_flight 单点处理）
    -- restore_item_rm()

    if actor ~= nil then
        pcall(function()
            actor:SetHiddenInGame(true, true)
        end)
        -- 若上一帧还有待毁 actor，先清掉再排队新的
        if M._state.pending_destroy_actor ~= nil and M._state.pending_destroy_actor ~= actor then
            local stale = M._state.pending_destroy_actor
            M._state.pending_destroy_actor = nil
            pcall(function()
                uevrUtils.destroy_actor(stale)
            end)
        end
        M._state.pending_destroy_actor = actor
    end
    set_left_hand_animation(nil)
    M._state.actor = nil
    M._state.mesh_comp = nil
    M._state.body_mesh = nil
    M._state.prop_type = nil
    M._state.attachment_id = nil
    M._state.pending = nil
    M._state.flight_start_t = nil
    M._state.flight_start_loc = nil
    M._state.flight_start_rot = nil
    M._state.phase = State.Idle
    publish_prop_active(false)
    print_log("destroy prop: " .. tostring(reason), 4)
    -- 任何销毁表演体路径均不重建 L1：世界 ASHItem 本体仅在成功拾取瞬时被引擎销毁，
    -- 此刻飞行开始（begin_prop_flight）已同步重建过；其余销毁分支只涉及表演体显示 mesh，与世界本体无关，属冗余空跑。
end

-- =============================================================================
-- 状态机与表演体飞行逻辑
-- =============================================================================

-- 查询是否有可存储的道具
function M.has_storeable_prop()
    local phase = M._state.phase
    return phase == State.Holding or phase == State.Flying or phase == State.AwaitBody
end

-- =============================================================================
-- 松开左抓握键入包（默认关闭，面板开关控制）
-- gripLeft.leave 时直接调用；开关开启且持有表演体才销毁（同左肩 store 行为）
-- =============================================================================
function M.is_gripleft_release_store_enabled()
    return gripleft_release_store_enabled == true
end

function M.set_gripleft_release_store(enabled)
    gripleft_release_store_enabled = enabled == true
    if type(rg_config) ~= "table" then
        rg_config = {}
    end
    rg_config.gripleft_release_store = gripleft_release_store_enabled
    save_rg_config()
end

function M.try_store_on_gripleft_release()
    if gripleft_release_store_enabled ~= true then
        return false
    end
    if not M.has_storeable_prop() then
        return false
    end
    destroy_prop_internal("gripleft release store")
    return true
end

-- 获取 ItemContext Mesh（用于等待阶段的验证）
local function get_item_context_mesh()
    local pawn = uevrUtils.get_local_pawn()
    return uevrUtils.getValid(pawn, {"Items", "ItemExecutive", "ItemContext", "Mesh"})
end

-- 解析身体 Mesh（优先使用 ItemContext Mesh，回退到缓存的组件）
local function resolve_body_mesh(pending)
    if pending == nil then
        return nil
    end
    local ctx = get_item_context_mesh()
    if ctx ~= nil then
        local pt = classify_actor_or_mesh(nil, ctx, ctx.StaticMesh)
        if pt == nil or pt == pending.prop_type then
            return ctx
        end
    end
    local cached = uevrUtils.getValid(pending.component)
    if cached ~= nil then
        return cached
    end
    return nil
end

-- 飞行完成：将表演体附着到左手 hand_l_bn 插槽
local function finish_flight_attach()
    local prop = uevrUtils.getValid(M._state.mesh_comp)
    local left_comp = resolve_left_hand_component()
    if prop == nil or left_comp == nil then
        destroy_prop_internal("flight finish fail")
        return
    end
    local opts = make_attach_options(M._state.attachment_id)
    local prop_ok = false
    pcall(function()
        prop_ok = attachments.attachToMesh(prop, left_comp, LEFT_ATTACH_SOCKET, Handed.Left, opts) == true
    end)
    apply_prop_transform(prop, M._state.attachment_id)
    M._state.flight_start_t = nil
    M._state.flight_start_loc = nil
    M._state.flight_start_rot = nil
    M._state.phase = State.Holding
    -- 飞行完毕：恢复 root motion（[RM 已停用]，保留原逻辑于注释）
    -- restore_item_rm()
    set_left_hand_animation(M._state.prop_type)
    if event_feedback ~= nil and type(event_feedback.play_remote_grab_haptic) == "function" then
        pcall(event_feedback.play_remote_grab_haptic)
    end
    print_log("holding " .. tostring(M._state.prop_type) .. " on hand_l_bn", 4)
end

-- 飞行阶段 tick：每帧更新表演体位置/旋转
local function tick_flying()
    local prop = uevrUtils.getValid(M._state.mesh_comp)
    if prop == nil then
        destroy_prop_internal("flight mesh lost")
        return
    end
    local start_loc = M._state.flight_start_loc
    local start_rot = M._state.flight_start_rot
    if start_loc == nil then
        finish_flight_attach()
        return
    end
    local elapsed = os.clock() - (M._state.flight_start_t or os.clock())
    local t = FLIGHT_DURATION > 0 and (elapsed / FLIGHT_DURATION) or 1
    if t >= 1 then
        finish_flight_attach()
        return
    end
    local left_comp = resolve_left_hand_component()
    local end_loc, end_rot = get_hand_attach_world(left_comp, M._state.attachment_id)
    if end_loc == nil then
        end_loc = start_loc
        end_rot = start_rot
    end
    set_prop_world_pose(
        prop,
        flight_lerp_loc(start_loc, end_loc, t),
        flight_lerp_rot(start_rot, end_rot or start_rot, t)
    )
end

-- 隐藏本体 -> 缓存点 spawn 表演体 -> Flying lerp
local function begin_prop_flight(pending, body_mesh)
    local left_comp = resolve_left_hand_component()
    if left_comp == nil then
        M._state.pending = nil
        M._state.phase = State.Idle
        return
    end

    local attachment_id = resolve_attachment_id(body_mesh, pending.prop_type)
    if attachment_id == nil then
        M._state.pending = nil
        M._state.phase = State.Idle
        return
    end

    if pending.loc == nil then
        M._state.pending = nil
        M._state.phase = State.Idle
        return
    end

    -- 隐藏本体 Mesh 和 Actor
    hide_body_mesh(body_mesh)
    -- Context mesh 与地上缓存 mesh 可能不是同一个：一并藏，避免引擎动画再飞一次
    if pending.component ~= nil and pending.component ~= body_mesh then
        hide_body_mesh(pending.component)
    end
    pcall(function()
        local owner = pending.actor
        if owner ~= nil and owner.SetActorHiddenInGame ~= nil then
            owner:SetActorHiddenInGame(true)
        end
    end)

    -- Spawn 表演体
    local actor, prop_comp = spawn_prop_mesh(pending, attachment_id)
    if prop_comp == nil then
        M._state.pending = nil
        M._state.phase = State.Idle
        return
    end

    local start_loc = copy_vector(pending.loc)
    local start_rot = copy_rotator(pending.rot) or { Pitch = 0, Yaw = 0, Roll = 0 }
    set_prop_world_pose(prop_comp, start_loc, start_rot)

    -- 更新状态
    M._state.body_mesh = body_mesh
    M._state.actor = actor
    M._state.mesh_comp = prop_comp
    M._state.prop_type = pending.prop_type
    M._state.attachment_id = attachment_id
    M._state.flight_start_t = os.clock()
    M._state.flight_start_loc = start_loc
    M._state.flight_start_rot = start_rot
    M._state.pending = nil
    M._state.phase = State.Flying
    -- 兜底再开禁制（await 可能已开）：幂等，确保飞行全程 RM 被抑制（[RM 已停用]）
    -- start_item_rm_disable()
    publish_prop_active(true)
    clear_hit_cache()
    -- 拾取成功后从 L1 定点移除该项（引擎已销毁 ASHItem 本体，无需全图重建）
    remove_from_l1_cache(pending.actor)
    print_log("flight begin " .. tostring(pending.prop_type), 4)
end

-- 从缓存开始等待阶段（按下 E 键时调用）
local function begin_await_body_from_cache()
    if M._state.phase ~= State.Idle then
        return
    end
    if left_hand_occupied() then
        print_log("left hand occupied, skip E await", 4)
        return
    end
    if M._state.hit_valid ~= true and M._state.hit_prop_type ~= nil and M._state.hit_loc ~= nil then
        publish_hit_valid(true)
    end
    if M._state.hit_valid ~= true or M._state.hit_prop_type == nil then
        print_log("no valid whitelist cache for E", 4)
        return
    end

    local prop_type = M._state.hit_prop_type
    M._state.pending = {
        prop_type = prop_type,
        attachment_id = PROP_ATTACHMENT_IDS[prop_type],
        actor = M._state.hit_actor,
        component = M._state.hit_component,
        mesh_asset = M._state.hit_mesh_asset,
        loc = copy_vector(M._state.hit_loc),
        rot = copy_rotator(M._state.hit_rot),
        started_at = os.clock(),
    }
    M._state.phase = State.AwaitBody
    -- 抓取开始：禁用 root motion（等待本体 mesh / 飞行期间抑制拾取动画 RM）
    -- 置于校验通过后，避免 E 空按 / 左手占用早退时误开启禁制（[RM 已停用]）
    -- start_item_rm_disable()
    print_log("await body for " .. tostring(prop_type), 4)

    -- 同帧若 Context/缓存已可附着则立刻完成
    local body = resolve_body_mesh(M._state.pending)
    if body ~= nil then
        begin_prop_flight(M._state.pending, body)
    end
end

-- 等待阶段 tick：等待 ItemContext Mesh 就绪
local function tick_await_body()
    local pending = M._state.pending
    if pending == nil then
        M._state.phase = State.Idle
        return
    end

    local body = resolve_body_mesh(pending)
    if body ~= nil then
        begin_prop_flight(pending, body)
        return
    end

    -- 超时则放弃
    if (os.clock() - (pending.started_at or 0)) >= AWAIT_BODY_TIMEOUT then
        print_log("await body timeout", 4)
        M._state.pending = nil
        M._state.phase = State.Idle
    end
end

-- 持有阶段 tick：每帧更新附件变换
local function tick_holding()
    local prop = uevrUtils.getValid(M._state.mesh_comp)
    if prop == nil then
        destroy_prop_internal("holding mesh lost")
        return
    end
    apply_prop_transform(prop, M._state.attachment_id)
    -- 本体已隐藏；引擎销毁后只清引用
    if M._state.body_mesh ~= nil and uevrUtils.getValid(M._state.body_mesh) == nil then
        M._state.body_mesh = nil
    end
end

-- =============================================================================
-- 手部交互与配置接口
-- =============================================================================

-- 确保左手激光射线启用
local function ensure_interaction_left_laser()
    pcall(function()
        if interaction.setInteractionAttachment ~= nil then
            interaction.setInteractionAttachment(Handed.Left)
        end
        if interaction.setInteractionType ~= nil and interaction.InteractionType ~= nil then
            interaction.setInteractionType(interaction.InteractionType.Mesh)
        end
        -- 只保证射线组件开启；可见性由 Interaction 面板 Show Laser 控制
        if interaction.enableInteractionLaser ~= nil then
            interaction.enableInteractionLaser(true)
        elseif interaction.showInteractionLaser ~= nil then
            interaction.showInteractionLaser(true)
        end
        if interaction.setMeshEnableHitTesting ~= nil then
            interaction.setMeshEnableHitTesting(true)
        end
        if interaction.create ~= nil and interaction.exists ~= nil and not interaction.exists() then
            interaction.create()
        end
    end)
    local exists = false
    pcall(function() exists = interaction.exists() == true end)
end

-- 合并左右手 Grip 输出（在 Holding 阶段用表演体替换左手输出）
function M.on_grip_update_merge(rA, rM, rS, lA, lM, lS, oR, oL)
    if feature_enabled ~= true then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    if M._state.phase ~= State.Holding then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    local prop = uevrUtils.getValid(M._state.mesh_comp)
    if prop == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    local left_comp = resolve_left_hand_component()
    if left_comp == nil then
        return rA, rM, rS, lA, lM, lS, oR, oL
    end
    -- 返回：右手不变，左手 Aiming 改为表演体 + 控制器 + 插槽 + 选项
    return rA, rM, rS, prop, left_comp, LEFT_ATTACH_SOCKET, oR, make_attach_options(M._state.attachment_id)
end

-- 初始化附件回调（热重载或新附着时重新应用变换）
function M.on_init_attachment(attachment, gripHand, options)
    if feature_enabled ~= true then
        return
    end
    if gripHand ~= Handed.Left then
        return
    end
    if attachment ~= nil and attachment == M._state.mesh_comp then
        apply_prop_transform(attachment, M._state.attachment_id)
    end
end

-- 停止功能运行时（禁用时清理状态）
local function stop_feature_runtime()
    if M._state.phase ~= State.Idle then
        destroy_prop_internal("feature disabled")
    end
    -- 功能禁用：即使 phase 已 Idle（不经 destroy）也强制恢复 RM，避免残留（[RM 已停用]）
    -- restore_item_rm()
    clear_hit_cache()
    publish_hit_valid(false)
    publish_prop_active(false)
    _G[KEY_E_EDGE] = false
    _G[KEY_STORE_EDGE] = false
end

-- 设置功能启用状态
local function set_feature_enabled(enabled)
    local next_on = enabled == true
    if feature_enabled == next_on then
        return
    end
    feature_enabled = next_on
    if type(rg_config) ~= "table" then
        rg_config = {}
    end
    rg_config.enabled = feature_enabled
    if feature_enabled then
        ensure_interaction_left_laser()
        schedule_l1_rebuild()
    else
        stop_feature_runtime()
    end
    save_rg_config()
end

-- 对外接口：设置功能启用状态
function M.set_enabled(enabled)
    set_feature_enabled(enabled == true)
end

-- 对外接口：获取锥体远端最大半径
function M.get_cone_max_radius()
    return cone_max_radius
end

-- 对外接口：设置锥体远端最大半径
function M.set_cone_max_radius(radius)
    if type(radius) ~= "number" then
        return
    end
    local v = radius
    if v < CONE_MIN_RADIUS then
        v = CONE_MIN_RADIUS
    elseif v > 800 then
        v = 800
    end
    cone_max_radius = v
    if type(rg_config) ~= "table" then
        rg_config = {}
    end
    rg_config.cone_max_radius = v
    save_rg_config()
end

-- =============================================================================
-- 主循环：on_tick（每帧调用）
-- =============================================================================

local function on_tick()
    -- 上一帧 store/清理排队的 Destroy（与卸挂拆开）
    flush_pending_destroy_actor()

    -- 自愈守卫：若已回 Idle（begin_prop_flight 早退 / await 超时直接置 Idle，不经 destroy）
    -- 但 rm_active 仍为 true，则恢复 RM，避免禁制泄漏（[RM 已停用]）
    -- if M._state.phase == State.Idle and M._state.rm_active then
    --     restore_item_rm()
    -- end

    -- L1/L2 缓存检查：pawn 引用变化/关卡切换/过场结束时触发 L1 重建
    check_cache_invalidation()

    -- 功能禁用时：清除边沿触发，清理残留状态
    if feature_enabled ~= true then
        if rawget(_G, KEY_E_EDGE) == true then
            _G[KEY_E_EDGE] = false
        end
        if rawget(_G, KEY_STORE_EDGE) == true then
            _G[KEY_STORE_EDGE] = false
        end
        if M._state.hit_valid or M._state.phase ~= State.Idle then
            stop_feature_runtime()
        end
        return
    end

    -- 过场中：销毁表演体，清空缓存
    if uevrUtils.isInCutscene() then
        if M._state.phase ~= State.Idle then
            destroy_prop_internal("cutscene")
        end
        if M._state.hit_valid or M._state.hit_loc ~= nil or M._state.hit_prop_type ~= nil then
            clear_hit_cache()
        else
            publish_hit_valid(false)
        end
        return
    end

    -- 左肩 store 边沿触发：销毁当前道具
    if rawget(_G, KEY_STORE_EDGE) == true then
        _G[KEY_STORE_EDGE] = false
        if M._state.phase == State.Holding
            or M._state.phase == State.AwaitBody
            or M._state.phase == State.Flying
        then
            destroy_prop_internal("shoulder store")
        end
    end

    -- E 键边沿触发：开始等待/抓取流程
    if rawget(_G, KEY_E_EDGE) == true then
        _G[KEY_E_EDGE] = false
        begin_await_body_from_cache()
    end

    -- Idle 状态下：定期检查缓存超时（2.5 * CACHE_INTERVAL 未命中则清空）
    local now = os.clock()
    if M._state.phase == State.Idle then
        if (now - (M._state.last_timeout_check_t or 0)) >= CACHE_INTERVAL then
            M._state.last_timeout_check_t = now
            if M._state.hit_valid and (now - (M._state.last_hit_t or 0)) > (CACHE_INTERVAL * 2.5) then
                clear_hit_cache()
            end
        end
    end

    -- 按状态机阶段执行对应的 tick
    if M._state.phase == State.AwaitBody then
        tick_await_body()
    elseif M._state.phase == State.Flying then
        tick_flying()
    elseif M._state.phase == State.Holding then
        tick_holding()
    end
end

-- 射线命中回调（由 interaction 模块调用，带节流）
local function on_hit_for_cache(hitResult)
    if feature_enabled ~= true then
        return
    end
    if M._state.phase ~= State.Idle then
        return
    end
    M._state.last_hit_t = os.clock()
    -- 节流：CACHE_INTERVAL 内的命中直接跳过
    if (M._state.last_hit_t - (M._state.last_cache_t or 0)) < CACHE_INTERVAL then
        return
    end
    M._state.last_cache_t = M._state.last_hit_t
    update_hit_cache_from_hit(hitResult)
end

-- =============================================================================
-- UI 注册与诊断接口
-- =============================================================================

-- 注册 UI 面板（ImGui 绘制远程抓取配置）
local function register_remote_grab_ui()
    if rawget(_G, "__sh2_remote_grab_ui_registered") == true then
        return
    end
    if type(compat) ~= "table" or type(compat.on_draw_ui) ~= "function" then
        return
    end
    local registered = compat.on_draw_ui(function()
        local mod = rawget(_G, "__sh2_remote_grab_module")
        if type(mod) ~= "table" or type(mod.is_enabled) ~= "function" then
            return
        end
        local enabled = mod.is_enabled() == true
        imgui.separator()
        imgui.text_colored("Remote Grab (left laser pickup)", 0xFF00FFFF)
        local en_changed, en_val = imgui.checkbox("Enable remote grab", enabled)
        if en_changed and type(mod.set_enabled) == "function" then
            mod.set_enabled(en_val == true)
            enabled = en_val == true
        end
        -- 玩家可视开关：显示/隐藏左手抓取激光射线（射线本身由 remote_grab 保持开启，仅控制可见性）
        local laser_shown = type(interaction.isShowInteractionLaser) == "function" and interaction.isShowInteractionLaser() == true
        local show_changed, show_val = imgui.checkbox("Show grab laser", laser_shown)
        if show_changed and type(interaction.showInteractionLaser) == "function" then
            interaction.showInteractionLaser(show_val == true)
        end
        -- 松开左抓握键即入包（默认关闭）
        local store_on_release = type(mod.is_gripleft_release_store_enabled) == "function" and mod.is_gripleft_release_store_enabled() == true
        local store_changed, store_val = imgui.checkbox("Store on grip release", store_on_release)
        if store_changed and type(mod.set_gripleft_release_store) == "function" then
            mod.set_gripleft_release_store(store_val == true)
        end
        if enabled == true and type(mod.get_cone_max_radius) == "function" then
            local tip = mod.get_cone_max_radius()
            local tip_changed, tip_val = imgui.slider_float(
                "Laser tip cone max radius (cm)",
                tip,
                50.0,
                600.0
            )
            if tip_changed and type(tip_val) == "number" and type(mod.set_cone_max_radius) == "function" then
                mod.set_cone_max_radius(tip_val)
            end
        end
    end)
    if registered then
        _G.__sh2_remote_grab_ui_registered = true
    end
end

-- =============================================================================
-- 模块初始化与销毁
-- =============================================================================

-- 过场状态变化回调（由 main.lua 转发）
-- isInCutscene==false 表示过场结束：清空 L1 并调度重建。
-- SH2 开门/交互动画会切换 GetGameplayInputMode（控制权收走），并伴随机型流送子关卡加载，
-- 此处重建用于流送漏扫覆盖（2026-09-05 捞回，实测过门后新区域 11 个条目靠它重扫进来）。
-- 注意：main.lua L600 每帧调用本回调，pending 守卫会把密集过场合并成一次重建，不叠加成本。
-- 不再置 last_pawn_ref= nil：pawn 检测已归 main check_pawn_globally 统一管理。
function M.on_cutscene_change(isInCutscene)
    if isInCutscene ~= false then
        return
    end
    -- 过场/开门/推柜动画结束：清空 L1 并调度重建
    M._state.l1_cache = nil
    M._state.l1_cache_valid = false
    M._state.l1_skip_empty_retry = true -- 本次结果为空跳过 2s 重试，只建一次
    schedule_l1_rebuild()
    -- 动画结束立即重建（不等 5s）：让重建卡顿与动画播放重叠，用户无感知
    -- 置 l1_rebuild_time=0 使 check_cache_invalidation 的 >=5 判定下一帧即满足；
    -- 若此前已有别的触发挂起，此处一并提前立即执行，同样符合"尽快重建"意图
    M._state.l1_rebuild_time = 0
    print_log("L1 scheduled rebuild: cutscene ended (immediate)", 4)
end

-- 统一 pawn 检测入口（main.lua check_pawn_globally 广播调用）。
-- reason：pawn_changed / level_change → 调度 L1 重建；pawn_nil → 清理 pending/retry 防缓存僵死。
function M.on_pawn_changed(reason)
    if reason == "pawn_nil" then
        M._state.l1_rebuild_pending = false
        M._state.l1_retry_pending = false
        return
    end
    schedule_l1_rebuild()
end

-- 关卡切换：销毁表演体 + 清空 L1 缓存 + 调度重建（由 main on_level_change 转发，替代原自注册 UEVR 回调）。
function M.on_level_change(level)
    pcall(M.destroy)
    M._state.l1_cache = nil
    M._state.l1_cache_valid = false
    M.on_pawn_changed("level_change")
end

-- 模块初始化：注册回调、建立全局引用、调度首次 L1 重建
function M.init()
    apply_rg_config()
    if feature_enabled then
        ensure_interaction_left_laser()
    else
        publish_hit_valid(false)
        publish_prop_active(false)
    end

    -- 兜底恢复 RM=3：热重载发生在飞行中时，新 M._state.rm_active=false
    -- 但引擎 RM 可能仍卡在 1（禁用态），此处幂等恢复防泄漏（默认值即 3）—— [RM 已停用]
    -- pcall(function()
    --     local pawn = uevrUtils.get_local_pawn()
    --     if pawn ~= nil and pawn.Mesh ~= nil then
    --         local anim_instance = pawn.Mesh.AnimScriptInstance
    --         if anim_instance ~= nil then
    --             anim_instance:SetRootMotionMode(3) -- RootMotionFromMontagesOnly
    --         end
    --     end
    -- end)

    -- 建立全局引用（热重载时使用）
    _G.__sh2_remote_grab_on_tick = on_tick
    _G.__sh2_remote_grab_on_hit = on_hit_for_cache
    -- [RM 已停用] _G.__sh2_remote_grab_rm_monitor = monitor_item_flight_root_motion
    _G.__sh2_remote_grab_module = M
    register_remote_grab_ui()

    -- 热重载处理
    if rawget(_G, "__sh2_remote_grab_initialized") then
        -- 热重载：清空 L1 缓存并调度重建（须在 early-return 之前）
        M._state.l1_cache = nil
        M._state.l1_cache_valid = false
        M._state.last_pawn_ref = nil
        schedule_l1_rebuild()
        print_log("hot-reload: rebound tick via _G enabled=" .. tostring(feature_enabled), 4)
        return M
    end

    -- 首次加载：注册引擎回调
    interaction.registerOnHitCallback(function(hitResult)
        local fn = rawget(_G, "__sh2_remote_grab_on_hit")
        if type(fn) == "function" then
            pcall(fn, hitResult)
        end
    end)

    uevrUtils.registerPostEngineTickCallback(function()
        local fn = rawget(_G, "__sh2_remote_grab_on_tick")
        if type(fn) == "function" then
            pcall(fn)
        end
    end)

    -- Root motion 监控：pre+post 双 tick —— [RM 已停用，整体注释保留为可恢复模板]
    -- if not rawget(_G, "__sh2_remote_grab_rm_registered") then
    --     uevrUtils.registerPreEngineTickCallback(function()
    --         local fn = rawget(_G, "__sh2_remote_grab_rm_monitor")
    --         if type(fn) == "function" then
    --             pcall(fn)
    --         end
    --     end)
    --     uevrUtils.registerPostEngineTickCallback(function()
    --         local fn = rawget(_G, "__sh2_remote_grab_rm_monitor")
    --         if type(fn) == "function" then
    --             pcall(fn)
    --         end
    --     end)
    --     _G.__sh2_remote_grab_rm_registered = true
    -- end

    -- 关卡切换已由 main on_level_change 统一转发到 M.on_level_change（销毁表演体+清 L1+重建），
    -- 原自注册 UEVR 回调删除，避免双触发；首次加载仍调度一次重建。

    _G.__sh2_remote_grab_initialized = true
    schedule_l1_rebuild()  -- 首次加载时调度 L1 重建
    print_log("initialized enabled=" .. tostring(feature_enabled), 4)
    return M
end

-- 模块销毁：清理状态 + 清空 L1 缓存
function M.destroy()
    destroy_prop_internal("module destroy")
    flush_pending_destroy_actor()
    clear_hit_cache()
    M._state.l1_cache = nil
    M._state.l1_cache_valid = false
end

-- =============================================================================
-- 纯工具导出（rt_ = remote tools）：供其他模块（如 unlock_item_door）复用
-- 左手解析 / 手位世界坐标 / 插值 / 附着选项。只依赖本地函数，不触碰 M._state。
-- =============================================================================

-- 解析左手组件（按手部类型选择控制器/手组件/IK 网格）
function M.rt_resolve_left_hand_component()
    return resolve_left_hand_component()
end

-- 左手 hand_l_bn 插槽世界位（attachment_id 省略时返回不带相对偏移的插槽位）
-- 返回 world_loc, world_rot
function M.rt_get_left_hand_world(attachment_id)
    local comp = resolve_left_hand_component()
    if comp == nil then
        return nil, nil
    end
    if attachment_id ~= nil then
        return get_hand_attach_world(comp, attachment_id)
    end
    -- 无 attachment_id：返回手 component 的世界位置/旋转（不带偏移）
    local loc, rot = nil, nil
    pcall(function()
        loc = comp:K2_GetComponentLocation()
        rot = comp:K2_GetComponentRotation()
    end)
    return copy_vector(loc), copy_rotator(rot)
end

-- 左手 hand_l_bn 插槽世界位置/旋转（不带附件偏移）：供距离检测/飞行终点使用
-- 与 get_hand_attach_world 的插槽读取一致，但跳过 attachment 相对偏移。
function M.rt_get_left_hand_socket_world()
    local comp = resolve_left_hand_component()
    if comp == nil then
        return nil, nil
    end
    local socket = uevrUtils.fname_from_string(LEFT_ATTACH_SOCKET)
    local socket_loc, socket_rot = nil, nil
    pcall(function()
        if comp.GetSocketLocation ~= nil then socket_loc = comp:GetSocketLocation(socket) end
        if comp.GetSocketRotation ~= nil then socket_rot = comp:GetSocketRotation(socket) end
    end)
    if socket_loc == nil then
        pcall(function()
            socket_loc = comp:K2_GetComponentLocation()
            socket_rot = comp:K2_GetComponentRotation()
        end)
    end
    if socket_loc == nil then
        return nil, nil
    end
    return copy_vector(socket_loc), copy_rotator(socket_rot)
end

-- 构建附着选项（供 attachToMesh 使用）
function M.rt_make_attach_options(attachment_id)
    return make_attach_options(attachment_id)
end

-- 通用飞行驱动：驱动任意 mesh_comp 从起点飞到 end_loc_fn() 返回的终点
-- 返回 "attach"(飞行完成) / "flying"(进行中) / "lost"(组件失效)
-- start_loc/start_rot/start_t：起点与起始时刻；duration：飞行时长（秒）
-- end_loc_fn：每帧返回终点 loc, rot 的函数（终点实时取自左手）
function M.rt_tick_flight(mesh_comp, start_loc, start_rot, start_t, duration, end_loc_fn)
    mesh_comp = uevrUtils.getValid(mesh_comp)
    if mesh_comp == nil then
        return "lost"
    end
    if start_loc == nil then
        return "attach"
    end
    local elapsed = os.clock() - (start_t or os.clock())
    local t = duration > 0 and (elapsed / duration) or 1
    if t >= 1 then
        return "attach"
    end
    local end_loc, end_rot = end_loc_fn()
    if end_loc == nil then
        end_loc = start_loc
    end
    if end_rot == nil then
        end_rot = start_rot
    end
    set_prop_world_pose(
        mesh_comp,
        flight_lerp_loc(start_loc, end_loc, t),
        flight_lerp_rot(start_rot, end_rot, t)
    )
    return "flying"
end

-- 通用 attach：把任意 mesh_comp attach 到左手 hand_l_bn 插槽（不做偏移，偏移由调用方设置）
function M.rt_attach_to_left_hand(mesh_comp)
    mesh_comp = uevrUtils.getValid(mesh_comp)
    local left_comp = resolve_left_hand_component()
    if mesh_comp == nil or left_comp == nil then
        return false
    end
    local opts = make_attach_options(nil)
    local ok = false
    pcall(function()
        ok = attachments.attachToMesh(mesh_comp, left_comp, LEFT_ATTACH_SOCKET, Handed.Left, opts) == true
    end)
    return ok
end

return M
