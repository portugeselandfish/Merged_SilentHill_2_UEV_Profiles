-- 专用配置：把通用 VR 手势系统接到本作的键鼠动作上。
-- 文件按三大类整理：
-- 第一类：底层依赖与运行骨架
-- 第二类：微调设置与模块开关
-- 第三类：游戏 个性化映射

-- 第一类运行骨架已下沉到 UEVR_08_environment：这里只保留业务热重载入口。
-- VR 运行时状态经 UEVR_00_init_globals 读取；publisher 见 UEVR_00 头注释。
-- =============================================================================
local environment = require("UEVR_08_environment")
local vr_globals = require("UEVR_00_init_globals")
local compat = vr_globals.compat

local existing_enhancer = environment:getEnhancer()
local skip_full_init = type(existing_enhancer) == "table"

-- 右手 VR B 键上升沿 → 写 g_mag_drop_edge 全局变量；manual_reload 在 tick 中消费并清零。
local function handle_mag_drop_b_button(enh, env)
    if type(env) ~= "table" or type(env.getVRState) ~= "function" then
        return
    end
    local vr_state = env:getVRState()
    local b = vr_state and (vr_state.b == true or (type(vr_state.b) == "number" and vr_state.b > 0.5))
    if b and not (enh._prevB == true) then
        _G[vr_globals.KEYS.mag_drop_edge] = true
    end
    enh._prevB = b
end

local function patch_enhancer_mag_drop_edge(enh)
    if type(enh) ~= "table" then return end
    if enh._magDropEdgeOriginalTick == nil then
        enh._magDropEdgeOriginalTick = enh.tick
    end
    function enh:tick(source)
        if type(enh._magDropEdgeOriginalTick) == "function" then
            enh._magDropEdgeOriginalTick(enh, source)
        end
        handle_mag_drop_b_button(enh, enh.environment or rawget(_G, "VREnvironment") or environment)
    end
    enh._magDropEdgePatched = true
end

-- =============================================================================
-- 第二类：微调设置与模块开关
-- 配置文件、默认开关和面板状态归在这一类；保持原位，方便以后迁移时单独替换。
--
-- 【作用】持久化并驱动「武器槽位手势」总开关，不负责具体手势映射（那是第三类）。
--   1. 从 JSON 读出 ImmersionEnhancerHolster（默认 true）
--   2. 得到运行时变量 ImmersionEnhancerHolster_enabled
--   3. apply_holster_toggle() 据此启停 holsterWeaponRight / shoulderWeaponRight /
--      chestRight / shoulderWeaponLeft 四个槽位手势
--   4. Scripts 面板勾选变化 → save_holster_config() 写回 JSON，下次启动仍生效
--
-- 【数据流】磁盘 JSON ↔ holster_config ↔ ImmersionEnhancerHolster_enabled ↔ UI 勾选
-- =============================================================================

-- 配置文件路径。
-- 新文件：本脚本专用，存 ImmersionEnhancerHolster 开关。

local holster_config_relative_path = "immersion_enhancer_holster.json"
local legacy_holster_config_relative_path = "vr_holster.json"
-- io.open 兜底读写用同一条相对路径（不要加 reframework/data/ 前缀，会套娃）。
local holster_config_path = holster_config_relative_path
local legacy_holster_config_path = legacy_holster_config_relative_path
local holster_config = nil      -- 从磁盘读出的配置表
local holster_json = nil        -- json 模块缓存，只 require 一次

-- 安全读文件：仅 json.load_file 不可用时的兜底路径会用到。
local function is_blocked_binary_path(path)
    -- 禁止对 .dll / .exe 做 io.open，防止误操作二进制。
    local normalized = tostring(path or ""):gsub("\\", "/"):lower()
    return normalized:match("%.dll$") ~= nil or normalized:match("%.exe$") ~= nil
end

local function safe_io_open(path, mode)
    if is_blocked_binary_path(path) then
        return nil, "io.open blocked for executables or DLLs"
    end

    if type(io) ~= "table" or type(io.open) ~= "function" then
        return nil, "io.open unavailable"
    end

    local ok, file_or_err = pcall(io.open, path, mode)
    if not ok then
        return nil, tostring(file_or_err)
    end

    return file_or_err, nil
end

-- 获取 json 模块；成功则缓存，后续 load/save 共用。
local function get_holster_json()
    if holster_json ~= nil then
        return holster_json
    end

    local ok, json = pcall(require, "json")
    if ok and json then
        holster_json = json
    end

    return holster_json
end

-- 从单个路径读配置。优先 json.load_file，失败再 io.open + json.decode。
local function load_holster_config_from_path(relative_path, absolute_path)
    local json = get_holster_json()
    if not json then return nil end

    if type(json.load_file) == "function" then
        local ok, data = pcall(json.load_file, relative_path)
        if ok and type(data) == "table" then
            return data
        end
    end

    local file = safe_io_open(absolute_path, "r")
    if not file then return nil end
    local content = file:read("*a")
    file:close()
    local ok2, data = pcall(json.decode, content)
    if ok2 and type(data) == "table" then return data end
    return nil
end

-- 加载总入口：先新文件，再旧文件；旧文件只迁移 ImmersionEnhancerHolster 字段。
local function load_holster_config()
    local dedicated_config = load_holster_config_from_path(holster_config_relative_path, holster_config_path)
    if type(dedicated_config) == "table" then
        return dedicated_config
    end

    local legacy_config = load_holster_config_from_path(legacy_holster_config_relative_path, legacy_holster_config_path)
    if type(legacy_config) == "table" and legacy_config.ImmersionEnhancerHolster ~= nil then
        return {
            ImmersionEnhancerHolster = legacy_config.ImmersionEnhancerHolster ~= false,
        }
    end

    return nil
end

-- 保存配置：优先 json.dump_file，失败再 encode + safe_io_open 写盘。
local function save_holster_config()
    local json = get_holster_json()
    if not json then return false end

    if type(json.dump_file) == "function" then
        local ok = pcall(json.dump_file, holster_config_relative_path, holster_config)
        if ok then
            return true
        end
    end

    if type(json.encode) ~= "function" then
        return false
    end

    local ok, encoded = pcall(json.encode, holster_config)
    if not ok or type(encoded) ~= "string" then
        return false
    end

    local file = safe_io_open(holster_config_path, "w")
    if not file then
        return false
    end

    file:write(encoded)
    file:close()
    return true
end

-- 冷启动：读盘 → 补默认 → 得到运行时开关 ImmersionEnhancerHolster_enabled。
-- 该开关控制腰/肩/胸/左肩武器槽位手势整组启停（apply_holster_toggle）。
holster_config = load_holster_config()
local holster_config_needs_save = false
local function ensure_panel_toggle(field_name, default_value)
    -- 配置缺字段时写入默认值，并标记稍后 save_holster_config。
    if holster_config[field_name] == nil then
        holster_config[field_name] = default_value
        holster_config_needs_save = true
    end
end

if type(holster_config) ~= "table" then
    holster_config = {}
    holster_config_needs_save = true
end
ensure_panel_toggle("ImmersionEnhancerHolster", true)
-- ~= false：只有明确 false 才关；nil/缺字段/true 都算开。
local ImmersionEnhancerHolster_enabled = holster_config.ImmersionEnhancerHolster ~= false

-- ImGui 每帧绘制前调用：重读配置并同步运行时开关（含热重载后）。
local function refresh_panel_toggles_from_config()
    if type(holster_config) ~= "table" then
        holster_config = load_holster_config() or {}
    end
    ensure_panel_toggle("ImmersionEnhancerHolster", true)
    ImmersionEnhancerHolster_enabled = holster_config.ImmersionEnhancerHolster ~= false
end

-- =============================================================================
-- 第一类：底层依赖与运行骨架（初始化入口）
-- 脚本热重载后兼容旧代码：有些 enhancer:tick 调体仍通过全局名访问，这里提供兼容路径。
-- =============================================================================
if not skip_full_init then
environment:initialize({})

local input = environment.input
local gamepad = environment.gamepad
local actions = environment.actions
local defaultHaptics = environment.defaultHaptics
local gestures = environment.gestures

local Key = input.Key
local MouseButton = input.MouseButton
local GestureValidation_Delay = gestures.GestureValidation_Delay

local gestureSets = environment:createGestureSets(nil)
local gestureTracker = gestureSets.defaultGestureSet
local vrToMouse = environment.vrToMouse

-- =============================================================================
-- 这一段虽然写在配置后面，但本质仍是动作别名和公共辅助；不前移，避免影响上面的配置装载。
-- =============================================================================

local MultiAction = actions.MultiAction
local Mode = actions.Mode
local ModeBasedAction = actions.ModeBasedAction
local ModeSwitch = actions.ModeSwitch
local ModeCopy = actions.ModeCopy
local ModeSwitchWithReset = actions.ModeSwitchWithReset
local CombinedAction = actions.CombinedAction
local Counter = actions.Counter
local ActionSplit = actions.ActionSplit
local Action = actions.Action
local CallbackAction = actions.CallbackAction
local Chain = actions.Chain
local ChainStart = actions.ChainStart
local ChainEnd = actions.ChainEnd
local PersistentAction = actions.PersistentAction
local ActionSequence = actions.ActionSequence
local ActionRepeat = actions.ActionRepeat
local ResetAction = actions.ResetAction
local TimedAction = actions.TimedAction
local GuardedAction = actions.GuardedAction
local RefcountAction = actions.RefcountAction

local function noop_action()
    return Action.new()
end

local HapticsGroup = environment.haptics.HapticsGroup

-- =============================================================================
-- 第二类：由本文将发布的G.在此管理
-- =============================================================================
--[[ pullpin 暂时禁用
local pullpin_state = { active = false }
local function set_pullpin_active(active)
    pullpin_state.active = active and true or false
    _G.pullpin_active = pullpin_state.active
end

set_pullpin_active(false)
]]
_G.pullpin_active = false

--第一类
environment.haptics.applyCompanionGestureDefaults(gestureTracker, defaultHaptics)

-- =============================================================================
-- 这个辅助函数直接服务模块启停，所以归第二类；代码留在这里是为了不改已有执行顺序。
-- =============================================================================

-- 第二类 批量启停一组手势；关闭时顺手 reset，避免模式状态残留。
local function set_gesture_group_enabled(gesture_list, enabled)
    for _, gesture in ipairs(gesture_list) do
        if gesture ~= nil then
            if not enabled then
                gesture:reset()
            end
            gesture.enabled = enabled
        end
    end
end

-- =============================================================================
-- 第三类：定义一些限定条件
-- =============================================================================

-- 定义副手是否空闲（双手持枪）。
local function is_support_hand_free()
    if vr_globals.isTwoHandingWeapon() then
        return false
    end
    return true
end

-- 治疗系统守卫：相应手上必须持有表演道具才能触发治疗动作
-- heal.lua 在 spawn/despawn 时设置 g_heal_left_prop_active / g_heal_right_prop_active
local function is_left_hand_has_prop()
    return rawget(_G, vr_globals.KEYS.heal_left_prop_active) == true
end

local function is_right_hand_has_prop()
    return rawget(_G, vr_globals.KEYS.heal_right_prop_active) == true
end

-- 2026-07-29：左抓握按下状态，由 gestureTracker.gripLeft.action 的 enter/leave 维护
-- 用于 syncTwoHandAim 的前置检查：松手后即使 accessory label 仍为 foregrip（sticky），也不算双手持枪
-- 状态存于 _G[KEYS.left_grip_held]（不用 local upvalue，避免 09 热重载时 upvalue 错位导致断裂）
-- RE_12 通过 vr_globals.isLeftGripHeld() 读取

-- =============================================================================
-- 第三类：游戏 个性化映射
-- 下面开始进入具体的手势到键鼠映射：战斗、交互、槽位、近战都在这一类。
-- =============================================================================

local aimMode

-- 诊断面板里直接显示当前 aimMode 实际对应的命令，便于排查映射是否跑偏。
local function get_current_aim_command()
    if type(aimMode) ~= "table" then
        return "none"
    end
    if aimMode.current == 2 then
        return "Escape"
    end
    return "gamepad RT"
end

-- 基础手势集：
-- 菜单与地图。
aimMode = Mode.new()
gestureTracker.triggerLeft.enabled = true
gestureTracker.triggerLeft.action = ModeSwitchWithReset.new(aimMode, 2, 0)

-- 瞄准。空仓挂机（g_slide_locked）时禁止注入 RMB/LT：否则 AnimBP 会走「瞄准+空弹→换弹」混合，与 hook 无关。
local function is_aim_input_allowed()
    return vr_globals.isAimInputAllowed()
end

local aim_pistol_like_action_inner = MultiAction.new({
    gamepad.Press.new(gamepad.Button.LeftTrigger),
    ModeSwitchWithReset.new(aimMode, 1, 0),
})
local aim_pistol_like_action = GuardedAction.new(aim_pistol_like_action_inner, is_aim_input_allowed)

gestureTracker.aimPistol.enabled = true
gestureTracker.aimPistol.action = aim_pistol_like_action

-- 换弹
--gestureTracker.aimPistol.gripAction = input.KeyPress.new(Key.R)

--切换弹药
--gestureTracker.aimPistol.triggerAction = input.KeyPress.new(Key.F)

-- 治疗（右手持有针剂道具时才允许注射）
gestureTracker.injectSyringe.enabled = true
gestureTracker.injectSyringe.triggerAction = GuardedAction.new(gamepad.Press.new(gamepad.Button.Y), is_right_hand_has_prop)



-- 右手抓握：切 aimMode 3（不受 slide_lock 守卫，空仓仍可走 RT/近战）+ 治疗 despawn
-- LT 仍由 main.lua / aimPistol 负责；leave 发 heal_despawn_right_edge（仅右手道具）
local grip_right_aim_action = ModeSwitchWithReset.new(aimMode, 3, 0)
local grip_right_heal_despawn_action = CallbackAction.new({
    leave = function()
        -- 仅 despawn 右手表演道具（syringe），不影响左手
        _G[vr_globals.KEYS.heal_despawn_right_edge] = true
    end,
})
gestureTracker.gripRight.enabled = true
gestureTracker.gripRight.action = MultiAction.new({
    grip_right_aim_action,
    grip_right_heal_despawn_action,
})

-- 右手扳机：开火（虚拟手柄 RT）；RE_10 通过 triggerRightFireAction 绑定开火震动。
-- 后座力：在 RT Press 同组 MultiAction 上挂 CallbackAction（abandon RequestManualFire hook）。
-- 空仓不能瞄准 → 进不了 mode 1 开火；mode 0 dry-fire 不走本 action。
local function notify_recoil_on_trigger_fire()
    local mod = rawget(_G, "__sh2_recoil_module")
    if type(mod) == "table" and type(mod.on_fire_success) == "function" then
        pcall(mod.on_fire_success, nil, nil)
    end
end

local function make_trigger_right_fire_action(press_factory, callback_factory)
    -- press_factory / callback_factory：冷启动用 locals；热重载用 runtime rg/ra
    return MultiAction.new({
        press_factory(),
        callback_factory({
            enter = notify_recoil_on_trigger_fire,
        }),
    })
end

gestureTracker.triggerRight.enabled = true
local trigger_right_fire_action = make_trigger_right_fire_action(
    function() return gamepad.Press.new(gamepad.Button.RightTrigger) end,
    function(cbs) return CallbackAction.new(cbs) end
)
--local trigger_right_knife_action = input.KeyPress.new(Key.Space)

-- 右扳机默认状态（mode 0）：发出 dry fire 信号，pistol_reload/shotgun_reload 消费后播放空仓扣扳机音效
local trigger_right_dry_fire_action = CallbackAction.new({
    enter = function()
        _G[vr_globals.KEYS.dry_fire_edge] = true
    end,
})

gestureTracker.triggerRight.action = ModeBasedAction.new(aimMode, {
    [0] = trigger_right_dry_fire_action,
    [1] = trigger_right_fire_action,
    -- [2] 原 trigger_right_menu_action（Escape）已移除：左扳机 + 右扳机不再发键；
    -- ModeBasedAction 取不到 [2] 映射即为无动作（UEVR_06_actions getCurrentAction 返回 nil）
    -- mode 3（右手抓握）与 mode 1 共用同一 fire action：
    -- 否则 RT 能开火但 recoil.on_fire_success 收不到 seed → 无后坐力/无 RE_10 震动
    -- 2026-09-19 修复：与热重载路径（[3] = fire）保持一致
    [3] = trigger_right_fire_action,
})


gestureTracker.meleeRight.enabled = true
gestureTracker.meleeRight.action = noop_action()    

--[[体术
gestureTracker.thrustLeft.enabled = true
gestureTracker.thrustLeft.gripAction = input.MousePress.new(MouseButton.Left)
gestureTracker.thrustRight.enabled = true
gestureTracker.thrustRight.gripAction = input.MousePress.new(MouseButton.Left)

-- 扔鱼叉
gestureTracker.upperAreaRight.enabled = true
gestureTracker.upperAreaRight.action = input.MousePress.new(MouseButton.Right)
]]

--[[ pullpin 暂时禁用
-- 拉雷手势。
gestureTracker.pullPin.enabled = true
gestureTracker.pullPin.triggerAction = PersistentAction.new(MultiAction.new({
    CallbackAction.new({
        enter = function()
            set_pullpin_active(true)
        end,
        leave = function()
            set_pullpin_active(false)
        end,
        reset = function()
            set_pullpin_active(false)
        end,
    }),
    input.MousePress.new(MouseButton.Right),
}), 2.0, 1)
]]
gestureTracker.pullPin.enabled = false

-- 蹲伏、重置、侧移。
gestureTracker.duck.enabled = false
gestureTracker.duck.action = input.KeyPress.new(Key.Space)

--重置（含体感桥 reinitialize：bHaptics + TrueGear 停震 / 重开 10s 连接窗口）
gestureTracker.lightLeft.enabled = true
gestureTracker.lightLeft.triggerAction = MultiAction.new({
    CallbackAction.new(function()
        input.resetKB(environment)
    end),
    CallbackAction.new(function()
        pcall(function() environment:reset() end)
    end),
    CallbackAction.new(function()
        pcall(function()
            if environment.haptics ~= nil and type(environment.haptics.reinitialize) == "function" then
                environment.haptics.reinitialize()
            end
        end)
    end),
})

-- 守卫：左手必须持有药瓶道具才能触发喝药（is_left_hand_has_prop）
gestureTracker.mouthLeft.enabled = true
gestureTracker.mouthLeft.action = GuardedAction.new(
    ActionRepeat.new(
        gamepad.Press.new(gamepad.Button.Y),
        2, 0.05, 0.15
    ),
    is_left_hand_has_prop
)

--[[gestureTracker.leanLeft.enabled = false
gestureTracker.leanLeft.action = input.KeyPress.new(Key.A)

gestureTracker.leanRight.enabled = false
gestureTracker.leanRight.action = input.KeyPress.new(Key.D)
]]

-- 交互。
gestureTracker.useRightDown.enabled = true
gestureTracker.useRightDown.gripAction = gamepad.Press.new(gamepad.Button.A)

-- 左手下挥交互（Key.E）；步枪拉栓/握栓，或左手持弹时禁止
-- 直接读 _G 字面量键：避免 00 KEYS 热重载缺字段 / isRifleBoltBusy 未装上
local function is_use_left_down_allowed()
    if rawget(_G, "g_rifle_bolt_busy") == true then
        return false
    end
    if rawget(_G, "g_rifle_bolt_open") == true then
        return false
    end
    if rawget(_G, vr_globals.KEYS.mag_in_left_hand) == true then
        return false
    end
    return true
end
gestureTracker.useLeftDown.enabled = false
gestureTracker.useLeftDown.gripAction = GuardedAction.new(
    input.KeyPress.new(Key.E),
    is_use_left_down_allowed
)

-- 地图/切换楼层
gestureTracker.chestRight.enabled = true
gestureTracker.chestRight.triggerAction = MultiAction.new({
    CallbackAction.new(function()
        _G[vr_globals.KEYS.manual_unequip_signal] = true
        pcall(function()
            uevr.api:dispatch_custom_event("sh2:allow_unequip_window", '{"duration_ms":1000}')
        end)
    end),
    input.KeyPress.new(Key.M),
})


-- 治疗需求 A：chestLeft/Right.gripRetrieveAction 发 spawn edge 信号，heal.lua 消费后 spawn 表演道具
-- chestLeft → spawn health_drink 到左手；chestRight → spawn syringe 到右手
-- .leave do nothing：despawn 由 gripLeft/Right.action.leave 统一处理（分手机制）
-- 不 require heal.lua，通过 00 注册的全局 edge 信号沟通（文件体系隔离约束）
gestureTracker.chestLeft.enabled = true
gestureTracker.chestLeft.gripRetrieveAction = CallbackAction.new({
    enter = function()
        _G[vr_globals.KEYS.heal_spawn_left_edge] = true
    end,
    leave = function()
        -- do nothing：despawn 由 gripLeft.action.leave 统一处理
    end,
})

gestureTracker.chestRight.gripRetrieveAction = CallbackAction.new({
    enter = function()
        _G[vr_globals.KEYS.heal_spawn_right_edge] = true
    end,
    leave = function()
        -- do nothing：despawn 由 gripRight.action.leave 统一处理
    end,
})

--物品栏/背包
gestureTracker.shoulderInventoryLeft.enabled = true
gestureTracker.shoulderInventoryLeft.gripRetrieveAction = input.KeyPress.new(Key.Tab)
-- 左肩存放：销毁 remote_grab 左手表演体（不写库存）
local REMOTE_GRAB_STORE_EDGE = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_store_edge) or "g_remote_grab_store_edge"
local REMOTE_GRAB_E_EDGE = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_e_edge) or "g_remote_grab_e_edge"
local REMOTE_GRAB_WHITELIST_HIT = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_whitelist_hit) or "g_remote_grab_whitelist_hit"
local REMOTE_GRAB_PROP_ACTIVE = (vr_globals.KEYS and vr_globals.KEYS.remote_grab_left_prop_active) or "g_remote_grab_left_prop_active"
gestureTracker.shoulderInventoryLeft.gripStoreAction = CallbackAction.new({
    enter = function()
        -- 左手无 remote_grab 表演体时不写 edge，避免空 store 仍进销毁路径
        local mod = rawget(_G, "__sh2_remote_grab_module")
        local busy = false
        if type(mod) == "table" and type(mod.has_storeable_prop) == "function" then
            busy = mod.has_storeable_prop() == true
        else
            busy = rawget(_G, REMOTE_GRAB_PROP_ACTIVE) == true
        end
        if busy then
            _G[REMOTE_GRAB_STORE_EDGE] = true
        end
    end,
})

-- 左胯取弹：holsterInventoryLeft + grip → 写 g_mag_grab_edge，manual_reload 消费
gestureTracker.holsterInventoryLeft.enabled = true
gestureTracker.holsterInventoryLeft.gripRetrieveAction = CallbackAction.new({
    enter = function()
        _G[vr_globals.KEYS.mag_grab_edge] = true
    end,
})

-- 左手 grip：白名单激光命中时注入 E（remote_grab）；保留 left_grip_held / mag / heal 清理
-- useLeftDown 保持 disabled，不走掌心朝下手势
local remote_grab_e_action = input.KeyQuickPress.new(Key.E)

local function remote_grab_feature_enabled()
    local mod = rawget(_G, "__sh2_remote_grab_module")
    if type(mod) == "table" and type(mod.is_enabled) == "function" then
        return mod.is_enabled() == true
    end
    return false
end

local function grip_left_remote_grab_enter(current_time, from_voice_recognition)
    _G[vr_globals.KEYS.left_grip_held] = true
    if not remote_grab_feature_enabled() then
        return
    end
    local whitelist = rawget(_G, REMOTE_GRAB_WHITELIST_HIT) == true
    local prop_active = rawget(_G, REMOTE_GRAB_PROP_ACTIVE) == true
    local heal_left = rawget(_G, vr_globals.KEYS.heal_left_prop_active) == true
    local mag_left = rawget(_G, vr_globals.KEYS.mag_in_left_hand) == true
    -- 白名单门控：锥体命中白名单物品才注入 E
    if whitelist and not prop_active and not heal_left and not mag_left then
        remote_grab_e_action:enter(current_time, from_voice_recognition)
        _G[REMOTE_GRAB_E_EDGE] = true
    end
end

local function grip_left_remote_grab_leave()
    _G[vr_globals.KEYS.left_grip_held] = false
    if rawget(_G, vr_globals.KEYS.mag_in_left_hand) == true then
        _G[vr_globals.KEYS.mag_grab_release] = true
    end
    -- despawn 左手表演道具（仅左手，不影响右手）
    _G[vr_globals.KEYS.heal_despawn_left_edge] = true
    -- 松开左抓握键入包（默认关闭，由 remote_grab 面板开关控制；持有表演体时才销毁）
    local rg_mod = rawget(_G, "__sh2_remote_grab_module")
    if type(rg_mod) == "table" and type(rg_mod.try_store_on_gripleft_release) == "function" then
        rg_mod.try_store_on_gripleft_release()
    end
end

gestureTracker.gripLeft.enabled = true
gestureTracker.gripLeft.action = CallbackAction.new({
    enter = grip_left_remote_grab_enter,
    leave = grip_left_remote_grab_leave,
})

--[[
gestureTracker.swipeLeftHandUp.enabled = true
gestureTracker.swipeLeftHandUp.gripAction = input.KeyPress.new(Key.T)
gestureTracker.swipeLeftHandDown.enabled = true
gestureTracker.swipeLeftHandDown.gripAction = input.KeyPress.new(Key.G)
]]

--菜单
--[[
gestureTracker.swipeLeftHandLeft.enabled = true
gestureTracker.swipeLeftHandLeft.gripAction = input.KeyPress.new(Key.Z)
gestureTracker.swipeLeftHandRight.enabled = true
gestureTracker.swipeLeftHandRight.gripAction = input.KeyPress.new(Key.C)
]]



-- 武器槽位模块。
-- 右腰、右肩、右胸、左肩的数字键绑定都集中在这里；诊断面板读取的最近一次槽位事件也在这里维护。
local last_weapon_slot_event = {
    region = "none",
    binding = "none",
    key = "none",
    source = "none",
    at = 0.0,
}

local function record_weapon_slot_event(region_name, binding_name, digit_name, current_time, from_voice_recognition)
    local region = region_name or "unknown"
    local binding = binding_name or "unknown"
    local key = tostring(digit_name or "?")
    local source = from_voice_recognition and "voice" or "gesture"
    local at = current_time or os.clock()

    _G[vr_globals.KEYS.weapon_slot_region] = region
    _G[vr_globals.KEYS.weapon_slot_binding] = binding
    _G[vr_globals.KEYS.weapon_slot_key] = key
    _G[vr_globals.KEYS.weapon_slot_source] = source
    _G[vr_globals.KEYS.weapon_slot_at] = at

    last_weapon_slot_event.region = region
    last_weapon_slot_event.binding = binding
    last_weapon_slot_event.key = key
    last_weapon_slot_event.source = source
    last_weapon_slot_event.at = at
end

local function get_last_weapon_slot_event()
    return {
        region = last_weapon_slot_event.region,
        binding = last_weapon_slot_event.binding,
        key = last_weapon_slot_event.key,
        source = last_weapon_slot_event.source,
        at = last_weapon_slot_event.at,
    }
end

local SLOT_HAPTIC_CLASS_BY_REGION_BINDING = {
    holsterWeaponRight = { grip = "Pistol", trigger = "AutoPistol" },
    shoulderWeaponRight = { grip = "Shotgun", trigger = "AutoShotgun" },
    shoulderWeaponLeft = { grip = "Rifle", trigger = "AutoRifle" },
}

local function set_slot_haptic_class(region_name, binding_name)
    local region_map = SLOT_HAPTIC_CLASS_BY_REGION_BINDING[region_name]
    if region_map == nil then
        return
    end

    local haptic_class = region_map[binding_name]
    if haptic_class ~= nil then
        _G[vr_globals.KEYS.last_slot_haptic_class] = haptic_class
    end
end

local function create_weapon_slot_press(region_name, binding_name, digit_name, key_code)
    return MultiAction.new({
        CallbackAction.new(function(current_time, from_voice_recognition)
            record_weapon_slot_event(region_name, binding_name, digit_name, current_time, from_voice_recognition)
            set_slot_haptic_class(region_name, binding_name)
        end),
        input.KeyPress.new(key_code),
    })
end

local function create_weapon_slot_gamepad_press(region_name, binding_name, digit_name, gamepad_button)
    return MultiAction.new({
        CallbackAction.new(function(current_time, from_voice_recognition)
            record_weapon_slot_event(region_name, binding_name, digit_name, current_time, from_voice_recognition)
            set_slot_haptic_class(region_name, binding_name)
            -- §17: 切枪时直接发窗口信号，每个 slot 独立触发
            _G[vr_globals.KEYS.manual_unequip_signal] = true
            _G.g_trigger_action_count = (_G.g_trigger_action_count or 0) + 1
            _G.g_last_allow_unequip_info = {
                slot = region_name,
                action = "switch",
                binding = binding_name,
                time = os.clock(),
            }
            local ok, err = pcall(function()
                uevr.api:dispatch_custom_event("sh2:allow_unequip_window", '{"duration_ms":1000}')
            end)
            if not ok then
                _G.g_last_allow_unequip_info.err = tostring(err)
            end
        end),
        gamepad.Press.new(gamepad_button),
    })
end

-- 通过 SHWeaponManageCmbSubcomp:RequestUnequipWeapon(false) 调用游戏API卸下武器
-- 正确路径：pawn.Mesh.AnimScriptInstance.WeaponManageCmbSubcomp（与 main.lua / manual_reload.lua 一致）
-- 旧路径 pawn.Combat:FindSubcomponentByClass(cls) 无效：SHWeaponManageCmbSubcomp 不注册在 Combat 下
-- §17: 主动收枪前先发 allow_unequip_window 信号给 DLL，放行本次收枪（拦截只针对自动收枪）
local function request_unequip_weapon()
    local pawn = uevr.api:get_local_pawn(0)
    if pawn == nil then return end

    local mesh = pawn.Mesh
    if mesh == nil then return end

    local anim_inst = mesh.AnimScriptInstance
    if anim_inst == nil then return end

    local weapon_manage = anim_inst.WeaponManageCmbSubcomp
    if weapon_manage == nil then return end

    -- 通知 DLL：这是手动收枪，放行一次
    _G[vr_globals.KEYS.manual_unequip_signal] = true
    _G.g_last_allow_unequip_info = {
        slot = "unequip",
        action = "holster",
        time = os.clock(),
    }
    pcall(function()
        uevr.api:dispatch_custom_event("sh2:allow_unequip_window", '{"duration_ms":1000}')
    end)

    weapon_manage:RequestUnequipWeapon(false)
end

local function configure_weapon_slot_bindings()
    -- §17: 切枪时 dispatch 已内置于 create_weapon_slot_gamepad_press 回调中，每个 slot 独立触发

    gestureTracker.holsterWeaponRight.gripRetrieveAction = create_weapon_slot_gamepad_press(
        "holsterWeaponRight", "grip", "dpad_left", gamepad.Button.DpadLeft)
    gestureTracker.holsterWeaponRight.gripStoreAction = CallbackAction.new(function(current_time, from_voice_recognition)
        record_weapon_slot_event("holsterWeaponRight", "grip", "unequip", current_time, from_voice_recognition)
        set_slot_haptic_class("holsterWeaponRight", "grip")
        request_unequip_weapon()
    end)
    --gestureTracker.holsterWeaponRight.triggerAction = create_weapon_slot_gamepad_press("holsterWeaponRight", "trigger", "rt", gamepad.Button.RightTrigger)

    gestureTracker.shoulderWeaponRight.gripRetrieveAction = create_weapon_slot_gamepad_press(
        "shoulderWeaponRight", "grip", "dpad_down", gamepad.Button.DpadDown)
    gestureTracker.shoulderWeaponRight.gripStoreAction = CallbackAction.new(function(current_time, from_voice_recognition)
        record_weapon_slot_event("shoulderWeaponRight", "grip", "unequip", current_time, from_voice_recognition)
        set_slot_haptic_class("shoulderWeaponRight", "grip")
        request_unequip_weapon()
    end)
    gestureTracker.shoulderWeaponRight.triggerRetrieveAction = create_weapon_slot_gamepad_press("shoulderWeaponRight", "trigger", "RT", gamepad.Button.RightTrigger)
    gestureTracker.shoulderWeaponRight.triggerStoreAction = CallbackAction.new(function(current_time, from_voice_recognition)
        record_weapon_slot_event("shoulderWeaponRight", "trigger", "unequip", current_time, from_voice_recognition)
        set_slot_haptic_class("shoulderWeaponRight", "trigger")
        request_unequip_weapon()
    end)

    --gestureTracker.chestRight.gripAction = create_weapon_slot_press("chestRight", "grip", "3", Key.D3)
    --gestureTracker.chestRight.triggerAction = create_weapon_slot_press("chestRight", "trigger", "7", Key.D7)

    gestureTracker.shoulderWeaponLeft.gripRetrieveAction = create_weapon_slot_gamepad_press(
        "shoulderWeaponLeft", "grip", "dpad_right", gamepad.Button.DpadRight)
    gestureTracker.shoulderWeaponLeft.gripStoreAction = CallbackAction.new(function(current_time, from_voice_recognition)
        record_weapon_slot_event("shoulderWeaponLeft", "grip", "unequip", current_time, from_voice_recognition)
        set_slot_haptic_class("shoulderWeaponLeft", "grip")
        request_unequip_weapon()
    end)
    --gestureTracker.shoulderWeaponLeft.triggerAction = create_weapon_slot_press("shoulderWeaponLeft", "trigger", "8", Key.D8)
end

configure_weapon_slot_bindings()

local holster_toggle_gestures = {
    gestureTracker.holsterWeaponRight,
    gestureTracker.shoulderWeaponRight,
    gestureTracker.chestRight,
    gestureTracker.shoulderWeaponLeft,
}

local function apply_holster_toggle()
    set_gesture_group_enabled(holster_toggle_gestures, ImmersionEnhancerHolster_enabled ~= false)
end

-- =============================================================================
-- 第二类：微调设置与模块开关（收口）
-- =============================================================================

apply_holster_toggle()
if holster_config_needs_save then
    save_holster_config()
end

-- 暴露给其他脚本。
enhancer = {
    environment = environment,
    gestureSets = gestureSets,
    gestureTracker = gestureTracker,
    triggerRightFireAction = trigger_right_fire_action,
    aimMode = aimMode,
    -- pullpinState = pullpin_state,
    pullpinState = { active = false },
    getCurrentAimCommand = get_current_aim_command,
    getLastWeaponSlotEvent = get_last_weapon_slot_event,
    getLastWeaponSlotAction = get_last_weapon_slot_event,
    vrToMouse = vrToMouse,
    holsterConfig = holster_config,
    applyHolsterToggle = apply_holster_toggle,
    _last_tick_at = 0.0,
    _last_tick_source = "uninitialized",
    _fallback_active = false,
    _twoHandAimHold = false,
    _aimPistolLikeAction = aim_pistol_like_action,
}

end -- not skip_full_init

-- 空仓挂机瞄准拦截：只松 aimPistol（LT/mode1），不要 leave gripRight
-- 否则每帧把 aimMode 3 打回 0，空仓右抓握+RT 永远进不去
local function release_injected_pistol_aim(enhancer_obj)
    if type(enhancer_obj) ~= "table" then
        return
    end
    pcall(function()
        if type(enhancer_obj._aimPistolLikeAction) == "table"
            and type(enhancer_obj._aimPistolLikeAction.leave) == "function" then
            enhancer_obj._aimPistolLikeAction:leave()
        end
    end)
    enhancer_obj._twoHandAimHold = false
end

local function install_slide_lock_aim_on_enhancer(target)
    if type(target) ~= "table" then
        return
    end

    function target:syncTwoHandAim(current_time)
        local action = self._aimPistolLikeAction
        if action == nil then
            return
        end
        if not vr_globals.isAimInputAllowed() then
            if self._twoHandAimHold then
                action:leave()
                self._twoHandAimHold = false
            end
            return
        end
        local left_grip_held = rawget(_G, vr_globals.KEYS.left_grip_held) == true
        local want_two_hand = vr_globals.isTwoHandingWeapon() and left_grip_held
        if want_two_hand and not self._twoHandAimHold then
            action:enter(current_time, false)
            self._twoHandAimHold = true
        elseif not want_two_hand and self._twoHandAimHold then
            action:leave()
            self._twoHandAimHold = false
        elseif want_two_hand and self._twoHandAimHold then
            action:update(current_time)
        end
    end

    function target:tick(source)
        self._last_tick_at = os.clock()
        self._last_tick_source = source or "unknown"

        if self.hapticFeedbackManager ~= nil and type(self.hapticFeedbackManager.syncCurrentWeapon) == "function" then
            self.hapticFeedbackManager:syncCurrentWeapon()
            if self.hapticFeedbackEnabled ~= false and type(self.hapticFeedbackManager.applyHapticFeedbackGroup) == "function" then
                self.hapticFeedbackManager:applyHapticFeedbackGroup()
            elseif type(self.hapticFeedbackManager.applyTouchOnlyGroup) == "function" then
                self.hapticFeedbackManager:applyTouchOnlyGroup()
            end
        end

        if type(self.environment) == "table" and type(self.environment.tick) == "function" then
            self.environment:tick(self._last_tick_at)
        end

        if type(self.syncTwoHandAim) == "function" then
            self:syncTwoHandAim(self._last_tick_at)
        end

        -- 诊断：leftGrip 原始值 + gripLeft.inGesture，定位 enter 为何不触发
        local _diag_vr_state = self.environment and type(self.environment.getVRState) == "function" and self.environment:getVRState() or nil
        _G["g_diag_left_grip_value"] = (_diag_vr_state and _diag_vr_state.leftGrip) or 0.0
        local _diag_gl = self.gestureTracker and self.gestureTracker.gripLeft
        _G["g_diag_grip_left_in_gesture"] = (_diag_gl ~= nil and _diag_gl.inGesture == true)

        if not vr_globals.isAimInputAllowed() then
            release_injected_pistol_aim(self)
            _G[vr_globals.KEYS.aim_active] = false
            return
        end

        local aim_pistol_gesture = self.gestureTracker and self.gestureTracker.aimPistol
        local is_aiming = (aim_pistol_gesture and aim_pistol_gesture.inGesture) or (self._twoHandAimHold == true)
        _G[vr_globals.KEYS.aim_active] = is_aiming
    end
end

local enhancer = existing_enhancer or enhancer
install_slide_lock_aim_on_enhancer(enhancer)

-- =============================================================================
-- UI 在冷启动与脚本热重载时都会注册，避免 Scripts 面板菜单消失。
-- =============================================================================

local function register_immersion_enhancer_ui()
    if rawget(_G, "__UEVR09_immersion_ui_registered") == true then
        return
    end

    local registered = compat.on_draw_ui(function()
        refresh_panel_toggles_from_config()
        local active_enhancer = environment:getEnhancer() or enhancer

        imgui.separator()
        imgui.text_colored("Immersion Enhancer", 0xFF00FFFF)
        local holster_changed, holster_enabled = imgui.checkbox("Enable holster weapon slots", ImmersionEnhancerHolster_enabled ~= false)
        if holster_changed then
            ImmersionEnhancerHolster_enabled = holster_enabled and true or false
            holster_config.ImmersionEnhancerHolster = ImmersionEnhancerHolster_enabled
            if type(active_enhancer) == "table" and type(active_enhancer.applyHolsterToggle) == "function" then
                active_enhancer.applyHolsterToggle()
            elseif type(apply_holster_toggle) == "function" then
                apply_holster_toggle()
            end
            save_holster_config()
        end

    end)

    if registered then
        _G.__UEVR09_immersion_ui_registered = true
    end
end

if not skip_full_init then
    environment:attachEnhancerRuntime(enhancer)
end

register_immersion_enhancer_ui()

-- =============================================================================
-- 【第二类 · 热重载迁移】skip_full_init 分支（Scripts 重载 RE_09 时进入，非冷启动）
-- =============================================================================
-- 保留内存里已有的 enhancer，只 patch 缺字段/旧 closure，再 attachEnhancerRuntime。
-- 移植其它作品时这里最常改：要同步哪些 _G、补哪些 enhancer 字段、重绑哪些手势。
--
-- 当前维护项：
--   pullpinState        → _G.pullpin_active
--   _aimPistolLikeAction（syncTwoHandAim 依赖）
--   triggerLeft.action  → 菜单 ModeSwitchWithReset 重绑
--   syncTwoHandAim      + _twoHandAimHold（缺则补定义）
--
-- 注意：syncTwoHandAim 与冷启动处逻辑需保持一致；改第三类业务时两处都要看。
-- =============================================================================
if skip_full_init then
    -- 重载前松开模拟输入，避免键鼠卡住
    local old_env = rawget(_G, "VREnvironment")
    if old_env ~= nil then
        if type(old_env.input) == "table" and type(old_env.input.releaseAll) == "function" then
            old_env.input.releaseAll()
        end
    end

    --[[ pullpin 暂时禁用
    -- 拉雷运行时标志：旧 enhancer → _G
    local existing_pullpin_state = existing_enhancer.pullpinState
    if type(existing_pullpin_state) == "table" then
        _G.pullpin_active = existing_pullpin_state.active == true
    elseif rawget(_G, "pullpin_active") == nil then
        _G.pullpin_active = false
    end
    ]]
    _G.pullpin_active = false

    -- 瞄准运行时标志：空仓挂机时不向游戏注入瞄准
    if not vr_globals.isAimInputAllowed() then
        release_injected_pistol_aim(existing_enhancer)
        _G[vr_globals.KEYS.aim_active] = false
    else
        local existing_aim_pistol = existing_enhancer.gestureTracker and existing_enhancer.gestureTracker.aimPistol
        local is_aiming = (existing_aim_pistol and existing_aim_pistol.inGesture)
            or (existing_enhancer._twoHandAimHold == true)
        _G[vr_globals.KEYS.aim_active] = is_aiming
    end

    -- 热重载：用 runtime_env 重绑 gripRight→mode3、triggerRight[3]=RT（冷启动 locals 在此为 nil）
    if type(existing_enhancer.gestureTracker) == "table"
        and type(existing_enhancer.aimMode) == "table" then
        local runtime_env = existing_enhancer.environment or rawget(_G, "VREnvironment")
        local ra = type(runtime_env) == "table" and runtime_env.actions or nil
        local rg = type(runtime_env) == "table" and runtime_env.gamepad or nil
        local ri = type(runtime_env) == "table" and runtime_env.input or nil
        if type(ra) == "table" and type(rg) == "table" and type(ri) == "table"
            and type(ra.ModeSwitchWithReset) == "table"
            and type(ra.ModeBasedAction) == "table"
            and type(ra.MultiAction) == "table"
            and type(ra.CallbackAction) == "table"
            and type(rg.Press) == "table"
            and rg.Button ~= nil
            and type(ri.KeyPress) == "table"
            and ri.Key ~= nil then
            if type(existing_enhancer.gestureTracker.gripRight) == "table" then
                existing_enhancer.gestureTracker.gripRight.action = ra.MultiAction.new({
                    ra.ModeSwitchWithReset.new(existing_enhancer.aimMode, 3, 0),
                    ra.CallbackAction.new({
                        leave = function()
                            _G[vr_globals.KEYS.heal_despawn_right_edge] = true
                        end,
                    }),
                })
            end
            if type(existing_enhancer.gestureTracker.triggerRight) == "table" then
                -- 与冷启动一致：RT Press + recoil CallbackAction 合成；暴露给 RE_10 haptics
                local fire = ra.MultiAction.new({
                    rg.Press.new(rg.Button.RightTrigger),
                    ra.CallbackAction.new({
                        enter = function()
                            local mod = rawget(_G, "__sh2_recoil_module")
                            if type(mod) == "table" and type(mod.on_fire_success) == "function" then
                                pcall(mod.on_fire_success, nil, nil)
                            end
                        end,
                    }),
                })
                existing_enhancer.triggerRightFireAction = fire
                existing_enhancer.gestureTracker.triggerRight.action = ra.ModeBasedAction.new(existing_enhancer.aimMode, {
                    [0] = ra.CallbackAction.new({
                        enter = function()
                            _G[vr_globals.KEYS.dry_fire_edge] = true
                        end,
                    }),
                    [1] = fire,
                    -- [2] 已移除（原 Escape）：左扳机 + 右扳机不再发键
                    [3] = fire,
                })
            end
            if type(existing_enhancer.gestureTracker.lightLeft) == "table" then
                existing_enhancer.gestureTracker.lightLeft.enabled = true
                existing_enhancer.gestureTracker.lightLeft.trigerAction = ra.MultiAction.new({
                    ra.CallbackAction.new(function()
                        if type(ri.resetKB) == "function" then
                            ri.resetKB(runtime_env)
                        end
                    end),
                    ra.CallbackAction.new(function()
                        pcall(function() runtime_env:reset() end)
                    end),
                    ra.CallbackAction.new(function()
                        pcall(function()
                            local h = runtime_env.haptics
                            if h ~= nil and type(h.reinitialize) == "function" then
                                h.reinitialize()
                            end
                        end)
                    end),
                })
            end
            -- 热重载：useLeftDown 拉栓/持弹守卫（与冷启动一致）
            if type(existing_enhancer.gestureTracker.useLeftDown) == "table"
                and type(ra.GuardedAction) == "table" then
                existing_enhancer.gestureTracker.useLeftDown.enabled = true
                existing_enhancer.gestureTracker.useLeftDown.gripAction = ra.GuardedAction.new(
                    ri.KeyPress.new(ri.Key.E),
                    function()
                        if rawget(_G, "g_rifle_bolt_busy") == true then
                            return false
                        end
                        if rawget(_G, "g_rifle_bolt_open") == true then
                            return false
                        end
                        if rawget(_G, vr_globals.KEYS.mag_in_left_hand) == true then
                            return false
                        end
                        return true
                    end
                )
            end
        end
    end

    -- 2026-07-29：热重载时 gripLeft.action 也要重建，否则旧 callback 写旧 upvalue/缺 _G 写入，left_grip_held 断裂
    -- callback 逻辑须与冷启动 gripLeft.action 处保持一致
    if type(existing_enhancer.gestureTracker) == "table"
        and type(existing_enhancer.gestureTracker.gripLeft) == "table" then
        local runtime_env = existing_enhancer.environment or rawget(_G, "VREnvironment")
        local runtime_actions = type(runtime_env) == "table" and runtime_env.actions or nil
        if type(runtime_actions) == "table" and type(runtime_actions.CallbackAction) == "table" then
            existing_enhancer.gestureTracker.gripLeft.enabled = true
            existing_enhancer.gestureTracker.gripLeft.action = runtime_actions.CallbackAction.new({
                enter = grip_left_remote_grab_enter,
                leave = grip_left_remote_grab_leave,
            })
        end
    end
    install_slide_lock_aim_on_enhancer(existing_enhancer)

    -- 热重载后 triggerLeft 菜单切换 action 可能指向旧 closure，需重建
    if type(existing_enhancer.gestureTracker) == "table"
        and type(existing_enhancer.aimMode) == "table"
        and type(existing_enhancer.gestureTracker.triggerLeft) == "table" then
        local runtime_env = existing_enhancer.environment or rawget(_G, "VREnvironment")
        if type(runtime_env) == "table" and type(runtime_env.actions) == "table" then
            existing_enhancer.gestureTracker.triggerLeft.action =
                runtime_env.actions.ModeSwitchWithReset.new(existing_enhancer.aimMode, 2, 0)
        end
    end

    -- 重新挂 UpdateBehavior / on_frame；跳过后面的冷启动 init
    local existing_environment = existing_enhancer.environment or rawget(_G, "VREnvironment")
    if type(existing_environment) == "table" then
        environment:attachEnhancerRuntime(existing_enhancer)
    end
    patch_enhancer_mag_drop_edge(existing_enhancer)
    return existing_enhancer
end

-- =============================================================================
-- 【第一类 · 模块收口】冷启动路径：全局导出与 require 返回值
-- =============================================================================
-- 全局导出统一由 RE_08_environment.publishEnhancer 完成，这里仅确保兼容路径可用。
environment:publishEnhancer(enhancer)
patch_enhancer_mag_drop_edge(enhancer)

-- require 本文件时返回同一份 enhancer 实例，属于模块对外接口收口。
return enhancer
