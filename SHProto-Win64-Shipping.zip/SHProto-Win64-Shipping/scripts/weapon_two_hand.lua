--[[修改说明：
1. 独立 WeaponDriver：左右 MotionController → 唯一武器世界姿态 → 驱动可见 Mesh
2. 双手激活时 Mesh 脱离 hand_r_bn，避免"手拉枪、枪再锁手"的反馈环
3. 右手 IK 只覆写旋转（跟枪相对角），位置仍跟真实 MC；后坐改走 Mesh 权威（RE9：后坐进双手/武器解算）
4. 左手 accessory socket 跟枪 Mesh，故随 Mesh 后坐一起动
5. Root/FirePoint 读已含后坐的 Mesh，双手时勿再 apply_to_aim_transform
6. 门控：rifle/shotgun + Holder/foregrip + 左 Grip；换弹/拉栓禁用
7. left_stability 默认 0：清洁求解不把枪从右手 MC 握点拽开
8. 后坐：清洁求解 → 绝对弹簧 → 绕右手握点枢轴补偿再写 Mesh（勿绕 Mesh 原点）
9. 纯数学/求解逻辑已下沉至 libs/weapon_tools.lua（零 SDK、零 IO、零游戏语义）
]]--

local uevrUtils = require("libs/uevr_utils")
local controllers = require("libs/controllers")
local configui = require("libs/configui")
local accessories = require("libs/accessories")
local attachments = require("libs/attachments")
local vr_globals = require("UEVR_00_init_globals")
local weaponTools = require("libs/weapon_tools")

local M = {}
local KEYS = vr_globals.KEYS

local config = {
    enabled = true,
    support_labels = { "Holder", "foregrip" },
    support_lookup = {},
}

local solver_state = weaponTools.new_solver_state()

local state = {
    last_weapon = nil,
    last_labels_text = nil,
    config_panel_created = false,
    support_docked = false,
    gate_ok = false,
    gate_reason = "init",
    weapon_type = "none",
    left_label = nil,
    left_grip = false,
    reload_blocked = false,
    world_drive = false,
    mesh_ref = nil,
    weapon_loc = nil,
    weapon_rot = nil,
    ctrl_override_loc = nil,
    ctrl_override_rot = nil,
    clean_weapon_loc = nil,
    clean_weapon_rot = nil,
    mesh_recoil_applied = false,
    last_solve = nil,
    last_fail_reason = nil,
}

-- ===== UE 转换 =====

local function v3_to_ue(v)
    if v == nil then return nil end
    return uevrUtils.vector(v.X or 0, v.Y or 0, v.Z or 0)
end

local function rot_to_ue(r)
    if r == nil then return nil end
    return uevrUtils.rotator(r.Pitch or 0, r.Yaw or 0, r.Roll or 0)
end

local function quat_to_rotator_tbl(q)
    local r = uevrUtils.rotatorFromQuat(q.X or q.x, q.Y or q.y, q.Z or q.z, q.W or q.w)
    return weaponTools.rot_copy(r)
end

-- 立刻从 MotionControllerComponent 读取并拷贝（非 raw VR pose）
local function read_motion_controller_pose(handed)
    local comp = controllers.getController(handed, true)
    if uevrUtils.getValid(comp) == nil then
        return nil, nil, nil
    end
    local loc, rot = nil, nil
    pcall(function()
        loc = comp:K2_GetComponentLocation()
        rot = comp:K2_GetComponentRotation()
    end)
    return weaponTools.v3_copy(loc), weaponTools.rot_copy(rot), comp
end

-- ===== 白名单 =====

local function rebuild_support_lookup()
    config.support_lookup = {}
    for _, label in ipairs(config.support_labels) do
        config.support_lookup[label] = true
    end
end

local function parse_labels(text)
    local labels = {}
    for label in string.gmatch(text or "", "[^,]+") do
        local trimmed = string.match(label, "^%s*(.-)%s*$")
        if trimmed ~= nil and trimmed ~= "" then
            table.insert(labels, trimmed)
        end
    end
    if #labels == 0 then
        labels = { "Holder", "foregrip" }
    end
    return labels
end

-- ===== 状态 =====

local function set_world_drive_flag(on)
    state.world_drive = on == true
    _G.__sh2_two_hand_world_drive = state.world_drive
    if not state.world_drive then
        state.mesh_recoil_applied = false
        _G.__sh2_two_hand_mesh_recoil_applied = false
    end
end

local function clear_overrides()
    state.weapon_loc = nil
    state.weapon_rot = nil
    state.ctrl_override_loc = nil
    state.ctrl_override_rot = nil
    state.clean_weapon_loc = nil
    state.clean_weapon_rot = nil
    state.mesh_recoil_applied = false
    state.last_solve = nil
    _G.__sh2_two_hand_mesh_recoil_applied = false
end

--- 清洁武器姿态上叠加绝对后坐弹簧（不回写 last_blended）
--- 旋转绕右手握点 right_grip_local，避免绕 Mesh 原点导致枪管上扬、握把下压
--- （步枪握点杠杆约 34cm，霰弹约 15cm，原点旋转时步枪更明显）
local function apply_recoil_to_weapon_pose(loc_tbl, rot_tbl)
    if loc_tbl == nil or rot_tbl == nil then
        return loc_tbl, rot_tbl, false
    end
    local mod = rawget(_G, "__sh2_recoil_module")
    if type(mod) ~= "table" then
        return loc_tbl, rot_tbl, false
    end
    local active = false
    pcall(function()
        active = mod.is_active ~= nil and mod.is_active() == true
    end)
    if not active or type(mod.apply_to_aim_transform) ~= "function" then
        return loc_tbl, rot_tbl, false
    end

    local base_loc = v3_to_ue(loc_tbl)
    local base_rot = rot_to_ue(rot_tbl)
    if base_loc == nil or base_rot == nil then
        return loc_tbl, rot_tbl, false
    end

    local ok, packed = pcall(function()
        -- 步枪/霰弹 Mesh 轴向与手枪手骨不同：上扬走 Roll
        local l, r = mod.apply_to_aim_transform(base_loc, base_rot, { long_gun_mesh_axes = true })
        return { loc = l, rot = r }
    end)
    if not ok or type(packed) ~= "table" or packed.loc == nil or packed.rot == nil then
        return loc_tbl, rot_tbl, false
    end

    local new_rot = weaponTools.rot_copy(packed.rot)
    local linear_kick = weaponTools.v3_sub(weaponTools.v3_copy(packed.loc), loc_tbl)
    local grip = solver_state.right_grip_local
    if grip ~= nil and new_rot ~= nil then
        local clean_q = weaponTools.rotator_to_quat(rot_tbl)
        local new_q = weaponTools.rotator_to_quat(new_rot)
        local grip_w = weaponTools.v3_add(loc_tbl, weaponTools.quat_rotate_v3(grip, clean_q))
        local pivoted = weaponTools.v3_sub(grip_w, weaponTools.quat_rotate_v3(grip, new_q))
        return weaponTools.v3_add(pivoted, linear_kick), new_rot, true
    end
    return weaponTools.v3_copy(packed.loc), new_rot, true
end

local function reset_solver_state()
    weaponTools.reset_solver_state(solver_state)
    clear_overrides()
    set_world_drive_flag(false)
    state.mesh_ref = nil
end

local function publish_globals()
    local support = state.support_docked == true
    local aiming = solver_state.active == true and state.gate_ok == true and state.world_drive == true
    _G.g_is_support_docked = support
    _G.g_is_two_hand_aiming_active = aiming
    _G.g_is_two_handing_weapon = support
    _G.__sh2_two_hand_aim_active = aiming
end

-- ===== 门控 =====

local function is_reload_blocked()
    if rawget(_G, KEYS.rifle_bolt_busy) == true then return true, "rifle_bolt_busy" end
    if rawget(_G, KEYS.rifle_bolt_open) == true then return true, "rifle_bolt_open" end
    if rawget(_G, KEYS.mag_in_left_hand) == true then return true, "mag_in_left_hand" end
    if rawget(_G, KEYS.block_closed_hands_dock) == true then return true, "block_closed_hands_dock" end
    if rawget(_G, KEYS.manual_reload_active) == true then return true, "manual_reload_active" end
    return false, nil
end

local function evaluate_gating()
    state.weapon_type = vr_globals.getCurrentWeaponType() or "none"
    state.left_label = rawget(_G, KEYS.active_left_accessory_label)
    state.left_grip = accessories.isGripDown(Handed.Left) == true
        or vr_globals.isLeftGripHeld() == true

    local reload_blocked, reload_reason = is_reload_blocked()
    state.reload_blocked = reload_blocked

    local left_attached = rawget(_G, KEYS.left_accessory_attached) == true
    local label_ok = state.left_label ~= nil and config.support_lookup[state.left_label] == true
    state.support_docked = left_attached and label_ok

    if not config.enabled then
        state.gate_ok = false
        state.gate_reason = "disabled"
        return false
    end
    if rawget(_G, KEYS.heal_right_prop_active) == true then
        state.gate_ok = false
        state.gate_reason = "heal_right_prop"
        return false
    end
    if state.weapon_type ~= "rifle" and state.weapon_type ~= "shotgun" then
        state.gate_ok = false
        state.gate_reason = "weapon_type=" .. tostring(state.weapon_type)
        return false
    end
    if reload_blocked then
        state.gate_ok = false
        state.gate_reason = "reload:" .. tostring(reload_reason)
        return false
    end
    if not left_attached then
        state.gate_ok = false
        state.gate_reason = "left_not_attached"
        return false
    end
    if not label_ok then
        state.gate_ok = false
        state.gate_reason = "label=" .. tostring(state.left_label)
        return false
    end
    if not state.left_grip then
        state.gate_ok = false
        state.gate_reason = "left_grip_up"
        return false
    end

    state.gate_ok = true
    state.gate_reason = "ok"
    return true
end

-- ===== Mesh 驱动 =====

local function get_weapon_mesh()
    local mesh = nil
    pcall(function()
        mesh = attachments.getCurrentGrippedAttachment(Handed.Right)
    end)
    if uevrUtils.getValid(mesh) == nil then
        return nil
    end
    return mesh
end

local function read_raw_mesh_pose(mesh)
    if mesh == nil then return nil, nil end
    local loc, rot = nil, nil
    pcall(function()
        loc = mesh:K2_GetComponentLocation()
        rot = mesh:K2_GetComponentRotation()
    end)
    return weaponTools.v3_copy(loc), weaponTools.rot_copy(rot)
end

local function ensure_mesh_detached(mesh)
    if mesh == nil then return end
    pcall(function()
        if mesh.AttachParent ~= nil and mesh.DetachFromParent ~= nil then
            -- maintainWorld=true：脱手瞬间不跳变
            mesh:DetachFromParent(true, false)
        end
    end)
end

local function write_mesh_world(mesh, loc_tbl, rot_tbl)
    if mesh == nil or loc_tbl == nil or rot_tbl == nil then return false end
    local loc = v3_to_ue(loc_tbl)
    local rot = rot_to_ue(rot_tbl)
    if loc == nil or rot == nil then return false end
    local ok = pcall(function()
        ensure_mesh_detached(mesh)
        if mesh.K2_SetWorldLocation ~= nil then
            mesh:K2_SetWorldLocation(loc, false, reusable_hit_result, false)
        end
        if mesh.K2_SetWorldRotation ~= nil then
            mesh:K2_SetWorldRotation(rot, false, reusable_hit_result, false)
        end
    end)
    return ok == true
end

-- ===== 配置 UI =====

local function build_config_widgets()
    return {
        { widgetType = "text", label = "Two-Hand Weapon Driver (Mesh authority)" },
        { widgetType = "tree_node", id = "thw_params_tree", initialOpen = true, label = "Parameters" },
            {
                widgetType = "drag_float",
                id = "thw_rotation_blend_speed",
                label = "Rotation Blend Speed",
                speed = 0.1,
                range = { 0.1, 100.0 },
                initialValue = 8.0,
            },
            {
                widgetType = "drag_float",
                id = "thw_position_blend_speed",
                label = "Position Blend Speed",
                speed = 0.1,
                range = { 0.1, 50.0 },
                initialValue = 1.0,
            },
            {
                widgetType = "drag_float",
                id = "thw_left_stability",
                label = "Left Stability (keep ~0; >0 drifts gun from right hand)",
                speed = 0.05,
                range = { 0.0, 1.0 },
                initialValue = 0.0,
            },
            {
                widgetType = "drag_float",
                id = "thw_roll_strength",
                label = "Roll Strength",
                speed = 0.05,
                range = { 0.0, 1.0 },
                initialValue = 1.0,
            },
            {
                widgetType = "checkbox",
                id = "thw_apply_180y_fix",
                label = "Apply 180 Yaw Fix",
                initialValue = false,
            },
            {
                widgetType = "drag_float",
                id = "thw_baseline_ref_cm",
                label = "Baseline Ref (cm) - pitch reference distance",
                speed = 0.5,
                range = { 5.0, 100.0 },
                initialValue = 35.0,
            },
            {
                widgetType = "drag_float",
                id = "thw_baseline_scale_min",
                label = "Baseline Scale Min - pitch floor",
                speed = 0.01,
                range = { 0.0, 1.0 },
                initialValue = 0.25,
            },
        { widgetType = "tree_pop" },
        { widgetType = "tree_node", id = "thw_labels_tree", initialOpen = true, label = "Support Label Whitelist" },
            {
                widgetType = "text",
                label = "Holder,foregrip only. Exclude performance pump/bolt.",
                wrapped = true,
                width = 350,
            },
            {
                widgetType = "input_text",
                id = "thw_support_labels",
                label = "Labels",
                initialValue = "Holder,foregrip",
                width = 300,
            },
        { widgetType = "tree_pop" },
    }
end

local function init_config_panel()
    configui.createConfigPanel("SH2 Weapon", "sh2_weapon", build_config_widgets())
end

local function refresh_config()
    local v
    v = configui.getValue("thw_rotation_blend_speed")
    if v ~= nil then weaponTools.CONFIG.rotation_blend_speed = tonumber(v) or 8.0 end
    v = configui.getValue("thw_position_blend_speed")
    if v ~= nil then weaponTools.CONFIG.position_blend_speed = tonumber(v) or 1.0 end
    v = configui.getValue("thw_left_stability")
    if v ~= nil then weaponTools.CONFIG.left_stability = tonumber(v) or 0.0 end
    v = configui.getValue("thw_roll_strength")
    if v ~= nil then weaponTools.CONFIG.roll_strength = tonumber(v) or 1.0 end
    v = configui.getValue("thw_apply_180y_fix")
    if v ~= nil then weaponTools.CONFIG.apply_180y_fix = (v == true) end
    v = configui.getValue("thw_baseline_ref_cm")
    if v ~= nil then weaponTools.CONFIG.baseline_ref_cm = tonumber(v) or 35.0 end
    v = configui.getValue("thw_baseline_scale_min")
    if v ~= nil then weaponTools.CONFIG.baseline_scale_min = tonumber(v) or 0.25 end
    v = configui.getValue("thw_support_labels")
    if v ~= nil and v ~= state.last_labels_text then
        state.last_labels_text = v
        config.support_labels = parse_labels(v)
        rebuild_support_lookup()
    end
end

-- ===== 主开关：Scripts 面板 checkbox + JSON 持久化 =====
-- 数据流：磁盘 JSON ↔ two_hand_config ↔ config.enabled ↔ UI 勾选
-- 关闭时整个文件跳过，不做双手控枪（on_pre_tick / on_inactive_frame 早退）

local two_hand_config_relative_path = "weapon_two_hand_config.json"
local two_hand_config_path = two_hand_config_relative_path
local two_hand_json = nil
local two_hand_config = nil

local function get_two_hand_json()
    if two_hand_json ~= nil then
        return two_hand_json
    end
    local ok, json = pcall(require, "json")
    if ok and json then
        two_hand_json = json
    end
    return two_hand_json
end

local function safe_io_open(path, mode)
    if type(io) ~= "table" or type(io.open) ~= "function" then
        return nil, "io.open unavailable"
    end
    local ok, file_or_err = pcall(io.open, path, mode)
    if not ok then
        return nil, tostring(file_or_err)
    end
    return file_or_err, nil
end

local function load_two_hand_config()
    local json = get_two_hand_json()
    if not json then return nil end

    if type(json.load_file) == "function" then
        local ok, data = pcall(json.load_file, two_hand_config_relative_path)
        if ok and type(data) == "table" then
            return data
        end
    end

    local file = safe_io_open(two_hand_config_path, "r")
    if not file then return nil end
    local content = file:read("*a")
    file:close()
    local ok2, data = pcall(json.decode, content)
    if ok2 and type(data) == "table" then return data end
    return nil
end

local function save_two_hand_config()
    local json = get_two_hand_json()
    if not json then return false end

    if type(json.dump_file) == "function" then
        local ok = pcall(json.dump_file, two_hand_config_relative_path, two_hand_config)
        if ok then return true end
    end

    if type(json.encode) ~= "function" then
        return false
    end
    local ok, encoded = pcall(json.encode, two_hand_config)
    if not ok or type(encoded) ~= "string" then
        return false
    end
    local file = safe_io_open(two_hand_config_path, "w")
    if not file then return false end
    file:write(encoded)
    file:close()
    return true
end

-- 冷启动：读盘 → 补默认 → 得到运行时开关 config.enabled
two_hand_config = load_two_hand_config()
if type(two_hand_config) ~= "table" then
    two_hand_config = {}
end
if two_hand_config.enabled == nil then
    two_hand_config.enabled = true
end
-- ~= false：只有明确 false 才关；nil/true 都算开
config.enabled = two_hand_config.enabled ~= false

local function register_scripts_panel_ui()
    if rawget(_G, "__SH2_WEAPON_TWO_HAND_SCRIPTS_UI_REGISTERED") == true then
        return
    end
    if not (uevr and uevr.sdk and uevr.sdk.callbacks and uevr.sdk.callbacks.on_draw_ui) then
        return
    end

    uevr.sdk.callbacks.on_draw_ui(function()
        local ok_ui = pcall(function()
            imgui.separator()
            imgui.text_colored("Two-Hand Weapon Control", 0xFF00FFFF)
            local changed, new_val = imgui.checkbox("Enable two-hand weapon driver", config.enabled ~= false)
            if changed then
                config.enabled = new_val and true or false
                two_hand_config.enabled = config.enabled
                save_two_hand_config()
            end
        end)
        if not ok_ui then
            -- silently ignore UI errors
        end
    end)

    _G.__SH2_WEAPON_TWO_HAND_SCRIPTS_UI_REGISTERED = true
end

register_scripts_panel_ui()

-- ===== 导出 =====

function M.init()
    rebuild_support_lookup()
    reset_solver_state()
    state.gate_ok = false
    state.gate_reason = "init"
    state.support_docked = false
    publish_globals()

    uevrUtils.registerPreLevelChangeCallback(function()
        reset_solver_state()
        state.last_weapon = nil
        state.gate_ok = false
        state.gate_reason = "level_change"
        state.support_docked = false
        publish_globals()
    end)

    -- recoil(10000) 之后、IK(0) 之前：先驱动 Mesh 并发布控制器覆写
    uevrUtils.registerPreEngineTickCallback(function(engine, delta)
        M.on_pre_tick(delta)
    end, 5000)
end

function M.init_config_ui()
    if state.config_panel_created then return end
    local ok = pcall(init_config_panel)
    if ok then state.config_panel_created = true end
end

function M.on_pre_tick(delta)
    if not state.config_panel_created then
        M.init_config_ui()
    end
    refresh_config()

    -- 主开关：Scripts 面板 checkbox 关闭时整体跳过，不做双手控枪
    if config.enabled == false then
        if solver_state.active or state.world_drive or state.support_docked then
            reset_solver_state()
            state.gate_ok = false
            state.gate_reason = "master_disabled"
            state.support_docked = false
            publish_globals()
        end
        return
    end

    local current_weapon = rawget(_G, KEYS.equipped_weapon)
    if current_weapon ~= state.last_weapon then
        reset_solver_state()
        state.last_weapon = current_weapon
    end

    local gating = evaluate_gating()
    if not gating then
        if solver_state.active or state.world_drive then
            reset_solver_state()
        end
        publish_globals()
        return
    end

    local mesh = get_weapon_mesh()
    if mesh == nil then
        reset_solver_state()
        state.gate_reason = "mesh_nil"
        publish_globals()
        return
    end
    state.mesh_ref = mesh

    local base_loc, base_rot = read_raw_mesh_pose(mesh)
    -- 未激活时用原始 Mesh 姿态作 engage 基准；已激活时 solve 只用内部状态
    if base_loc == nil or base_rot == nil then
        local rloc, rrot = read_motion_controller_pose(Handed.Right)
        base_loc = rloc
        base_rot = rrot
    end

    local ok, result = pcall(function()
        local rmc_pos, rmc_rot = read_motion_controller_pose(Handed.Right)
        local lmc_pos, lmc_rot = read_motion_controller_pose(Handed.Left)
        local solved, err = weaponTools.solve(solver_state, {
            dt = delta,
            base_location = base_loc,
            base_rotation = base_rot,
            right_ctrl_pos = rmc_pos,
            right_ctrl_rot = rmc_rot,
            left_ctrl_pos  = lmc_pos,
            left_ctrl_rot  = lmc_rot,
        })
        if solved == nil then error(tostring(err or "solve_fail"), 0) end
        return solved
    end)
    if not ok or result == nil then
        state.last_fail_reason = tostring(result)
        reset_solver_state()
        state.gate_ok = false
        state.gate_reason = "solve_error:" .. tostring(result)
        publish_globals()
        return
    end

    -- last_blended 已是清洁解；写 Mesh 前再叠绝对后坐（RE9：后坐进武器权威姿态）
    -- 底层 solve 返回的 weapon_rotation / ctrl_rotation 是四元数 {W,X,Y,Z}，
    -- 上层用 uevrUtils.rotatorFromQuat 转为 {Pitch,Yaw,Roll} 供 UE API 使用
    state.clean_weapon_loc = result.weapon_location
    state.clean_weapon_rot = quat_to_rotator_tbl(result.weapon_rotation)
    state.ctrl_override_loc = result.ctrl_location
    state.ctrl_override_rot = quat_to_rotator_tbl(result.ctrl_rotation)
    state.last_solve = result
    state.last_fail_reason = nil

    local write_loc, write_rot, recoiled = apply_recoil_to_weapon_pose(
        state.clean_weapon_loc,
        state.clean_weapon_rot
    )
    state.weapon_loc = write_loc
    state.weapon_rot = write_rot
    state.mesh_recoil_applied = recoiled == true
    _G.__sh2_two_hand_mesh_recoil_applied = state.mesh_recoil_applied

    set_world_drive_flag(true)
    if not write_mesh_world(mesh, state.weapon_loc, state.weapon_rot) then
        reset_solver_state()
        state.gate_reason = "mesh_write_fail"
        state.last_fail_reason = "mesh_write_fail"
        publish_globals()
        return
    end

    publish_globals()
end

--- IK 用：返回右手【控制器等价】覆写（UE FVector/FRotator）。切勿当作手骨世界姿态。
--- 调用方双手驱动时应只采用 rot；loc 仅供诊断，写入 IK 目标会触发旧护木跳变 bug。
function M.get_right_controller_override(hand)
    if hand ~= Handed.Right then return nil, nil end
    if state.world_drive ~= true then return nil, nil end
    if state.ctrl_override_loc == nil or state.ctrl_override_rot == nil then
        return nil, nil
    end
    -- 每帧新建 UE 对象，避免把可复用 struct 交给 IK 后被覆盖
    return v3_to_ue(state.ctrl_override_loc), rot_to_ue(state.ctrl_override_rot)
end

function M.is_world_drive_active()
    return state.world_drive == true
end

function M.is_active()
    return solver_state.active == true and state.gate_ok == true and state.world_drive == true
end

function M.get_state()
    return {
        enabled = config.enabled,
        support_docked = state.support_docked == true,
        two_hand_active = M.is_active(),
        gate_ok = state.gate_ok == true,
        gate_reason = state.gate_reason,
        blend = solver_state.blend,
        weapon_type = state.weapon_type,
        left_label = state.left_label,
        left_grip = state.left_grip == true,
        reload_blocked = state.reload_blocked == true,
        world_drive = state.world_drive == true,
        mesh_recoil_applied = state.mesh_recoil_applied == true,
        rotation_blend_speed = weaponTools.CONFIG.rotation_blend_speed,
        left_stability = weaponTools.CONFIG.left_stability,
        roll_strength = weaponTools.CONFIG.roll_strength,
        last_fail_reason = state.last_fail_reason,
        baseline_L = solver_state.baseline_L,
        baseline_pitch_scale = solver_state.baseline_pitch_scale,
        baseline_ref_cm = weaponTools.CONFIG.baseline_ref_cm,
        baseline_scale_min = weaponTools.CONFIG.baseline_scale_min,
    }
end

function M.reset()
    reset_solver_state()
    state.gate_ok = false
    state.gate_reason = "manual_reset"
    state.support_docked = false
    publish_globals()
end

--- 本帧未进入武器 Root 同步时调用：清驱动并刷新 dock/aiming 全局，避免标志残留
function M.on_inactive_frame()
    -- 主开关关闭时整体跳过
    if config.enabled == false then
        if solver_state.active or state.world_drive or state.support_docked then
            reset_solver_state()
            state.gate_ok = false
            state.gate_reason = "master_disabled"
            state.support_docked = false
            publish_globals()
        end
        return
    end
    if solver_state.active or state.world_drive then
        reset_solver_state()
    end
    evaluate_gating()
    state.gate_ok = false
    if state.gate_reason == "ok" then
        state.gate_reason = "no_weapon_root_sync"
    end
    publish_globals()
end

return M
